/* BelkaŻB – eksport rysunku zbrojenia do pliku DXF (AutoCAD R12, ASCII).
   Arkusz w milimetrach papieru: widok podłużny w skali 1:K, przekroje poprzeczne 1:Ks,
   wyciągi prętów (podłużne w skali widoku, strzemiona w skali przekrojów) i zestawienie stali. */
(function () {
'use strict';
const BZD = window.BZD = {};
// tekst DXF: znak średnicy %%c, pozostałe znaki spoza ASCII jako \U+XXXX
const enc = t => String(t).replace(/[⌀ØøΦ]/g, '%%c').replace(/°/g, '%%d').replace(/±/g, '%%p')
  .replace(/[^\x20-\x7e]/g, ch => '\\U+' + ch.codePointAt(0).toString(16).toUpperCase().padStart(4, '0'));
const LAYERS = [['BETON', 7, 'CONTINUOUS'], ['PODPORY', 8, 'CONTINUOUS'], ['OSIE', 8, 'CENTER'], ['STRZEMIONA', 1, 'CONTINUOUS'],
  ['ZBR_DOLNE', 5, 'CONTINUOUS'], ['ZBR_GORNE', 4, 'CONTINUOUS'], ['ZBR_DODATKOWE', 6, 'CONTINUOUS'], ['ZBR_BOCZNE', 3, 'CONTINUOUS'],
  ['WYMIARY', 8, 'CONTINUOUS'], ['OPISY', 7, 'CONTINUOUS'], ['TABELA', 7, 'CONTINUOUS'], ['PRZEKROJE', 7, 'CONTINUOUS']];

function writer() {
  const o = [], bb = [Infinity, Infinity, -Infinity, -Infinity];
  const n = v => { const r = Math.round(v * 1000) / 1000; return Object.is(r, -0) ? '0' : String(r); };
  const add = (...a) => { for (let i = 0; i < a.length; i += 2) o.push(String(a[i]), String(a[i + 1])); };
  const ext = (x, y) => { if (!isFinite(x) || !isFinite(y)) return; bb[0] = Math.min(bb[0], x); bb[1] = Math.min(bb[1], y); bb[2] = Math.max(bb[2], x); bb[3] = Math.max(bb[3], y); };
  const W = {
    line(x1, y1, x2, y2, L) { add(0, 'LINE', 8, L, 10, n(x1), 20, n(y1), 30, 0, 11, n(x2), 21, n(y2), 31, 0); ext(x1, y1); ext(x2, y2); },
    circle(x, y, r, L) { add(0, 'CIRCLE', 8, L, 10, n(x), 20, n(y), 30, 0, 40, n(r)); ext(x - r, y - r); ext(x + r, y + r); },
    arc(x, y, r, a0, a1, L) { add(0, 'ARC', 8, L, 10, n(x), 20, n(y), 30, 0, 40, n(r), 50, n(a0), 51, n(a1)); ext(x - r, y - r); ext(x + r, y + r); },
    // pręt w przekroju – wypełnione koło (polilinia o szerokości r z dwóch łuków)
    dot(x, y, r, L) { const w = r; add(0, 'POLYLINE', 8, L, 66, 1, 10, 0, 20, 0, 30, 0, 70, 1, 40, n(w), 41, n(w));
      add(0, 'VERTEX', 8, L, 10, n(x - r / 2), 20, n(y), 30, 0, 42, 1); add(0, 'VERTEX', 8, L, 10, n(x + r / 2), 20, n(y), 30, 0, 42, 1); add(0, 'SEQEND', 8, L); ext(x - r, y - r); ext(x + r, y + r); },
    text(x, y, h, t, L, al, rot) {
      const s = enc(t), j = al === 'c' ? 1 : al === 'r' ? 2 : 0;
      add(0, 'TEXT', 8, L, 10, n(x), 20, n(y), 30, 0, 40, n(h), 1, s);
      if (rot) add(50, n(rot));
      if (j) add(72, j, 11, n(x), 21, n(y), 31, 0);
      const w = String(t).length * h * 0.6;
      if (rot) { ext(x - h, y); ext(x, y + w); } else { const x0 = j === 1 ? x - w / 2 : j === 2 ? x - w : x; ext(x0, y); ext(x0 + w, y + h); }
    },
    pline(pts, L, closed) { for (let i = 0; i < pts.length - 1; i++) W.line(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], L); if (closed && pts.length > 2) W.line(pts[pts.length - 1][0], pts[pts.length - 1][1], pts[0][0], pts[0][1], L); },
    rrect(x0, y0, x1, y1, r, L) {
      r = Math.max(0, Math.min(r, (x1 - x0) / 2, (y1 - y0) / 2));
      W.line(x0 + r, y0, x1 - r, y0, L); W.line(x1, y0 + r, x1, y1 - r, L); W.line(x1 - r, y1, x0 + r, y1, L); W.line(x0, y1 - r, x0, y0 + r, L);
      if (r > 0) { W.arc(x1 - r, y0 + r, r, 270, 360, L); W.arc(x1 - r, y1 - r, r, 0, 90, L); W.arc(x0 + r, y1 - r, r, 90, 180, L); W.arc(x0 + r, y0 + r, r, 180, 270, L); }
    },
    dimH(x1, x2, y, label, h) { h = h || 2; const L = 'WYMIARY'; W.line(x1, y, x2, y, L); [x1, x2].forEach(x => { W.line(x, y - 1.2, x, y + 1.2, L); W.line(x - 0.7, y - 0.7, x + 0.7, y + 0.7, L); }); if (label) W.text((x1 + x2) / 2, y + 0.8, h, label, 'WYMIARY', 'c'); },
    dimV(x, y1, y2, label, h) { h = h || 2; const L = 'WYMIARY'; W.line(x, y1, x, y2, L); [y1, y2].forEach(y => { W.line(x - 1.2, y, x + 1.2, y, L); W.line(x - 0.7, y - 0.7, x + 0.7, y + 0.7, L); }); if (label) W.text(x - 0.8, (y1 + y2) / 2, h, label, 'WYMIARY', 'c', 90); },
    bbox: () => bb.slice(),
    out: () => o,
  };
  return W;
}

BZD.build = function (R, S) {
  const E = window.EC2, U = window.BZ, fmt = (v, dp) => U.fmt(v, dp).replace(/[\s\u00a0\u202f\u2009]/g, '');
  const md = R.md, cv = R.cov, c = cv.cs, cb = cv.cb, ct = cv.ct;
  const sc = E.steelSchedule(R), rows = sc.rows, xL = sc.xL, xR = sc.xR;
  const zones = R.stirZones || E.stirrupZones(R);
  const hmax = Math.max(...md.segs.map(sg => sg.g.h));
  const bmax = Math.max(...md.segs.map(sg => sg.g.beff));
  const K = [20, 25, 50, 75, 100, 150, 200].find(k => (xR - xL) / k <= 1100) || 250;
  const Ks = hmax <= 800 && bmax <= 1000 ? 10 : (hmax <= 1600 && bmax <= 2000 ? 20 : 25);
  const D = writer();
  const ox = 30;
  const ex = x => ox + (x - xL) / K, ey = y => -y / K;
  const hAt = (x, sup) => { if (sup) { const p = md.sups.find(q => Math.abs(q.x - x) < 1); if (p) return Math.max(...[p.segL, p.segR].filter(i => i !== null).map(i => md.segs[i].g.h)); } const sg = md.segs.find(q => x >= q.x0 - 1e-6 && x <= q.x1 + 1e-6) || md.segs[x < 0 ? 0 : md.segs.length - 1]; return sg.g.h; };
  const layerOf = r => r.side === 'bot' ? 'ZBR_DOLNE' : r.side === 'mid' ? 'ZBR_BOCZNE' : r.sup !== undefined ? 'ZBR_DODATKOWE' : 'ZBR_GORNE';
  const f2 = v => fmt(v / 1000, 2);

  // ================= WIDOK PODŁUŻNY
  const hasFix = md.sups.some(p => p.type === 'fix');
  // podpory, osie
  md.sups.forEach(p => {
    const x0 = ex(p.x - p.t / 2), x1 = ex(p.x + p.t / 2), hp = hAt(p.x, true);
    if (p.type === 'fix') { D.pline([[x0, 0], [x0, 10], [x1, 10], [x1, 0]], 'PODPORY'); D.pline([[x0, ey(hp)], [x0, ey(hmax) - 14], [x1, ey(hmax) - 14], [x1, ey(hp)]], 'PODPORY'); }
    else D.pline([[x0, ey(hp)], [x0, ey(hmax) - 8], [x1, ey(hmax) - 8], [x1, ey(hp)]], 'PODPORY');
    D.line(ex(p.x), (hasFix ? 12 : 4), ex(p.x), ey(hmax) - (p.type === 'fix' ? 17 : 11), 'OSIE');
    D.text(ex(p.x), ey(hmax) - (p.type === 'fix' ? 21 : 15), 3, p.label, 'OPISY', 'c');
  });
  // obrys belki
  { const xs = [xL]; md.segs.forEach((sg, i) => { if (i < md.segs.length - 1) xs.push(E.segEdge(md, i)); }); xs.push(xR);
    const pts = [[ex(xL), 0], [ex(xR), 0]];
    for (let i = md.segs.length - 1; i >= 0; i--) { pts.push([ex(xs[i + 1]), ey(md.segs[i].g.h)]); pts.push([ex(xs[i]), ey(md.segs[i].g.h)]); }
    const P = pts.filter((q, i) => i === 0 || Math.abs(q[0] - pts[i - 1][0]) > 1e-9 || Math.abs(q[1] - pts[i - 1][1]) > 1e-9);
    D.pline(P, 'BETON', true); }
  // przeguby
  (md.hinges || []).forEach(xh => { D.circle(ex(xh), ey(hAt(xh) / 2), 1.2, 'OPISY'); D.text(ex(xh) + 1.8, ey(hAt(xh) / 2) - 0.8, 2, 'przegub', 'OPISY'); });
  // strzemiona
  zones.forEach(z => { const hz = z.seg.g.h; z.xs.forEach(xx => D.line(ex(xx), ey(ct), ex(xx), ey(hz - cb), 'STRZEMIONA')); });
  // pręty podłużne z odgięciami (łuki w osi pręta: r = φm/2 + ⌀/2)
  const yOf = r => { let y = ey(r.y); if (r.side === 'bot' && r.cut) y += 0.5; if (r.side === 'top' && r.sup !== undefined) y -= 0.5; if (r.npc > 1 && r.piece % 2) y += r.side === 'bot' ? 0.35 : -0.35; return y; };
  const barDXF = (r, xa, xb, yb, k, L, legPx) => {
    const lgL = r.legL ? (legPx ? legPx(r.legL) : r.legL / k) : 0, lgR = r.legR ? (legPx ? legPx(r.legR) : r.legR / k) : 0;
    const rcL = r.legL ? Math.min(((r.rL || 0) + r.d / 2) / k, lgL * 0.9) : 0, rcR = r.legR ? Math.min(((r.rR || 0) + r.d / 2) / k, lgR * 0.9) : 0;
    const uL = r.dirL === 'up' ? 1 : -1, uR = r.dirR === 'up' ? 1 : -1;
    let a = xa, b = xb;
    if (r.legL) { D.line(xa, yb + uL * lgL, xa, yb + uL * rcL, L); if (rcL > 0) D.arc(xa + rcL, yb + uL * rcL, rcL, uL > 0 ? 180 : 90, uL > 0 ? 270 : 180, L); a = xa + rcL; }
    if (r.legR) { D.line(xb, yb + uR * lgR, xb, yb + uR * rcR, L); if (rcR > 0) D.arc(xb - rcR, yb + uR * rcR, rcR, uR > 0 ? 270 : 0, uR > 0 ? 360 : 90, L); b = xb - rcR; }
    D.line(a, yb, b, yb, L);
    return { lgL, lgR, uL, uR };
  };
  const bends = {};
  rows.filter(r => ['bot', 'top', 'mid'].includes(r.side)).forEach(r => {
    const L = layerOf(r), y = yOf(r), xa = ex(r.x0), xb = ex(r.x1);
    const g = barDXF(r, xa, xb, y, K, L);
    [['L', r.legL, r.rL, xa, g.uL], ['R', r.legR, r.rR, xb, g.uR]].forEach(([sd, lg, rr, xx, u]) => {
      if (!lg || !rr) return; const key = sd + r.side + Math.round(xx * 10); if (bends[key]) return; bends[key] = 1;
      D.text(xx + (sd === 'L' ? 1.5 : -1.5), y + (u > 0 ? 1.2 : -2.6), 1.8, `φm = ${fmt(2 * rr, 0)} (${fmt(2 * rr / r.d, 0)}⌀)`, 'OPISY', sd === 'L' ? 'l' : 'r');
    });
  });
  // odnośniki pozycji
  const labs = [];
  const grp = {};
  rows.forEach(r => { if (!['bot', 'top', 'mid'].includes(r.side)) return; const key = (r.side === 'bot' ? 'b' + r.seg : r.sup !== undefined ? 'x' + r.sup : r.side) + (r.npc > 1 ? 'p' + r.piece : ''); (grp[key] = grp[key] || []).push(r); });
  Object.values(grp).forEach(rs => rs.forEach((r, i) => { const a = Math.max(r.x0, xL), b = Math.min(r.x1, xR); labs.push({ r, x: a + (b - a) * (i + 1) / (rs.length + 1), up: r.side === 'top', txt: `${r.n}⌀${r.d}  l = ${fmt(r.len, 0)}` }); }));
  rows.filter(r => r.side === 'stir' || r.side === 'stir2').forEach(r => {
    const zs = zones.filter(z => (r.segs || []).includes(z.seg.idx)); const z0 = (zs.length ? zs : zones)[0]; if (!z0) return;
    const xt = z0.a + (z0.b - z0.a) * (r.side === 'stir2' ? 0.35 : 0.65), xs0 = z0.xs.reduce((p, q) => (Math.abs(q - xt) < Math.abs(p - xt) ? q : p), z0.xs[0]);
    labs.push({ r, x: xs0, up: false, zh: z0.seg.g.h, txt: `${r.n} szt. ⌀${r.d}${r.side === 'stir2' ? (r.shape && r.shape.type === 'pin' ? ' szpilki' : ' wewn.') : `, ${r.set ? r.set.legs : S.stir.legs}-cięte`}` });
  });
  const th = 2.5, lanes = { up: [], dn: [] };
  labs.forEach(l => { const w = 6 + l.txt.length * th * 0.62; l.bx = ex(l.x) - 2.2; const LN = lanes[l.up ? 'up' : 'dn']; let k = 0; while (LN[k] && LN[k].some(([u, v]) => l.bx < v + 3 && l.bx + w > u - 3)) k++; (LN[k] = LN[k] || []).push([l.bx, l.bx + w]); l.lane = k; });
  const yUp0 = (hasFix ? 16 : 8), yDn0 = ey(hmax) - (hasFix ? 28 : 22);
  labs.forEach(l => {
    const r = l.r, ly = l.up ? yUp0 + l.lane * 6 : yDn0 - l.lane * 6, cx = l.bx + 2.2;
    const ya = r.side === 'stir' || r.side === 'stir2' ? ey((l.zh || hmax) - cb) + (r.side === 'stir2' ? 2 : 0) : yOf(r);
    D.line(ex(l.x), ya, cx, ly + (l.up ? -2.2 : 2.2), 'OPISY');
    D.circle(cx, ly, 2.2, 'OPISY'); D.text(cx, ly - 0.9, 1.8, String(r.pos), 'OPISY', 'c'); D.text(cx + 3.4, ly - 1, th, l.txt, 'OPISY');
  });
  const yTop = yUp0 + lanes.up.length * 6 + 6;
  // oznaczenia przekrojów
  (R.secs || []).forEach((q, i) => { const xx = ex(q.x), hq = hAt(q.x); [[2, 6], [ey(hq) - 2, ey(hq) - 6]].forEach(([a, b]) => D.line(xx, a, xx, b, 'PRZEKROJE')); D.text(xx + 0.8, 4.2, 2.5, String(i + 1), 'PRZEKROJE'); D.text(xx + 0.8, ey(hq) - 6, 2.5, String(i + 1), 'PRZEKROJE'); });
  // wymiary pod belką
  let yd = yDn0 - Math.max(1, lanes.dn.length) * 6 - 6;
  zones.forEach(z => {
    const parts = (z.parts || []).map(q => [q.x0, q.x1, q.s, q.n]);
    parts.forEach(([u, v, ss, nn]) => { const w = (v - u) / K, lab = `${nn}×${fmt(ss, Math.abs(ss - Math.round(ss)) < 1e-6 ? 0 : 1)} = ${fmt(v - u, 0)}`; D.dimH(ex(u), ex(v), yd, w > lab.length * 1.25 ? lab : (w > 12 ? `${nn}×${fmt(ss, 0)}` : '')); });
  });
  yd -= 7;
  md.sups.forEach(p => D.dimH(ex(p.x - p.t / 2), ex(p.x + p.t / 2), yd, p.t / K > 8 ? fmt(p.t, 0) : ''));
  md.segs.forEach(sg => { const a = sg.supL ? sg.x0 + sg.supL.t / 2 : sg.x0, b = sg.supR ? sg.x1 - sg.supR.t / 2 : sg.x1; if (b - a > 1) D.dimH(ex(a), ex(b), yd, fmt(b - a, 0)); });
  yd -= 7;
  md.segs.forEach(sg => D.dimH(ex(sg.x0), ex(sg.x1), yd, `${sg.kind === 'span' ? 'L' : 'l'} = ${fmt(sg.L, 0)}`));
  yd -= 7;
  D.dimH(ex(xL), ex(xR), yd, `${fmt(xR - xL, 0)}`);
  (sc.laps || []).forEach(l => D.dimH(ex(l.a), ex(l.b), l.side === 'top' ? yTop - 3 : yd - 7, `zakład l0 = ${fmt(l.l0, 0)}`));
  md.sups.filter(p => !p.end && p.segL !== null && p.segR !== null).forEach(p => {
    const rl = rows.find(r => r.side === 'bot' && r.seg === p.segL && !r.cut && (r.npc ? r.piece === r.npc - 1 : true)), rr = rows.find(r => r.side === 'bot' && r.seg === p.segR && !r.cut && (r.piece || 0) === 0);
    const stp = (sc.steps || []).find(q => (q.R && q.R.sup === p) || (q.L && q.L.sup === p));
    if (stp && rl && rr) { const shal = stp.R && stp.R.sup === p ? rr : rl; if (shal === rr) D.dimH(ex(rr.x0), ex(p.x), yd - 7, `${fmt(p.x - rr.x0, 0)} za oś (uskok)`); else D.dimH(ex(p.x), ex(rl.x1), yd - 7, `${fmt(rl.x1 - p.x, 0)} za oś (uskok)`); }
    else if (rl && rr && rl.x1 > rr.x0 + 1) D.dimH(ex(rr.x0), ex(rl.x1), yd - 7, `zakład ${fmt(rl.x1 - rr.x0, 0)}`);
  });
  // tytuł
  D.text(ox, yTop + 6, 3.5, `WIDOK PODŁUŻNY – ZBROJENIE BELKI ${S.meta.name || ''}   skala 1:${K}`, 'OPISY');
  D.text(ox, yTop + 1.5, 2, `Beton ${S.mat.concrete}, stal ${S.mat.steel}; otulina do strzemion: dół ${cb}, góra ${ct}, boki ${c} mm. Wymiary w mm.`, 'OPISY');

  // ================= PRZEKROJE POPRZECZNE
  let y0 = yd - 26, cx0 = ox, rowH = 0;
  const maxW = Math.max(600, (xR - xL) / K + 20);
  (R.secs || []).forEach((q, i) => {
    const g = q.g || R.g, k = Ks, Bw = g.beff / k, Hh = g.h / k, w = Bw + 46;
    if (cx0 + w > ox + maxW && cx0 > ox) { cx0 = ox; y0 -= rowH + 22; rowH = 0; }
    const X = x => cx0 + 18 + x / k, Y = y => y0 - y / k;
    const xw0 = (g.beff - g.bw) / 2, xw1 = xw0 + g.bw;
    const pts = g.T ? [[0, 0], [g.beff, 0], [g.beff, g.hf], [xw1, g.hf], [xw1, g.h], [xw0, g.h], [xw0, g.hf], [0, g.hf]] : [[0, 0], [g.beff, 0], [g.beff, g.h], [0, g.h]];
    D.pline(pts.map(([a, b]) => [X(a), Y(b)]), 'BETON', true);
    // strzemiona
    let set; try { const hq = U.holdOfSec ? U.holdOfSec(q) : null, sq = U.stirOfSec ? U.stirOfSec(q) : (q.stir || S.stir); set = E.stirSet(sq, g, cv, hq && hq.xs && hq.xs.length === Math.max(2, Math.round(sq.legs)) ? hq.xs : null); } catch (e) { set = null; }
    if (set) {
      const d = set.d, rc = set.r + d / 2, a0 = xw0 + cv.cs + d / 2, a1 = xw1 - cv.cs - d / 2, b0 = cv.ct + d / 2, b1 = g.h - cv.cb - d / 2, eh = Math.min(set.ext, (b1 - b0) * 0.35) * 0.7071;
      const legX = j => set.xs ? set.xs[j] : a0 + (a1 - a0) * j / (set.legs - 1);
      const hook = xa => { if (set.hookA === 90) { D.line(X(xa) + rc / k, Y(b0) - 0.35, X(xa) + rc / k + eh * 1.4 / k, Y(b0) - 0.35, 'STRZEMIONA'); D.line(X(xa) + 0.35, Y(b0) - rc / k, X(xa) + 0.35, Y(b0) - rc / k - eh * 1.4 / k, 'STRZEMIONA'); return; } const hx = X(xa) + rc / k * 0.3, hy = Y(b0) - rc / k * 0.3; D.line(hx, hy, hx + eh / k, hy - eh / k, 'STRZEMIONA'); D.line(hx + 0.35, hy + 0.1, hx + 0.35 + eh / k, hy + 0.1 - eh / k, 'STRZEMIONA'); };
      set.pieces.forEach(pc => {
        if (pc.type === 'closed' || pc.type === 'tors') { D.rrect(X(a0), Y(b1), X(a1), Y(b0), rc / k, 'STRZEMIONA'); if (pc.type === 'closed') hook(a0); else D.line(X(a0 + rc), Y(b0) - d / k, X(a0 + rc + Math.min(pc.lap || 0, (a1 - a0) * 0.8)), Y(b0) - d / k, 'STRZEMIONA'); }
        else if (pc.type === 'inner') { const u = legX(pc.k), v = legX(set.legs - 1 - pc.k); D.rrect(X(u), Y(b1), X(v), Y(b0), rc / k, 'STRZEMIONA'); hook(u); }
        else if (pc.type === 'open') { D.line(X(a0), Y(b0), X(a0), Y(b1 - rc), 'STRZEMIONA'); D.arc(X(a0 + rc), Y(b1 - rc), rc / k, 180, 270, 'STRZEMIONA'); D.line(X(a0 + rc), Y(b1), X(a1 - rc), Y(b1), 'STRZEMIONA'); D.arc(X(a1 - rc), Y(b1 - rc), rc / k, 270, 360, 'STRZEMIONA'); D.line(X(a1), Y(b1 - rc), X(a1), Y(b0), 'STRZEMIONA'); }
        else if (pc.type === 'pin') { const list = []; if (set.kind === 'pins') for (let j = 1; j < set.legs - 1; j++) list.push(legX(j)); else list.push((a0 + a1) / 2); list.forEach(xx => { D.line(X(xx), Y(b0), X(xx), Y(b1), 'STRZEMIONA'); D.line(X(xx), Y(b0), X(xx) + eh / k, Y(b0) - eh / k, 'STRZEMIONA'); D.line(X(xx), Y(b1), X(xx) - eh / k, Y(b1) + eh / k, 'STRZEMIONA'); }); }
      });
    }
    // pręty
    (q.bars || []).forEach(bq => {
      const L = bq.side === 'bot' ? 'ZBR_DOLNE' : bq.side === 'mid' ? 'ZBR_BOCZNE' : bq.tag === 'z' ? 'ZBR_DODATKOWE' : 'ZBR_GORNE';
      const rr = (bq.dBar || bq.d) / 2 / k;
      if (bq.nb > 1) { const r0 = bq.dBar / 2, kk = bq.nb; const off = bq.shape === 'h' ? Array.from({ length: kk }, (_, j) => [(2 * j - (kk - 1)) * r0, 0]) : bq.shape === 't' ? [[-r0, r0 * 0.58], [r0, r0 * 0.58], [0, -r0 * 1.15]] : Array.from({ length: kk }, (_, j) => [0, (2 * j - (kk - 1)) * r0]); off.forEach(([dx, dy]) => D.dot(X(bq.x + dx), Y(bq.y + (bq.side === 'bot' ? dy : -dy)), rr, L)); }
      else if (bq.cut) D.circle(X(bq.x), Y(bq.y), rr, L);
      else D.dot(X(bq.x), Y(bq.y), rr, L);
    });
    // wymiary i opisy
    D.dimH(X(0), X(g.beff), Y(0) + 4, fmt(g.beff, 0));
    if (g.T) D.dimH(X(xw0), X(xw1), Y(g.h) - 5, fmt(g.bw, 0));
    D.dimV(X(0) - 5, Y(g.h), Y(0), fmt(g.h, 0));
    const isS = q.kind === 'span', dTxt = isS ? q.tens.desc : (q.comp ? q.comp.desc : ''), tTxt = isS ? (q.comp ? q.comp.desc : '') : q.tens.desc;
    D.text(X(g.beff) + 3, Y(g.h) + 1, 2, `dół: ${dTxt}`, 'OPISY');
    D.text(X(g.beff) + 3, Y(0) - 3, 2, `góra: ${tTxt}`, 'OPISY');
    const qs = U.stirOfSec ? U.stirOfSec(q) : S.stir;
    D.text(X(g.beff) + 3, Y(g.h / 2), 2, `strz. ⌀${qs.d} ${qs.legs}-cięte`, 'OPISY');
    D.text(X(0), Y(g.h) - (g.T ? 11 : 6), 1.8, `c: dół ${cv.cb}, góra ${cv.ct}, boki ${cv.cs}`, 'OPISY');
    D.text(cx0, y0 + 9, 3, `PRZEKRÓJ ${i + 1}-${i + 1}`, 'OPISY');
    D.text(cx0, y0 + 5.5, 2, `${q.loc}, x = ${f2(q.x)} m, skala 1:${k}`, 'OPISY');
    cx0 += w + 30 + 24; rowH = Math.max(rowH, Hh + 22);
  });
  y0 -= rowH + 18;

  // ================= WYCIĄGI PRĘTÓW
  D.text(ox, y0, 3.5, `WYCIĄGI PRĘTÓW (pręty podłużne 1:${K}, strzemiona 1:${Ks}; wymiary osiowe w mm)`, 'OPISY');
  y0 -= 10;
  rows.filter(r => ['bot', 'top', 'mid'].includes(r.side)).forEach(r => {
    const L = layerOf(r), xa = ox + 48, xb = xa + (r.x1 - r.x0) / K;
    const legPx = v => Math.max(4, v / K);
    const up = (r.legL && r.dirL === 'up') || (r.legR && r.dirR === 'up'), dn = (r.legL && r.dirL !== 'up') || (r.legR && r.dirR !== 'up');
    const hl = Math.max(r.legL ? legPx(r.legL) : 0, r.legR ? legPx(r.legR) : 0);
    const yb = y0 - (up ? hl : 0) - 3;
    const gg = barDXF(r, xa, xb, yb, K, L, legPx);
    D.circle(ox + 3, yb, 2.2, 'OPISY'); D.text(ox + 3, yb - 0.9, 1.8, String(r.pos), 'OPISY', 'c');
    D.text(ox + 7, yb - 1, 2.5, `${r.n}⌀${r.d}`, 'OPISY');
    D.text((xa + xb) / 2, yb + 0.8, 2, fmt(r.x1 - r.x0, 0), 'WYMIARY', 'c');
    if (r.legL) { D.text(xa - 1, yb + gg.uL * gg.lgL / 2, 2, String(r.legL), 'WYMIARY', 'r'); if (r.rL) D.text(xa + 2, yb + (gg.uL > 0 ? 2 : -3.5), 1.8, `φm = ${fmt(2 * r.rL, 0)}`, 'OPISY'); }
    if (r.legR) { D.text(xb + 1, yb + gg.uR * gg.lgR / 2, 2, String(r.legR), 'WYMIARY'); if (r.rR) D.text(xb - 2, yb + (gg.uR > 0 ? 2 : -3.5), 1.8, `φm = ${fmt(2 * r.rR, 0)}`, 'OPISY', 'r'); }
    D.text(xb + 12, yb - 1, 2.5, `l = ${fmt(r.len, 0)}`, 'OPISY');
    y0 = yb - (dn ? hl : 0) - 9;
  });
  // strzemiona (skala przekrojów)
  let sx0 = ox, sRowH = 0;
  y0 -= 4;
  rows.filter(r => r.side === 'stir' || r.side === 'stir2').forEach(r => {
    const sh = r.shape || { type: 'closed', B: 200, H: 400 }, set = r.set || { d: r.d, r: 2 * r.d, ext: Math.max(10 * r.d, 70), phm: 4 * r.d };
    const k = Ks, Bp = (sh.type === 'pin' ? 0 : sh.B) / k, Hp = sh.H / k, rc = (set.r + r.d / 2) / k, eh = set.ext * 0.7071 / k, w = Math.max(Bp, 10) + 50;
    if (sx0 + w > ox + maxW && sx0 > ox) { sx0 = ox; y0 -= sRowH + 16; sRowH = 0; }
    const ax = sx0 + 12, top = y0 - 6, bot = top - Hp + (sh.type === 'pin' ? 0 : 0);
    D.circle(sx0 + 3, y0 + 1, 2.2, 'OPISY'); D.text(sx0 + 3, y0 + 0.1, 1.8, String(r.pos), 'OPISY', 'c');
    D.text(sx0 + 7, y0, 2.5, `${r.n} szt. ⌀${r.d}  l = ${fmt(r.len, 0)}`, 'OPISY');
    // wymiary zewnętrzne B, H → oś pręta
    const i0 = r.d / 2 / k;
    if (sh.type === 'pin') { const xx = ax + 4, e9 = set.ext / k; D.line(xx, top, xx, bot, 'STRZEMIONA'); if (set.hookA === 90) { D.line(xx, top, xx + e9, top, 'STRZEMIONA'); D.line(xx, bot, xx - e9, bot, 'STRZEMIONA'); } else { D.line(xx, top, xx + eh, top - eh, 'STRZEMIONA'); D.line(xx, bot, xx - eh, bot + eh, 'STRZEMIONA'); } D.dimV(xx - 6, bot, top, fmt(sh.H, 0)); D.text(xx + eh + 1, top - eh - 1, 1.8, `hak ${set.hookA || 135}° ${fmt(set.ext, 0)}`, 'OPISY'); }
    else if (sh.type === 'open') { const a = ax + i0, b = ax + Bp - i0, t = top - i0, u = bot + i0; D.line(a, t, a, u + rc, 'STRZEMIONA'); D.arc(a + rc, u + rc, rc, 180, 270, 'STRZEMIONA'); D.line(a + rc, u, b - rc, u, 'STRZEMIONA'); D.arc(b - rc, u + rc, rc, 270, 360, 'STRZEMIONA'); D.line(b, u + rc, b, t, 'STRZEMIONA'); if (set.hookA === 90) { D.line(a, t, a + set.ext / k, t, 'STRZEMIONA'); D.line(b, t, b - set.ext / k, t, 'STRZEMIONA'); } else { D.line(a, t, a + eh, t - eh * 0.5, 'STRZEMIONA'); D.line(b, t, b - eh, t - eh * 0.5, 'STRZEMIONA'); } D.dimH(ax, ax + Bp, bot - 4, fmt(sh.B, 0)); D.dimV(ax - 4, bot, top, fmt(sh.H, 0)); }
    else { const a = ax + i0, b = ax + Bp - i0, t = top - i0, u = bot + i0; D.rrect(a, u, b, t, rc, 'STRZEMIONA'); if (sh.type === 'tors') D.line(a + rc, t - r.d / k, a + rc + Math.min((sh.lap || 300) / k, b - a - 2 * rc), t - r.d / k, 'STRZEMIONA'); else if (set.hookA === 90) { const e9 = set.ext / k; D.line(a + rc, t - r.d / k, a + rc + e9, t - r.d / k, 'STRZEMIONA'); D.line(a + r.d / k, t - rc, a + r.d / k, t - rc - e9, 'STRZEMIONA'); } else { const hx = a + rc * 0.3, hy = t - rc * 0.3; D.line(hx, hy, hx + eh, hy - eh, 'STRZEMIONA'); D.line(hx + 0.4, hy + 0.1, hx + 0.4 + eh, hy + 0.1 - eh, 'STRZEMIONA'); }
      D.dimH(ax, ax + Bp, bot - 4, fmt(sh.B, 0)); D.dimV(ax - 4, bot, top, fmt(sh.H, 0)); if (sh.type === 'tors') D.text(ax + 1, top - 3.5, 1.8, `zakład ${fmt(sh.lap, 0)}`, 'OPISY'); else D.text(ax + Bp + 2, top - 4, 1.8, `haki ${set.hookA || 135}° ${fmt(set.ext, 0)}`, 'OPISY'); }
    D.text(sx0, bot - 9, 1.8, `φm = ${fmt(set.phm, 0)} (${fmt(set.phm / r.d, 0)}⌀), r = ${fmt(set.r, 0)}`, 'OPISY');
    sx0 += w + 14; sRowH = Math.max(sRowH, Hp + 18);
  });
  y0 -= sRowH + 16;

  // ================= ZESTAWIENIE STALI
  const ds = Object.keys(sc.byD).map(Number).sort((a, b) => a - b);
  const cols = [['Poz.', 10], ['Opis', 112], ['⌀', 10], ['n [szt.]', 16], ['l [m]', 16], ['L [m]', 18], ...ds.map(d => [`⌀${d} [kg]`, 18])];
  const tw = cols.reduce((a, q) => a + q[1], 0), rh = 6;
  D.text(ox, y0, 3.5, `ZESTAWIENIE STALI ZBROJENIOWEJ – ${S.mat.steel}${S.mat.steelW !== S.mat.steel ? ` (strzemiona ${S.mat.steelW})` : ''}`, 'OPISY');
  y0 -= 4;
  const lines = [cols.map(q => q[0])];
  sc.rows.forEach(r => lines.push([String(r.pos), r.name, String(r.d), String(r.n), fmt(r.len / 1000, 2), fmt(r.tot, 2), ...ds.map(d => d === r.d ? fmt(r.mass, 1) : '')]));
  lines.push(['', 'Razem [kg] (masa 1 m: 0,00617·⌀²)', '', '', '', '', ...ds.map(d => fmt(sc.byD[d], 1))]);
  if (ds.length) lines.push(['', `Masa całkowita [kg] · beton ${fmt(sc.vol, 3)} m³ · ${fmt(sc.total / sc.vol, 0)} kg/m³`, '', '', '', '', fmt(sc.total, 1), ...ds.slice(1).map(() => '')]);
  lines.forEach((ln, i) => {
    const yy = y0 - i * rh;
    D.line(ox, yy, ox + tw, yy, 'TABELA');
    let xx = ox;
    ln.forEach((t, j) => { const cw = cols[j][1], num = j !== 1 && i > 0; D.text(num ? xx + cw - 1.2 : xx + 1.2, yy - rh + 1.6, i === 0 ? 2 : 2.2, String(t).slice(0, j === 1 ? 70 : 14), 'TABELA', num ? 'r' : 'l'); xx += cw; });
  });
  const yEnd = y0 - lines.length * rh;
  D.line(ox, yEnd, ox + tw, yEnd, 'TABELA');
  { let xx = ox; [0, ...cols.map(q => q[1])].forEach(cw => { xx += cw; D.line(xx, y0, xx, yEnd, 'TABELA'); }); }

  // ================= nagłówek, tabele, zapis
  const bb = D.bbox();
  const H = [];
  const add = (...a) => { for (let i = 0; i < a.length; i += 2) H.push(String(a[i]), String(a[i + 1])); };
  add(0, 'SECTION', 2, 'HEADER', 9, '$ACADVER', 1, 'AC1009', 9, '$DWGCODEPAGE', 3, 'ANSI_1250', 9, '$INSBASE', 10, 0, 20, 0, 30, 0,
    9, '$EXTMIN', 10, bb[0].toFixed(2), 20, bb[1].toFixed(2), 30, 0, 9, '$EXTMAX', 10, bb[2].toFixed(2), 20, bb[3].toFixed(2), 30, 0,
    9, '$LIMMIN', 10, bb[0].toFixed(2), 20, bb[1].toFixed(2), 9, '$LIMMAX', 10, bb[2].toFixed(2), 20, bb[3].toFixed(2), 9, '$LTSCALE', 40, 1, 9, '$TEXTSTYLE', 7, 'STANDARD', 9, '$INSUNITS', 70, 4, 9, '$MEASUREMENT', 70, 1, 0, 'ENDSEC');
  add(0, 'SECTION', 2, 'TABLES');
  add(0, 'TABLE', 2, 'LTYPE', 70, 3);
  add(0, 'LTYPE', 2, 'CONTINUOUS', 70, 0, 3, 'Solid line', 72, 65, 73, 0, 40, 0);
  add(0, 'LTYPE', 2, 'CENTER', 70, 0, 3, 'Center ____ _ ____', 72, 65, 73, 4, 40, 12, 49, 8, 49, -1.5, 49, 1, 49, -1.5);
  add(0, 'LTYPE', 2, 'DASHED', 70, 0, 3, 'Dashed __ __', 72, 65, 73, 2, 40, 4, 49, 2.5, 49, -1.5);
  add(0, 'ENDTAB');
  add(0, 'TABLE', 2, 'LAYER', 70, LAYERS.length + 1);
  add(0, 'LAYER', 2, '0', 70, 0, 62, 7, 6, 'CONTINUOUS');
  LAYERS.forEach(([nm, col, lt]) => add(0, 'LAYER', 2, nm, 70, 0, 62, col, 6, lt));
  add(0, 'ENDTAB');
  add(0, 'TABLE', 2, 'STYLE', 70, 1, 0, 'STYLE', 2, 'STANDARD', 70, 0, 40, 0, 41, 0.9, 50, 0, 71, 0, 42, 2.5, 3, 'arial.ttf', 4, '', 0, 'ENDTAB');
  add(0, 'ENDSEC');
  add(0, 'SECTION', 2, 'BLOCKS', 0, 'ENDSEC');
  add(0, 'SECTION', 2, 'ENTITIES');
  const body = D.out();
  const tail = ['0', 'ENDSEC', '0', 'EOF'];
  return H.concat(body, tail).join('\r\n') + '\r\n';
};
BZD.enc = enc;
})();
