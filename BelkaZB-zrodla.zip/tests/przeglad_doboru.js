const E=require(process.argv[2]||'/home/claude/belka/web/engine.js');
const cases=[];
for (const L of [3,4.5,6,7.5,9]) for (const q of [15,40,80]) for (const hr of [10,14,18]) for (const b of [250,350,500]) for (const sch of ['ss','cont2']) {
  if ((L*q*b)%7>2) continue;   // przerzedzenie
  cases.push({L,q,hr,b,sch});
}
cases.push({L:2,q:30,hr:6,b:300,sch:'cant'},{L:3,q:20,hr:7,b:300,sch:'cant'});
const tally={}; let nBad=0, n=0; const t0=Date.now();
for (const c of cases) {
  const s=E.defaultState(); const h=Math.max(250,Math.round(c.L*1000/c.hr/50)*50);
  s.geom.b=c.b; s.geom.h=h; s.geom.L=c.L; s.loads.perm=[{name:'g',q:c.q*0.6,span:0,x1:'',x2:'',pts:[]}]; s.loads.var=[{kind:'imp',name:'Q',cat:'B',dir:'y',span:0,q:c.q*0.4,x1:'',x2:'',pts:[]}];
  if (c.sch==='cont2'){ s.scheme='cont'; s.cont.spans=[c.L,c.L*0.8]; } else if (c.sch==='cant'){ s.scheme='cant'; }
  let r; try { r=E.autoReb(E.normalize(s),{eta:1,strict:true}); } catch(e){ console.log('EXC',JSON.stringify(c),e.message); continue; }
  n++; const bad=E.allBad(r.R,1); if (r.R.errors.length) { console.log('ERR',JSON.stringify(c),r.R.errors[0]); continue; }
  if (bad.length){ nBad++; const ids=[...new Set(bad.map(x=>x.id+':'+x.status))]; ids.forEach(i=>tally[i]=(tally[i]||0)+1); console.log(JSON.stringify(c),'h'+h, ids.join(' ')); }
}
console.log('cases',n,'withBad',nBad,'ms',Date.now()-t0); console.log(tally);
