# BelkaŻB 2.9.12 – obliczenia belek żelbetowych wg PN-EN 1992-1-1

Trzy postacie tej samej aplikacji (wspólny kod z katalogu `web/`):
- `BelkaZB.exe` – program dla Windows 10/11 (jeden plik, bez instalacji, WebView2),
- `app/app.html` – plik do otwarcia w dowolnej przeglądarce (offline),
- `webapp/belkazb.html` – strona publikowana w claude.ai (artefakt): układ na telefon, tryb ciemny,
  „Moje projekty” zapisywane prywatnie na koncie (capability `db` + `user`), pobieranie projektu .json
  i raportu HTML (capability `downloads`); wydruk/PDF z pobranego raportu.

## Poprawki 2.9.12

- **Raport własny – opcja w zakładce „Raport obliczeń”** (trzeci przycisk obok „Raport pełny” i „Statyka”) zamiast osobnej zakładki. Przyciski „Wstaw raport pełny” i „Wstaw statykę”; zapis HTML / .odt, druk / PDF oraz „Raport HTML” w górnym pasku działają na raporcie własnym, gdy jest wybrany. Wybór widoku zapisywany w projekcie (`meta.repMode = 'own'`).

## Poprawki 2.9.11

- **Raport własny (nowa zakładka):** edytowalny raport – kliknij w tekst i pisz, usuwaj, formatuj (pogrubienie, kursywa, podkreślenie, nagłówki H1–H3, akapit, listy, cofnij / ponów). Dopóki nic nie zmienisz, pokazuje bieżący raport obliczeń; po pierwszej zmianie staje się własną kopią zapisywaną w projekcie (`meta.own`, `meta.ownOn`), niezależną od zmian danych. „Wstaw raport obliczeń” – aktualne obliczenia w miejscu kursora (za akapitem), „Wstaw datę”, „Przywróć raport obliczeń”, „Wyczyść”; zapis HTML i .odt, druk / PDF (także Ctrl+P z tej zakładki). Treść z pliku projektu jest oczyszczana (bez skryptów i zdarzeń).
- **Raporty bez odwołań do normy:** w raporcie obliczeń (pełnym i statyki, także w HTML, .odt i druku) usunięto odwołania do punktów, tablic, rysunków i załączników normy oraz numery wzorów; zostały tylko numery wzorów kombinacji (6.10, 6.10a/b, 6.14b, 6.15b, 6.16b).
- **Zbrojenie belki – odnośniki bez nakładania:** opisy pozycji prętów i strzemion rozmieszczane w rzędach tak, aby odnośniki (linie wskazujące) nie przechodziły przez opisy innych pozycji, a opisy nie nachodziły na siebie (etykieta wskazująca bardziej na lewo – rząd wyżej).
- **Wykresy:** prawy przycisk myszy na wykresie usuwa wszystkie znaczniki postawione lewym przyciskiem.

## Poprawki 2.9.10

- **q_k obciążenia użytkowego wpisywane automatycznie** (zamiast stałych 5 kN/m): nowe obciążenie użytkowe dostaje q_k = górna granica zakresu z PN-EN 1991-1-1 × pasmo b (np. kat. B: 3,0 kN/m² × b). Pasmo b nowego obciążenia: jak w poprzednim obciążeniu użytkowym, dla belki teowej z b_eff liczonym z b₁, b₂ – b₁ + b_w + b₂, w pozostałych przypadkach 1,0 m (do wpisania rozstawu belek). Zmiana kategorii, podkategorii lub pasma przelicza q_k; ręczne wpisanie q_k wyłącza przeliczanie (powrót – „przyjmij (automatycznie)”). Zapis: `loads.var[i].qAuto`.

## Poprawki 2.9.9

- **Obciążenie użytkowe – podpowiedź wg PN-EN 1991-1-1:** przy obciążeniu użytkowym wybór podkategorii (A: stropy / schody / balkony, C1–C5, D1–D2) i pole „pasmo b” (szerokość zbierania obciążenia, rozstaw belek). Pod polami: zakres q_k i Q_k z tablicy 6.2 (E – 6.4, F, G – 6.8, H – 6.10), górna granica przeliczona na obciążenie belki (np. C3: 5,0 kN/m² × 2,50 m = 12,50 kN/m) z przyciskiem „przyjmij” oraz kontrola wpisanej wartości (q_k/b poniżej zakresu normy / górna granica / powyżej). Zapis: `loads.var[i].sub`, `loads.var[i].bw`.
- **Wykresy – znaczniki wartości po kliknięciu:** kliknięcie wykresu w zakładce *Wykresy* stawia znacznik w tym miejscu belki na wszystkich wykresach (M, V, T, N, ugięcia): kropka na każdej linii i wartość (jak przy ekstremach) oraz x na osi; kliknięcie przy znaczniku usuwa go, „usuń znaczniki” – wszystkie, kliknięcie wartości – „jak obliczono” w tym miejscu (dotąd po kliknięciu wykresu). Do 8 znaczników, zachowywane przy przełączaniu zakładek.

## Poprawki 2.9.8

- **Przyciski w *Danych*: „Dobierz przekroje”, „Dobierz zbrojenie” (nowy), „Dobierz wszystko”** (dawniej „Dobierz przekroje i zbrojenie”) i wytężenie η.
- **Jedno zbrojenie wszędzie:** wykres M w *Danych*, „Dobierz zbrojenie” (w *Danych*, w zakładce zbrojenia i w raporcie) oraz „Dobierz wszystko” korzystają z tego samego doboru (wytężenie ≤ η, wszystkie sprawdzenia z Podsumowania). Przycisk przyjmuje dokładnie zbrojenie pokazane na wykresie M; po przyjęciu wykres pokazuje przyjęte zbrojenie. Gdy samym zbrojeniem nie da się spełnić ostrzeżeń (np. pełzanie liniowe przy za małym przekroju), dobór nie przezbraja belki bez skutku – wybierany jest wariant z mniejszą liczbą niespełnionych warunków.
- **„Dobierz wszystko”** – wymiary przekrojów, zbrojenie (średnice i liczby prętów), strzemiona, klasa betonu i otulina tak, aby wszystkie sprawdzenia z Podsumowania były spełnione (bez ✖ i bez ⚠) przy wytężeniu ≤ η: klasa betonu co najmniej minimalna dla ekspozycji (zał. E), wyższa tylko gdy przy zadanej nie da się spełnić warunków; rozstawy strzemion i długości stref – automatycznie; otulina ręczna za mała – wymagana; średnice zadane – zachowane, chyba że z nimi nie da się spełnić warunków. Okno postępu z przyciskiem „Przerwij”, w komunikacie – co zmieniono. „Dobierz przekroje” także sprawdza wszystkie warunki.
- **Średnice prętów w Materiałach:** „Średnica prętów dolnych / górnych (dobór zbrojenia)” – automatycznie albo ⌀12–⌀28; liczba prętów dobierana do średnicy (wykres M, „Dobierz zbrojenie”, dobór przekrojów, „Dobierz wszystko”). Zmiana w Materiałach zastępuje średnice wybrane wcześniej na wykresie M dla tej strony belki. Zapis: `reb.dB`, `reb.dT`.
- **Przedłużenie / skrócenie każdego pręta wpisaną wartością:** kliknięcie końca pręta albo narożnika odgięcia na rysunku „Zbrojenie belki” – w oknie zakończenia pole „przedłużenie (+) / skrócenie (−) o … mm” z podglądem długości (za licem podpory, w podporze skrajnej albo od osi podpory), także dla prętów dolnych nad podporami pośrednimi. Zapis: `barEdit[klucz].dL/dR` [mm]; pręty dodatkowe nad podporą belki ciągłej – `cont.rebSupps[i].extL/extR` [m] (także ujemne). Sprawdzenia: zakotwienie w podporze skrajnej z rzeczywistą długością w podporze (w razie potrzeby odgięcie), ≥ 10⌀ za licem / zakład nad podporą pośrednią, długość prętów dodatkowych ≥ wymagana.
- **Wymiar zakotwienia klikalny:** na rysunku „Zbrojenie belki” kliknięcie wymiaru zakotwienia w podporze skrajnej, wymiaru prętów dolnych nad podporą pośrednią („za licem …”, „zakład …”) albo długości prętów dodatkowych od osi podpory otwiera okno z długością do wpisania (puste – automatycznie); wymiary pokazują rzeczywiste długości (✎ – zmienione ręcznie).
- **Redukcje dopuszczane przez normę – tylko po zaznaczeniu, z informacją:** współczynniki α₂ (otulina) i α₅ (docisk poprzeczny) < 1 w długości zakotwienia (tab. 8.2) oraz pary prętów jeden nad drugim liczone jak pręty pojedyncze (8.9.1(4)) – w grupie „Zakotwienia i zakłady”; pod polem informacja o możliwym skróceniu (np. l_bd 580 → 506 mm). Wcześniej stosowane automatycznie – w starszych projektach zakotwienia mogą się wydłużyć. Zapis: `anch.alRed`, `anch.pairSep`.

## Poprawki 2.9.7

- **Wykres M w *Danych* – opisy prętów z pełnego doboru zbrojenia.** Pręty n⌀ nad i pod wykresem to zbrojenie z automatycznego doboru spełniające wszystkie warunki (SGN, A_s,min, rysy, naprężenia, ugięcie, rozstaw 8.2, zakotwienie) – to samo, które zada „Dobierz zbrojenie”; wcześniej opisy pochodziły z samego zginania i mogły się różnić. Dobór liczony w tle (do zakończenia – „dobór zbrojenia…”); wymiary pod wykresem: rzeczywiste długości prętów dodatkowych nad podporami i prętów skróconych w przęśle, z opisem n⌀. Gdy dobór przy tych wymiarach lub wybranych średnicach nie spełnia warunków – czerwona informacja „✖ nie spełnia: …”.
- **Wybór średnicy prętów na wykresie M:** kliknięcie n⌀ (dół przęsła, góra – pręty ciągłe, pręty dodatkowe nad podporą) otwiera listę średnic (automatycznie, ⌀12–⌀28); liczba prętów jest dobierana do wybranej średnicy (pełny dobór, wszystkie warunki). Wybór obowiązuje także w „Dobierz zbrojenie” i w automatycznym doborze przekrojów; opcja „od razu zastosuj w zbrojeniu belki”. Średnice wybrane ręcznie – kolor pomarańczowy. Zapis: `reb.dSel` (`b<i>` – dół przęsła, `t` – góra ciągła, `x<i>` / `x` – nad podporą).
- **Buława wibratora domyślnie nieuwzględniana** w nowych projektach (opcja „Buława wibratora” w pasku zbrojenia – do włączenia); projekty zapisane z włączoną buławą bez zmian.
- **Obniżenie klasy konstrukcji za klasę betonu (tab. 4.3N) – tylko na życzenie.** Program nie redukuje już sam otuliny: gdy warunek jest spełniony, pod polem wyświetla informację (np. S4 → S3, c_min,dur 15 → 10 mm), a redukcję uwzględnia dopiero po zaznaczeniu pola „Obniżenie klasy konstrukcji o 1 za klasę wytrzymałości betonu”. Zapis: `env.scRed`. Uwaga: w projektach z poprzednich wersji, w których redukcja była stosowana automatycznie, otulina może wzrosnąć – zaznacz pole, aby ją zachować.

## Poprawki 2.9.6

- **Strzemiona ≤ 15⌀ tylko przy ściskającej sile osiowej N_Ed** (belka ściskana jak słup, 9.2.1.2(3)); ⌀ – najmniejsza średnica prętów podłużnych. Sama strefa ściskana przy zginaniu (bez siły N) nie wprowadza tego ograniczenia (poprawka 2.9.3).
- **Pręty w dwóch warstwach – pierwsza warstwa pełna.** Automatyczny dobór: w pierwszej warstwie największa liczba prętów, jaka się mieści (odstępy 8.2(2), z buławą – z prześwitem na buławę, także przy układzie od naroży), nadmiar w drugiej warstwie nad prętami pierwszej (np. 8⌀16 w b = 300: 6 + 2, wcześniej 4 + 4). Okno strefy zbrojenia: pręty, które się nie mieszczą, przechodzą do warstwy wyższej, a gdy w niższej jest miejsce – wracają do niej; warstwa sparowana / w styku nie ma więcej prętów niż warstwa pod nią; zmiana warstwy na „w styku” nie usuwa już prętów, tylko przenosi nadmiar. Nieparzysta liczba prętów nad nieparzystą liczbą kolumn – symetrycznie (środkowa kolumna).

## Poprawki 2.9.5

- **Oznaczenia przy wymiarach przekroju (Dane):** czerwony ✖ – przekrój za mały (nie spełnia warunków; po najechaniu – niespełnione warunki i proponowany przekrój); żółty **?** – przekrój spełnia wszystkie warunki, ale jest większy niż potrzeba (po najechaniu – objaśnienie i najmniejszy wystarczający wymiar, kliknięcie – przyjęcie razem ze sprawdzonym zbrojeniem). Propozycje mniejszej szerokości – tylko przy h/b ≤ 2,5.
- **Odwrotna strzałka w każdym przęśle osobno:** na wykresie ugięcia w *Danych* (przełącznik „ugięcie”) i w zakładce *Wykresy* – kliknięcie przęsła otwiera okno strzałki w tym przęśle (jak ogólna / bez strzałki / auto / podana w mm, opcja „we wszystkich przęsłach”); wartość w₀ opisana na wykresach. Zapis: `sls.camberSeg` (indeks odcinka).
- **Przedłużenie prętów nad podporą pośrednią – w oknie końca pręta:** na rysunku „Zbrojenie belki” kliknięcie końca pręta dodatkowego nad podporą otwiera okno zakończenia (zakotwienie, odgięcie) z osobną sekcją „Przedłużenie pręta” – przedłużenie o Δ [m] ponad długość wymaganą (podgląd: wymagana → przyjęta). Wymiar długości z przedłużeniem – „+”. Przeciąganie końca pręta usunięto. Zapis: `cont.rebSupps[i].extL/extR`.

## Poprawki 2.9.4

- **Przedłużanie prętów nad podporą pośrednią – na rysunku „Zbrojenie belki”.** Końce prętów górnych dodatkowych nad podporami pośrednimi mają uchwyty: przeciągnięcie końca zmienia długość pręta od osi podpory (co 0,05 m, podgląd długości w trakcie), kliknięcie otwiera okno długości (w lewo / w prawo, „Automatycznie” – długość wymagana) z odnośnikiem do zakończenia pręta (odgięcia). Długość przyjęta ręcznie – „*” przy wymiarze. Tabelę długości usunięto z *Danych*.
- **Wykres ugięcia na schemacie w *Danych*** (przełącznik „ugięcie”): linia ugięcia długotrwałego w(x) (quasi-stałe + skurcz, 7.4.3), w każdym przęśle f (albo f − w₀ przy odwrotnej strzałce) – na czerwono, gdy przekracza f_lim, ugięcie graniczne f_lim (linia przerywana) i kształt odwrotnej strzałki w₀.

## Poprawki 2.9.3

- **Powiększanie wszystkich rysunków: Ctrl + kółko myszy** – przekroje (także w oknach), wykresy, rysunki w raporcie i podsumowaniu; zoom względem kursora, przeciąganie – przesuw, dwuklik albo „✕” w rogu rysunku – powrót do 100%. Schemat w *Danych*, widok podłużny i widok 3D – jak dotąd (Ctrl + kółko).
- **Pręty w styku z warstwą sąsiednią** (warstwa „bezpośrednio na warstwie niższej”): prześwit poziomy w obu warstwach ≥ max(1,5·⌀; d_g + 5 mm; 30 mm) – w doborze układu, sprawdzeniu 8.2 i wymiarach prześwitów na przekroju (wcześniej ⌀n = ⌀·√2 i 20 mm wg 8.9.1/8.2(2); nowe wymaganie jest ostrzejsze, więc spełnia też Eurokod).
- **Wykres M z redukcją nad szerokimi podporami (5.3.2.2)** na schemacie w *Danych*: obwiednia zredukowana (zaokrąglenie na szerokości podpory, przy podporze monolitycznej – moment w licu), wartość opisana – zredukowana; wykres bez redukcji – linia przerywana nad podporą (wartość w osi w podpowiedzi).
- **Rozstaw strzemion ≤ 15⌀ (9.2.1.2(3))** przy belce ściskanej siłą N_Ed (od 2.9.6 – tylko przy sile ściskającej). Uwzględniane w automatycznym rozstawie strzemion, sprawdzane w podsumowaniu i opisane w raporcie.
- Objaśnienia pod wykresami w *Danych* przeniesione do podpowiedzi „ⓘ objaśnienie”.

## Poprawki 2.9.2

- **Automatyczny dobór przekrojów i zbrojenia przy zadanej klasie betonu.** Przyciski „Dobierz przekroje” i „Dobierz przekroje i zbrojenie” nie zmieniają klasy betonu (po doborze wyłączony jest też automatyczny dobór klasy). Spełniane są wszystkie warunki, w tym liniowość pełzania σ_c,qp ≤ k₂·f_ck (7.2(3)) – przy zadanej klasie przez wymiary przekroju i zbrojenie – oraz prześwit na zadaną buławę wibratora (8.2(4)). Nowy algorytm: najpierw wspólny przekrój wszystkich przęseł (wysokość rośnie skokowo do spełnienia warunków, potem połowienie przedziału; szerokość – gdy decydują warunki od niej zależne lub h/b > 2,5, do 1200 mm), a dla przęseł o różnych przekrojach – zmniejszanie wysokości każdego przęsła przy sprawdzaniu warunków całej belki; komunikat „nie znaleziono” tylko wtedy, gdy nie wystarcza nawet przekrój 1200 mm szerokości. Domyślnie klasa betonu nie jest dobierana automatycznie (opcja w *Materiałach*).
- **Mniejszy przekrój (✖) przyjmowany razem ze sprawdzonym zbrojeniem.** Propozycja jest sprawdzana doborem zbrojenia i kompletem warunków (z rozstawem prętów 8.2(2)); po kliknięciu ✖ przyjmowane są wymiary i – gdy belka ma zbrojenie – zbrojenie, z którym przekrój został sprawdzony (dotychczasowe zbrojenie w mniejszym przekroju mogło nie spełniać nośności lub rozstawu).
- **Wymiary prześwitów poza przekrojem.** Łańcuchy wymiarowe z liniami pomocniczymi: rzędy dolne pod przekrojem, górne nad nim (rząd skrajny najbliżej), odstępy pionowe warstw z lewej strony; wąskie odcinki – opisy na przemian nad i pod linią.
- **Przedłużenie prętów nad podporami pośrednimi** (od 2.9.4 – z rysunku „Zbrojenie belki”). Długość przyjęta ręcznie – „*” w widoku podłużnym.
- **Odwrotna strzałka ugięcia** (*Dane → SGU – parametry → Odwrotna strzałka ugięcia w₀*): wartość w mm albo „auto” (równa ugięciu, ≤ L/250). Wg 7.4.1(4): sprawdzane f − w₀ ≤ L/lim oraz w₀ ≤ L/250; przy ugięciu granicznym L/500 (7.4.1(5) – ugięcie po wykonaniu elementów wrażliwych) strzałka nie zmniejsza ugięcia. W raporcie – wiersz ze strzałką; na wykresie ugięć – linia w₀.

## Poprawki 2.9.1

- **Proponowane wymiary przekroju – tylko możliwe do zazbrojenia.** Propozycje przy ✔/✖ (b, h) są sprawdzane tym samym doborem zbrojenia, który wykonuje przycisk „Dobierz zbrojenie wymagane”, i kompletem warunków – także rozstawem prętów w świetle (8.2(2)), zakotwieniami, prześwitem na buławę i zbrojeniem górnym przy podporze skrajnej (wcześniej pomijane, przez co propozycja mogła się nie dać zazbroić). Usunięto nieużywany szacunek wymiarów „wg wytycznych normy”. Pętla klas betonu szuka dalej klasy bez nieliniowego pełzania, gdy znalazła już wariant spełniający warunki.
- **Rozstaw strzemion z wykresu V** (zakładka *Dane*, „V + strzemiona”): okno strefy przy podporze ma pola rozstawu s₁, s_p, s₂ (puste – automatycznie); w belce ciągłej rozstaw zapisywany dla przęsła, w pozostałych – dla całej belki; ostrzeżenie, gdy rozstaw > s_l,max lub s₁ > s₂. *Automatycznie* przywraca rozstaw i długości stref.
- **Haki strzemion wokół pręta narożnego.** Na przekroju strzemię jest owinięte wokół pręta w narożu (promień ⌀/2 + ⌀w/2), haki 135° – zakończenia styczne do pręta, skierowane do wnętrza przekroju (nie nachodzą na pręt, także grubszy); haki 90° – zakończenia wzdłuż ramion.
- **Objaśnienia pod rozwinięciem.** Wszystkie objaśnienia tekstowe (podpowiedzi w Danych, w oknach, na wykresach, uwagi w tabeli sprawdzeń) są zwinięte pod klikalnym „Objaśnienie”; widoczne pozostają komunikaty i wyniki.
- **Redukcja momentu nad szerokimi podporami (5.3.2.2) stosowana konsekwentnie.** Podpora swobodna: ΔM = F_Ed,sup·t/8 z reakcją tej kombinacji, która daje największy moment ujemny (wcześniej – najmniejsza reakcja z obwiedni, więc redukcja była zaniżona); podpora monolityczna: moment w licu ≥ 0,65·M w osi. Moment zredukowany jest teraz używany także w doborze zbrojenia nad podporami, w zbrojeniu wymaganym wzdłuż belki i w SGU przekrojów podporowych (rysy, naprężenia). Widoczny w tabeli przekroju („Redukcja nad podporą”), w raporcie (wzór ΔM lub moment w licu) i na wykresach (wartość „red.” nad podporą, obwiednia M_Ed,red na szerokości podpory).

## Poprawki 2.9.0

- **Najmniejsze możliwe średnice.** Dobór zbrojenia zaczyna od ⌀12 i przechodzi do większej średnicy dopiero, gdy pręty nie mieszczą się z odstępami w świetle max(⌀; d_g + 5; 20 mm) (8.2(2)), także w dwóch warstwach. Gdy włączona jest buława wibratora, a pręty rozłożone równomiernie nie zostawiają prześwitu, program najpierw skupia je przy narożach w odstępach normowych (prześwit pośrodku), a dopiero potem zwiększa średnicę.
- **Wymiary odstępów w przekroju.** Na przekrojach (zakładka *Przekrój i zbrojenie*) – prześwity w świetle między sąsiednimi prętami w każdym rzędzie oraz odstęp pionowy między warstwami; na czerwono, gdy mniejsze od wymaganych.
- **Usuwanie pojedynczych prętów.** Kliknięcie pręta w przekroju zaznacza go (Ctrl/Shift – kilka prętów); klawisz Delete lub przycisk „Usuń” usuwa, Esc – anuluje zaznaczenie. Pozostałe pręty zostają na swoich miejscach (warstwa przechodzi na układ ręczny).
- **Bez wiązek.** Z okna strefy zbrojenia usunięto wybór „pojedyncze / wiązki po 2 / wiązki po 3”. W projektach z wiązkami – podpowiedź i przycisk zamiany (wiązki pionowe → warstwy w styku).
- **Warstwy.** Przy kolejnej warstwie wybór: „odstęp normowy między rzędami – max(⌀; d_g + 5; 20 mm)” albo „bezpośrednio na warstwie niższej – pręty w styku”. Pary prętów w styku liczone jak wiązka: ⌀n = √(⌀₁² + ⌀₂²) (8.9.1(2)); prześwit poziomy w obu warstwach ≥ max(⌀n; d_g + 5; 20 mm).
- **Automatyczny dobór** (zakładka *Dane*, nad danymi): „Dobierz przekroje” – najmniejszy przekrój b × h (co 50 mm, h/b ≤ 2,5) i klasa betonu, przy których dobrane zbrojenie spełnia wszystkie warunki; „Dobierz przekroje i zbrojenie” – dodatkowo zbrojenie podłużne i strzemiona. Pole „wytężenie ≤ … %” (50–100%): wszystkie sprawdzenia nośności i SGU (zginanie, ścinanie, skręcanie, rysy, naprężenia, ugięcie) z wytężeniem nie większym niż zadane; przy wartości < 100% rozstawy strzemion i długości stref zapisywane są jako ręczne. Dobór usuwa też ostrzeżenia: prześwit na buławę (8.2(4)), liniowość pełzania (7.2(3)) i zbrojenie górne przy podporze skrajnej ≥ 0,15·A_s (9.2.1.2(1)). Belka ciągła z różnymi przekrojami przęseł – wymiary dobierane dla każdego przęsła.
- **Pręty przy bocznych powierzchniach** dodawane automatycznie, gdy wysokość belki h ≥ 1000 mm (7.3.3(3)), rozstaw ≤ 300 mm; przy niższych belkach norma ich nie wymaga.

## Poprawki 2.8.9

- **Dobór zbrojenia spełniający SGU.** Gdy po doborze nie jest spełnione ugięcie, a dokładanie zbrojenia rozciąganego już nie pomaga (lub osiąga ρ ≈ 2%), program dokłada zbrojenie ściskane w przęśle (pręty górne) – zmniejsza ugięcie od pełzania i skurczu; przy niespełnionej szerokości rys zbrojenie zwiększane jest bez zwiększania średnicy; do 24 kroków doboru. Gdy warunków nie da się spełnić samym zbrojeniem (przekrój za mały), komunikat po doborze to mówi, a ✖ przy b / h podaje najmniejszy wystarczający przekrój. Pętla klas betonu przerywana, gdy dwie kolejne klasy nic nie poprawiają (krótszy czas doboru dla przekrojów wyraźnie za małych).
- **Jedna średnica na krawędzi przekroju** (pole wyboru w pasku zbrojenia, domyślnie włączone): w przęśle dołem wszystkie pręty (obie warstwy, narożne i środkowe) tej samej średnicy; u góry pręty ciągłe i dodatkowe nad podporami tej samej średnicy – dobierana najmniejsza, przy której pręty nad podporami mieszczą się w jednej warstwie.
- **Pełzanie można pominąć:** *Współczynnik pełzania* → „nie uwzględniaj pełzania (φ = 0)” – E_c,eff = E_cm w ugięciach, naprężeniach i rysach; warunek liniowości pełzania 7.2(3) nie jest wtedy sprawdzany; w raporcie – „pełzanie pominięte”.
- **✖ także dla przekroju za dużego:** gdy przekrój spełnia wszystkie warunki, program sprawdza (pełnym doborem zbrojenia i kompletem warunków), czy wystarczy mniejsza wysokość przy tej samej szerokości i mniejsza szerokość przy tej samej wysokości. Wymiar do zmniejszenia – pomarańczowy ✖ z najmniejszą wystarczającą wartością (kliknięcie przyjmuje); w podpowiedzi także przekrój o najmniejszym polu.

## Poprawki 2.8.8

- **Długości stref zagęszczenia strzemion z wykresu V (zakładka *Dane*, wykres „V + strzemiona”).** Na końcu strefy s₁ (i s_p) przy każdej podporze jest uchwyt ⊢ – przeciągnięcie zmienia długość strefy od lica (co 0,05 m, w granicach dostępnej długości); kliknięcie uchwytu lub strefy otwiera okno: długość s₁ (i s_p) przy tej podporze, wymagana i dostępna długość, ostrzeżenie, gdy strefa jest krótsza od wymaganej, opcja „zastosuj przy wszystkich podporach”, przycisk *Automatycznie*. Długość ustawiona ręcznie – uchwyt pomarańczowy i ✎; sprawdzana warunkiem 6.2.3 (długość strefy ≥ wymagana). Zapis w projekcie: `stir.zl` (klucz – podpora i strona).
- **Wartości ekstremalne w każdym przęśle.** Na wykresach M i V pod schematem w *Danych* – największa wartość dodatnia i ujemna w każdym przęśle i wsporniku (dotąd tylko jedna, największa w belce); opisy bez nakładania na opisy prętów i stref. W zakładce *Wykresy* – także dla momentów skręcających T i M_z (wcześniej jedna wartość).

## Poprawki 2.8.7

- **Buława wibratora – można wyłączyć.** W pasku narzędzi zbrojenia (zakładka *Przekrój i zbrojenie*) pole wyboru „Buława wibratora”. Wyłączone: dobór zbrojenia nie zostawia prześwitu na buławę, warunek 8.2(4) nie jest sprawdzany (znika z podsumowania i raportu), w raporcie – „nie uwzględniana”. Odstępy prętów wg 8.2(2) sprawdzane zawsze. Domyślnie włączone; projekty z wcześniejszych wersji – włączone.
- **Widok 3D – poprawna orientacja przy różnych wysokościach przekrojów.** Górna krawędź wspólna jak w widoku podłużnym (głębsze przęsła wystają w dół), pręty, strzemiona i odgięcia liczone od góry; podpory pod spodem głębszego z sąsiednich przęseł, utwierdzenie – słup także nad belką; litery podpór.
- **Widok 3D na całej długości belki** – do zewnętrznych krawędzi podpór skrajnych i końców wsporników (wcześniej do osi podpór); uskok w miejscu jak w widoku podłużnym.
- **Sterowanie 3D:** stała skala – obrót nie przybliża i nie oddala; tryby *Obrót* / *Przesuw* (przesuw bez obrotu i bez zmiany skali), prawy przycisk lub Shift – przesuw, Ctrl + kółko – powiększenie w miejscu kursora, przyciski + / − / ⌂, na ekranie dotykowym dwa palce – przesuw i powiększenie.

## Poprawki 2.8.6

- **„Jak obliczono” – zielone wyróżnienie konkretnego wzoru i wartości.** Po kliknięciu wyniku okno pokazuje fragment raportu, w którym na zielono wyróżniony jest wiersz z obliczeniem tej wielkości, a sama wartość – zielonym znacznikiem; okno przewija się do niego. Dla jednej wartości (np. M_Rd) wyróżniane są też wzory, z których pochodzą liczby (np. „M_Rd = … = 107,23 kNm”, „|M_Ed| = 103,36 kNm” i porównanie „103,36 ≤ 107,23”).
- Dopasowanie po wartości z klikniętej komórki (z uwzględnieniem zaokrągleń: 107,2 ↔ 107,23), po symbolu wielkości (np. „A_s,min =”) i po nazwie; pręty „⌀20” ↔ „2⌀20”. Gdy w przypisanym rozdziale nie ma wzoru z tą wartością, program szuka go w całym raporcie i pokazuje właściwy rozdział.
- Wyróżnienie działa w zakładkach Przekrój i zbrojenie, Zbrojenie belki (przekrój pod kursorem, zestawienie stali, zakotwienia i zakłady), Podsumowanie, w paskach sprawdzeń i po kliknięciu wykresu (M – przekrój obliczeniowy, V – siła przy podporze, ugięcia – przęsło).

## Poprawki 2.8.5

- **Wartości ekstremalne sił wewnętrznych w osiach podpór.** Na wykresach M i V (obwiednie i wykresy bez obwiedni, w programie i w raporcie) opisane są wartości w osi podpory – szczyt wykresu (np. M nad podporą B = −193,4 kNm zamiast zredukowanego −188,2), dla V – po obu stronach podpory. Opisy wartości w licach usunięto z wykresów; obliczeniowe M_Ed w licu / zredukowane (5.3.2.2) i V_Ed przy licu pozostają w tabelach, oknie przekroju i raporcie.
- Opisy ekstremów zawsze widoczne: nad i pod wykresem zostawiono miejsce, a gdy brak miejsca – opis obok znacznika; opisy linii nośności (M_Rd, V_Rd) i pasm (s₁) ustępują opisom ekstremów.

## Poprawki 2.8.4

- **Klikalne wyniki w całym programie.** Każdy wiersz z wynikiem obliczeń – zakładka *Przekrój*, *Zbrojenie belki* (przekrój pod kursorem, zestawienie stali, zakotwienia i zakłady), okno przekroju, tabele kombinacji i szybkich sprawdzeń – otwiera okno „Jak obliczono” z odpowiednim fragmentem raportu (wzory, podstawienia, wyniki) dla właściwego przęsła lub podpory; wiersze z klikniętą wielkością są wyróżnione. Kliknięcie w wykres M, V, T, N lub ugięć otwiera obliczenia w najbliższym przekroju (zginanie, ścinanie przy podporze, ugięcia), a kliknięcie w zielony chip podsumowania – sprawdzenie decydujące.
- **Geometria – osobno ✔/✖ dla szerokości i wysokości.** Znacznik przy *b* i przy *h* (także dla każdego przęsła belki ciągłej). Wymiar do poprawy wynika z proponowanego przekroju albo z rodzaju niespełnionych warunków (rozstaw prętów, V_Rd,max, zwichrzenie → b; pozostałe → h). Gdy zbrojenie nie mieści się w wysokości, program pokazuje ✖ i proponuje przekrój zamiast pustego pola.
- **Wykresy bez obwiedni** (G i każde obciążenie zmienne osobno) – opisane wartości maksymalne i minimalne w przęsłach, w licach podpór i na załamaniach (siły skupione), tak jak na obwiedni; dla V – wartości po obu stronach podpór i w licach.
- Opisy wartości na wykresach nie wychodzą poza rysunek i nie zasłaniają liter podpór.

## Poprawki 2.8.3
- Siła podłużna N_Ed na schemacie obciążeń (Dane, Wykresy, raport): pozioma strzałka przy krawędzi belki / węźle, w którym ją zadano
  (ściskanie – do belki, rozciąganie – od belki) z wartością; kliknięcie strzałki w Danych – zmiana. Starsze projekty: strzałka
  przy końcu belki przeciwnym do pierwszej podpory nieprzesuwnej.

## Poprawki 2.8.2
- Obciążenia węzłowe osobno od edycji podpór: na schemacie w Danych kropki węzłów (podpory, węzły w przęsłach, swobodne
  końce belki); kliknięcie kropki – siła pionowa P, moment skręcający T (stałe/użytkowe) i siła podłużna N_Ed; kropka
  czerwona – węzeł z obciążeniem. Okna podpory i węzła – tylko podparcie / położenie i przegub.
- Zakład prętów: kliknięcie wymiaru zakładu w widoku podłużnym – położenie środka i długość l₀ („✎” – ustawiony ręcznie,
  „Automatycznie” – powrót); dotyczy prętów dolnych, górnych ciągłych i dodatkowych nad podporami.
- Wyciągi strzemion zamkniętych „rozchylone”: naroże z hakami rozsunięte – koniec pręta pionowego i początek poziomego
  zagięte do wnętrza, oba haki widoczne osobno.

## Poprawki 2.8.1
- Schemat w Danych i widok podłużny w zakładce Zbrojenie belki znów przewijają się razem z zawartością (bez przyklejania);
  przyklejony pozostaje tylko pasek szybkich sprawdzeń.
- Przełącznik „wykresy bez obwiedni” (od poszczególnych obciążeń, bez kombinacji) przeniesiony spod schematu w Danych
  do zakładki Wykresy M, V, T, N, ugięcia.
- Wykres sił poprzecznych: przy każdej podporze wartość maksymalna na granicy wykresu (oś podpory, „max”) oraz wartość
  przy licu podpory („lico”).

## Nowe w 2.8 (etap 3: raport .odt, 3D, kilka belek, „jak obliczono”)
- **Raport do edycji .odt** (OpenDocument – LibreOffice/OpenOffice Writer, MS Word): nagłówki, wzory z podstawieniami, tabele,
  indeksy dolne/górne, kolory statusów, rysunki (schemat, wykresy, zbrojenie) jako obrazy; przycisk w zakładce Raport
  (program Windows – okno zapisu, przeglądarka – pobranie pliku).
- **Widok 3D zbrojenia** (przełącznik 2D / 3D w zakładce Zbrojenie belki): beton półprzezroczysty, pręty dolne/górne/dodatkowe/
  boczne z odgięciami, strzemiona, pręty odgięte, podpory; przeciąganie – obrót, Ctrl + kółko – powiększenie, Shift – przesuw.
- **Kilka belek w projekcie**: zakładki 1…10 nad schematem w Danych („+” – nowa belka z materiałami i środowiskiem bieżącej,
  dwuklik – zmiana nazwy w polu nazwy projektu, „×” – usunięcie); każda belka ma własne dane i obliczenia; plik projektu,
  autozapis i „Moje projekty” zawierają wszystkie belki (pliki z jedną belką – bez zmian).
- **„Jak obliczono”**: kliknięcie warunku/wyniku w Podsumowaniu lub wyniku w tabeli przekroju – okno z wzorami, podstawieniami
  i wynikami z raportu dla danego miejsca belki oraz objaśnieniem punktu normy.
- **Pręty dolne ciągłe przez podpory pośrednie** (nowa opcja w Zakotwieniach): przęsła o tym samym zbrojeniu dolnym i wysokości –
  jeden pręt bez podziału nad podporą (podział zakładem tylko przy L > L_max).
- Dane po lewej w 3 kolumnach przy szerokim panelu (w połączeniu z przeciąganym podziałem – więcej danych bez przewijania).

## Nowe w 2.8 (etap 2: obciążenia, statyka, edycja zbrojenia, widoki)
- **Obciążenia o zmiennej wartości**: liniowo zmienne (trapezowe q₁ → q₂, trójkątne – przyciski ◺/◹) i o zadanej geometrii
  (łamana „x : q; x : q”); **kąt odchylenia od pionu α** (składowe q·cos α w Y i q·sin α w Z – zginanie ukośne).
  Na schemacie wykres q(x); weryfikacja: trójkąt qL²/(9√3), qL/6, qL/3; trójkąt symetryczny qL²/12; trapez; α = 30°.
- **Obciążenia w węzłach**: kliknięcie podpory lub węzła na schemacie – siła pionowa P, moment skręcający T (stałe/użytkowe)
  i siła podłużna N_Ed (pole N_Ed usunięte z tabeli obciążeń; T_Ed „podany wprost” tylko w starszych projektach).
- **Wyłączanie obciążeń**: pole wyboru przy każdym obciążeniu w zestawieniu i na schemacie – wyniki tylko dla zaznaczonych.
- **Redystrybucja momentów (5.5)** – pod schematem: δ automatycznie (najmniejsze dopuszczalne: δ ≥ k₁ + k₂·x_u/d, δ ≥ k₅ =
  0,7 dla stali B/C, 0,8 dla A; przęsła 0,5 ≤ L₁/L₂ ≤ 2) albo 0,9…0,7; momenty przęsłowe i siły poprzeczne zwiększane
  dla zachowania równowagi; sprawdzenie w Podsumowaniu.
- **Pręty odgięte 45° na ścinanie** (6.2.3(4), wzór 6.13) – tylko gdy same strzemiona nie wystarczają; dobór preferuje
  strzemiona (większa średnica), odgięcia s_b ≤ 0,6·d·(1 + cot α), strzemiona ≥ 50% (9.2.2(4)); rysunek, wyciąg, zestawienie.
- **Wykresy bez kombinacji** (pole pod schematem): M i V od G i od każdego obciążenia zmiennego (char.) – w Danych i Wykresach.
- **Schemat w Danych**: zakładki M / V / **N** / **R** (reakcje R_Ed max/min i R_k); wymiary osiowe, podpory i przęsła
  w świetle, długość całkowita z podporami; zasięg stref dozbrojenia (góra / dół) pod wykresem M; wymiary +15%.
- **Ctrl + kółko** – powiększanie schematu i widoku podłużnego (przeciąganie – przesuw, „100% ✕” – powrót).
- **Widok podłużny**: kliknięcie strefy strzemion – rozstaw (≤ s_l,max), długość strefy, liczba stref (auto / 1 / 2 / 3);
  okno przekroju w dowolnym miejscu – przyciski zmiany zbrojenia dolnego/górnego, strzemion, prętów bocznych, wymiarów, otuliny;
  ręczne położenie i długość zakładu pręta (sprawdzane l₀ ≥ wymagane); tablica pól przekroju prętów (też w Przekroju).
- **Strzemiona**: poprawiona długość w rozwinięciu osiowym (3 naroża 90° + 2 zagięcia haków w narożu początkowym –
  wcześniej zaniżona o ≈ π/2·(r + ⌀/2)); wyciąg „rozchylony” z widocznymi hakami i rozbiciem długości pod rysunkiem.

## Nowe w 2.8 (etap 1: obliczenia, dobór, ustawienia domyślne, raport)
- **Dobór zbrojenia wg praktyki**: pręty ⌀12/16/20/25/28 (bez ⌀14, 18, 22 i ≥ 32); jedna średnica albo 2 pręty narożne
  + jednakowe pręty środkowe (⌀ ≤ narożnych); druga warstwa – pary prętów nad prętami narożnymi (nie pojedynczy pręt
  w środku); każdy wariant sprawdzany rzeczywistym układem (prześwity 8.2(2), obrys strzemion, buława wibratora).
  Pręty boczne: skręcanie (rozstaw ≤ 350 mm) lub zbrojenie przypowierzchniowe przy h ≥ 1 m (7.3.3), kilka rzędów.
- **Dobór spełnia wszystkie warunki**: po zbrojeniu podłużnym – w razie potrzeby większa średnica strzemion (s₁ ≥ 75 mm),
  strzemiona 2-cięte zamiast 4-ciętych w wąskich belkach, najniższa klasa betonu spełniająca warunki (opcja „klasa
  dobierana automatycznie”, także σ_c,qp ≤ k₂·f_ck); wynik możliwie blisko 100% wykorzystania.
- **Wymiary przekroju: ✔ / ✖ przy b × h** (w tle: dobór zbrojenia na bieżących wymiarach i komplet sprawdzeń). Najechanie
  na ✖ – lista niespełnionych warunków i proponowany przekrój (co 50 mm, sprawdzony z dobranym zbrojeniem, z uwzględnieniem
  otuliny ogniowej i rozstawu prętów); kliknięcie ✖ – przyjęcie. Ostrzeżenia 5.3.1(3) (belka-ściana, L < 3h) i 5.3.1(4) (b ≥ 5h).
- **Domyślnie**: C20/25, B500SP (bez znaku EPSTAL – nowy materiał), strzemiona B500A, wykres parabola-prostokąt, nowy projekt
  bez obciążeń, redukcja momentu nad szerokimi podporami (5.3.2.2), pręty dolne nad podporami pośrednimi zakotwione ≥ 10⌀
  za licem (9.2.1.5(1)) – albo zakład (do wyboru); udział prętów doprowadzonych do podpór (wszystkie / 50% / 25%, min. 2 szt.).
- Otulina z odporności ogniowej (odległość osi a z tab. 5.5/5.6) – klasa konstrukcji nie obniża otuliny poniżej wymaganej ogniowo.
- Opcje w Danych: zbrojenie górne w nośności (przekrój podwójnie zbrojony), redukcja momentu nad podporami, odwrotna strzałka w₀
  (≤ L/250, sprawdzenie f − w₀; na wykresie ugięć linia przerywana), buława wibratora o dowolnej średnicy (np. 38 mm).
- **Zakotwienia osobno** dla przęseł i podpór (skrajnych i pośrednich): σ_sd, przyczepność i c_d w danym miejscu.
- **Raport**: raport pełny zawsze z wszystkimi obliczeniami i sprawdzeniami (spełnionymi i niespełnionymi), usunięty raport
  uproszczony; w raporcie „Statyka” – bez noty pod schematem, reakcje tylko na rysunku.
- **Interfejs**: szybkie sprawdzenia, schemat w Danych i widok podłużny zbrojenia przyklejone przy przewijaniu; przeciągany podział
  Danych (dane | schemat); czerwone, pulsujące podświetlenie miejsca do poprawy (do kliknięcia); niespełnione części przekroju
  (strefa zbrojenia, strzemiona, wymiary, otulina) zaznaczone na czerwono do kliknięcia; zwijana podpowiedź zakończeń prętów.
- **Rysunki**: pasma obciążeń i strzałki sił skalowane wartością; moment skupiony na wysokości belki; odnośniki prętów z półką
  opisu i strzałką (strzemiona – strzałka pozioma na 1/3 wysokości); na wykresach M i V – wartości przy licach podpór, maksima
  i załamania (siły skupione), bez nakładania opisów.
- Weryfikacja statyki z rozwiązaniami analitycznymi: `node tests/statyka.js` (19 przypadków: qL²/8, PL/4, qL²/12, 9qL²/128,
  belki ciągłe 2- i 3-przęsłowe, równowaga ΣR = ΣF, ciężar własny).

## Poprawki 2.7.1
- **Porównanie z innymi programami**: pod zestawieniem obciążeń w Danych – przyjęta kombinacja SGN (6.10 albo 6.10a/6.10b)
  oraz, dla obciążeń równomiernych na całej długości, q_Ed (6.10a, 6.10b i dla porównania 6.10), q_k i q_qp.
- ψ wyświetlane z dokładnością do 0,01 (np. ψ₂ = 0,25 nie jest już pokazywane jako 0,3).
- Weryfikacja statyki z RM-3D/RM_Zb1992 (belka 5 m przegub–utwierdzenie, b×h = 25×40): przy tych samych obciążeniach
  i kombinacji 6.10 wyniki identyczne (M_B = −47,695, M(2,5) = 23,848, V_A = 28,617, V_B = 47,695 kNm/kN;
  quasi-stałe M_B = −21,875, M_max = 12,305 kNm); M_Rd = 66,28 / 66,23 kNm, V_Rd,c = 43,753 kN, A_s,req 3,19 / 3,22 cm².

## Nowe w 2.7
- **Przekroje „gołe” na start**: nowy projekt nie ma zbrojenia podłużnego – program liczy statykę, ścinanie i zbrojenie
  wymagane (bez SGU, zakotwień i rysunku zbrojenia); podgląd „brak zbrojenia – dobierz”. W zakładce Przekrój i zbrojenie
  przyciski **„Dobierz zbrojenie wymagane”** i **„Wyczyść zbrojenie”**; pasek zbrojenia ograniczony do siatki
  przypowierzchniowej i buławy wibratora (strefy – kliknięciem przekroju).
- **Dobór zbrojenia normowo-optymalny**: A_s,req z SGN (z N_Ed, teowe, zbrojenie ściskane), A_s,min (9.2.1.1(1)),
  skręcanie (6.3.2(3)); najmniejsza masa stali + koszt prętów przy odstępach ≥ max(⌀; d_g + 5; 20) (8.2(2)), otulinie
  zależnej od ⌀ (4.4.1.2), prześwicie na buławę, preferencji 1 warstwy, liczbie prętów zgodnej z ramionami strzemion;
  następnie iteracyjnie zwiększane strefy z niespełnionymi warunkami (nośność, ciągliwość, rysy, naprężenia, ugięcia do
  ρ ≈ 2 %, zakotwienie – mniejsza średnica, F_E na podporze, ramiona strzemion); liczba ramion z s_t,max (9.2.2(8)).
- **Wykres pod belką w Danych** (półprzezroczysty, pod obciążeniami; przełącznik M / V / bez): M – obwiednia SGN
  i wymagana liczba prętów n⌀ w każdym miejscu (obwiednia przesunięta o a_l, 9.2.1.3; dół i góra: ciągłe + dodatkowe),
  podpowiedź z A_s,req po najechaniu; V – obwiednia, strefy strzemion s₁ / s_p / s₂, V_Rd,s(s₂) i wymagany zasięg
  zagęszczenia od lica. W raporcie wykresy bez tych danych.
- **Strzemiona do 3 stref** (s₁ przy podporze, s_p – pośrednia, s₂ – środek): rozstawy i podział automatycznie
  (strefa pośrednia, gdy oszczędza ≥ 3 strzemiona i ≥ 4 %), wybór liczby stref (auto / 1 / 2 / 3), ręczne s₁ / s_p / s₂
  i długości stref; zasięg zagęszczenia przy redukcji 6.2.1(8) liczony od odległości d od lica; sprawdzenie strefy pośredniej.
- **Uskok belki ciągłej**: wyższy przekrój sięga do lica podpory od strony niższego (rysunek, DXF, pręty dolne
  przęsła wyższego z otuliną od tego lica, pręty boczne).
- **Zakończenie prętów**: „automatycznie” (proste, a gdy się nie mieszczą – odgięcie z α₁ = 0,7, tab. 8.2) – domyślnie,
  „wyłącznie proste” (bez odginania – sprawdzenie zakotwienia), „haki / odgięcia / pętle”.
- **Wymiary minimalne przekroju** (Dane, pod geometrią): dla każdego przęsła b × h z wytycznych – zginanie bez zbrojenia
  ściskanego i z prętami w ≤ 2 warstwach, A_s ≤ 0,04·A_c, V_Ed ≤ V_Rd,max, L/d (7.4.2), zwichrzenie (5.9(3)),
  odporność ogniowa (b_min, otulina dolna), otulina z klasy ekspozycji, ciężar własny przeliczany; „przyjmij” weryfikuje
  wymiar pełnym obliczeniem z dobranym zbrojeniem (ugięcie metodą dokładną) i w razie potrzeby zwiększa h.

## Nowe w 2.6
- **Redukcja V wg 6.2.1(8)** działa na wymiarowanie strzemion (V_Ed,red w odległości d od lica przy podparciu bezpośrednim
  i obciążeniu górą, bez sił skupionych w tej strefie); V_Rd,max sprawdzane zawsze bez redukcji. Podgląd „SGN ścinanie”
  pokazuje wykorzystanie nośności strzemion (wcześniej przesłaniały je sprawdzenia konstrukcyjne), a przy rozstawie
  automatycznym zmiana redukcji od razu zmienia rozstaw s₁.
- **Rozstaw strzemion automatyczny** (domyślnie w nowych projektach; w starych – dotychczasowy rozstaw ręczny):
  s₂ = min(s_l,max = 0,75d; ρ_w,min; 400 mm; przy skręcaniu u/8 i wymiary przekroju), s₁ ≤ s₂ z warunku V_Ed,red ≤ V_Rd,s
  przy przyjętym (lub automatycznym) cot θ, z sumą zbrojenia na ścinanie i skręcanie; zaokrąglenie w dół do 25 mm
  (poniżej 100 mm – do 5 mm), min. 50 mm. Wyłączenie przełącznika przywraca ręczne s₁ / s₂ (także osobno dla przęseł).
- **Strzemiona ⌀6–12**, **haki 135° lub 90°** (rys. 8.5: 135° ≥ max(5⌀; 50 mm), 90° ≥ max(10⌀; 70 mm); haki 90° niedozwolone
  przy skręcaniu – sprawdzenie). Rysunki przekroju, wyciągi i DXF z hakami 90°.
- **Wyciągi**: klik pręta – zmiana średnicy (przelicza strefę zbrojenia) i długości (Enter zatwierdza); klik strzemienia –
  średnica, kąt i długość haka. Klik końca pręta w widoku podłużnym – opcje tylko dla klikniętego końca.
  Pręt skrócony ręcznie poniżej długości wymaganej z zakotwienia i zasięgu – sprawdzenie „nie spełnia”.
- **Otulina końców i zagięć**: końce prętów i zagięcia w narożach w odległości ≥ max(c_nom prętów głównych; c_nom,s + ⌀_w)
  od lica betonu (do powierzchni pręta); przy uskoku – od lica uskoku; promienie gięcia wg tab. 8.1N.
- **Odporność ogniowa** w Danych pod schematem (R30…R240, PN-EN 1992-1-2 tab. 5.5 / 5.6): sprawdzanie na bieżąco b_min,
  a, a_sd, b_w i podpowiedź, o ile zwiększyć otulinę lub szerokość przekroju.
- **Podgląd wyników** także w zakładkach Przekrój, Wykresy i Zbrojenie belki; klik niespełnionego warunku przenosi do miejsca
  błędu (pole danych, okno, pręt, koniec pręta) i podświetla na zielono przez 5 s, co zmienić.
- **Numery normy klikalne** w całym programie (punkty, tablice, rysunki, wzory, PN-EN 1990, PN-EN 1992-1-2) – okno
  z objaśnieniem nad bieżącym oknem.
- **Reakcje**: pionowe (SGN max/min, charakterystyczne max i od każdego oddziaływania), poziome H (podpora nieprzesuwna –
  od N_Ed; przy kilku podporach nieprzesuwnych przyjęto pierwszą), R_z, momenty utwierdzenia; przy podporach pośrednich
  siły poprzeczne po lewej i prawej stronie. Opis słowny reakcji w raportach.
- **Raport „Statyka”**: dane materiałowe, wymiary przekrojów, schemat statyczny, wykresy M, V, N (także przy N = 0), T,
  reakcje maksymalne charakterystyczne i obliczeniowe w formie opisowej. Wykres N pokazywany zawsze także w zakładce Wykresy.

## Nowe w 2.5
- **Długość pręta ≤ L_max liczona z odgięciami** (odcinek prosty + odgięcia − odliczenia na gięcie); dotyczy też prętów górnych
  dodatkowych nad podporami i prętów bocznych – pręty dłuższe dzielone zakładem l₀ w miejscu najmniejszego momentu.
- **Ręczne wymiary prętów**: klik pręta w wyciągach – długość odcinka prostego, odgięcia na końcach (długość, kierunek),
  powrót do automatycznych; klik końca pręta w widoku podłużnym – dodanie / zmiana odgięcia. Długość rozwinięta jest
  pilnowana względem L_max (bez zgody – brak zastosowania; „podziel zakładem”). Haki strzemion 135° zmieniane w wyciągach
  (min. 5⌀ i 50 mm wg rys. 8.5). Sprawdzenia: odgięcie ręczne ≥ wymagane z zakotwienia, hak ≥ min., l ≤ L_max.
- **Uskok belki ciągłej** (różne wysokości przęseł): pręty dolne przęsła głębszego kończą się przy licu uskoku i są odgięte
  do góry (do poziomu prętów przęsła płytszego + 10⌀), pręty przęsła płytszego przedłużone w przęsło głębsze o max(l₀/2; l_bd)
  za oś podpory; pręty boczne niemieszczące się w płytszym przekroju kończą się przy uskoku – żaden pręt nie wychodzi poza beton.
- **Zakład prętów dolnych nad podporami pośrednimi** = l₀ (8.7.3) symetrycznie względem osi (wcześniej tylko 10⌀ za licem);
  wymiar na rysunku i sprawdzenie w Podsumowaniu.
- **Strzemiona obejmują pręty podłużne**: ramiona (także wewnętrzne i szpilki) w miejscach prętów warstwy 1 u dołu i u góry;
  liczba ramion większa niż liczba prętów w narożach jest niedostępna (podpowiedź: ile prętów jest i ile ramion można dać),
  a gdy zbrojenie zmieni się później – sprawdzenie „nie spełnia”.
- **Wymiary przekroju** zmieniane kliknięciem wymiaru b lub h na rysunku przekroju (zakładka Przekrój i panel Danych).
- **Dane**: tylko wymiary b × h każdego przęsła (pole ogólne usunięte), zmiany natychmiast w obliczeniach; usunięty schemat
  „przęsło belki ciągłej – siły ręcznie”; pod schematem przełączniki ciężaru własnego i redukcji V wg 6.2.1(8); w grupie
  Obciążenia tylko kombinacje i siły przekrojowe; osobne przewijanie formularza i panelu ze schematem; przekroje przęseł
  w panelu edytowalne (okna zbrojenia, wymiarów, otuliny); objaśnienia słowne rozwijane na życzenie.
- **Raport uproszczony** (przełącznik w zakładce Raport): dane podstawowe, schemat, wykresy M, V, N, reakcje, ugięcia,
  zbiorcze SGN i SGU, zginanie, ścinanie, ściskanie, rysy, ugięcia oraz uproszczone sprawdzenie zbrojenia (min / max / zadane).

## Nowe w 2.4
- **Dane**: obciążenia zadaje się tylko na schemacie (klik elementu); pod schematem zestawienie obciążeń (klik wiersza →
  edycja tego jednego obciążenia); na schemacie nazwy obciążeń (np. „Q1 Użytkowe – biura”) i strzałki kierunku działania;
  **zaznaczanie kilku przęseł** (Ctrl + klik lub tryb „zaznacz kilka przęseł”) i jedno obciążenie na wszystkich zaznaczonych;
  momenty skręcające m_t [kNm/m] i T [kNm] jako obciążenie (rysowane na schemacie). Nad formularzem **podgląd wyników**
  (SGN zginanie, ścinanie; SGU rysy, ugięcie, naprężenia; konstrukcja) – klik przenosi do Podsumowania.
  Belka ciągła: **różne przekroje b×h przęseł** i przekrój każdego przęsła z zadanym zbrojeniem w panelu bocznym.
  Ze schematów usunięto „belkę utwierdzoną” i „obustronnie utwierdzoną” (stare projekty → belka jednoprzęsłowa z utwierdzeniem
  w podporach); objaśnienie rozstawu stężeń bocznych l_0t i ugięcia granicznego (L/250, L/500, L/300–400, L/200).
- **Ścinanie 6.2.1(8)**: V_Ed w odległości d od lica tylko gdy obciążenie działa na górną powierzchnię **i** reakcja na dolną
  (podparcie bezpośrednie – ustawienie w oknie podpory; obciążenie podwieszone – w oknie obciążenia) oraz brak siły skupionej
  w odległości ≤ d; powód braku redukcji w Podsumowaniu i raporcie.
- **Strzemiona**: rodzaje – zamknięte (2–8 ramion jako strzemiona wewnętrzne), zamknięte + szpilki, otwarte (U), na skręcanie
  (zakład); podpowiedź kiedy które (s_t,max wg 9.2.2(8), skręcanie 9.2.3); **inne strzemiona w każdym przęśle**. Haki 135°
  ≥ max(10⌀; 70 mm), trzpień gięcia φ_m wg tab. 8.1N.
- **Otulina** osobno dla krawędzi dolnej, górnej i boków (okno z przekroju i z paska zbrojenia).
- **Przekrój**: zamiast pasków – tabela „wymagane / przyjęte / TAK-NIE”; pręty, które nie mieszczą się w warstwie
  (prześwit < s_min), automatycznie przenoszone do kolejnej warstwy z komunikatem; rysunek rodzajów strzemion.
- **Wykresy M, V, T, N, ugięcia**: odczyt wartości pod kursorem na wszystkich wykresach jednocześnie, wykres momentów
  skręcających (MES pręta skręcanego, podparcie widełkowe) i siły osiowej, schemat z **reakcjami podporowymi**
  (R_Ed max/min, R_k od G i każdego Q), krzywa interakcji M–N na końcu zakładki (zakładka „Interakcja M–N” usunięta).
- **Zbrojenie belki**: różne wysokości przęseł, zagięcia rysowane łukami o promieniu φ_m/2 z opisem (φ_m = 7⌀ = 140, r = 70),
  przekrój pod kursorem obok widoku podłużnego, **wyciągi prętów** (pręty podłużne z odgięciami, strzemiona z hakami
  i wymiarami), **eksport DXF** (AutoCAD R12: widok 1:K, przekroje 1:10/1:20, wyciągi, zestawienie stali; warstwy BETON,
  ZBR_*, STRZEMIONA, WYMIARY, OPISY…).
- **Podsumowanie**: przy niespełnionych warunkach przycisk „pokaż →” przenoszący w miejsce problemu (przekrój, strefa
  zbrojenia, strzemiona, otulina, wykres ugięcia, zakotwienia).
- **Raport**: czarny tekst (kolory tylko w sprawdzeniach i wykresach), bez tabel i ramek, bez nagłówka i stopki z wersją;
  dodane reakcje, skręcanie, otulina krawędzi, strzemiona przęseł, powód (braku) redukcji V_Ed, trzpienie gięcia.

## Nowe w 2.3
- **Dane**: schemat belki na pół ekranu, interaktywny. Kliknięcie **elementu belki** otwiera okno obciążeń tego elementu
  (stałe, użytkowe, śnieg, wiatr, inne, wyjątkowe – osobno dla każdego przęsła/elementu; położenia od początku elementu);
  w tym samym oknie **wstawianie węzłów** (w podanym miejscu lub podział na n równych części) i **przegubów**.
  Kliknięcie **obciążenia** na schemacie otwiera jego edycję, **węzła** – przesunięcie, przegub, usunięcie. Tabele obciążeń
  usunięte z formularza (pozostały g_k na całej długości, ciężar własny i parametry kombinacji).
- **Podpory**: blokada lub zwolnienie przesuwu **x** (podłużnie), **y** (pionowo), **z** (poprzecznie, płaszczyzna Z)
  i **obrotu φ**; przegub w belce nad podporą pośrednią. Stateczność sprawdzana macierzą sztywności MES osobno w płaszczyźnie
  Y i Z (mechanizm → błąd z opisem). Przeguby – kondensacja obrotu w elemencie MES (sprawdzone: belka Gerbera
  2×6 m z przegubem 1 m za podporą: M_B = −30,00 kNm, M_przęsła = 31,25 kNm – ściśle).
- **Przekrój**: poglądowe porównanie zbrojenia – A_s,req (SGN), A_s,min (9.1N), A_s,min rysy (7.3.2), przyjęte; zapas lub
  brak (z liczbą prętów do dodania); strzemiona: wymagane A_sw/s przy licach podpór, ρ_w,min, przyjęte s₁ i s₂.
  W oknie strefy zbrojenia porównanie aktualizuje się na żywo. „Sparowane” (warstwy 2+) = pręty zlicowane z prętami
  warstwy 1 (w tych samych pionach).
- **Zbrojenie belki**: zakłady prętów dłuższych od długości handlowej (ustawienie: 6–14 m, domyślnie 12 m) w miejscach
  najmniejszego momentu rozciągającego dane pręty (pręty górne – w strefie przęsłowej), z wymiarem l₀; wymiary zakotwień
  na podporach skrajnych (długość w podporze, odgięcie, l_bd) i przedłużenia prętów dolnych za lico podpór pośrednich;
  wymiary odcinków odgiętych; przeguby; odnośnik strzemion trafia w strzemię.
- Zakładka **Podsumowanie** przeniesiona przed **Raport obliczeń**.

## Obsługa (2.2)
- **Dane** – formularz zajmuje większą część ekranu, obok schemat belki z obciążeniami, tabela podpór i podgląd przekroju.
  Kliknięcie podpory na schemacie otwiera okno: rodzaj – **przesuwna** (więź pionowa), **nieprzesuwna** (pionowa + pozioma),
  **sztywna** (utwierdzenie), szerokość podpory t (indywidualna) i **podatność**: pionowa k_v [kN/m] (sprężyna w MES) oraz
  obrotowa k_φ [kNm/rad] dla podpory sztywnej. Program sprawdza stateczność układu (np. wspornik wymaga podpory sztywnej)
  i ostrzega o braku podpory nieprzesuwnej; ugięcia liczone względem cięciwy osiadających podpór.
- **Przekrój i zbrojenie** – zbrojenie dodaje się tylko tutaj: kliknięcie górnej/dolnej krawędzi przekroju, boku (pręty boczne)
  lub wnętrza (strzemiona) albo przycisku na pasku. Okno strefy zbrojenia: dowolna liczba **warstw** (do 6), w każdej grupy
  prętów n×⌀ o **różnych średnicach**; rozmieszczenie: równomiernie, **w odstępach normowych od naroży** (s_min wg 8.2(2),
  wolny środek na buławę), **parami** (pary w odstępie normowym), albo **współrzędne ręcznie** [mm od lewej krawędzi środnika];
  odstęp w świetle od niższej warstwy (pusty – normowy); w strefie dolnej – ile prętów warstwy dochodzi do podpór
  (pozostałe skrócone wg 9.2.1.3); wiązki 2/3 prętów. Podgląd przekroju na żywo z kontrolą prześwitów, mieszczenia się
  w strzemionach i w wysokości przekroju oraz prześwitu na buławę wibratora. Dla prętów nad podporą – długości w lewo/w prawo.
- **Zbrojenie belki** – widok podłużny: pręty wszystkich warstw, **odgięcia** na podporach skrajnych (dolne do góry przy
  podporach swobodnych, górne w dół w podporę sztywną), gdy prosty pręt nie mieści się na długości zakotwienia l_bd
  (odgięcie na wymaganą długość, α₁ = 0,7); **oznaczenia pozycji** (numer w kółku, n⌀d, długość) dla prętów dolnych, górnych,
  bocznych i strzemion; **wymiary**: szerokości podpór, rozpiętości w świetle, rozpiętości w osiach, długość całkowita, strefy
  strzemion; tabela zakotwień na podporach skrajnych; zestawienie stali z długościami odgięć.

## Zakres obliczeń
- **Otulina** (4.4.1): klasa konstrukcji wg tab. 4.3N, c_min,dur (tab. 4.4N), c_min,b, Δc_dev, betonowanie na gruncie; minimalna klasa betonu (zał. E);
  otulina automatyczna albo wpisana ręcznie (porównywana z wymaganą).
- **Statyka**: belka jednoprzęsłowa (podpory dowolne na schemacie), wspornik oraz **belka ciągła
  wieloprzęsłowa liczona w całości** (do 8 przęseł, wsporniki skrajne) – MES; każda podpora przesuwna, nieprzesuwna lub sztywna,
  sprężysta (k_v, k_φ) i o własnej szerokości;
  Obciążenia zmienne rozkładane na przęsła (układ szachownicowy w obwiedniach i ugięciach).
- **Płaszczyzna Z**: obciążenia ciągłe i skupione działające poziomo (prostopadle do układu) lub jednocześnie Y i Z;
  zginanie ukośne (kontur M<sub>y</sub>–M<sub>z</sub> przy N<sub>Ed</sub>, metoda włókien), ścinanie poziome (poziome ramiona strzemion, interakcja
  krzyżulców Y/Z), naprężenia SGU w przekroju zarysowanym przy zginaniu ukośnym, ugięcie poziome.
- **Obciążenia i kombinacje (PN-EN 1990)**: dowolna liczba obciążeń zmiennych w osobnych grupach – użytkowe (kat. A–H),
  śnieg (H ≤ / > 1000 m), wiatr, inne (ψ podane), dodatkowe obciążenia stałe; każde jako obciążenie ciągłe na całej lub części
  długości i dowolna liczba sił skupionych. Położenie siły na pręcie: od lewego końca, od prawego końca [m] lub względnie x/L;
  w MES węzły leżą dokładnie w punktach przyłożenia sił i na granicach obciążeń. Podgląd schematu obciążeń z łańcuchem wymiarowym.
  Automatyczne kombinacje 6.10 lub 6.10a/6.10b z każdym obciążeniem jako wiodącym, charakterystyczne (6.14b) i quasi-stała (6.16b);
  obciążenia zmienne tylko tam, gdzie niekorzystne; γ_G,inf = 1,0 dla działania korzystnego; obciążenie dachu kat. H nie jest
  łączone ze śniegiem/wiatrem. Sytuacja wyjątkowa 6.11b: obciążenia wyjątkowe A_d (każde osobno), ψ1 lub ψ2 dla wiodącego,
  sprawdzenie SGN z γ_c = 1,2, γ_s = 1,0.
- **SGN**: zginanie z siłą osiową – metoda ogólna (zgodność odkształceń, krzywa interakcji M–N) i uproszczona (A_s,req, ξ_eff,lim);
  ścinanie 6.2 (V_Rd,c, V_Rd,s, V_Rd,max, automatyczny dobór cot θ, długość strefy zagęszczonej strzemion, F_E na podporze);
  skręcanie 6.3; ścinanie półka–środnik 6.2.4.
- **SGU**: naprężenia 7.2, minimalne zbrojenie i szerokość rys 7.3 (w_k, tab. 7.2N/7.3N), ugięcia 7.4 – metoda dokładna
  (interpolacja ζ, pełzanie i skurcz wg zał. B, MES z iteracją sztywności) oraz uproszczona L/d.
- **Zakotwienia i zakłady** 8.4/8.7, wiązki prętów 8.9 (⌀n = ⌀√nb), rozstaw prętów 8.2, A_s,min/A_s,max, wymagania rozdz. 9.2
  (m.in. pręty dolne na podporach pośrednich, długości prętów górnych nad każdą podporą z przesunięcia obwiedni a_l),
  **zbrojenie przypowierzchniowe 9.2.4 / zał. J.1** (pręty lub wiązki ⌀ > 32 mm → 1% A_ct,ext, otulina > 70 mm → 0,5% A_ct,ext,
  oczko ≤ 150 mm), zwichrzenie 5.9. Strzemiona rozmieszczane od lica podpór (pierwsze 50 mm od lica), strefa s₁ od lica.
- **Odporność ogniowa** wg PN-EN 1992-1-2, tab. 5.5/5.6.
- **Zbrojenie (2.1)**: pręty boczne „w połowie wysokości” (rzędy przy każdym boku – w SGN, SGU, skręcaniu i zbrojeniu bocznym
  belek h ≥ 1 m wg 7.3.3(3)); wiązki prętów dolnych i górnych dodatkowych: jeden nad drugim bez odstępu (8.9.1(4)), obok siebie
  lub w trójkąt; pręty kolejnych warstw nad prętami warstwy 1 i sprawdzenie prześwitu na buławę wibratora (8.2(4));
  ręczne przedłużanie prętów dodatkowych nad podporami (kontrola z długością wymaganą, min. 0,2·L od lica przy podporach skrajnych).
- **Strzemiona (2.1)**: odstęp pierwszego strzemienia od lica 10–50 mm dobierany dla równomiernego rozstawu (część środkowa –
  równy rozstaw ≤ s₂, najlepiej okrągły) albo podany ręcznie (≤ 50 mm).
- **Klasy ekspozycji**: podpowiedzi z przykładowymi elementami i tabela wszystkich klas.
- **Widok podłużny**: kliknięcie w belkę pokazuje przekrój poprzeczny w danym miejscu (rzeczywiste zbrojenie, M_Rd±, V_Ed, strzemiona).
- **Podsumowanie**: odnośniki do punktów normy otwierają okno z objaśnieniem (streszczenie, wzór, podpowiedź, wartości z projektu);
  sprawdzenia można odhaczać – raport obejmuje tylko odhaczone; warunek, który przestaje być spełniony, jest odznaczany
  automatycznie, a ponownie spełniony – zaznaczany (nowy projekt: wszystkie spełnione zaznaczone).
- Raport z pełnym tokiem obliczeń (druk / PDF / HTML) bez nagłówków i stopek przeglądarki (margines strony 0, odstępy
  powtarzane na każdej stronie), zestawienie stali, zapis projektu (*.belka).

## Struktura źródeł
- `web/engine.js` – silnik obliczeń (czysty JavaScript, działa też w Node.js),
- `web/norms.js` – objaśnienia punktów normy (streszczenia własne + podpowiedzi),
- `web/ui.js`, `web/report.js`, `web/style.css`, `web/index.html` – interfejs i raport,
- `web/dxf.js` – eksport rysunku zbrojenia do DXF,
- `build_html.py` – skleja pliki w jeden `app/app.html` (działa samodzielnie w przeglądarce),
- `app/main.go` – okno Windows (WebView2), okna dialogowe plików, autozapis.

## Kompilacja
```
python3 build_html.py          # generuje app/app.html i webapp/belkazb.html (+ web/svgtheme.css)
cd app
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-H windowsgui -s -w" -o BelkaZB.exe .
```

Program jest narzędziem pomocniczym – wyniki wymagają weryfikacji przez projektanta z uprawnieniami.
