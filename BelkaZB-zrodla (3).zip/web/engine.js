/* =====================================================================
   BelkaŻB – silnik obliczeń belek żelbetowych wg PN-EN 1992-1-1
   (z uwzględnieniem wartości z Załącznika Krajowego PL tam, gdzie
   różnią się od zalecanych), PN-EN 1990, PN-EN 1992-1-2 (tablice).
   Jednostki wewnętrzne: N, mm, MPa.  Momenty wyjściowe: kNm, siły: kN.
   ===================================================================== */
(function (root) {
'use strict';

/* ---------------------------------------------------------------- tabele */
// nazwa, fck, fck,cube, fctm, fctk0.05, fctk0.95, Ecm[GPa], εc1, εcu1, εc2, εcu2, n, εc3, εcu3 [‰]  (Tablica 3.1)
const CONC_ROWS = [
  ['C12/15', 12, 15, 1.6, 1.1, 2.0, 27, 1.8, 3.5, 2.0, 3.5, 2.0, 1.75, 3.5],
  ['C16/20', 16, 20, 1.9, 1.3, 2.5, 29, 1.9, 3.5, 2.0, 3.5, 2.0, 1.75, 3.5],
  ['C20/25', 20, 25, 2.2, 1.5, 2.9, 30, 2.0, 3.5, 2.0, 3.5, 2.0, 1.75, 3.5],
  ['C25/30', 25, 30, 2.6, 1.8, 3.3, 31, 2.1, 3.5, 2.0, 3.5, 2.0, 1.75, 3.5],
  ['C30/37', 30, 37, 2.9, 2.0, 3.8, 33, 2.2, 3.5, 2.0, 3.5, 2.0, 1.75, 3.5],
  ['C35/45', 35, 45, 3.2, 2.2, 4.2, 34, 2.25, 3.5, 2.0, 3.5, 2.0, 1.75, 3.5],
  ['C40/50', 40, 50, 3.5, 2.5, 4.6, 35, 2.3, 3.5, 2.0, 3.5, 2.0, 1.75, 3.5],
  ['C45/55', 45, 55, 3.8, 2.7, 4.9, 36, 2.4, 3.5, 2.0, 3.5, 2.0, 1.75, 3.5],
  ['C50/60', 50, 60, 4.1, 2.9, 5.3, 37, 2.45, 3.5, 2.0, 3.5, 2.0, 1.75, 3.5],
  ['C55/67', 55, 67, 4.2, 3.0, 5.5, 38, 2.5, 3.2, 2.2, 3.1, 1.75, 1.8, 3.1],
  ['C60/75', 60, 75, 4.4, 3.1, 5.7, 39, 2.6, 3.0, 2.3, 2.9, 1.6, 1.9, 2.9],
  ['C70/85', 70, 85, 4.6, 3.2, 6.0, 41, 2.7, 2.8, 2.4, 2.7, 1.45, 2.0, 2.7],
  ['C80/95', 80, 95, 4.8, 3.4, 6.3, 42, 2.8, 2.8, 2.5, 2.6, 1.4, 2.2, 2.6],
  ['C90/105', 90, 105, 5.0, 3.5, 6.6, 44, 2.8, 2.8, 2.6, 2.6, 1.4, 2.3, 2.6],
];
const CONCRETE = {}, CONC_NAMES = [];
CONC_ROWS.forEach(r => {
  CONCRETE[r[0]] = { name: r[0], fck: r[1], fckcube: r[2], fctm: r[3], fctk05: r[4], fctk95: r[5], Ecm: r[6],
    ec1: r[7], ecu1: r[8], ec2: r[9], ecu2: r[10], n: r[11], ec3: r[12], ecu3: r[13] };
  CONC_NAMES.push(r[0]);
});
const classIdx = n => CONC_NAMES.indexOf(n);

// Stal zbrojeniowa (Załącznik C): klasa ciągliwości A/B/C
const STEEL_LIST = [
  { id: 'B500SPn', name: 'B500SP – klasa C', fyk: 500, cls: 'C', euk: 7.5, k: 1.15 },
  { id: 'B500SP', name: 'B500SP (EPSTAL) – klasa C', fyk: 500, cls: 'C', euk: 7.5, k: 1.15 },
  { id: 'B500C', name: 'B500C – klasa C', fyk: 500, cls: 'C', euk: 7.5, k: 1.15 },
  { id: 'B500B', name: 'B500B / BSt500S – klasa B', fyk: 500, cls: 'B', euk: 5.0, k: 1.08 },
  { id: 'B500A', name: 'B500A – klasa A', fyk: 500, cls: 'A', euk: 2.5, k: 1.05 },
  { id: 'B450C', name: 'B450C – klasa C', fyk: 450, cls: 'C', euk: 7.5, k: 1.15 },
  { id: 'B400B', name: 'B400B – klasa B', fyk: 400, cls: 'B', euk: 5.0, k: 1.08 },
];
const STEEL = {}; STEEL_LIST.forEach(s => STEEL[s.id] = s);

const BAR_DIAS = [6, 8, 10, 12, 14, 16, 18, 20, 22, 25, 28, 32, 36, 40];
const EXPOSURES = ['X0', 'XC1', 'XC2', 'XC3', 'XC4', 'XD1', 'XD2', 'XD3', 'XS1', 'XS2', 'XS3'];
const EXP_DESC = {
  X0: 'brak zagrożenia korozją', XC1: 'karbonatyzacja – sucho lub stale mokro', XC2: 'karbonatyzacja – mokro, rzadko sucho',
  XC3: 'karbonatyzacja – umiarkowana wilgotność', XC4: 'karbonatyzacja – cyklicznie mokro i sucho',
  XD1: 'chlorki – umiarkowana wilgotność', XD2: 'chlorki – mokro, rzadko sucho', XD3: 'chlorki – cyklicznie mokro i sucho',
  XS1: 'woda morska – sól w powietrzu', XS2: 'woda morska – stałe zanurzenie', XS3: 'woda morska – strefy pływów/rozbryzgów',
  XF1: 'mróz – umiarkowane nasycenie, bez odladzaczy', XF2: 'mróz – umiarkowane nasycenie, z odladzaczami',
  XF3: 'mróz – silne nasycenie, bez odladzaczy', XF4: 'mróz – silne nasycenie, z odladzaczami',
  XA1: 'agresja chemiczna – słaba', XA2: 'agresja chemiczna – umiarkowana', XA3: 'agresja chemiczna – silna'
};
// Tablica 4.4N  cmin,dur [mm]: kolumny X0, XC1, XC2/XC3, XC4, XD1/XS1, XD2/XS2, XD3/XS3
const CMIN_DUR = [
  [10, 10, 10, 15, 20, 25, 30],
  [10, 10, 15, 20, 25, 30, 35],
  [10, 10, 20, 25, 30, 35, 40],
  [10, 15, 25, 30, 35, 40, 45],
  [15, 20, 30, 35, 40, 45, 50],
  [20, 25, 35, 40, 45, 50, 55],
];
const EXP_COL = { X0: 0, XC1: 1, XC2: 2, XC3: 2, XC4: 3, XD1: 4, XS1: 4, XD2: 5, XS2: 5, XD3: 6, XS3: 6 };
// Tablica 4.3N – klasa wytrzymałości pozwalająca obniżyć klasę konstrukcji o 1
const SC_STRENGTH = { X0: 'C30/37', XC1: 'C30/37', XC2: 'C35/45', XC3: 'C35/45', XC4: 'C40/50', XD1: 'C40/50', XD2: 'C40/50', XS1: 'C40/50', XD3: 'C45/55', XS2: 'C45/55', XS3: 'C45/55' };
// Tablica E.1N – orientacyjna minimalna klasa betonu
const MIN_CLASS = { X0: 'C12/15', XC1: 'C20/25', XC2: 'C25/30', XC3: 'C30/37', XC4: 'C30/37', XD1: 'C30/37', XD2: 'C30/37', XD3: 'C35/45',
  XS1: 'C30/37', XS2: 'C35/45', XS3: 'C35/45', XF1: 'C30/37', XF2: 'C25/30', XF3: 'C30/37', XF4: 'C30/37', XA1: 'C30/37', XA2: 'C30/37', XA3: 'C35/45' };
// Tablica 7.1N – wmax [mm] (kombinacja quasi-stała, elementy żelbetowe)
const WMAX = { X0: 0.4, XC1: 0.4, XC2: 0.3, XC3: 0.3, XC4: 0.3, XD1: 0.3, XD2: 0.3, XD3: 0.3, XS1: 0.3, XS2: 0.3, XS3: 0.3 };

// PN-EN 1990, Tablica A1.1 (z ZK)
const PSI = {
  A: { name: 'Kat. A – powierzchnie mieszkalne', p0: 0.7, p1: 0.5, p2: 0.3 },
  B: { name: 'Kat. B – biura', p0: 0.7, p1: 0.5, p2: 0.3 },
  C: { name: 'Kat. C – miejsca zebrań', p0: 0.7, p1: 0.7, p2: 0.6 },
  D: { name: 'Kat. D – powierzchnie handlowe', p0: 0.7, p1: 0.7, p2: 0.6 },
  E: { name: 'Kat. E – magazyny', p0: 1.0, p1: 0.9, p2: 0.8 },
  F: { name: 'Kat. F – ruch pojazdów ≤ 30 kN', p0: 0.7, p1: 0.7, p2: 0.6 },
  G: { name: 'Kat. G – ruch pojazdów 30–160 kN', p0: 0.7, p1: 0.5, p2: 0.3 },
  H: { name: 'Kat. H – dachy', p0: 0.0, p1: 0.0, p2: 0.0 },
  S: { name: 'Śnieg (H ≤ 1000 m n.p.m.)', p0: 0.5, p1: 0.2, p2: 0.0 },
  W: { name: 'Wiatr', p0: 0.6, p1: 0.2, p2: 0.0 },
  T: { name: 'Temperatura (nie pożar)', p0: 0.6, p1: 0.5, p2: 0.0 },
};

// PN-EN 1991-1-1: obciążenia użytkowe – zakresy q_k [kN/m²] i Q_k [kN] z tablic 6.2 (A–D), 6.4 (E), 6.8 (F, G), 6.10 (H; dachy)
const IMP_EC1 = {
  A: [{ id: 'A', n: 'stropy', d: 'pomieszczenia mieszkalne, domy, pokoje w hotelach i szpitalach, toalety', q: [1.5, 2.0], Q: [2.0, 3.0], t: '6.2' },
    { id: 'As', n: 'schody', d: 'schody w budynkach kategorii A', q: [2.0, 4.0], Q: [2.0, 4.0], t: '6.2' },
    { id: 'Ab', n: 'balkony', d: 'balkony w budynkach kategorii A', q: [2.5, 4.0], Q: [2.0, 3.0], t: '6.2' }],
  B: [{ id: 'B', n: 'biura', d: 'powierzchnie biurowe', q: [2.0, 3.0], Q: [1.5, 4.5], t: '6.2' }],
  C: [{ id: 'C1', n: 'C1 – ze stołami', d: 'szkoły, kawiarnie, restauracje, stołówki, czytelnie, recepcje', q: [2.0, 3.0], Q: [3.0, 4.0], t: '6.2' },
    { id: 'C2', n: 'C2 – z zamocowanymi siedzeniami', d: 'kościoły, teatry, kina, sale konferencyjne i wykładowe, poczekalnie', q: [3.0, 4.0], Q: [2.5, 7.0], t: '6.2' },
    { id: 'C3', n: 'C3 – bez przeszkód dla ruchu ludzi', d: 'muzea, sale wystawowe, dostępy w budynkach publicznych, hotelach, szpitalach, dworcach', q: [3.0, 5.0], Q: [4.0, 7.0], t: '6.2' },
    { id: 'C4', n: 'C4 – z możliwą aktywnością fizyczną', d: 'sale taneczne, gimnastyczne, sceny', q: [4.5, 5.0], Q: [3.5, 7.0], t: '6.2' },
    { id: 'C5', n: 'C5 – dostępne dla tłumu', d: 'sale koncertowe, sportowe z trybunami, tarasy, wejścia, perony', q: [5.0, 7.5], Q: [3.5, 4.5], t: '6.2' }],
  D: [{ id: 'D1', n: 'D1 – sklepy detaliczne', d: 'powierzchnie w sklepach detalicznych', q: [4.0, 5.0], Q: [3.5, 7.0], t: '6.2' },
    { id: 'D2', n: 'D2 – domy towarowe', d: 'powierzchnie w domach towarowych', q: [4.0, 5.0], Q: [3.5, 7.0], t: '6.2' }],
  E: [{ id: 'E1', n: 'E1 – składowanie', d: 'magazyny, archiwa, biblioteki (gromadzenie towarów) – wartości minimalne', q: [7.5, 7.5], Q: [7.0, 7.0], t: '6.4' }],
  F: [{ id: 'F', n: 'F – pojazdy ≤ 30 kN', d: 'garaże, parkingi, drogi dla pojazdów lekkich', q: [1.5, 2.5], Q: [10, 20], t: '6.8' }],
  G: [{ id: 'G', n: 'G – pojazdy 30–160 kN', d: 'drogi dojazdowe, strefy dostaw, dojazdy pożarowe', q: [5.0, 5.0], Q: [40, 90], t: '6.8' }],
  H: [{ id: 'H', n: 'H – dachy bez dostępu', d: 'dachy niedostępne, z wyjątkiem zwykłego utrzymania i napraw', q: [0.0, 1.0], Q: [0.9, 1.5], t: '6.10' }],
};

// PN-EN 1992-1-2 Tablica 5.5 (belki swobodnie podparte) i 5.6 (belki ciągłe): [bmin, a], bw,min (klasa WA)
const FIRE_SS = {
  R30: { c: [[80, 25], [120, 20], [160, 15], [200, 15]], bw: 80 },
  R60: { c: [[120, 40], [160, 35], [200, 30], [300, 25]], bw: 100 },
  R90: { c: [[150, 55], [200, 45], [300, 40], [400, 35]], bw: 110 },
  R120: { c: [[200, 65], [240, 60], [300, 55], [500, 50]], bw: 130 },
  R180: { c: [[240, 80], [300, 70], [400, 65], [600, 60]], bw: 150 },
  R240: { c: [[280, 90], [350, 80], [500, 75], [700, 70]], bw: 170 },
};
const FIRE_CONT = {
  R30: { c: [[80, 15], [160, 12]], bw: 80 },
  R60: { c: [[120, 25], [200, 12]], bw: 100 },
  R90: { c: [[150, 35], [250, 25]], bw: 110 },
  R120: { c: [[200, 45], [300, 35], [450, 35], [500, 30]], bw: 130 },
  R180: { c: [[240, 60], [400, 50], [550, 50], [600, 40]], bw: 150 },
  R240: { c: [[280, 75], [500, 60], [650, 60], [700, 50]], bw: 170 },
};

const SCHEMES = {
  ss: { name: 'Belka jednoprzęsłowa (podpory na schemacie)', sup: ['pin', 'pin'], K: 1.0, l0: 1.0 },
  cant: { name: 'Wspornik (utwierdzenie z lewej)', sup: ['fix', 'free'], K: 0.4, l0: 2.0 },
  cont: { name: 'Belka ciągła wieloprzęsłowa', sup: ['pin', 'pin'], K: 1.3, l0: 0.85 },
  manual: { name: 'Przęsło belki ciągłej – siły wewnętrzne ręcznie', sup: ['pin', 'pin'], K: 1.3, l0: 0.85 },
};

/* --------------------------------------------------------------- pomocnicze */
const area = d => Math.PI * d * d / 4;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const num = (v, def) => {
  if (typeof v === 'number') return isFinite(v) ? v : def;
  if (v === null || v === undefined || v === '') return def;
  const x = parseFloat(String(v).replace(',', '.').replace(/\s/g, ''));
  return isFinite(x) ? x : def;
};
const interp = (tab, x) => {
  if (x <= tab[0][0]) return tab[0][1];
  for (let i = 1; i < tab.length; i++) if (x <= tab[i][0]) {
    const [x0, y0] = tab[i - 1], [x1, y1] = tab[i];
    return y0 + (y1 - y0) * (x - x0) / (x1 - x0);
  }
  return tab[tab.length - 1][1];
};
const ceilTo = (v, s) => Math.ceil(v / s - 1e-9) * s;

// strefa zbrojenia (dół przęsła, góra ciągła, góra dodatkowa nad podporą): warstwy z grupami prętów n×⌀
// place: 'even' – równomiernie, 'min' – w odstępach normowych od naroży, 'pair' – parami, 'manual' – współrzędne x [mm] od lewej krawędzi środnika
// gap: odstęp w świetle od poprzedniej warstwy ('' – normowy), toSupp: pręty doprowadzone do podpór ('all' lub liczba – skrajne)
const zoneOf = (groups, o) => Object.assign({ nb: 1, shape: 'v', auto: false, layers: groups.filter(q => q.n > 0).length ? [{ bars: groups.filter(q => q.n > 0), place: 'even', xs: '', gap: '', toSupp: 'all' }] : [] }, o || {});
function normZone(z, def) {
  if (!z || typeof z !== 'object' || !Array.isArray(z.layers)) z = def;
  const layers = z.layers.slice(0, 6).map(ly => ({
    bars: (Array.isArray(ly.bars) ? ly.bars : []).map(b => ({ n: clamp(Math.round(num(b.n, 0)), 0, 40), d: num(b.d, 16) })).filter(b => b.n > 0).slice(0, 8),
    place: ['even', 'min', 'pair', 'manual'].includes(ly.place) ? ly.place : 'even',
    xs: typeof ly.xs === 'string' ? ly.xs : (Array.isArray(ly.xs) ? ly.xs.join('; ') : ''),
    gap: (ly.gap === '' || ly.gap === null || ly.gap === undefined) ? '' : Math.max(0, num(ly.gap, 0)),
    toSupp: (ly.toSupp === undefined || ly.toSupp === '' || ly.toSupp === 'all' || ly.toSupp === null) ? 'all' : Math.max(0, Math.round(num(ly.toSupp, 0))),
    touch: ly.touch === true,                                   // warstwa ułożona bezpośrednio na niższej (pręty w styku, 8.9.1)
  })).filter(l => l.bars.length);
  return { nb: clamp(Math.round(num(z.nb, 1)), 1, 3), shape: ['v', 'h', 't'].includes(z.shape) ? z.shape : 'v', auto: !!z.auto, layers };
}
const zoneBars = z => (z && z.layers ? z.layers.reduce((a, l) => a + l.bars.reduce((b, q) => b + q.n, 0), 0) : 0);
function defaultState() {
  return {
    meta: { name: 'Belka B-1', author: '', note: '', ticks: {} },
    scheme: 'ss',
    geom: { type: 'rect', b: 300, h: 600, beff: 1200, hf: 150, beffMode: 'manual', b1: 1500, b2: 1500, L: 6.0, t: 250, l0t: '' },
    mat: { concrete: 'C20/25', steel: 'B500SPn', steelW: 'B500A', dg: 16, diag: 'parab', autoC: false },
    env: { exp: 'XC1', expF: '-', expA: '-', life: 50, scSel: 'auto', qc: false, scRed: false, dcdev: 10, dcg: 0, dcst: 0, dcadd: 0, cast: 'form', cnomSel: 'auto', cnomVal: 30, cBot: '', cTop: '', cSide: '' },
    loads: { gk: 0, sw: true, redM: true, perm: [], comb: '610ab', gG: 1.35, gQ: 1.5, xi: 0.85, NEd: 0, TEd: 0,
      var: [],
      acc: [], accPsi: 'psi1', accN: 0, accT: 0 },
    man: { MEd: [-140, 110, -160], MEk: [-100, 80, -115], MEqp: [-75, 60, -85], VL: 140, VR: 155, NEd: 0, TEd: 0, K: '1.3' },
    reb: { bot: zoneOf([]), top: zoneOf([]), topX: zoneOf([]), taLen: '', mid: { n: 0, d: 12, ys: '' }, vib: 40, vibOn: false, dB: 0, dT: 0 },
    supCfg: [], nodes: [],
    cont: { spans: [6, 6], left: 'pin', right: 'pin', cantL: 0, cantR: 0,
      rebSpans: [zoneOf([]), zoneOf([])],
      rebSupps: [Object.assign(zoneOf([]), { lenL: '', lenR: '' }), Object.assign(zoneOf([]), { lenL: '', lenR: '' }), Object.assign(zoneOf([]), { lenL: '', lenR: '' })],
      geoSpans: [], stirSpans: [] },
    surf: { d: 6, s: 100 },
    stir: { d: 8, legs: 2, kind: 'closed', s1: 150, s2: 250, sp: '', nz: 'auto', sAuto: true, hookA: 135, l1: 'auto', lp: 'auto', zl: {}, cot: 'auto', redV: true, ffd: 8, ffs: 200, e0: '' },
    anch: { shape: 'auto', lap: '50', sigma: 'fyd', bond: 'auto', Lmax: 12, innerB: 'anch', toEnd: 'all', alRed: false, pairSep: false },
    sls: { RH: 50, t0: 28, cem: 'N', t: 'inf', ts: 7, phiSel: 'auto', phi: 2.5, lim: 250, wSel: 'auto', sens: true, camber: '' },
    fire: { R: '-' },
    coef: { gc: 1.4, gs: 1.15, gcA: 1.2, gsA: 1.0, acc: 1.0, act: 1.0, k1: 0.6, k2: 0.45, k3: 0.8 },
  };
}
const VAR_KINDS = { imp: 'Obciążenia użytkowe', snow: 'Obciążenie śniegiem', wind: 'Oddziaływanie wiatru', other: 'Inne obciążenia zmienne' };
const SNOW_HIGH = { name: 'Śnieg (H > 1000 m n.p.m.)', p0: 0.7, p1: 0.5, p2: 0.2 };
function psiOf(it) {
  if (it.kind === 'imp') return PSI[it.cat] || PSI.B;
  if (it.kind === 'snow') return it.alt === 'high' ? SNOW_HIGH : PSI.S;
  if (it.kind === 'wind') return PSI.W;
  return { name: 'Inne (ψ podane)', p0: clamp(num(it.p0, 0.7), 0, 1), p1: clamp(num(it.p1, 0.5), 0, 1), p2: clamp(num(it.p2, 0.3), 0, 1) };
}
const optNum = v => (v === '' || v === null || v === undefined) ? '' : num(v, '');
function normPt(p) {
  p = p || {};
  return { P: num(p.P, 0), Pz: num(p.Pz, 0), T: num(p.T, 0), a: optNum(p.a), ref: ['L', 'R', 'rel'].includes(p.ref) ? p.ref : 'L' };
}
function normItem(it, kind) {
  const o = Object.assign({ kind: kind || 'imp', name: '', cat: 'B', alt: 'low', dir: 'y', span: 0, q: 0, qz: 0, x1: '', x2: '', pts: [], p0: 0.7, p1: 0.5, p2: 0.3 }, it || {});
  if (!['y', 'z', 'yz', 't'].includes(o.dir)) o.dir = 'y';
  o.span = Math.max(0, Math.round(num(o.span, 0)));
  // obciążenie na kilku przęsłach jednocześnie (jedno oddziaływanie): spans – numery odcinków (od 1)
  o.spans = Array.isArray(o.spans) ? Array.from(new Set(o.spans.map(v => Math.round(num(v, 0))).filter(v => v > 0))).sort((a, b) => a - b) : [];
  if (o.spans.length < 2) o.spans = []; else { o.span = o.spans[0]; o.el = ''; }
  o.tor = !!o.tor || o.dir === 't'; o.mt = num(o.mt, 0);
  o.top = o.top !== false;                    // przyłożone do górnej powierzchni (6.2.1(8))
  if (!o.spans.length) o.el = (o.el === '' || o.el === null || o.el === undefined || !(o.span > 0)) ? '' : Math.max(0, Math.round(num(o.el, 0)));
  o.qz = num(o.qz, 0);
  if (kind === 'acc' || kind === 'perm') o.kind = kind;
  else if (!VAR_KINDS[o.kind]) o.kind = 'imp';
  o.name = String(o.name || '');
  o.q = num(o.q, 0);
  o.x1 = optNum(o.x1); o.x2 = optNum(o.x2);
  // migracja z wersji 1.1: jedna siła P w położeniu a
  if ((!Array.isArray(o.pts) || !o.pts.length) && num(o.P, 0)) o.pts = [{ P: num(o.P, 0), a: optNum(o.a), ref: 'L' }];
  o.pts = (Array.isArray(o.pts) ? o.pts : []).map(normPt);
  delete o.P; delete o.a;
  ['p0', 'p1', 'p2'].forEach(k => o[k] = num(o[k], 0));
  // obciążenie użytkowe: podkategoria wg PN-EN 1991-1-1 (tabl. 6.2 itd.) i szerokość pasma zbierania obciążenia b [m] (kN/m² → kN/m)
  if (o.kind === 'imp') { const L = IMP_EC1[o.cat] || IMP_EC1.B; o.sub = L.some(q => q.id === o.sub) ? o.sub : L[0].id; o.bw = optNum(o.bw); if (o.bw !== '' && !(o.bw > 0)) o.bw = ''; o.qAuto = o.qAuto === true; }
  return o;
}

// uzupełnia brakujące pola wartościami domyślnymi i rzutuje liczby
function normalize(S0) {
  const D = defaultState();
  const S = JSON.parse(JSON.stringify(S0 || {}));
  // migracja z wersji 1.0 (jedno obciążenie zmienne)
  if (S.loads && S.loads.var === undefined && (S.loads.qk !== undefined || S.loads.QP !== undefined)) {
    const c = S.loads.cat || 'B';
    const kind = c === 'S' ? 'snow' : c === 'W' ? 'wind' : c === 'T' ? 'other' : 'imp';
    const ps = PSI[c] || PSI.B;
    S.loads.var = (num(S.loads.qk, 0) || num(S.loads.QP, 0)) ? [{ kind, name: ps.name, cat: kind === 'imp' ? c : 'B', q: num(S.loads.qk, 0), P: num(S.loads.QP, 0), a: S.loads.aP, p0: ps.p0, p1: ps.p1, p2: ps.p2 }] : [];
    if (S.loads.aG === undefined) S.loads.aG = S.loads.aP;
  }
  if (S.mat && S.mat.situation === 'A' && S.coef) { S.coef.gcA = S.coef.gc; S.coef.gsA = S.coef.gs; S.coef.gc = 1.4; S.coef.gs = 1.15; }
  for (const k of Object.keys(D)) {
    if (typeof D[k] !== 'object' || D[k] === null) { if (S[k] === undefined) S[k] = D[k]; continue; }
    if (typeof S[k] !== 'object' || S[k] === null) S[k] = {};
    for (const kk of Object.keys(D[k])) if (S[k][kk] === undefined) S[k][kk] = D[k][kk];
  }
  if (!(S0 && S0.loads && Array.isArray(S0.loads.perm))) S.loads.perm = [];
  const fix = (sec, keys) => keys.forEach(k => { S[sec][k] = num(S[sec][k], num(D[sec][k], 0)); });
  fix('geom', ['b', 'h', 'beff', 'hf', 'b1', 'b2', 'L', 't']);
  S.geom.l0t = (S.geom.l0t === '' || S.geom.l0t === null || S.geom.l0t === undefined) ? '' : num(S.geom.l0t, '');
  fix('mat', ['dg']);
  fix('env', ['life', 'dcdev', 'dcg', 'dcst', 'dcadd']);
  fix('loads', ['gk', 'gG', 'gQ', 'xi', 'NEd', 'TEd', 'accN', 'accT']);
  if (num(S.loads.GP, 0)) S.loads.perm = (Array.isArray(S.loads.perm) ? S.loads.perm : []).concat([{ name: 'Siła skupiona G', q: 0, pts: [{ P: num(S.loads.GP, 0), a: optNum(S.loads.aG), ref: 'L' }] }]);
  // obciążenie g_k „na całej długości” (wersje ≤ 2.3) → zwykłe obciążenie stałe na schemacie
  if (S.loads.gk) { S.loads.perm = [{ name: 'Obciążenie stałe g_k', q: S.loads.gk, span: 0, x1: '', x2: '', pts: [] }].concat(Array.isArray(S.loads.perm) ? S.loads.perm : []); S.loads.gk = 0; }
  S.loads.perm = (Array.isArray(S.loads.perm) ? S.loads.perm : []).map(it => normItem(it, 'perm'));
  ['qk', 'cat', 'QP', 'aP', 'GP', 'aG'].forEach(k => delete S.loads[k]);
  delete S.mat.situation;
  S.loads.var = (Array.isArray(S.loads.var) ? S.loads.var : []).map(it => normItem(it, it && it.kind));
  S.loads.acc = (Array.isArray(S.loads.acc) ? S.loads.acc : []).map(it => normItem(it, 'acc'));
  ['MEd', 'MEk', 'MEqp'].forEach(k => { S.man[k] = [0, 1, 2].map(i => num((S.man[k] || [])[i], 0)); });
  ['VL', 'VR', 'NEd', 'TEd'].forEach(k => S.man[k] = num(S.man[k], 0));
  // migracja zbrojenia z wersji ≤ 2.1 (grupy b1/b2, t1, ta) do stref z warstwami
  const R0 = S0 && S0.reb ? S0.reb : {};
  const old = R0.bot === undefined && (R0.b1n !== undefined || R0.t1n !== undefined);
  const oNb = clamp(Math.round(num(R0.nb, 1)), 1, 3), oNbT = clamp(Math.round(num(R0.nbT, 1)), 1, 3), oSh = ['v', 'h', 't'].includes(R0.nbShape) ? R0.nbShape : 'v';
  const oldBot = r => { const z = zoneOf([{ n: num(r.b1n, 4), d: num(r.b1d, 20) }, { n: num(r.b2n, 0), d: num(r.b2d, 16) }], { nb: oNb, shape: oSh, auto: true }); if (z.layers[0]) z.layers[0].toSupp = (r.bS === undefined || r.bS === 'all') ? 'all' : num(r.bS, 'all'); return z; };
  if (old) {
    S.reb = { bot: oldBot(R0), top: zoneOf([{ n: num(R0.t1n, 2), d: num(R0.t1d, 12) }], { auto: true }), topX: zoneOf([{ n: num(R0.tan, 0), d: num(R0.tad, 16) }], { nb: oNbT, shape: oSh, auto: true }),
      taLen: R0.taLen === undefined ? '' : R0.taLen, mid: { n: num(R0.mn, 0), d: num(R0.md, 12), ys: '' }, vib: num(R0.vib, 40) };
  }
  S.reb.bot = normZone(S.reb.bot, D.reb.bot); S.reb.top = normZone(S.reb.top, D.reb.top); S.reb.topX = normZone(S.reb.topX, D.reb.topX);
  const md0 = S.reb.mid && typeof S.reb.mid === 'object' ? S.reb.mid : {};
  S.reb.mid = { n: clamp(Math.round(num(md0.n, 0)), 0, 6), d: num(md0.d, 12), ys: typeof md0.ys === 'string' ? md0.ys : '' };
  S.reb.vib = Math.min(90, Math.max(20, num(S.reb.vib, 40)));
  S.reb.vibOn = S.reb.vibOn !== false;
  // średnice wybrane przez projektanta (wykres M w Danych): b<i> – dół przęsła, t – góra ciągła, x<i> – nad podporą (x – belka jednoprzęsłowa)
  { const d0 = S.reb.dSel && typeof S.reb.dSel === 'object' ? S.reb.dSel : {}, d1 = {}; Object.keys(d0).forEach(k => { if (/^(b\d+|t|x\d*)$/.test(k) && BAR_MAIN.includes(+d0[k])) d1[k] = +d0[k]; }); S.reb.dSel = d1; }
  S.reb.sameD = S.reb.sameD !== false;
  // średnice prętów zadane w Materiałach (0 – dobór automatyczny): dB – dolne, dT – górne (ciągłe i dodatkowe nad podporami)
  S.reb.dB = BAR_MAIN.includes(+S.reb.dB) ? +S.reb.dB : 0; S.reb.dT = BAR_MAIN.includes(+S.reb.dT) ? +S.reb.dT : 0;
  S.design = { eta: clamp(Math.round(num(S.design && S.design.eta, 100)), 50, 100) };   // wytężenie docelowe [%] – automatyczny dobór przekrojów i zbrojenia                                   // dobór: jednakowa średnica prętów na krawędzi przekroju                                   // prześwit na buławę wibratora (8.2(4)) – uwzględniany / pominięty
  S.reb.useComp = S.reb.useComp !== false;
  S.loads.redM = S.loads.redM === true;
  S.loads.NEdX = S.loads.NEdX === '' || S.loads.NEdX === undefined || S.loads.NEdX === null || !isFinite(+S.loads.NEdX) ? '' : +S.loads.NEdX;   // miejsce przyłożenia siły podłużnej (rysunek)
  S.loads.redist = S.loads.redist === 'auto' ? 'auto' : (+S.loads.redist >= 0.7 && +S.loads.redist < 1 ? +S.loads.redist : '');
  S.anch.innerB = ['anch', 'lap', 'cont'].includes(S.anch.innerB) ? S.anch.innerB : 'lap';          // pręty dolne nad podporą pośrednią: zakotwienie ≥ 10⌀ za licem albo zakład l₀
  S.anch.toEnd = ['50', '25'].includes(String(S.anch.toEnd)) ? String(S.anch.toEnd) : 'all';
  S.sls.camber = S.sls.camber === 'auto' ? 'auto' : (S.sls.camber === '' || S.sls.camber === undefined || S.sls.camber === null || !(+S.sls.camber > 0) ? '' : Math.max(0, num(S.sls.camber, 0)));
  // odwrotna strzałka w poszczególnych odcinkach (klucz – indeks odcinka belki): '' – jak ogólna, 'auto', 0 – bez strzałki, w₀ [mm]
  { const c0 = S.sls.camberSeg && typeof S.sls.camberSeg === 'object' ? S.sls.camberSeg : {}, c1 = {};
    Object.keys(c0).forEach(k => { const v = c0[k]; if (!/^\d+$/.test(k)) return; if (v === 'auto') c1[k] = 'auto'; else if (v !== '' && v !== null && v !== undefined && isFinite(+v) && +v >= 0) c1[k] = Math.round(+v * 10) / 10; });
    S.sls.camberSeg = c1; }
  S.mat.autoC = S.mat.autoC === true;
  ['b1n', 'b1d', 'b2n', 'b2d', 'bS', 't1n', 't1d', 'tan', 'tad', 'nb', 'nbT', 'nbShape', 'mn', 'md'].forEach(k => delete S.reb[k]);
  // podpory: blokady przesuwu x, y, z i obrotu r (dof); dawny rodzaj ('roller' | 'pin' | 'fix') → blokady
  const optP = v => (v === '' || v == null) ? '' : Math.max(0, num(v, ''));
  S.supCfg = (Array.isArray(S.supCfg) ? S.supCfg : []).slice(0, 12).map(c => {
    if (!c || typeof c !== 'object') return { dof: null, kv: '', kr: '', t: '', hinge: false, direct: true };
    const dof = c.dof && typeof c.dof === 'object' ? { x: !!c.dof.x, y: c.dof.y !== false, z: c.dof.z !== false, r: !!c.dof.r } : (SUP_DOF[c.type] ? Object.assign({}, SUP_DOF[c.type]) : null);
    return { dof, kv: optP(c.kv), kr: optP(c.kr), t: optP(c.t), hinge: !!c.hinge, direct: c.direct !== false };
  });
  // węzły użytkownika w odcinkach (podział na elementy, przeguby): seg – nr odcinka, a – odległość od początku odcinka [m]
  S.nodes = (Array.isArray(S.nodes) ? S.nodes : []).filter(n => n && typeof n === 'object').slice(0, 60)
    .map(n => ({ seg: Math.max(0, Math.round(num(n.seg, 0))), a: Math.max(0, num(n.a, 0)), hinge: !!n.hinge })).filter(n => n.a > 0);
  S.anch.Lmax = Math.max(0, num(S.anch.Lmax, 12));
  // redukcje dopuszczane przez normę – tylko po zaznaczeniu przez projektanta: α₂ (otulina) i α₅ (docisk poprzeczny) w l_bd (tab. 8.2),
  // para prętów jeden nad drugim jak pręty pojedyncze (8.9.1(4))
  S.anch.alRed = S.anch.alRed === true; S.anch.pairSep = S.anch.pairSep === true;
  // zakończenie prętów: 'auto' – proste, a gdy prosty pręt się nie mieści – odgięcie / hak (wcześniejsze „pręty proste” działały tak samo);
  // 'line' – wyłącznie proste (bez odginania), 'hook' – haki / odgięcia / pętle (α₁ = 0,7 przy c_d > 3⌀)
  S.anch.shape = S.anch.shape === 'hook' ? 'hook' : S.anch.shape === 'line' ? 'line' : 'auto';
  // schematy „utwierdzona – przegubowa” i „obustronnie utwierdzona” (≤ 2.3) → belka jednoprzęsłowa z utwierdzeniem na podporach
  if (S.scheme === 'pf' || S.scheme === 'ff') {
    const fx = { dof: Object.assign({}, SUP_DOF.fix), kv: '', kr: '', t: '', hinge: false, direct: true };
    while (S.supCfg.length < 2) S.supCfg.push({ dof: null, kv: '', kr: '', t: '', hinge: false, direct: true });
    if (!S.supCfg[0].dof) S.supCfg[0] = Object.assign({}, S.supCfg[0], { dof: fx.dof });
    if (S.scheme === 'ff' && !S.supCfg[1].dof) S.supCfg[1] = Object.assign({}, S.supCfg[1], { dof: Object.assign({}, SUP_DOF.fix) });
    S.scheme = 'ss';
  }
  if (S.scheme === 'manual') S.scheme = 'ss';      // „przęsło belki ciągłej – siły ręcznie” usunięte w 2.5
  if (!SCHEMES[S.scheme]) S.scheme = 'ss';
  // otulina osobno dla krawędzi (puste – c_nom)
  ['cBot', 'cTop', 'cSide'].forEach(k => { S.env[k] = (S.env[k] === '' || S.env[k] == null) ? '' : Math.max(0, num(S.env[k], '')); });
  if (!['closed', 'pins', 'open', 'tors'].includes(S.stir.kind)) S.stir.kind = 'closed';
  const optLen = v => (v === '' || v === null || v === undefined) ? '' : Math.max(0, num(v, ''));
  S.reb.taLen = optLen(S.reb.taLen);
  S.stir.e0 = (S.stir.e0 === '' || S.stir.e0 === null || S.stir.e0 === undefined) ? '' : clamp(num(S.stir.e0, 30), 0, 50);
  S.stir.hook = (S.stir.hook === '' || S.stir.hook == null) ? '' : Math.max(0, num(S.stir.hook, ''));
  S.stir.hookA = +S.stir.hookA === 90 ? 90 : 135;
  S.stir.sAuto = S.stir.sAuto === true;
  S.stir.bent = S.stir.bent === 'off' ? 'off' : 'auto';
  S.stir.nz = ['1', '2', '3'].includes(String(S.stir.nz)) ? String(S.stir.nz) : 'auto';
  S.stir.sp = S.stir.sp === '' || S.stir.sp === null || S.stir.sp === undefined || !(+S.stir.sp > 0) ? '' : Math.max(30, num(S.stir.sp, 150));
  S.sls.phiSel = ['auto', 'manual', 'off'].includes(S.sls.phiSel) ? S.sls.phiSel : 'auto';
  S.stir.lp = S.stir.lp === 'auto' || S.stir.lp === '' || S.stir.lp === undefined || S.stir.lp === null ? 'auto' : String(Math.max(0, num(S.stir.lp, 0)));
  // długości stref zagęszczenia przy poszczególnych podporach (z wykresu V w Danych): klucz „indeks podpory + L/P strona” → { l1, lp } [m]
  { const zl = {}; Object.entries(S.stir.zl && typeof S.stir.zl === 'object' ? S.stir.zl : {}).forEach(([k, v]) => { if (!/^\d+[LR]$/.test(k) || !v || typeof v !== 'object') return;
      const o = {}; ['l1', 'lp'].forEach(f => { if (v[f] !== undefined && v[f] !== '' && v[f] !== null && v[f] !== 'auto' && isFinite(+v[f])) o[f] = String(Math.max(0, +v[f])); }); if (Object.keys(o).length) zl[k] = o; });
    S.stir.zl = zl; }
  S.stir.d = Math.min(12, Math.max(6, num(S.stir.d, 8)));
  // ręczne zmiany wymiarów prętów (wyciągi / widok podłużny): klucz strefy → { len – odcinek prosty, legL/legR – odgięcia [mm], dirL/dirR }
  { const BE = S.barEdit && typeof S.barEdit === 'object' && !Array.isArray(S.barEdit) ? S.barEdit : {}, out = {};
    const nv = v => (v === '' || v == null) ? '' : Math.max(0, Math.round(num(v, 0)));
    const sv = v => (v === '' || v == null || !isFinite(+v) || Math.round(+v) === 0) ? '' : Math.round(clamp(+v, -20000, 20000));      // przedłużenie (+) / skrócenie (−) końca [mm]
    Object.keys(BE).forEach(k => { const e = BE[k] || {}; if (!/^(b|t|x|m)\d*$/.test(k)) return; const o = { len: nv(e.len), legL: nv(e.legL), legR: nv(e.legR), dirL: ['up', 'down'].includes(e.dirL) ? e.dirL : '', dirR: ['up', 'down'].includes(e.dirR) ? e.dirR : '', lapC: +e.lapC > 0 ? +e.lapC : '', lapL: nv(e.lapL), dL: sv(e.dL), dR: sv(e.dR) }; if (o.len !== '' || o.legL !== '' || o.legR !== '' || o.lapC !== '' || o.dL !== '' || o.dR !== '') out[k] = o; });
    S.barEdit = out; }
  // otulina: dawny wybór wartości z listy -> tryb ręczny
  if (S.env.cnomSel !== 'auto' && S.env.cnomSel !== 'manual') { const v = num(S.env.cnomSel, null); S.env.cnomSel = v === null ? 'auto' : 'manual'; if (v !== null) S.env.cnomVal = v; }
  S.env.cnomVal = num(S.env.cnomVal, 30);
  // belka ciągła
  const C = S.cont;
  C.spans = (Array.isArray(C.spans) && C.spans.length ? C.spans : D.cont.spans).map(v => Math.max(0.3, num(v, 6))).slice(0, 10);
  if (C.spans.length < 2) C.spans.push(C.spans[0]);
  ['cantL', 'cantR'].forEach(k => { C[k] = Math.max(0, num(C[k], 0)); });
  if (!['pin', 'fix'].includes(C.left)) C.left = 'pin';
  if (!['pin', 'fix'].includes(C.right)) C.right = 'pin';
  const nSp = C.spans.length;
  C.rebSpans = (Array.isArray(C.rebSpans) ? C.rebSpans : []).slice(0, nSp).map(r => (r && !r.layers && r.b1n !== undefined) ? oldBot(r) : r);
  while (C.rebSpans.length < nSp) C.rebSpans.push(JSON.parse(JSON.stringify(C.rebSpans[C.rebSpans.length - 1] || S.reb.bot)));
  C.rebSpans = C.rebSpans.map(r => normZone(r, D.cont.rebSpans[0]));
  C.rebSupps = (Array.isArray(C.rebSupps) ? C.rebSupps : []).slice(0, nSp + 1);
  while (C.rebSupps.length < nSp + 1) C.rebSupps.push(Object.assign(zoneOf([]), { lenL: '', lenR: '' }));
  C.rebSupps = C.rebSupps.map(r => {
    const z = (r && !r.layers && r.tan !== undefined) ? zoneOf([{ n: num(r.tan, 0), d: num(r.tad, 16) }], { nb: oNbT, shape: oSh, auto: true }) : r;
    const optExt = v => (v === '' || v === null || v === undefined || !isFinite(+v) || +v === 0) ? '' : clamp(+v, -20, 20);     // przedłużenie (+) / skrócenie (−) [m]
    return Object.assign(normZone(z, zoneOf([])), { lenL: optLen(r && r.lenL), lenR: optLen(r && r.lenR), extL: optExt(r && r.extL), extR: optExt(r && r.extR) });
  });
  // przekroje i strzemiona poszczególnych przęseł (puste pola – wartości ogólne)
  const oN = v => (v === '' || v == null) ? '' : num(v, '');
  C.geoSpans = Array.from({ length: nSp }, (_, i) => { const q = (Array.isArray(C.geoSpans) ? C.geoSpans : [])[i] || {}; return { b: oN(q.b), h: oN(q.h) }; });
  C.stirSpans = Array.from({ length: nSp }, (_, i) => { const q = (Array.isArray(C.stirSpans) ? C.stirSpans : [])[i] || {}; return { d: q.d > 12 ? 12 : oN(q.d), legs: oN(q.legs), s1: oN(q.s1), s2: oN(q.s2), sp: oN(q.sp), hook: oN(q.hook), hookA: +q.hookA === 90 ? 90 : +q.hookA === 135 ? 135 : '', kind: ['closed', 'pins', 'open', 'tors'].includes(q.kind) ? q.kind : '' }; });
  S.surf.d = num(S.surf.d, 6); S.surf.s = Math.max(20, num(S.surf.s, 100));
  if (typeof S.meta.ticks !== 'object' || S.meta.ticks === null || Array.isArray(S.meta.ticks)) S.meta.ticks = {};
  fix('stir', ['d', 'legs', 's1', 's2', 'ffd', 'ffs']);
  fix('sls', ['RH', 't0', 'ts', 'phi', 'lim']);
  fix('coef', ['gc', 'gs', 'gcA', 'gsA', 'acc', 'act', 'k1', 'k2', 'k3']);
  // minimalna klasa betonu wg klas ekspozycji (zał. E) – przy automatycznym doborze klasy nie mniejsza niż wymagana
  if (S.mat.autoC) { let mc = null; [S.env.exp, S.env.expF, S.env.expA].filter(e => e && e !== '-').forEach(e => { const c = MIN_CLASS[e]; if (c && (!mc || classIdx(c) > classIdx(mc))) mc = c; }); if (mc && classIdx(S.mat.concrete) < classIdx(mc)) S.mat.concrete = mc; }
  return S;
}

/* ------------------------------------------------------------- materiały */
function materials(S) {
  const c = CONCRETE[S.mat.concrete] || CONCRETE['C30/37'];
  const st = STEEL[S.mat.steel] || STEEL.B500SP;
  const sw = STEEL[S.mat.steelW] || STEEL.B500SP;
  const k = S.coef;
  const m = { c, st, sw, fck: c.fck, fcm: c.fck + 8, fctm: c.fctm, fctk05: c.fctk05, Ecm: c.Ecm * 1000,
    gc: k.gc, gs: k.gs, acc: k.acc, act: k.act };
  m.fcd = k.acc * c.fck / k.gc;
  m.fctd = k.act * c.fctk05 / k.gc;
  m.fctdBond = k.act * Math.min(c.fctk05, CONCRETE['C60/75'].fctk05) / k.gc;
  m.lambda = c.fck <= 50 ? 0.8 : 0.8 - (c.fck - 50) / 400;
  m.eta = c.fck <= 50 ? 1.0 : 1.0 - (c.fck - 50) / 200;
  m.ec2 = c.ec2 / 1000; m.ecu2 = c.ecu2 / 1000; m.npar = c.n; m.ec3 = c.ec3 / 1000; m.ecu3 = c.ecu3 / 1000;
  m.diag = S.mat.diag === 'parab' ? 'parab' : 'rect';
  if (m.diag === 'rect') { m.ec = m.ec3; m.ecu = m.ecu3; } else { m.ec = m.ec2; m.ecu = m.ecu2; }
  m.Es = 200000; m.fyk = st.fyk; m.fyd = st.fyk / k.gs; m.eyd = m.fyd / m.Es;
  m.euk = st.euk / 100; m.eud = 0.9 * m.euk;
  m.fywk = sw.fyk; m.fywd = sw.fyk / k.gs;
  m.nu = 0.6 * (1 - c.fck / 250);
  m.xiLim = m.ecu3 / (m.ecu3 + m.eyd);          // ξ_lim = x_lim/d
  m.xiEffLim = m.lambda * m.xiLim;                // ξ_eff,lim = λ·ξ_lim
  return m;
}

/* -------------------------------------------------------------- geometria */
function sectionParts(g, flip) {
  let parts = g.T ? [{ y0: 0, y1: g.hf, b: g.beff }, { y0: g.hf, y1: g.h, b: g.bw }] : [{ y0: 0, y1: g.h, b: g.bw }];
  if (flip) parts = parts.map(p => ({ y0: g.h - p.y1, y1: g.h - p.y0, b: p.b })).reverse();
  return parts;
}
function grossProps(parts) {
  let A = 0, S = 0, I0 = 0;
  parts.forEach(p => { const d = p.y1 - p.y0; A += p.b * d; S += p.b * (p.y1 * p.y1 - p.y0 * p.y0) / 2; I0 += p.b * (p.y1 ** 3 - p.y0 ** 3) / 3; });
  const yc = S / A; return { A, yc, I: I0 - A * yc * yc };
}
// pole i moment statyczny (względem góry) fragmentu przekroju między ya i yb
function areaBetween(parts, ya, yb) {
  let A = 0, Ay = 0;
  parts.forEach(p => {
    const a = Math.max(ya, p.y0), b = Math.min(yb, p.y1);
    if (b > a) { A += p.b * (b - a); Ay += p.b * (b * b - a * a) / 2; }
  });
  return { A, Ay };
}
function widthAt(parts, y) { for (const p of parts) if (y >= p.y0 - 1e-9 && y <= p.y1 + 1e-9) return p.b; return 0; }

function geometry(S, R) {
  const G = S.geom, T = G.type === 'T';
  const cont = S.scheme === 'cont';
  const g = { T, bw: G.b, h: G.h, L: cont ? Math.max(...S.cont.spans) * 1000 : G.L * 1000, t: G.t, hf: T ? G.hf : 0 };
  const sch = SCHEMES[S.scheme] || SCHEMES.ss;
  let l0f = sch.l0;
  if (!cont && S.scheme !== 'cant' && S.scheme !== 'manual') {
    const dd = SUP_DEF[S.scheme] || SUP_DEF.ss, nFix = [0, 1].filter(i => { const c = (S.supCfg || [])[i]; return c && c.dof ? c.dof.r : dd[i] === 'fix'; }).length;
    l0f = nFix === 2 ? 0.7 : nFix === 1 ? 0.85 : 1.0;
  }
  g.l0 = cont ? 0.7 * Math.min(...S.cont.spans) * 1000 : l0f * g.L;
  if (T) {
    if (G.beffMode === 'auto') {
      const bi = [G.b1, G.b2].map(b => Math.max(0, Math.min(0.2 * b + 0.1 * g.l0, 0.2 * g.l0, b)));
      g.beffParts = bi; g.beff = g.bw + bi[0] + bi[1]; g.beffAuto = true;
    } else g.beff = G.beff;
  } else g.beff = g.bw;
  if (!(g.bw > 50 && g.h > 100)) R.errors.push('Nieprawidłowe wymiary przekroju (b > 50 mm, h > 100 mm).');
  if (!(g.L > 300)) R.errors.push('Rozpiętość L musi być większa od 0,3 m.');
  if (T && !(g.hf > 0 && g.hf < g.h)) R.errors.push('Grubość półki h_f musi spełniać 0 < h_f < h.');
  if (T && !(g.beff >= g.bw)) R.errors.push('Szerokość współpracująca b_eff musi być ≥ b_w.');
  if (R.errors.length) return g;
  g.partsS = sectionParts(g, false);
  g.partsH = sectionParts(g, true);
  const gp = grossProps(g.partsS); g.Ac = gp.A; g.yc = gp.yc; g.Ic = gp.I;
  g.u = T ? 2 * (g.beff + g.h) : 2 * (g.bw + g.h);
  g.h0 = 2 * g.Ac / g.u;
  g.selfW = 25e-6 * (T ? g.bw * (g.h - g.hf) : g.bw * g.h); // kN/m
  g.l0t = (G.l0t === '' || !(G.l0t > 0)) ? g.L : G.l0t * 1000;
  g.bFlange = T ? g.beff : g.bw;
  return g;
}

/* ---------------------------------------------------------------- otulina */
function coverCalc(S, m, dMain, dSw) {
  const env = S.env;
  const exp = EXP_COL[env.exp] !== undefined ? env.exp : 'XC1';
  let sc = 4; const mods = ['klasa wyjściowa S4'];
  if (+env.life >= 100) { sc += 2; mods.push('+2: projektowy okres użytkowania 100 lat'); }
  const thr = SC_STRENGTH[exp];
  // obniżenie klasy konstrukcji o 1 za klasę wytrzymałości betonu (tab. 4.3N) – tylko po zaznaczeniu przez projektanta (env.scRed)
  const redPossible = !!(thr && classIdx(S.mat.concrete) >= classIdx(thr));
  if (redPossible && env.scRed) { sc -= 1; mods.push(`−1: klasa betonu ≥ ${thr} (tab. 4.3N, przyjęte przez projektanta)`); }
  else if (redPossible) mods.push(`możliwe −1: klasa betonu ≥ ${thr} (tab. 4.3N) – nieuwzględnione`);
  if (env.qc) { sc -= 1; mods.push('−1: zapewniona specjalna kontrola jakości'); }
  sc = clamp(sc, 1, 6);
  let scAuto = sc;
  if (env.scSel && env.scSel !== 'auto') { sc = clamp(parseInt(String(env.scSel).replace('S', ''), 10) || 4, 1, 6); mods.push(`przyjęto ręcznie S${sc}`); }
  const cdur = CMIN_DUR[sc - 1][EXP_COL[exp]];
  const cdurRed = redPossible && !env.scRed && !(env.scSel && env.scSel !== 'auto') ? CMIN_DUR[clamp(sc - 1, 1, 6) - 1][EXP_COL[exp]] : null;   // c_min,dur po obniżeniu (informacja)
  const dg = S.mat.dg, add = dg > 32 ? 5 : 0;
  const cminb_sw = dSw + add, cminb_main = dMain + add;
  const cdurNet = cdur + env.dcg - env.dcst - env.dcadd;
  const cmin_sw = Math.max(cminb_sw, cdurNet, 10);
  const cmin_main = Math.max(cminb_main, cdurNet, 10);
  const dcdev = env.dcdev;
  const cnom_sw = cmin_sw + dcdev, cnom_main = cmin_main + dcdev;
  const ground = env.cast === 'prep' ? 40 : env.cast === 'ground' ? 75 : 0;
  const req = Math.max(cnom_sw, cnom_main - dSw, ground);
  const reqR = ceilTo(req, 5);
  const reqNG = Math.max(cnom_sw, cnom_main - dSw), reqNGR = ceilTo(reqNG, 5);       // góra i boki – bez wymagania betonowania na podłożu
  const manual = env.cnomSel === 'manual';
  const cnom = manual ? Math.max(0, num(env.cnomVal, reqR)) : reqR;
  // minimalna klasa betonu (Tablica E.1N)
  const exps = [exp]; if (env.expF && env.expF !== '-') exps.push(env.expF); if (env.expA && env.expA !== '-') exps.push(env.expA);
  let minCls = 'C12/15', minFrom = 'X0';
  exps.forEach(e => { const c = MIN_CLASS[e]; if (c && classIdx(c) > classIdx(minCls)) { minCls = c; minFrom = e; } });
  return { exp, exps, sc, scAuto, mods, cdur, redPossible, scRed: !!env.scRed, cdurRed, thr, add, cminb_sw, cminb_main, cdurNet, cmin_sw, cmin_main, dcdev,
    cnom_sw, cnom_main, ground, req, reqR, reqNG, reqNGR, cnom, manual, dMain, dSw, minCls, minFrom, minOk: classIdx(S.mat.concrete) >= classIdx(minCls) };
}

/* ------------------------------------------------------- układ prętów */
// jednostka = pręt pojedynczy lub wiązka nb prętów (8.9): do odstępów i otuliny – średnica zastępcza ⌀n = ⌀·√nb
// shape: 'v' – pręty jeden nad drugim (bez odstępu), 'h' – obok siebie, 't' – trójkąt (3 pręty)
// sep: para prętów jeden nad drugim w dobrych warunkach przyczepności nie musi być traktowana jak wiązka (8.9.1(4)) – ⌀ zamiast ⌀n
function unitOf(d, nb, shape, sep) {
  nb = nb || 1;
  if (nb === 1) return { d, dBar: d, nb: 1, shape: '', w: d, hgt: d, cg: d / 2, A: area(d), dn: d };
  shape = shape === 'h' ? 'h' : (shape === 't' && nb === 3 ? 't' : 'v');
  const dn = d * Math.sqrt(nb);
  const dEff = sep && nb === 2 && shape === 'v' ? d : dn;
  const base = { dBar: d, nb, shape, A: nb * area(d), dn, d: dEff, sep: dEff === d };
  if (shape === 'h') return Object.assign(base, { w: nb * d, hgt: d, cg: d / 2 });
  if (shape === 't') return Object.assign(base, { w: 2 * d, hgt: d * (1 + Math.sqrt(3) / 2), cg: d / 2 + d * Math.sqrt(3) / 6 });
  return Object.assign(base, { w: d, hgt: nb * d, cg: nb * d / 2 });
}
function layoutSide(groups, g, cnom, dsw, dg) {
  const list = []; groups.forEach(gr => { for (let i = 0; i < gr.n; i++) list.push(unitOf(gr.d, gr.nb, gr.shape, gr.sep)); });
  list.sort((a, b) => b.d - a.d || b.w - a.w);
  const bClear = g.bw - 2 * (cnom + dsw);
  const layers = []; let idx = 0;
  while (idx < list.length && layers.length < 6) {
    const L = []; let w = 0;
    while (idx < list.length) {
      const u = list[idx];
      const smin = Math.max(Math.max(u.d, ...L.map(v => v.d), 0), dg + 5, 20);
      const need = L.length ? w + smin + u.w : u.w;
      if (L.length === 0 || need <= bClear + 1e-6) { L.push(u); w = need; idx++; } else break;
    }
    layers.push(L);
  }
  const res = { layers: [], bars: [], bClear, ok: idx >= list.length && layers.length <= 3 };
  const e0 = cnom + dsw; let prevTop = e0, prevMax = 0;
  const x0 = (g.beff - g.bw) / 2 + cnom + dsw;
  let cols = null;                                        // kolumny warstwy 1 (8.2(4): pręty kolejnych warstw nad prętami warstwy 1)
  layers.forEach((L, k) => {
    const dmax = Math.max(...L.map(u => u.d)), hmax = Math.max(...L.map(u => u.hgt));
    const sv = k > 0 ? Math.max(dmax, prevMax, dg + 5, 20) : 0;
    const edge = k === 0 ? e0 : prevTop + sv;
    const sorted = L.slice().sort((a, b) => b.d - a.d);
    const left = [], right = [];
    sorted.forEach((u, i) => (i % 2 === 0 ? left : right).push(u));
    const ord = [...left, ...right.reverse()];
    const n = ord.length;
    let xs = [];
    if (k > 0 && cols && cols.length >= n && cols.length > 1) {
      const pick = []; for (let i = 0, a = 0, b = cols.length - 1; i < n; i++) pick.push(i % 2 === 0 ? a++ : b--);
      pick.sort((u, v) => u - v);
      xs = pick.map(i => cols[i]);
    } else if (n === 1) xs = [g.beff / 2];
    else {
      const sumw = ord.reduce((a, u) => a + u.w, 0), gp = (bClear - sumw) / (n - 1);
      let x = x0; ord.forEach(u => { xs.push(x + u.w / 2); x += u.w + gp; });
    }
    if (k === 0) cols = xs.slice();
    let gap = Infinity;
    for (let i = 0; i < n - 1; i++) gap = Math.min(gap, (xs[i + 1] - ord[i + 1].w / 2) - (xs[i] + ord[i].w / 2));
    if (n < 2) gap = 0;
    const sminL = Math.max(dmax, dg + 5, 20);
    const eC = edge + (ord.reduce((a, u) => a + u.A * u.cg, 0) / ord.reduce((a, u) => a + u.A, 0));
    res.layers.push({ n, ds: ord.map(u => u.d), e: eC, edge, gap, smin: sminL, sv: k > 0 ? sv : null, ok: n < 2 || gap >= sminL - 1e-6, dmax,
      cc: n > 1 ? (xs[n - 1] - xs[0]) / (n - 1) : 0, xs, ws: ord.map(u => u.w), aligned: k > 0 && cols && cols.length >= n });
    ord.forEach((u, i) => res.bars.push({ x: xs[i], e: edge + u.cg, edge, d: u.d, dBar: u.dBar, dn: u.dn, nb: u.nb, shape: u.shape, sep: !!u.sep, A: u.A, layer: k }));
    prevTop = edge + hmax; prevMax = dmax;
  });
  // największy prześwit między kolumnami prętów (dostęp buławy wibratora, 8.2(4))
  if (res.layers.length) {
    const L0 = res.layers[0];
    let og = 0;
    if (L0.n === 1) og = (bClear - L0.ws[0]) / 2;
    else for (let i = 0; i < L0.n - 1; i++) og = Math.max(og, (L0.xs[i + 1] - L0.ws[i + 1] / 2) - (L0.xs[i] + L0.ws[i] / 2));
    res.open = og;
  } else res.open = bClear;
  res.stacked = res.layers.length > 1 || res.bars.some(b => b.nb > 1 && b.shape !== 'h');
  res.A = res.bars.reduce((a, b) => a + b.A, 0);
  res.eC = res.A > 0 ? res.bars.reduce((a, b) => a + b.A * b.e, 0) / res.A : 0;
  res.n = res.bars.length;
  res.nBars = res.bars.reduce((a, b) => a + b.nb, 0);
  res.dmax = res.n ? Math.max(...res.bars.map(b => b.d)) : 0;
  res.dnMax = res.n ? Math.max(...res.bars.map(b => b.dn || b.d)) : 0;
  res.dBarMax = res.n ? Math.max(...res.bars.map(b => b.dBar)) : 0;
  const shp = { v: 'pionowo', h: 'poziomo', t: 'trójkąt' };
  res.desc = groups.filter(x => x.n > 0).map(x => (x.nb || 1) > 1 ? `${x.n}×${x.nb}⌀${x.d}` : `${x.n}⌀${x.d}`).join(' + ') || '—';
  const bu = groups.find(x => x.n > 0 && (x.nb || 1) > 1);
  if (bu) res.bundle = `wiązki po ${bu.nb} (${shp[bu.nb === 3 && bu.shape === 't' ? 't' : bu.shape === 'h' ? 'h' : 'v']})`;
  return res;
}
// układ strefy zbrojenia: warstwy, rozmieszczenie poziome (równomierne / normowe od naroży / parami / współrzędne), odstęp pionowy
// o.base – strefa prętów ciągłych łączona warstwami z prętami dodatkowymi nad podporą (o.baseLay – jej układ w przęśle)
function layoutZone(zone, g, cnom, dsw, dg, o) {
  o = o || {};
  const cE = typeof cnom === 'object' ? cnom.e : cnom, cS = typeof cnom === 'object' ? cnom.s : cnom;   // otulina krawędzi (dół/góra) i boków
  const x0 = (g.beff - g.bw) / 2 + cS + dsw, bClear = g.bw - 2 * (cS + dsw), xWeb = (g.beff - g.bw) / 2;
  const mk = (gr, z, sp, tag) => { const out = []; for (let i = 0; i < gr.n; i++) out.push(Object.assign(unitOf(gr.d, z.nb || 1, z.shape, sp), { tag })); return out; };
  const specsOf = (z, sp, tag) => {
    if (!z || !z.layers || !z.layers.length) return [];
    if (z.auto) {                                           // układ automatyczny (projekty z wersji ≤ 2.1): przelewanie do kolejnych warstw
      const all = []; z.layers.forEach(ly => ly.bars.forEach(gr => all.push(...mk(gr, z, sp, tag))));
      all.sort((a, b) => b.d - a.d || b.w - a.w);
      const ts = z.layers[0].toSupp, k = ts === 'all' ? Infinity : Math.max(1, ts);
      all.forEach((u, i) => { u.suppRank = i < k; });
      const out = []; let idx = 0;
      while (idx < all.length && out.length < 6) {
        const L = []; let w = 0;
        while (idx < all.length) { const u = all[idx], smin = Math.max(u.d, ...L.map(v => v.d), dg + 5, 20), need = L.length ? w + smin + u.w : u.w; if (!L.length || need <= bClear + 1e-6) { L.push(u); w = need; idx++; } else break; }
        out.push({ units: L, place: 'pair', auto: true, xs: '', gap: '', toSupp: 'rank' });
      }
      return out;
    }
    return z.layers.map((ly, k) => { const L = []; ly.bars.forEach(gr => L.push(...mk(gr, z, sp, tag))); const touch = k > 0 && ly.touch === true; return { units: L, place: k === 0 && ly.place === 'pair' ? 'even' : touch ? 'pair' : ly.place, xs: ly.xs, gap: touch ? 0 : ly.gap, toSupp: ly.toSupp, touch }; });
  };
  const own = specsOf(zone, !!o.sep, 'z'), base = o.base ? specsOf(o.base, !!o.baseSep, 'b') : [];
  const nL = Math.max(own.length, base.length);
  const parseXs = t => String(t || '').split(/[;\s]+/).map(v => parseFloat(v.replace(',', '.'))).filter(v => isFinite(v));
  const srt = arr => arr.slice().sort((a, b) => b.d - a.d);
  const alt = arr => { const l = [], r = []; srt(arr).forEach((u, i) => (i % 2 ? r : l).push(u)); return [l, r.reverse()]; };
  const res = { layers: [], bars: [], bClear, x0, issues: [] };
  let prevEdge = cE + dsw, prevH = 0, prevDmax = 0, cols = null;
  for (let k = 0; k < nL; k++) {
    const sb = base[k], so = own[k];
    const bU = sb ? sb.units : [], oU = so ? so.units : [];
    const units = [...bU, ...oU];
    if (!units.length) continue;
    const spec = so || sb;
    const mode = spec.place || 'even';
    const n = units.length, dmax = Math.max(...units.map(u => u.d)), hmax = Math.max(...units.map(u => u.hgt));
    const smin = Math.max(dmax, dg + 5, 20);
    // odstęp pionowy od poprzedniej warstwy
    const touch = !!spec.touch && res.layers.length > 0;
    const svMin = res.layers.length && !touch ? Math.max(dmax, prevDmax, dg + 5, 20) : 0;
    const gapMan = spec.gap !== '' && spec.gap !== undefined && spec.gap !== null;
    const sv = res.layers.length ? (touch ? 0 : gapMan ? +spec.gap : svMin) : 0;
    const edge = res.layers.length ? prevEdge + prevH + sv : prevEdge;
    // kolejność i położenia poziome
    let ord, xs = [], aligned = false;
    if (mode === 'manual') {
      ord = units;
      const xb = sb && o.baseLay && o.baseLay.layers[k] ? o.baseLay.layers[k] : null;
      const man = parseXs(so ? so.xs : sb.xs);
      // pręty ciągłe zachowują położenie z przęsła; pozostałe – współrzędne od lewej krawędzi środnika
      const fixedB = bU.map((u, i) => xb && xb.xs[i] !== undefined ? xb.xs[i] : null);
      const freeU = oU.length ? oU : bU;
      const ev = []; { const sumw = freeU.reduce((a, u) => a + u.w, 0), gp = freeU.length > 1 ? (bClear - sumw) / (freeU.length - 1) : 0; let x = x0; freeU.forEach(u => { ev.push(freeU.length > 1 ? x + u.w / 2 : g.beff / 2); x += u.w + gp; }); }
      if (oU.length) { bU.forEach((u, i) => xs.push(fixedB[i] !== null ? fixedB[i] : x0 + u.w / 2)); oU.forEach((u, i) => xs.push(man[i] !== undefined ? xWeb + man[i] : ev[i])); }
      else bU.forEach((u, i) => xs.push(man[i] !== undefined ? xWeb + man[i] : ev[i]));
    } else {
      if (bU.length && oU.length) { const [bl, br] = alt(bU), [ol, or] = alt(oU); ord = [...bl, ...ol, ...or, ...br]; }
      else { const [l, r] = alt(units); ord = [...l, ...r]; }
      const W = u => u.w;
      if (n === 1) xs = [g.beff / 2];
      else if (mode === 'min') {
        const nl = Math.ceil(n / 2); let x = x0;
        ord.slice(0, nl).forEach(u => { xs.push(x + u.w / 2); x += u.w + smin; });
        const right = ord.slice(nl).reverse(), xr = []; x = x0 + bClear;
        right.forEach(u => { xr.push(x - u.w / 2); x -= u.w + smin; });
        xs = xs.concat(xr.reverse());
      } else if (mode === 'pair' && k > 0 && cols && (cols.length > 1 || touch) && cols.length >= n && !(spec.auto && bU.length)) {
        // pręty zlicowane z prętami warstwy 1 (w tych samych pionach) – od naroży do środka
        const nc = cols.length, pick = [];
        if (n % 2 === 1 && nc % 2 === 1 && n < nc) { for (let i = 0; i < (n - 1) / 2; i++) pick.push(i, nc - 1 - i); pick.push((nc - 1) / 2); }   // nieparzysta liczba – środkowa kolumna (symetrycznie)
        else for (let i = 0, a = 0, b = nc - 1; i < n; i++) pick.push(i % 2 === 0 ? a++ : b--);
        pick.sort((u, v) => u - v); xs = pick.map((i, j) => Math.min(x0 + bClear - ord[j].w / 2, Math.max(x0 + ord[j].w / 2, cols[i]))); aligned = true;   // grubszy pręt przy narożu – przesunięty do wnętrza strzemienia
      } else {
        if (mode === 'pair' && k > 0 && !spec.auto) res.issues.push(`warstwa ${res.layers.length + 1}: więcej prętów (${n}) niż w warstwie 1 (${cols ? cols.length : 0}) – nie można ich ${touch ? 'ułożyć na prętach warstwy niższej' : 'zlicować, rozmieszczono równomiernie'}`);
        const sumw = ord.reduce((a, u) => a + u.w, 0), gp = (bClear - sumw) / (n - 1); let x = x0; ord.forEach(u => { xs.push(x + u.w / 2); x += u.w + gp; });
      }
    }
    // kontrola: prześwit w poziomie, położenie wewnątrz strzemion
    const idxs = ord.map((u, i) => i).sort((a, b) => xs[a] - xs[b]);
    const sx = idxs.map(i => xs[i]), sw = idxs.map(i => ord[i].w);
    let gap = n > 1 ? Infinity : 0;
    for (let i = 0; i < n - 1; i++) gap = Math.min(gap, (sx[i + 1] - sw[i + 1] / 2) - (sx[i] + sw[i] / 2));
    const inside = sx.every((x, i) => x - sw[i] / 2 >= x0 - 0.5 && x + sw[i] / 2 <= x0 + bClear + 0.5);
    const kk = res.layers.length;
    // pręty w styku (warstwa bezpośrednio na warstwie niższej, pary jeden nad drugim): prześwit poziomy w obu warstwach
    // ≥ max(1,5·⌀; d_g + 5 mm; 30 mm) – ostrzej niż 8.2(2) z ⌀n = ⌀·√2 dla par w styku (8.9.1)
    let sminT = smin;
    if (touch) { const prev = res.layers[kk - 1], dT = Math.max(dmax, prev.dmax); sminT = Math.max(1.5 * dT, dg + 5, 30);
      if (prev.n > 1 && prev.gap < sminT - 1e-6) res.issues.push(`warstwa ${kk}: prześwit ${prev.gap.toFixed(0)} mm < ${sminT.toFixed(0)} mm (pręty w styku z warstwą wyższą – max(1,5⌀; d_g + 5; 30 mm))`);
      prev.smin = Math.max(prev.smin, sminT); prev.ok = prev.ok && (prev.n < 2 || prev.gap >= prev.smin - 1e-6); prev.touchUp = true; }
    if (n > 1 && gap < sminT - 1e-6) res.issues.push(`warstwa ${kk + 1}: prześwit ${gap.toFixed(0)} mm < ${sminT.toFixed(0)} mm${touch ? ' (pręty w styku z warstwą niższą – max(1,5⌀; d_g + 5; 30 mm))' : ''}`);
    if (!inside) res.issues.push(`warstwa ${kk + 1}: pręty poza obrysem strzemion`);
    if (kk > 0 && sv < svMin - 1e-6) res.issues.push(`odstęp pionowy warstw ${kk}–${kk + 1}: ${sv.toFixed(0)} mm < ${svMin.toFixed(0)} mm`);
    const A = ord.reduce((a, u) => a + u.A, 0);
    const eC = edge + ord.reduce((a, u) => a + u.A * u.cg, 0) / A;
    res.layers.push({ n, ds: ord.map(u => u.d), e: eC, edge, gap, smin: sminT, sv: kk ? sv : null, svMin: kk ? svMin : null, touch, ok: (n < 2 || gap >= sminT - 1e-6) && inside && (!kk || sv >= svMin - 1e-6), dmax,
      cc: n > 1 ? (sx[n - 1] - sx[0]) / (n - 1) : 0, xs: sx, ws: sw, mode, aligned, inside });
    // pręty doprowadzone do podpór (strefa dolna): skrajne – najdalej od osi
    let suppSet = null;
    if (spec.toSupp === 'rank') suppSet = new Set(ord.filter(u => u.suppRank));
    else if (spec.toSupp !== 'all' && spec.toSupp !== undefined) {
      const byOut = ord.map((u, i) => [u, Math.abs(xs[i] - g.beff / 2)]).sort((p, q) => q[1] - p[1]).map(p => p[0]);
      suppSet = new Set(byOut.slice(0, spec.toSupp));
    }
    ord.forEach((u, i) => res.bars.push({ x: xs[i], e: edge + u.cg, edge, d: u.d, dBar: u.dBar, dn: u.dn, nb: u.nb, shape: u.shape, sep: !!u.sep, A: u.A, layer: kk, tag: u.tag, supp: suppSet ? suppSet.has(u) : true }));
    if (kk === 0) cols = xs.slice();
    prevEdge = edge; prevH = hmax; prevDmax = dmax;
  }
  res.ok = res.issues.length === 0 && res.layers.length <= 6;
  return finishLay(res, g, bClear);
}
// średnica buławy wibratora do doboru zbrojenia – 0, gdy prześwit na buławę nie jest uwzględniany
function VIBOF(S) { return S && S.reb && S.reb.vibOn === false ? 0 : (S && S.reb ? S.reb.vib : 40); }
// podsumowanie układu (pola, środki ciężkości, opis, prześwit na buławę)
function finishLay(res, g, bClear) {
  const bars = res.bars;
  res.A = bars.reduce((a, b) => a + b.A, 0);
  res.eC = res.A > 0 ? bars.reduce((a, b) => a + b.A * b.e, 0) / res.A : 0;
  res.n = bars.length;
  res.nBars = bars.reduce((a, b) => a + b.nb, 0);
  res.dmax = res.n ? Math.max(...bars.map(b => b.d)) : 0;
  res.dnMax = res.n ? Math.max(...bars.map(b => b.dn || b.d)) : 0;
  res.dBarMax = res.n ? Math.max(...bars.map(b => b.dBar)) : 0;
  const descL = k => { const m = new Map(); bars.filter(b => b.layer === k).forEach(b => { const key = b.nb + '|' + b.dBar; m.set(key, (m.get(key) || 0) + 1); });
    return Array.from(m.entries()).sort((a, b) => +b[0].split('|')[1] - +a[0].split('|')[1]).map(([key, n]) => { const [nb, d] = key.split('|'); return +nb > 1 ? `${n}×${nb}⌀${d}` : `${n}⌀${d}`; }).join(' + '); };
  const ks = Array.from(new Set(bars.map(b => b.layer))).sort((a, b) => a - b);
  res.desc = ks.map(descL).join(' / ') || '—';
  const bu = bars.find(b => b.nb > 1);
  if (bu) res.bundle = `wiązki po ${bu.nb} (${{ v: 'jeden nad drugim', h: 'obok siebie', t: 'trójkąt' }[bu.shape] || ''})`;
  const L0 = res.layers.find(L => L.n > 0);
  if (L0) {
    const b0 = bars.filter(b => b.layer === res.layers.indexOf(L0)).sort((a, b) => a.x - b.x);
    const ws = b0.map(b => unitW(b));
    let og = 0;
    const xl = res.x0 !== undefined ? res.x0 : (g.beff - bClear) / 2;
    if (b0.length === 1) og = Math.max(b0[0].x - ws[0] / 2 - xl, xl + bClear - b0[0].x - ws[0] / 2);
    else for (let i = 0; i < b0.length - 1; i++) og = Math.max(og, (b0[i + 1].x - ws[i + 1] / 2) - (b0[i].x + ws[i] / 2));
    res.open = og;
  } else res.open = bClear;
  res.stacked = new Set(bars.map(b => b.layer)).size > 1 || bars.some(b => b.nb > 1 && b.shape !== 'h');
  return res;
}
const unitW = b => b.nb > 1 ? (b.shape === 'h' ? b.nb * b.dBar : b.shape === 't' ? 2 * b.dBar : b.dBar) : b.dBar;
// podzbiór układu (np. pręty doprowadzone do podpór) – położenia bez zmian
function subLayout(lay, pred, g) {
  const res = Object.assign({}, lay, { bars: lay.bars.filter(pred) });
  res.layers = lay.layers.map((L, k) => {
    const bk = res.bars.filter(b => b.layer === k).sort((a, b) => a.x - b.x);
    if (!bk.length) return Object.assign({}, L, { n: 0 });
    let gap = bk.length > 1 ? Infinity : 0;
    for (let i = 0; i < bk.length - 1; i++) gap = Math.min(gap, (bk[i + 1].x - unitW(bk[i + 1]) / 2) - (bk[i].x + unitW(bk[i]) / 2));
    const A = bk.reduce((a, b) => a + b.A, 0);
    return Object.assign({}, L, { n: bk.length, gap, e: bk.reduce((a, b) => a + b.A * b.e, 0) / A, xs: bk.map(b => b.x), ws: bk.map(unitW), dmax: Math.max(...bk.map(b => b.d)) });
  });
  return finishLay(res, g, lay.bClear);
}
// pręty przy bokach: n rzędów na każdym boku – równomiernie między warstwami skrajnymi albo na wysokościach ys [mm od dolnej krawędzi]
function midBars(g, cnom, dsw, mid, lb, lt) {
  const n = mid ? mid.n : 0, d = mid ? mid.d : 12;
  if (!(n > 0)) return [];
  const h = g.h, cb = typeof cnom === 'object' ? cnom.b : cnom, ct = typeof cnom === 'object' ? cnom.t : cnom, cs = typeof cnom === 'object' ? cnom.s : cnom;
  const yT = lt && lt.n ? lt.layers[0].e : ct + dsw + d / 2, yB = h - (lb && lb.n ? lb.layers[0].e : cb + dsw + d / 2);
  const xl = (g.beff - g.bw) / 2 + cs + dsw + d / 2, xr = (g.beff + g.bw) / 2 - cs - dsw - d / 2;
  const man = String(mid.ys || '').split(/[;\s]+/).map(v => parseFloat(v.replace(',', '.'))).filter(v => isFinite(v));
  const out = [];
  for (let i = 1; i <= n; i++) {
    const y = man[i - 1] !== undefined ? h - man[i - 1] : yT + (yB - yT) * (n + 1 - i) / (n + 1);
    [xl, xr].forEach(x => out.push({ x, y, edge: 0, d, dBar: d, dn: d, nb: 1, A: area(d), side: 'mid', layer: i }));
  }
  return out;
}
function sideBars(lay, side, h) { // side: 'bot' | 'top' ; y od góry przekroju
  return lay.bars.map(b => ({ x: b.x, y: side === 'bot' ? h - b.e : b.e, edge: b.edge, d: b.d, dBar: b.dBar, dn: b.dn, nb: b.nb, shape: b.shape, A: b.A, side, layer: b.layer, tag: b.tag }));
}
const flipBars = (bars, h) => bars.map(b => Object.assign({}, b, { y: h - b.y }));

/* ---------------------------------------------- SGN: zgodność odkształceń */
function makeULS(parts, h, bars, m) {
  const gp = grossProps(parts); const yc = gp.yc;
  const yA = bars.length ? Math.max(...bars.map(b => b.y)) : h;
  const ecu = m.ecu, ec = m.ec, eud = m.eud;
  const fcd = m.fcd;
  const sigParab = e => e <= 0 ? 0 : e >= m.ec2 ? fcd : fcd * (1 - Math.pow(1 - e / m.ec2, m.npar));
  function strains(p) {
    if (p <= 1) { const eT = -eud + p * (ecu + eud); const eB = eT + (-eud - eT) * h / yA; return [eT, eB]; }
    if (p <= 2) { const xAB = ecu / (ecu + eud) * yA; const x = xAB + (p - 1) * (h - xAB); return [ecu, ecu * (1 - h / x)]; }
    const yC = (1 - ec / ecu) * h; const eB = (p - 2) * ec; const eT = ec + (ec - eB) * yC / (h - yC); return [eT, eB];
  }
  function forces(eT, eB) {
    let N = 0, Fy = 0, block = null, x = null;
    const top = eT >= eB, emax = top ? eT : eB, emin = top ? eB : eT;
    if (emax > 0) x = emin >= 0 ? Infinity : emax * h / (emax - emin);
    if (m.diag === 'rect') {
      if (emax > 0) {
        const a = Math.min(m.lambda * x, h), s = m.eta * fcd;
        block = top ? [0, a] : [h - a, h];
        const r = areaBetween(parts, block[0], block[1]);
        N += s * r.A; Fy += s * r.Ay;
      }
    } else {
      parts.forEach(p => {
        const ns = 60, dy = (p.y1 - p.y0) / ns;
        for (let i = 0; i < ns; i++) {
          const y = p.y0 + (i + 0.5) * dy, e = eT + (eB - eT) * y / h;
          const s = sigParab(e); if (s > 0) { const F = s * p.b * dy; N += F; Fy += F * y; }
        }
      });
    }
    const bs = bars.map(b => {
      const e = eT + (eB - eT) * b.y / h;
      const ss = clamp(m.Es * e, -m.fyd, m.fyd);
      let sc = 0;
      if (m.diag === 'rect') { if (block && b.y >= block[0] && b.y <= block[1]) sc = m.eta * fcd; } else sc = sigParab(e);
      const F = b.A * (ss - sc); N += F; Fy += F * b.y;
      return { e, s: ss };
    });
    return { N, M: yc * N - Fy, eT, eB, x, block, bs };
  }
  const at = p => Object.assign(forces(...strains(p)), { p });
  const Nmin = at(0).N, Nmax = at(3).N;
  function MRd(N) {
    if (N < Nmin - 1e-6 || N > Nmax + 1e-6) return null;
    let lo = 0, hi = 3;
    for (let i = 0; i < 70; i++) { const mid = (lo + hi) / 2; if (at(mid).N < N) lo = mid; else hi = mid; }
    return at((lo + hi) / 2);
  }
  function curve(n) {
    const pts = []; n = n || 120;
    for (let i = 0; i <= n; i++) { const r = at(3 * i / n); pts.push([r.M, r.N]); }
    return pts;
  }
  return { yc, yA, at, MRd, curve, Nmin, Nmax };
}

/* --------------------------- SGN: metoda uproszczona (prostokątny wykres) */
// zginanie z siłą osiową (duży mimośród) – wymagane zbrojenie
function designBending(o) {
  // o: {M, N, bf, bw, hf, d, a2, yc, m}
  const { m } = o; const r = { steps: [] };
  const fc = m.eta * m.fcd;
  r.Ms = o.M + o.N * (o.d - o.yc);       // moment względem zbrojenia rozciąganego
  r.T = false; r.Ff = 0; r.b = o.bf;
  if (o.hf > 0 && o.bf > o.bw) {
    r.Mf = fc * o.bf * o.hf * (o.d - o.hf / 2);
    if (r.Ms > r.Mf) { r.T = true; r.Ff = fc * (o.bf - o.bw) * o.hf; r.b = o.bw; }
  }
  r.Mw = r.Ms - r.Ff * (o.d - o.hf / 2);
  r.mu = r.Mw / (fc * r.b * o.d * o.d);
  r.xiLim = m.xiEffLim;
  r.muLim = r.xiLim * (1 - r.xiLim / 2);
  if (r.mu <= r.muLim) {
    r.xi = 1 - Math.sqrt(1 - 2 * r.mu);
    r.As1 = (r.xi * r.b * o.d * fc + r.Ff - o.N) / m.fyd;
    r.As2 = 0; r.double = false;
  } else {
    r.double = true; r.xi = r.xiLim;
    r.Mlim = r.muLim * fc * r.b * o.d * o.d;
    const xlim = r.xiLim * o.d / m.lambda;
    r.ss2 = Math.min(m.fyd, m.Es * m.ecu3 * (xlim - o.a2) / xlim);
    r.As2 = (r.Mw - r.Mlim) / (r.ss2 * (o.d - o.a2));
    r.As1 = (r.xi * r.b * o.d * fc + r.Ff + r.As2 * r.ss2 - o.N) / m.fyd;
  }
  r.As1 = Math.max(0, r.As1);
  r.zeta = 1 - r.xi / 2;
  return r;
}

/* ------------------------------------------------------- SGU: przekrój */
function uncracked(parts, bars, alpha) {
  let A = 0, S = 0, I0 = 0;
  parts.forEach(p => { A += p.b * (p.y1 - p.y0); S += p.b * (p.y1 ** 2 - p.y0 ** 2) / 2; I0 += p.b * (p.y1 ** 3 - p.y0 ** 3) / 3; });
  bars.forEach(b => { const k = (alpha - 1) * b.A; A += k; S += k * b.y; I0 += k * b.y * b.y; });
  const yc = S / A, I = I0 - A * yc * yc;
  const Sb = bars.reduce((s, b) => s + b.A * (b.y - yc), 0);
  return { A, yc, I, S: Sb };
}
function cracked(parts, bars, alpha) {
  const f = x => {
    let s = 0;
    parts.forEach(p => { const a = Math.max(0, p.y0), b = Math.min(x, p.y1); if (b > a) s += p.b * (x * (b - a) - (b * b - a * a) / 2); });
    bars.forEach(br => { s += (br.y < x ? (alpha - 1) : alpha) * br.A * (x - br.y); });
    return s;
  };
  const h = parts[parts.length - 1].y1;
  let lo = 1e-6, hi = h;
  if (f(hi) < 0) hi = h * 0.999999;
  for (let i = 0; i < 80; i++) { const mid = (lo + hi) / 2; if (f(mid) < 0) lo = mid; else hi = mid; }
  const x = (lo + hi) / 2;
  let I = 0;
  parts.forEach(p => { const a = Math.max(0, p.y0), b = Math.min(x, p.y1); if (b > a) I += p.b * (((x - a) ** 3) - ((x - b) ** 3)) / 3; });
  bars.forEach(br => { I += (br.y < x ? (alpha - 1) : alpha) * br.A * (br.y - x) ** 2; });
  const Sb = bars.reduce((s, b) => s + b.A * (b.y - x), 0);
  return { x, I, S: Sb };
}

/* ----------------------------------------------------------- statyka MES */
// siatka węzłów: podział równomierny + węzły dokładnie w punktach charakterystycznych (podpory, siły skupione, granice obciążeń)
function makeMesh(L, n, pts) {
  const le = L / n;
  const extra = [];
  (pts || []).forEach(p => {
    if (!(p > 0.5 && p < L - 0.5)) return;
    if (!extra.some(e => Math.abs(e - p) < 0.5)) extra.push(p);
  });
  let X = [];
  for (let i = 0; i <= n; i++) {
    const x = i * le;
    if (i > 0 && i < n && extra.some(e => Math.abs(e - x) < 0.3 * le)) continue;
    X.push(x);
  }
  X = X.concat(extra).sort((u, v) => u - v);
  X[0] = 0; X[X.length - 1] = L;
  return X;
}
function nodeIndex(X, x) {
  let lo = 0, hi = X.length - 1;
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (X[mid] <= x) lo = mid; else hi = mid; }
  return Math.abs(X[lo] - x) <= Math.abs(X[hi] - x) ? lo : hi;
}
// sups: [{x, type: 'pin'|'fix'}]
function feSolve(X, sups, qDown, Ps, EI, k0, hinges) {
  const ne = X.length - 1, n = ne + 1, nd = 2 * n, BW = 3, W = 2 * BW + 1;
  hinges = hinges || sups.hinges || [];
  const rel = new Uint8Array(ne);                       // przegub: element zaczynający się w węźle przegubu ma uwolniony obrót na początku
  hinges.forEach(xh => { const i = nodeIndex(X, xh); if (i > 0 && i < ne) rel[i] = 1; });
  const K = new Float64Array(nd * W), F = new Float64Array(nd);
  const kidx = (i, j) => i * W + (j - i + BW);
  const ke = (c, le) => [[12 * c, 6 * le * c, -12 * c, 6 * le * c], [6 * le * c, 4 * le * le * c, -6 * le * c, 2 * le * le * c],
    [-12 * c, -6 * le * c, 12 * c, -6 * le * c], [6 * le * c, 2 * le * le * c, -6 * le * c, 4 * le * le * c]];
  const qa = typeof qDown === 'number' ? null : qDown;
  const parts = e => {
    const le = X[e + 1] - X[e];
    const EIe = typeof EI === 'number' ? EI : EI[e];
    const q = qa ? qa[e] : qDown;
    const kk = k0 ? (typeof k0 === 'number' ? k0 : k0[e]) : 0;
    let k = ke(EIe / le ** 3, le), fq = [-q * le / 2, -q * le * le / 12, -q * le / 2, q * le * le / 12], fk = [0, -EIe * kk, 0, EIe * kk];
    if (rel[e]) {                                         // kondensacja statyczna obrotu w węźle początkowym
      const c = k[1][1], kc = [0, 1, 2, 3].map(a => [0, 1, 2, 3].map(b => (a === 1 || b === 1) ? 0 : k[a][b] - k[a][1] * k[1][b] / c));
      const cond = f => [0, 1, 2, 3].map(a => a === 1 ? 0 : f[a] - k[a][1] * f[1] / c);
      fq = cond(fq); fk = cond(fk); k = kc;
    }
    return { le, EIe, q, k, fq, fk };
  };
  for (let e = 0; e < ne; e++) {
    const P = parts(e), dof = [2 * e, 2 * e + 1, 2 * e + 2, 2 * e + 3];
    for (let a = 0; a < 4; a++) for (let b = 0; b < 4; b++) K[kidx(dof[a], dof[b])] += P.k[a][b];
    for (let a = 0; a < 4; a++) F[dof[a]] += P.fq[a] + P.fk[a];
  }
  (Ps || []).forEach(P => { F[2 * nodeIndex(X, P.x)] -= P.F; });
  const fixed = [];
  sups.forEach(sp => {
    const nn = nodeIndex(X, sp.x);
    if (sp.ty !== false) { if (sp.kv > 0) K[kidx(2 * nn, 2 * nn)] += sp.kv; else fixed.push(2 * nn); }            // kv [N/mm = kN/m]
    if (sp.rot !== undefined ? sp.rot : sp.type === 'fix') { if (sp.kr > 0) K[kidx(2 * nn + 1, 2 * nn + 1)] += sp.kr * 1e6; else fixed.push(2 * nn + 1); }   // kr [kNm/rad]
  });

  fixed.forEach(i => {
    for (let j = Math.max(0, i - BW); j <= Math.min(nd - 1, i + BW); j++) { K[kidx(i, j)] = 0; K[kidx(j, i)] = 0; }
    K[kidx(i, i)] = 1; F[i] = 0;
  });
  const diag0 = new Float64Array(nd); for (let i = 0; i < nd; i++) diag0[i] = Math.abs(K[kidx(i, i)]);
  let sing = false;
  for (let k = 0; k < nd; k++) {
    let pv = K[kidx(k, k)];
    if (!(Math.abs(pv) > 1e-10 * diag0[k])) { sing = true; pv = K[kidx(k, k)] = diag0[k] || 1; }
    for (let i = k + 1; i <= Math.min(nd - 1, k + BW); i++) {
      const f = K[kidx(i, k)] / pv; if (f === 0) continue;
      for (let j = k; j <= Math.min(nd - 1, k + BW); j++) K[kidx(i, j)] -= f * K[kidx(k, j)];
      F[i] -= f * F[k];
    }
  }
  const u = new Float64Array(nd);
  for (let i = nd - 1; i >= 0; i--) {
    let s = F[i];
    for (let j = i + 1; j <= Math.min(nd - 1, i + BW); j++) s -= K[kidx(i, j)] * u[j];
    u[i] = s / K[kidx(i, i)];
  }
  const el = [];
  for (let e = 0; e < ne; e++) {
    const P = parts(e), ue = [u[2 * e], u[2 * e + 1], u[2 * e + 2], u[2 * e + 3]];
    const fi = [0, 1, 2, 3].map(a => P.k[a][0] * ue[0] + P.k[a][1] * ue[1] + P.k[a][2] * ue[2] + P.k[a][3] * ue[3] - P.fq[a] - P.fk[a]);
    const Mi = -fi[1], Mj = fi[3];
    el.push({ Mi, Mj, Mm: (Mi + Mj) / 2 + P.q * P.le * P.le / 8, Vi: fi[0], Vj: -fi[2], xi: X[e], xj: X[e + 1], le: P.le });
  }
  const w = [];
  for (let i = 0; i < n; i++) w.push(u[2 * i]);
  const x = X.slice();
  const Mn = x.map((_, i) => i < ne ? el[i].Mi : el[ne - 1].Mj);
  return { ne, x, w, Mn, el, sing };
}

// skręcanie swobodne: pręt skręcany (GJ = const), podpory widełkowe (obrót wokół osi belki zablokowany na podporach z blokadą y)
function feTorsion(X, sups, mt, Ps) {
  const ne = X.length - 1, n = ne + 1;
  const a = new Float64Array(n), b = new Float64Array(n), c = new Float64Array(n), F = new Float64Array(n);
  for (let e = 0; e < ne; e++) { const k = 1 / (X[e + 1] - X[e]), le = X[e + 1] - X[e]; b[e] += k; b[e + 1] += k; c[e] -= k; a[e + 1] -= k; F[e] += mt[e] * le / 2; F[e + 1] += mt[e] * le / 2; }
  (Ps || []).forEach(P => { F[nodeIndex(X, P.x)] += P.F; });
  const fix = new Set(); sups.forEach(sp => { if (sp.ty !== false || sp.rot) fix.add(nodeIndex(X, sp.x)); });
  if (!fix.size) fix.add(0);
  fix.forEach(i => { b[i] = 1; F[i] = 0; a[i] = 0; c[i] = 0; });          // węzły z blokadą: θ = 0
  const th = new Float64Array(n);
  { // Thomas z uwzględnieniem blokad (kolumny zablokowanych węzłów zerowane w sąsiednich równaniach)
    const A = a.slice(), B = b.slice(), C = c.slice(), D = F.slice();
    fix.forEach(i => { if (i > 0) C[i - 1] = 0; if (i + 1 < n) A[i + 1] = 0; });
    for (let i = 1; i < n; i++) { const w = A[i] / B[i - 1]; B[i] -= w * C[i - 1]; D[i] -= w * D[i - 1]; }
    th[n - 1] = D[n - 1] / B[n - 1];
    for (let i = n - 2; i >= 0; i--) th[i] = (D[i] - C[i] * th[i + 1]) / B[i];
  }
  const T = [];
  for (let e = 0; e < ne; e++) { const le = X[e + 1] - X[e], t0 = (th[e + 1] - th[e]) / le; T.push(t0 + mt[e] * le / 2, t0 - mt[e] * le / 2); }
  return T;      // moment skręcający na końcach elementów (indeksy jak xV)
}
// reakcje podporowe z sił poprzecznych w elementach (skok V w węźle podpory)
function reactionsOf(X, el, sups) {
  const ne = el.length;
  return sups.map(sp => { const nn = nodeIndex(X, sp.x); const Vr = nn < ne ? el[nn].Vi : 0, Vl = nn > 0 ? el[nn - 1].Vj : 0; return Vr - Vl; });
}

// średnica trzpienia do gięcia prętów (8.3, tab. 8.1N): ⌀ ≤ 16 mm – 4⌀, ⌀ > 16 mm – 7⌀ (pręty, haki, pętle, strzemiona)
const mandrelMin = d => (d <= 16 ? 4 : 7) * d;
// długość rozwinięta pręta (oś): wymiary zewnętrzne odcinków, gięcia 90° o promieniu wewnętrznym r
const devLen = (outer, nBend90, d, r) => outer - nBend90 * (2 * (r + d) - Math.PI * (r + d / 2) / 2);
// strzemiona w przekroju: zamknięte (haki 135°), wewnętrzne zamknięte / szpilki dla większej liczby ramion, otwarte (U)
// B, H – wymiary zewnętrzne strzemienia; haki: odcinek prosty ≥ 10⌀ i ≥ 70 mm (spełnia rys. 8.5)
const STIR_KIND = { closed: 'zamknięte (wewnętrzne zamknięte)', pins: 'zamknięte + szpilki', open: 'otwarte (U) z prętem montażowym', tors: 'zamknięte na skręcanie (zakład)' };
// ramiona strzemion muszą obejmować pręty podłużne: każde ramię (także wewnętrzne i szpilki) przy pręcie warstwy 1 u dołu i u góry
// lb / lt – układy prętów dolnych i górnych; zwraca położenia osi ramion (x jak w przekroju), ok, maxLegs i opis braków
function stirLegs(lb, lt, g, cov, q) {
  const legs = Math.max(2, Math.round(q.legs)), d = q.d, xw0 = (g.beff - g.bw) / 2;
  const L0 = lay => { if (!lay || !lay.bars || !lay.bars.length) return []; const k0 = Math.min(...lay.bars.map(b => b.layer)); return lay.bars.filter(b => b.layer === k0).slice().sort((a, b) => a.x - b.x); };
  const B = L0(lb), T = L0(lt);
  const wOf = b => (b.nb > 1 && b.shape === 'h' ? b.nb * b.dBar : b.nb === 3 && b.shape === 't' ? 2 * b.dBar : (b.dBar || b.d));
  const test = k => {
    if (B.length < k || T.length < k) return { ok: false, miss: [] };
    const miss = [], pick = [];
    for (let i = 0; i < k; i++) {
      const bb = B[Math.round(i * (B.length - 1) / (k - 1))], tb = T.reduce((p, t) => (Math.abs(t.x - bb.x) < Math.abs(p.x - bb.x) ? t : p), T[0]);
      const tol = (wOf(bb) + wOf(tb)) / 2 + 5;
      if (i > 0 && i < k - 1 && Math.abs(tb.x - bb.x) > tol) miss.push(i + 1);
      pick.push(bb);
    }
    return { ok: !miss.length, miss, pick };
  };
  const cand = [2, 3, 4, 5, 6, 8];
  let maxLegs = 0; cand.forEach(k => { if (test(k).ok) maxLegs = k; });
  const r = test(legs);
  const x0 = xw0 + cov.cs + d / 2, x1 = xw0 + g.bw - cov.cs - d / 2;
  let xs = null;
  if (r.pick && legs > 2) {
    const mid = (k) => (legs - 1) / 2;
    xs = r.pick.map((b, i) => i === 0 ? x0 : i === legs - 1 ? x1 : b.x + (i <= mid() ? -1 : 1) * (wOf(b) / 2 + d / 2));
  }
  return { legs, ok: r.ok, maxLegs, nB: B.length, nT: T.length, miss: r.miss || [], xs };
}
function stirSet(q, g, cov, xsLegs) {
  const hookA = +q.hookA === 90 ? 90 : 135;
  const d = q.d, r = mandrelMin(d) / 2, extAuto = Math.max(10 * d, 70), ext = q.hook > 0 ? +q.hook : extAuto, legs = Math.max(2, Math.round(q.legs));
  const extra = hookA === 90 ? 0 : Math.PI / 4;                         // dodatkowy kąt gięcia haka ponad naroże 90°
  const B = g.bw - 2 * cov.cs, H = g.h - cov.ct - cov.cb;
  const arc = a => a * (r + d / 2);
  // długość w rozwinięciu osiowym: 4 boki proste (wymiary zewnętrzne B×H minus odcinki gięcia), 3 naroża po 90° i 2 zagięcia haków w narożu początkowym
  // (90° + kąt haka ponad naroże), łuki po osi pręta (r + ⌀/2), 2 proste końce haków
  const closedLen = (b, hh) => 2 * (b + hh) - 8 * (r + d) + arc(2.5 * Math.PI) + 2 * arc(extra) + 2 * ext;
  const lapLen = Math.max(40 * d, 300);
  const lenParts = { straight: 2 * (B + H) - 8 * (r + d), arcs: arc(2.5 * Math.PI) + 2 * arc(extra), hooks: 2 * ext, rc: r + d / 2, ang: 450 + (hookA === 90 ? 0 : 90) };
  const pieces = [];
  if (q.kind === 'open') pieces.push({ type: 'open', B, H, n: 1, len: B + 2 * H - 4 * (r + d) + arc(Math.PI) + 2 * (ext + arc(Math.PI / 2) - (r + d)) });
  else pieces.push({ type: q.kind === 'tors' ? 'tors' : 'closed', B, H, n: 1, len: q.kind === 'tors' ? 2 * (B + H) - 8 * (r + d) + arc(2 * Math.PI) + lapLen : closedLen(B, H), lap: q.kind === 'tors' ? lapLen : 0 });
  const inner = legs - 2;
  const xs = xsLegs && xsLegs.length === legs ? xsLegs : null;
  if (inner > 0) {
    if (q.kind === 'pins') pieces.push({ type: 'pin', B: 0, H, n: inner, len: H - 2 * (r + d) + 2 * (arc(Math.PI / 2 + extra) + ext) });
    else {
      const pairs = Math.floor(inner / 2);
      for (let k = 1; k <= pairs; k++) { const b = xs ? Math.round(xs[legs - 1 - k] - xs[k] + d) : B * (legs - 1 - 2 * k) / (legs - 1) + d; pieces.push({ type: 'inner', B: b, H, n: 1, len: closedLen(b, H), k }); }
      if (inner % 2) pieces.push({ type: 'pin', B: 0, H, n: 1, len: H - 2 * (r + d) + 2 * (arc(Math.PI / 2 + extra) + ext) });
    }
  }
  pieces.forEach(pc => { pc.len = Math.round(pc.len); });
  return { d, r, phm: 2 * r, ext, extAuto, extMin: hookA === 90 ? Math.max(10 * d, 70) : Math.max(5 * d, 50), extMan: q.hook > 0, hookA, legs, B, H, pieces, kind: q.kind, xs, lenParts };
}

/* ------------------------------------------------------------ model belki */
// odcinki (przęsła, wsporniki) i podpory; schematy jednoprzęsłowe są szczególnym przypadkiem
// rodzaje podpór: 'roller' – przegubowa przesuwna, 'pin' – przegubowa nieprzesuwna, 'fix' – sztywna (utwierdzenie);
// podatność: kv [kN/m] – sprężyste podparcie pionowe, kr [kNm/rad] – sprężyste utwierdzenie; t – szerokość podpory [mm]
const SUP_DEF = { ss: ['pin', 'roller'], pf: ['fix', 'roller'], ff: ['fix', 'fix'], cant: ['fix'], manual: ['pin', 'roller'] };
const SUP_NAME = { roller: 'przegubowa przesuwna', pin: 'przegubowa nieprzesuwna', fix: 'sztywna (utwierdzenie)' };
// blokady: x – przesuw podłużny, y – pionowy, z – poprzeczny (poziomy), r – obrót (utwierdzenie)
const SUP_DOF = { roller: { x: false, y: true, z: true, r: false }, pin: { x: true, y: true, z: true, r: false }, fix: { x: true, y: true, z: true, r: true } };
function beamModel(S) {
  const sch = S.scheme, cont = sch === 'cont';
  const segs = [], sups = [];
  if (cont) {
    const C = S.cont;
    if (C.cantL > 0) segs.push({ kind: 'cantL', L: C.cantL * 1000, label: 'wspornik lewy', reb: null });
    C.spans.forEach((Ls, i) => segs.push({ kind: 'span', L: Ls * 1000, label: `przęsło ${i + 1}`, si: i, reb: C.rebSpans[i] }));
    if (C.cantR > 0) segs.push({ kind: 'cantR', L: C.cantR * 1000, label: 'wspornik prawy', reb: null });
  } else if (sch === 'cant') segs.push({ kind: 'cant', L: S.geom.L * 1000, label: 'wspornik', reb: S.reb.bot });
  else segs.push({ kind: 'span', L: S.geom.L * 1000, label: 'przęsło', si: 0, reb: S.reb.bot });
  let x = 0; segs.forEach((s, i) => { s.idx = i; s.x0 = x; x += s.L; s.x1 = x; });
  const Ltot = x;
  if (cont) {
    const C = S.cont, spans = segs.filter(s => s.kind === 'span');
    spans.forEach((s, i) => {
      if (i === 0) sups.push({ x: s.x0, def: C.cantL > 0 ? 'pin' : (C.left === 'fix' ? 'fix' : 'pin') });
      sups.push({ x: s.x1, def: i === spans.length - 1 ? (C.cantR > 0 ? 'roller' : (C.right === 'fix' ? 'fix' : 'roller')) : 'roller' });
    });
    sups.forEach((p, i) => { p.reb = C.rebSupps[i] || zoneOf([]); p.lenMan = { L: p.reb.lenL, R: p.reb.lenR }; p.extMan = { L: p.reb.extL, R: p.reb.extR }; });
  } else {
    const dd = SUP_DEF[sch] || SUP_DEF.ss;
    sups.push({ x: 0, def: dd[0] });
    if (dd[1]) sups.push({ x: Ltot, def: dd[1] });
    sups.forEach(p => { p.reb = S.reb.topX; p.lenMan = { L: S.reb.taLen, R: S.reb.taLen }; });
  }
  const pos = v => (v === '' || v === null || v === undefined || !(+v > 0)) ? 0 : +v;
  sups.forEach((p, i) => {
    const c = (S.supCfg || [])[i] || {};
    p.dof = c.dof ? Object.assign({}, c.dof) : (c.type && SUP_DOF[c.type] ? Object.assign({}, SUP_DOF[c.type]) : Object.assign({}, SUP_DOF[p.def]));
    p.type = p.dof.r ? 'fix' : p.dof.x ? 'pin' : 'roller';
    p.fx = p.dof.x; p.fy = p.dof.y; p.fz = p.dof.z;
    p.custom = !(p.fy && p.fz);
    p.kv = p.fy ? pos(c.kv) : 0; p.kr = p.type === 'fix' ? pos(c.kr) : 0;
    p.t = pos(c.t) || S.geom.t;
    p.rigid = !(p.kv > 0) && !(p.kr > 0);
    p.idx = i; p.label = String.fromCharCode(65 + i);
    const sl = segs.findIndex(s => Math.abs(s.x1 - p.x) < 1), sr = segs.findIndex(s => Math.abs(s.x0 - p.x) < 1);
    p.segL = sl < 0 ? null : sl; p.segR = sr < 0 ? null : sr;
    p.end = p.segL === null || p.segR === null;
    p.hinge = !p.end && !!c.hinge;
    p.direct = c.direct !== false;            // podparcie bezpośrednie – reakcja na dolną powierzchnię belki (6.2.1(8))
    p.name = cont ? `podpora ${p.label}` : (sch === 'cant' ? 'utwierdzenie' : (i === 0 ? 'podpora lewa' : 'podpora prawa'));
    p.nX = zoneBars(p.reb);
  });
  segs.forEach(s => {
    s.supL = sups.find(p => Math.abs(p.x - s.x0) < 1) || null;
    s.supR = sups.find(p => Math.abs(p.x - s.x1) < 1) || null;
    if (!s.reb) s.adj = s.kind === 'cantL' ? s.idx + 1 : s.idx - 1;   // wspornik belki ciągłej: pręty doprowadzone z sąsiedniego przęsła
  });
  // węzły użytkownika – podział odcinków na elementy, przeguby
  const unodes = [];
  (S.nodes || []).forEach((n, i) => {
    const sg = segs[n.seg]; if (!sg) return;
    const a = n.a * 1000; if (!(a > 1 && a < sg.L - 1)) return;
    if (unodes.some(q => Math.abs(q.x - (sg.x0 + a)) < 1)) return;
    unodes.push({ i, seg: sg.idx, a, x: sg.x0 + a, hinge: !!n.hinge });
  });
  segs.forEach(sg => {
    const xs = unodes.filter(q => q.seg === sg.idx).map(q => q.x).sort((u, v) => u - v), b = [sg.x0, ...xs, sg.x1];
    sg.els = b.slice(0, -1).map((x0, k) => ({ k, seg: sg.idx, x0, x1: b[k + 1], L: b[k + 1] - x0 }));
  });
  const hinges = [...unodes.filter(q => q.hinge).map(q => q.x), ...sups.filter(p => p.hinge).map(p => p.x)];
  const md = { segs, sups, Ltot, cont, scheme: sch, nSpan: segs.filter(s => s.kind === 'span').length, unodes, hinges };
  // stateczność: sprawdzenie macierzy sztywności (mechanizm) w płaszczyźnie Y i Z
  md.unstable = mechanism(md, 'y'); md.unstableZ = mechanism(md, 'z');
  md.noHor = !sups.some(p => p.fx);
  return md;
}
// więzy podporowe dla MES: y – płaszczyzna pionowa (sprężystość k_v, k_φ), z – płaszczyzna pozioma
function feSups(md, dir) {
  const a = md.sups.map(p => dir === 'z' ? { x: p.x, ty: p.fz, rot: p.type === 'fix', kv: 0, kr: 0 } : { x: p.x, ty: p.fy, rot: p.type === 'fix', kv: p.kv, kr: p.kr });
  a.hinges = md.hinges.slice();
  return a;
}
function mechanism(md, dir) {
  const pts = [0, md.Ltot, ...md.sups.map(p => p.x), ...md.hinges, ...md.unodes.map(q => q.x), ...md.segs.map(s => s.x0)];
  const u = Array.from(new Set(pts.map(v => Math.round(v)))).sort((p, q) => p - q);
  const X = []; u.forEach((x, i) => { if (i) { const a = u[i - 1]; for (let k = 1; k < 3; k++) X.push(a + (x - a) * k / 3); } X.push(x); });
  const r = feSolve(X, feSups(md, dir), 1, [], 1e13, 0);
  return !!r.sing || r.w.some(v => !isFinite(v));
}
// granica odcinków i, i+1 na rysunku: przy różnych wysokościach wyższy przekrój sięga do lica podpory od strony niższego
const segEdge = (md, i) => { const a = md.segs[i], b = md.segs[i + 1], p = a && a.supR; if (!p || !b) return a ? a.x1 : 0; const ha = a.g ? a.g.h : 0, hb = b.g ? b.g.h : 0; return ha > hb + 1 ? p.x + p.t / 2 : hb > ha + 1 ? p.x - p.t / 2 : p.x; };
const segAt = (md, x) => md.segs.find(s => x >= s.x0 - 1e-6 && x <= s.x1 + 1e-6) || md.segs[md.segs.length - 1];

/* ---------------------------------------- statyka: obciążenia i kombinacje */
// profil obciążenia rozłożonego: 'u' – równomierne, 't' – liniowo zmienne q → q₂ (trapezowe, trójkątne), 'p' – łamana z punktów „x:q; x:q” (x [m] od początku odcinka)
function profPts(it) {
  if (it.shape === 't') return null;
  if (it.shape !== 'p') return null;
  const pts = String(it.prof || '').split(/[;\n]+/).map(t => t.trim().split(/[:\s]+/).map(v => parseFloat(String(v).replace(',', '.')))).filter(q => q.length >= 2 && isFinite(q[0]) && isFinite(q[1])).map(q => [Math.max(0, q[0]), q[1]]).sort((a, b) => a[0] - b[0]);
  return pts.length >= 2 ? pts : null;
}
function qPeak(it) {
  const q = num(it.q, 0);
  if (it.shape === 't') { const q2 = num(it.q2, q); return Math.abs(q2) > Math.abs(q) ? q2 : q; }
  const pp = profPts(it); if (pp) return pp.reduce((a, b) => (Math.abs(b[1]) > Math.abs(a) ? b[1] : a), 0);
  return q;
}
function itemComp(it) {
  const dir = it.dir || 'y', tor = dir === 't' || !!it.tor, multi = it.spans && it.spans.length > 1;
  const ang = dir === 'y' ? num(it.ang, 0) * Math.PI / 180 : 0, cy = Math.cos(ang), cz = Math.sin(ang);       // odchylenie od pionu w płaszczyźnie przekroju (Y → Z)
  const qv = qPeak(it);
  return {
    qy: dir === 'z' || dir === 't' ? 0 : qv * cy, qz: dir === 'y' ? (ang ? qv * cz : 0) : dir === 't' ? 0 : num(it.qz, 0), mt: tor ? num(it.mt, 0) : 0, cy, cz: ang ? cz : 0,
    pts: multi ? [] : (it.pts || []).map(p => ({ Py: dir === 'z' || dir === 't' ? 0 : num(p.P, 0) * cy, Pz: dir === 'y' ? (ang ? num(p.P, 0) * cz : 0) : dir === 't' ? 0 : num(p.Pz, 0), T: tor ? num(p.T, 0) : 0, a: p.a, ref: p.ref })),
  };
}
const hasVal = it => { const c = itemComp(it); return Math.abs(c.qy) > 0 || Math.abs(c.qz) > 0 || Math.abs(c.mt) > 0 || c.pts.some(p => Math.abs(p.Py) > 0 || Math.abs(p.Pz) > 0 || Math.abs(p.T) > 0); };
const hasLoad = it => !(it && it.off) && hasVal(it);                       // obciążenie wyłączone (odznaczone w zestawieniu / na schemacie) – pomijane w obliczeniach
// położenie siły na pręcie: 'L' – od lewego końca [m], 'R' – od prawego końca [m], 'rel' – względnie x/L
function absX(L, a, ref) {
  if (a === '' || a === null || a === undefined) return L / 2;
  const v = num(a, 0);
  return ref === 'rel' ? v * L : ref === 'R' ? L - v * 1000 : v * 1000;
}
function resolveItem(it, md) {
  const seg = it.span > 0 && md.segs[it.span - 1] ? md.segs[it.span - 1] : null;
  let x0 = seg ? seg.x0 : 0, Lr = seg ? seg.L : md.Ltot, onEl = false;
  if (seg && it.el !== '' && it.el !== undefined && it.el !== null && seg.els && seg.els.length > 1) { const e = seg.els[Math.min(+it.el, seg.els.length - 1)]; x0 = e.x0; Lr = e.L; onEl = true; }
  const c = itemComp(it);
  const x1 = x0 + (it.x1 === '' || it.x1 === undefined ? 0 : num(it.x1, 0) * 1000);
  const x2 = x0 + (it.x2 === '' || it.x2 === undefined ? Lr : num(it.x2, Lr / 1000) * 1000);
  const pts = c.pts.filter(p => p.Py || p.Pz || p.T).map(p => {
    const x = x0 + absX(Lr, p.a, p.ref);
    return { Py: p.Py, Pz: p.Pz, T: p.T, x: clamp(x, x0, x0 + Lr), xRaw: x, out: x < x0 - 0.5 || x > x0 + Lr + 0.5, ref: p.ref, a: p.a };
  });
  if (it.spans && it.spans.length > 1) {         // kilka przęseł – całe odcinki
    const sgs = it.spans.map(i => md.segs[i - 1]).filter(Boolean);
    const ranges = sgs.map(sg => [sg.x0, sg.x1]);
    return { qy: c.qy, qz: c.qz, mt: c.mt, x1: Math.min(...ranges.map(r => r[0])), x2: Math.max(...ranges.map(r => r[1])), ranges, partial: true, base: 0, Lr: md.Ltot, seg: null, segs: sgs.map(sg => sg.idx), el: null, pts: [], top: it.top !== false };
  }
  const xa = clamp(Math.min(x1, x2), x0, x0 + Lr), xb = clamp(Math.max(x1, x2), x0, x0 + Lr);
  // profil (wartości bezwzględne q(x) w kN/m wzdłuż kierunku obciążenia; składowe: q_y = q·cos α, q_z = q·sin α)
  let prof = null;
  if (it.shape === 't' && (c.qy || c.qz)) { const q1 = num(it.q, 0), q2 = num(it.q2, q1); if (Math.abs(q2 - q1) > 1e-9) prof = [[xa, q1], [xb, q2]]; }
  const pp = profPts(it); if (pp && (c.qy || c.qz)) prof = pp.map(([x, q]) => [clamp(x0 + x * 1000, x0, x0 + Lr), q]);
  const prRange = prof ? [prof[0][0], prof[prof.length - 1][0]] : null;
  return { qy: c.qy, qz: c.qz, mt: c.mt, x1: prRange ? prRange[0] : xa, x2: prRange ? prRange[1] : xb,
    partial: it.x1 !== '' || it.x2 !== '' || onEl || !!prof, base: x0, Lr, seg: seg ? seg.idx : null, el: onEl ? +it.el : null, pts, top: it.top !== false,
    prof, cy: c.cy, cz: c.cz, qPk: qPeak(it), ang: num(it.ang, 0) };
}
// zestawienie obciążeń z położeniami bezwzględnymi (statyka i rysunek schematu)
function loadLayout(S0, gSelf) {
  const S = S0.loads && S0.loads.perm && S0.cont ? S0 : normalize(S0);
  const md = beamModel(S), Lo = S.loads;
  const out = { L: md.Ltot, md, scheme: S.scheme, G: [], vars: [], accs: [], warn: [] };
  const sw = gSelf !== undefined ? gSelf : 0, swA = Array.isArray(sw) ? sw : null;
  out.gSelf = swA ? Math.max(0, ...swA) : sw; out.gk = Lo.gk + out.gSelf; out.gkAdd = Lo.gk;
  if (Lo.gk) out.G.push({ qy: Lo.gk, qz: 0, mt: 0, x1: 0, x2: md.Ltot, partial: false, pts: [], name: 'g_k', top: true });
  // ciężar własny – na odcinkach o różnych przekrojach osobno
  if (swA && swA.some(v => Math.abs(v - swA[0]) > 1e-9)) md.segs.forEach((sg, i) => { if (swA[i]) out.G.push({ qy: swA[i], qz: 0, mt: 0, x1: sg.x0, x2: sg.x1, partial: true, pts: [], name: `ciężar własny – ${sg.label}`, sw: true, top: true }); });
  else if (out.gSelf) out.G.push({ qy: out.gSelf, qz: 0, mt: 0, x1: 0, x2: md.Ltot, partial: false, pts: [], name: 'ciężar własny', sw: true, top: true });
  const chk = (r, nm) => r.pts.forEach(p => { if (p.out) out.warn.push(`Siła w „${nm}” leży poza ${r.seg !== null ? 'wybranym odcinkiem' : 'belką'} (x = ${(p.xRaw / 1000).toFixed(2)} m) – przyjęto koniec odcinka.`); });
  Lo.perm.forEach((it, si) => { if (!hasLoad(it)) return; const r = Object.assign(resolveItem(it, md), { name: it.name || `Stałe ${si + 1}`, si }); chk(r, r.name); out.G.push(r); });
  Lo.var.forEach((it, si) => { if (!hasLoad(it)) return; const r = Object.assign(resolveItem(it, md), { name: it.name, kind: it.kind, si }); chk(r, it.name || 'obciążenie zmienne'); out.vars.push(r); });
  Lo.acc.forEach((it, si) => { if (!hasLoad(it)) return; const r = Object.assign(resolveItem(it, md), { name: it.name, kind: 'acc', si }); chk(r, it.name || 'obciążenie wyjątkowe'); out.accs.push(r); });
  out.hasZ = [...out.G, ...out.vars, ...out.accs].some(r => r.qz || r.pts.some(p => p.Pz));
  out.hasT = [...out.G, ...out.vars, ...out.accs].some(r => r.mt || r.pts.some(p => p.T));
  out.allTop = [...out.G, ...out.vars, ...out.accs].every(r => r.top !== false);
  return out;
}
const keyPoints = rs => { const P = []; rs.forEach(r => { r.pts.forEach(p => P.push(p.x)); if ((r.qy || r.qz || r.mt) && r.partial) (r.ranges || [[r.x1, r.x2]]).forEach(q => P.push(q[0], q[1])); if (r.prof) r.prof.forEach(q => P.push(q[0])); }); return P; };
// podział obciążenia zmiennego na części przęsłowe (układ obciążenia najniekorzystniejszy)
function splitParts(r, md) {
  const parts = [];
  if (r.qy || r.qz || r.mt) md.segs.forEach(s => (r.ranges || [[r.x1, r.x2]]).forEach(([u, v]) => {
    const a = Math.max(u, s.x0), b = Math.min(v, s.x1);
    if (b - a > 0.5) parts.push({ qy: r.qy, qz: r.qz, mt: r.mt, x1: a, x2: b, partial: true, pts: [], seg: s.idx, prof: r.prof, cy: r.cy, cz: r.cz });
  }));
  r.pts.forEach(p => parts.push({ qy: 0, qz: 0, mt: 0, x1: 0, x2: 0, pts: [p], seg: segAt(md, p.x).idx }));
  return parts;
}
// obciążenia na elementach siatki X dla kierunku dir ('y' | 'z'); parts: [{items, f}]
function loadArrays(X, parts, dir) {
  const ne = X.length - 1, q = new Array(ne).fill(0), Ps = [];
  const kq = dir === 'z' ? 'qz' : dir === 't' ? 'mt' : 'qy', kp = dir === 'z' ? 'Pz' : dir === 't' ? 'T' : 'Py';
  const sq = dir === 't' ? 1e3 : 1, sp = dir === 't' ? 1e6 : 1e3;            // skręcanie: kNm/m → Nmm/mm, kNm → Nmm
  parts.forEach(pt => pt.items.forEach(r => {
    const f = pt.f === undefined ? 1 : pt.f;
    const qv = (r[kq] || 0) * f * sq;
    if (qv && r.prof && kq !== 'mt') {                       // obciążenie o zmiennej wartości: całka z łamanej q(x) na każdym elemencie (średnia na elemencie)
      const comp = (kq === 'qz' ? r.cz : r.cy), P = r.prof;
      const qAt = x => { if (x <= P[0][0]) return P[0][1]; for (let i = 0; i < P.length - 1; i++) if (x <= P[i + 1][0] + 1e-9) { const d = P[i + 1][0] - P[i][0]; return d > 0 ? P[i][1] + (P[i + 1][1] - P[i][1]) * (x - P[i][0]) / d : P[i + 1][1]; } return P[P.length - 1][1]; };
      const lo = Math.max(r.x1, P[0][0]), hi = Math.min(r.x2, P[P.length - 1][0]);
      for (let e = 0; e < ne; e++) { const a = Math.max(lo, X[e]), b = Math.min(hi, X[e + 1]); if (b - a <= 0) continue;
        const brk = [a, ...P.map(p => p[0]).filter(x => x > a && x < b), b]; let I = 0; for (let k = 0; k < brk.length - 1; k++) I += (qAt(brk[k]) + qAt(brk[k + 1])) / 2 * (brk[k + 1] - brk[k]);
        q[e] += I * comp * f * sq / (X[e + 1] - X[e]); }
    } else if (qv) (r.ranges || [[r.x1, r.x2]]).forEach(([u, v]) => { for (let e = 0; e < ne; e++) { const ov = Math.min(v, X[e + 1]) - Math.max(u, X[e]); if (ov > 0) q[e] += qv * ov / (X[e + 1] - X[e]); } });
    r.pts.forEach(p => { if (p[kp]) Ps.push({ x: p.x, F: p[kp] * f * sp }); });
  }));
  return { q, Ps };
}
// rodziny oddziaływań: obciążenie dachu kat. H nie występuje jednocześnie ze śniegiem/wiatrem (PN-EN 1991-1-1, 3.3.2(1))
function families(vars) {
  const all = vars.map((_, i) => i);
  const H = all.filter(i => vars[i].it.kind === 'imp' && vars[i].it.cat === 'H');
  const SW = all.filter(i => vars[i].it.kind === 'snow' || vars[i].it.kind === 'wind');
  if (H.length && SW.length) return [{ set: all.filter(i => !SW.includes(i)), tag: ' [dach kat. H, bez śniegu/wiatru]' }, { set: all.filter(i => !H.includes(i)), tag: ' [śnieg/wiatr, bez kat. H]' }];
  return [{ set: all, tag: '' }];
}
function genCombos(vars, accs, Lo) {
  const fams = families(vars);
  const U = [], K = [], A = [];
  const gG = Lo.gG, gQ = Lo.gQ, xi = Lo.xi;
  fams.forEach(F => {
    const mk = (lead, fl, fo) => F.set.map(i => [i, i === lead ? fl : fo(i)]).filter(t => t[1] > 0);
    if (Lo.comb === '610') {
      if (!F.set.length) U.push({ name: '6.10', ref: '6.10', gs: gG, gi: 1, q: [], a: null, lead: null });
      F.set.forEach(i => U.push({ name: `6.10 – wiodące: ${vars[i].name}${F.tag}`, ref: '6.10', gs: gG, gi: 1, q: mk(i, gQ, j => gQ * vars[j].psi.p0), a: null, lead: i }));
    } else {
      U.push({ name: `6.10a${F.tag}`, ref: '6.10a', gs: gG, gi: 1, q: mk(null, 0, j => gQ * vars[j].psi.p0), a: null, lead: null });
      if (!F.set.length) U.push({ name: '6.10b', ref: '6.10b', gs: xi * gG, gi: 1, q: [], a: null, lead: null });
      F.set.forEach(i => U.push({ name: `6.10b – wiodące: ${vars[i].name}${F.tag}`, ref: '6.10b', gs: xi * gG, gi: 1, q: mk(i, gQ, j => gQ * vars[j].psi.p0), a: null, lead: i }));
    }
    if (!F.set.length) K.push({ name: 'charakterystyczna', gs: 1, gi: 1, q: [], a: null, lead: null });
    F.set.forEach(i => K.push({ name: `char. – wiodące: ${vars[i].name}${F.tag}`, gs: 1, gi: 1, q: mk(i, 1, j => vars[j].psi.p0), a: null, lead: i }));
    accs.forEach((ac, ai) => {
      const pl = Lo.accPsi === 'psi2' ? 'p2' : 'p1';
      A.push({ name: `6.11b – ${ac.name}${F.set.length ? ', bez wiodącego zmiennego' : ''}${F.tag}`, ref: '6.11b', gs: 1, gi: 1, q: mk(null, 0, j => vars[j].psi.p2), a: ai, lead: null });
      F.set.forEach(i => A.push({ name: `6.11b – ${ac.name}, wiodące: ${vars[i].name}${F.tag}`, ref: '6.11b', gs: 1, gi: 1, q: mk(i, vars[i].psi[pl], j => vars[j].psi.p2), a: ai, lead: i }));
    });
  });
  const QP = [{ name: 'quasi-stała', gs: 1, gi: 1, q: vars.map((v, i) => [i, v.psi.p2]).filter(t => t[1] > 0), a: null, lead: null }];
  const uniq = arr => { const seen = new Set(); return arr.filter(c => { const k = JSON.stringify([c.gs, c.q, c.a]); if (seen.has(k)) return false; seen.add(k); return true; }); };
  return { U: uniq(U), K: uniq(K), A: uniq(A), QP };
}
function comboDesc(c, vars, accs) {
  const ff = v => (Math.round(v * 1000) / 1000).toString().replace('.', ',');
  let s = `${ff(c.gs)}·G`;
  c.q.forEach(([i, f]) => { s += ` + ${ff(f)}·${vars[i].id}`; });
  if (c.a !== null && c.a !== undefined) s += ` + ${accs[c.a].id}`;
  return s;
}

// redystrybucja momentów (5.5): moment podporowy nad podporą pośrednią zmniejszony do δ·M; różnica rozłożona liniowo na sąsiednie przęsła
// (obwiednia momentów przęsłowych zwiększona o (1 − δ)·|M_j|·φ_j(x), siły poprzeczne o |ΔM_j|/L – bezpiecznie, równowaga zachowana)
function applyRedist(st, md, deltas) {
  if (!st.MEdMax0) { st.MEdMax0 = st.MEdMax.slice(); st.MEdMin0 = st.MEdMin.slice(); st.VEdMax0 = st.VEdMax.slice(); st.VEdMin0 = st.VEdMin.slice(); }
  const Mx = st.MEdMax0.slice(), Mn = st.MEdMin0.slice(), Vx = st.VEdMax0.slice(), Vn = st.VEdMin0.slice();
  const info = [];
  md.sups.forEach(p => {
    const dl = deltas[p.idx]; if (!(dl < 1)) return;
    const sl = md.segs[p.segL], sr = md.segs[p.segR]; if (!sl || !sr) return;
    let kj = 0; st.x.forEach((x, k) => { if (Math.abs(x - p.x) < Math.abs(st.x[kj] - p.x)) kj = k; }); const Mj = -st.MEdMin0[kj]; if (!(Mj > 0)) return;
    const dM = (1 - dl) * Mj, xa = sl.supL ? sl.supL.x : sl.x0, xb = sr.supR ? sr.supR.x : sr.x1;
    st.x.forEach((x, k) => { const phi = x <= p.x ? (x >= xa ? (x - xa) / Math.max(1, p.x - xa) : 0) : (x <= xb ? (xb - x) / Math.max(1, xb - p.x) : 0); if (phi <= 0) return; Mn[k] += dM * phi; Mx[k] += dM * phi; });
    st.xV.forEach((x, k) => { const dv = x < p.x ? dM / Math.max(1, p.x - xa) : dM / Math.max(1, xb - p.x); if ((x < p.x && x >= xa) || (x >= p.x && x <= xb)) { Vx[k] += dv; Vn[k] -= dv; } });
    info.push({ sup: p, delta: dl, M0: Mj, M: dl * Mj, dM });
  });
  st.MEdMax = Mx; st.MEdMin = Mn; st.VEdMax = Vx; st.VEdMin = Vn;
  st.redist = info;
  applySupRed(st);
  return info;
}
// redukcja momentu nad podporą o szerokości t (5.3.2.2): podpora swobodna (obrót możliwy) – ΔM = F_Ed,sup·t/8 (wykres zaokrąglony na szerokości
// podpory; F – reakcja tej kombinacji, która daje największy moment ujemny); podpora monolityczna – moment w licu, nie mniej niż 0,65 momentu w osi.
// Obwiednie zredukowane (…MinR) – SGN, charakterystyczna i quasi-stała; obwiednie w osi (…Min) bez zmian (wykresy, reakcje)
function applySupRed(st) {
  st.MEdMinR = st.MEdMin; st.MkMinR = st.MkMin; st.MqpMinR = st.MqpMin; st.supRed = [];
  const cfg = st._red; if (!cfg || !cfg.on || !st.kAt || !st.md) return;
  const md = st.md, L = md.Ltot;
  const Fof = (list, k, idx) => {
    if (!list || !list.length || !st.E || !st.ev) return 0;
    let c = null, bv = Infinity; list.forEach(q => { const v = st.ev(q, 'My', k, -1); if (v < bv) { bv = v; c = q; } });
    const gv = st.E.G.My[k]; let F = (gv < 0 ? c.gs : c.gi) * st.E.G.R[idx];
    c.q.forEach(([i, f]) => { const rs = st.vars[i].partsRes && st.vars[i].partsRes.y; if (rs) rs.forEach(r => { if (r.M[k] < 0) F += f * r.R[idx]; }); });
    if (c.a !== null && c.a !== undefined && st.accs[c.a] && st.accs[c.a].R) F += st.accs[c.a].R[idx];
    return Math.max(0, F);
  };
  const red = (arr, list, key) => {
    if (!arr) return arr;
    const out = arr.slice();
    md.sups.forEach(p => {
      if (!(p.t > 0)) return;
      const k = st.kAt(p.x), M0 = -arr[k]; if (!(M0 > 1e3)) return;
      const mono = p.type === 'fix' || p.kr > 0, h = p.t / 2;
      let q;
      if (mono) {
        const faces = [p.x - h, p.x + h].filter(x => x > 0 && x < L).map(x => Math.max(0, -arr[st.kAt(x)]));
        const Mf = faces.length ? Math.max(...faces) : M0, Md = Math.min(M0, Math.max(Mf, 0.65 * M0));
        st.x.forEach((x, j) => { if (Math.abs(x - p.x) <= h + 1e-6 && arr[j] < -Md) out[j] = -Md; });
        q = { kind: 'face', Mf, M0, M: Md, dM: M0 - Md, t: p.t };
      } else if (!p.end) {
        const F = Fof(list, k, p.idx), dM = F * p.t / 8;
        st.x.forEach((x, j) => { const a = Math.abs(x - p.x); if (a < h && arr[j] < 0) out[j] = Math.min(0, arr[j] + F / (2 * p.t) * (h - a) * (h - a)); });
        q = { kind: 'free', F, dM: Math.min(dM, M0), M0, M: Math.max(0, M0 - dM), t: p.t };
      } else return;
      (st.supRed[p.idx] = st.supRed[p.idx] || { sup: p })[key] = q;
    });
    return out;
  };
  const C = st.combos || {};
  st.MEdMinR = red(st.MEdMin, st.ulsList, 'U');
  st.MkMinR = red(st.MkMin, C.K, 'K');
  st.MqpMinR = red(st.MqpMin, C.QP, 'QP');
}
function statics(S, g, R, opts) {
  opts = opts || {};
  const md = opts.md || beamModel(S);
  const st = { manual: S.scheme === 'manual', md, _red: { on: !!(S.loads && S.loads.redM) } };
  st.sups = feSups(md, 'y');
  st.supsZ = feSups(md, 'z');
  const Ec0 = R.m ? R.m.Ecm : 30000;
  const EI0 = Ec0 * (g.Ic || 1e10);
  const EIofX = X => X.slice(0, -1).map((x, i) => { const sg = segAt(md, (x + X[i + 1]) / 2); return Ec0 * ((sg && sg.g && sg.g.Ic) || g.Ic || 1e10); });
  const L = md.Ltot;
  if (st.manual) {
    const M = S.man;
    const par = (arr) => { const [a, b, c] = arr.map(v => v * 1e6); const k = 4 * (b - (a + c) / 2) / (L * L); return x => a * (1 - x / L) + c * x / L + k * x * (L - x); };
    const fEd = par(M.MEd), fK = par(M.MEk), fQP = par(M.MEqp);
    const xs = []; for (let i = 0; i <= 200; i++) xs.push(L * i / 200);
    st.x = xs; st.MEdMax = xs.map(fEd); st.MEdMin = st.MEdMax.slice();
    st.MkMax = xs.map(fK); st.MkMin = st.MkMax.slice(); st.MqpMax = xs.map(fQP); st.MqpMin = st.MqpMax.slice();
    st.xV = []; xs.slice(0, -1).forEach((x, i) => st.xV.push(x, xs[i + 1]));
    const VL = Math.abs(M.VL) * 1e3, VR = Math.abs(M.VR) * 1e3;
    st.VEdMax = st.xV.map(x => VL + (-VR - VL) * x / L); st.VEdMin = st.VEdMax.slice();
    st.NEd = M.NEd * 1e3; st.TEd = Math.abs(M.TEd) * 1e6;
    st.simpleEnd = [Math.abs(M.MEd[0]) < 1e-9 || M.MEd[0] > 0, Math.abs(M.MEd[2]) < 1e-9 || M.MEd[2] > 0];
    st.K = num(M.K, 1.3);
    st.vars = []; st.accs = []; st.hasAcc = false; st.hasZ = false;
  } else {
    const Lo = S.loads;
    const swArr = md.segs.map(sg => Lo.sw ? (sg.g ? sg.g.selfW : g.selfW) : 0);
    st.gSelf = Math.max(0, ...swArr);
    st.gk = Lo.gk + st.gSelf;
    const lay = loadLayout(S, swArr);
    st.layout = lay; st.hasZ = lay.hasZ; st.hasT = lay.hasT; st.allTop = lay.allTop;
    lay.warn.forEach(w => R.warnings.push(w));
    st.Gitems = lay.G;
    const resOf = (list, si) => list.find(r => r.si === si);
    const kindCnt = {};
    const KORD = { imp: 0, snow: 1, wind: 2, other: 3 };
    st.vars = Lo.var.map((it, si) => ({ it, si })).filter(o => hasLoad(o.it)).sort((a, b) => (KORD[a.it.kind] - KORD[b.it.kind]) || (a.si - b.si)).map((o, i) => {
      kindCnt[o.it.kind] = (kindCnt[o.it.kind] || 0) + 1;
      return { id: 'Q' + (i + 1), it: o.it, si: o.si, r: resOf(lay.vars, o.si), psi: psiOf(o.it), name: o.it.name || `${VAR_KINDS[o.it.kind]} ${kindCnt[o.it.kind]}` };
    });
    st.accs = Lo.acc.map((it, si) => ({ it, si })).filter(o => hasLoad(o.it)).map((o, i) => ({ id: 'A' + (i + 1), it: o.it, si: o.si, r: resOf(lay.accs, o.si), name: o.it.name || `Wyjątkowe ${i + 1}` }));
    st.vars.forEach(v => { v.r.id = v.id; }); st.accs.forEach(a => { a.r.id = a.id; });
    st.hasAcc = st.accs.length > 0;
    st.keyPts = keyPoints([...lay.G, ...lay.vars, ...lay.accs]).concat(md.sups.map(p => p.x), md.segs.map(s => s.x0), md.hinges, md.unodes.map(q => q.x));
    const X = makeMesh(L, Math.max(200, 80 * md.segs.length), st.keyPts);
    st.mesh = X;
    const EIe = EIofX(X); st.EIofX = EIofX;
    const solve = (items, dir) => {
      const la = loadArrays(X, [{ items }], dir), sp = dir === 'z' ? st.supsZ : st.sups;
      const r = feSolve(X, sp, la.q, la.Ps, EIe, 0);
      const out = { M: r.Mn, V: r.el.flatMap(e => [e.Vi, e.Vj]), x: r.x, el: r.el, R: reactionsOf(X, r.el, sp) };
      if (dir === 'y' && st.hasT) { const lt = loadArrays(X, [{ items }], 't'); out.T = feTorsion(X, st.sups, lt.q, lt.Ps); }
      return out;
    };
    const dirs = st.hasZ ? ['y', 'z'] : ['y'];
    const posneg = (arrs, n) => { const pos = new Array(n).fill(0), neg = new Array(n).fill(0); arrs.forEach(a => a.forEach((v, k) => { if (v > 0) pos[k] += v; else neg[k] += v; })); return { pos, neg }; };
    const rG = solve(st.Gitems, 'y');
    st.x = rG.x; st.xV = rG.el.flatMap(e => [e.xi, e.xj]);
    st.E = { G: { My: rG.M, Vy: rG.V, R: rG.R } };
    if (st.hasT) st.E.G.T = rG.T;
    if (st.hasZ) { const rz = solve(st.Gitems, 'z'); st.E.G.Mz = rz.M; st.E.G.Vz = rz.V; st.E.G.Rz = rz.R; }
    st.vars.forEach(v => {
      v.parts = splitParts(v.r, md);
      dirs.forEach(dd => {
        const rs = v.parts.map(p => solve([p], dd));
        v.partsRes = v.partsRes || {}; v.partsRes[dd] = rs;
        const Ms = posneg(rs.map(r => r.M), st.x.length), Vs = posneg(rs.map(r => r.V), st.xV.length), Rs = posneg(rs.map(r => r.R), md.sups.length);
        if (dd === 'y') { v.My = Ms; v.Vy = Vs; v.R = Rs; if (st.hasT) v.T = posneg(rs.map(r => r.T), st.xV.length); } else { v.Mz = Ms; v.Vz = Vs; v.Rz = Rs; }
      });
    });
    st.accs.forEach(a => dirs.forEach(dd => { const r = solve([a.r], dd); if (dd === 'y') { a.My = r.M; a.Vy = r.V; a.R = r.R; if (st.hasT) a.T = r.T; } else { a.Mz = r.M; a.Vz = r.V; a.Rz = r.R; } }));
    const C = genCombos(st.vars, st.accs, Lo);
    st.combos = C;
    // wartość kombinacji c w punkcie k dla składowej comp (My, Vy, Mz, Vz); sign: +1 maksimum, −1 minimum
    st.ev = (c, comp, k, sign) => {
      const gArr = st.E.G[comp]; const gv = gArr ? gArr[k] : 0;
      let v = ((sign > 0 ? gv > 0 : gv < 0) ? c.gs : c.gi) * gv;
      c.q.forEach(([i, f]) => { const a = st.vars[i][comp]; if (a) v += f * (sign > 0 ? a.pos[k] : a.neg[k]); });
      if (c.a !== null && c.a !== undefined) { const a = st.accs[c.a][comp]; if (a) v += a[k]; }
      return v;
    };
    const env = (list, comp) => {
      const n = (comp[0] === 'V' || comp === 'T' ? st.xV : st.x).length, max = new Array(n), min = new Array(n);
      for (let k = 0; k < n; k++) { let mx = -Infinity, mn = Infinity; list.forEach(c => { mx = Math.max(mx, st.ev(c, comp, k, 1)); mn = Math.min(mn, st.ev(c, comp, k, -1)); }); max[k] = mx; min[k] = mn; }
      return { max, min };
    };
    const eUM = env(C.U, 'My'), eUV = env(C.U, 'Vy'), eK = env(C.K, 'My'), eQ = env(C.QP, 'My');
    st.envU = { M: eUM, V: eUV };
    st.MkMax = eK.max; st.MkMin = eK.min; st.MqpMax = eQ.max; st.MqpMin = eQ.min; st.envK = eK;
    if (st.hasAcc) st.envA = { M: env(C.A, 'My'), V: env(C.A, 'Vy') };
    const use = opts.acc && st.hasAcc ? st.envA : st.envU;
    st.MEdMax = use.M.max; st.MEdMin = use.M.min; st.VEdMax = use.V.max; st.VEdMin = use.V.min;
    st.ulsList = opts.acc && st.hasAcc ? C.A : C.U;
    if (S.loads.redist && md.cont && !opts.acc) {
      const stl = STEEL_LIST.find(q => q.id === S.mat.steel) || { cls: 'B' }, k5 = stl.cls === 'A' ? 0.8 : 0.7;
      const d0 = S.loads.redist === 'auto' ? k5 : Math.max(k5, +S.loads.redist), dl = {};
      md.sups.forEach(p => { if (p.end || p.segL === null || p.segR === null || p.hinge) return; const a = md.segs[p.segL], b = md.segs[p.segR]; if (a.kind !== 'span' || b.kind !== 'span') return;
        const ratio = a.L / b.L; if (ratio < 0.5 || ratio > 2) return; dl[p.idx] = (opts.redistD && opts.redistD[p.idx]) || d0; });
      st.redistK5 = k5; applyRedist(st, md, dl);
    }
    if (st.hasZ) {
      const absEnv = (list, comp) => { const e = env(list, comp); return e.max.map((v, k) => Math.max(Math.abs(v), Math.abs(e.min[k]))); };
      st.MzEd = absEnv(st.ulsList, 'Mz'); st.VzEd = absEnv(st.ulsList, 'Vz');
      st.MzK = absEnv(C.K, 'Mz'); st.MzQP = absEnv(C.QP, 'Mz');
      if (st.hasAcc) { st.MzEdA = absEnv(C.A, 'Mz'); }
    }
    st.NEd = (opts.acc ? Lo.accN : Lo.NEd) * 1e3;
    st.TEdAdd = Math.abs(opts.acc ? Lo.accT : Lo.TEd) * 1e6;      // dodatkowy moment skręcający podany wprost (stały na długości)
    if (st.hasT) {
      const eT = env(st.ulsList, 'T');
      st.TEdMax = eT.max; st.TEdMin = eT.min;
      st.TEdAbs = eT.max.map((v, k) => Math.max(Math.abs(v), Math.abs(eT.min[k])) + st.TEdAdd);
    } else st.TEdAbs = st.xV.map(() => st.TEdAdd);
    st.TEd = Math.max(0, ...st.TEdAbs);
    // reakcje podporowe: obwiednie SGN, charakterystyczne
    const nS = md.sups.length, envR = (list, comp) => { const mx = [], mn = []; for (let i = 0; i < nS; i++) { let a = -Infinity, b = Infinity; list.forEach(c => { a = Math.max(a, st.ev(c, comp, i, 1)); b = Math.min(b, st.ev(c, comp, i, -1)); }); mx.push(a); mn.push(b); } return { max: mx, min: mn }; };
    st.reac = { U: envR(st.ulsList, 'R'), K: envR(C.K, 'R'), G: rG.R.slice(), Q: st.vars.map(v => ({ id: v.id, name: v.name, max: v.R.pos.slice(), min: v.R.neg.slice() })) };
    if (st.hasZ) st.reac.Uz = envR(st.ulsList, 'Rz');
    st.simpleEnd = md.sups.length ? [md.sups[0].type !== 'fix' && md.sups[0].x < 1, md.sups[md.sups.length - 1].type !== 'fix' && md.sups[md.sups.length - 1].x > L - 1] : [false, false];
    st.Lo = Lo;
    // pary (M_y, |M_z|) kombinacji w punkcie k – do zginania ukośnego
    st.pairs = (list, k, signY) => list.map(c => [st.ev(c, 'My', k, signY), st.hasZ ? Math.max(Math.abs(st.ev(c, 'Mz', k, 1)), Math.abs(st.ev(c, 'Mz', k, -1))) : 0]);
    // obciążenia do ugięć: G w całości + części obciążeń zmiennych (parity: przęsła o tej samej parzystości obciążone)
    st.loadFor = (X2, c, parity, dir) => {
      const parts = [{ items: st.Gitems, f: 1 }];
      c.q.forEach(([i, f]) => { const v = st.vars[i]; parts.push({ items: v.parts.filter(p => parity === null || parity === undefined || (p.seg % 2) === parity), f }); });
      return loadArrays(X2, parts, dir || 'y');
    };
  }
  finishStatics(st, L);
  applySupRed(st);
  if (!st.manual) {
    const nV = st.xV.length - 1;
    const argmax = a => a.reduce((bi, v, i) => (v > a[bi] ? i : bi), 0), argmin = a => a.reduce((bi, v, i) => (v < a[bi] ? i : bi), 0);
    const tab = (list, envM) => {
      const iPos = argmax(envM.max), iNeg = argmin(envM.min);
      let kV = 0; st.Vabs.forEach((v, k) => { if (v > st.Vabs[kV]) kV = k; });
      return list.map((c, ci) => ({ name: c.name, ref: c.ref, desc: comboDesc(c, st.vars, st.accs), Mpos: st.ev(c, 'My', iPos, 1), Mneg: st.hasNeg ? st.ev(c, 'My', iNeg, -1) : 0,
        Vmax: Math.max(Math.abs(st.ev(c, 'Vy', kV, 1)), Math.abs(st.ev(c, 'Vy', kV, -1))), xPos: st.x[iPos], xNeg: st.x[iNeg], xV: st.xV[kV], ci,
        Mz: st.hasZ ? Math.max(...st.x.map((_, k) => Math.max(Math.abs(st.ev(c, 'Mz', k, 1)), Math.abs(st.ev(c, 'Mz', k, -1))))) : 0 }));
    };
    void nV;
    const mark = (rows) => { if (!rows.length) return rows; ['Mpos', 'Vmax', 'Mz'].forEach(k => { const mx = Math.max(...rows.map(r => r[k])); rows.forEach(r => { if (mx > 0 && Math.abs(r[k] - mx) < 1e-6 * mx) r['gov' + k] = true; }); });
      const mn = Math.min(...rows.map(r => r.Mneg)); rows.forEach(r => { if (mn < 0 && Math.abs(r.Mneg - mn) < 1e-6 * Math.abs(mn)) r.govMneg = true; }); return rows; };
    st.tabU = mark(tab(st.combos.U, st.envU.M));
    st.tabK = mark(tab(st.combos.K, st.envK));
    if (st.hasAcc) st.tabA = mark(tab(st.combos.A, st.envA.M));
    const iKp = argmax(st.envK.max), iKn = argmin(st.envK.min);
    let best = 0, bi = 0; st.combos.K.forEach((c, ci) => { const v = Math.abs(st.ev(c, 'My', st.hasPos ? iKp : iKn, st.hasPos ? 1 : -1)); if (v > best) { best = v; bi = ci; } });
    st.chCombo = st.combos.K[bi]; st.qpCombo = st.combos.QP[0];
    if (st.hasZ) { let bz = 0, bzi = 0; st.combos.K.forEach((c, ci) => { const v = Math.max(...st.x.map((_, k) => Math.abs(st.ev(c, 'Mz', k, 1)))); if (v > bz) { bz = v; bzi = ci; } }); st.chComboZ = st.combos.K[bzi]; }
  }
  return st;
}
function finishStatics(st, L) {
  let iMax = 0, iMin = 0;
  st.MEdMax.forEach((v, i) => { if (v > st.MEdMax[iMax]) iMax = i; });
  st.MEdMin.forEach((v, i) => { if (v < st.MEdMin[iMin]) iMin = i; });
  st.MEdPos = Math.max(0, st.MEdMax[iMax]); st.xPos = st.x[iMax];
  st.MEdNeg = Math.min(0, st.MEdMin[iMin]); st.xNeg = st.x[iMin];
  st.MkPos = Math.max(0, ...st.MkMax); st.MkNeg = Math.min(0, ...st.MkMin);
  st.MqpPos = Math.max(0, ...st.MqpMax); st.MqpNeg = Math.min(0, ...st.MqpMin);
  const mag = (a, b) => a.map((v, i) => (Math.abs(v) >= Math.abs(b[i]) ? v : b[i]));
  st.Mk = mag(st.MkMax, st.MkMin); st.Mqp = mag(st.MqpMax, st.MqpMin);
  st.hasNeg = st.MEdNeg < -1e3 || st.MkNeg < -1e3;
  st.hasPos = st.MEdPos > 1e3 || st.MkPos > 1e3;
  st.Vabs = st.VEdMax.map((v, i) => Math.max(Math.abs(v), Math.abs(st.VEdMin[i])));
  const atX = (vs) => (x) => {
    const xs = st.xV; let best = 0;
    for (let i = 0; i < xs.length - 1; i += 2) {
      if (x >= xs[i] - 1e-9 && x <= xs[i + 1] + 1e-9) {
        const v = xs[i + 1] > xs[i] ? vs[i] + (vs[i + 1] - vs[i]) * (x - xs[i]) / (xs[i + 1] - xs[i]) : Math.max(vs[i], vs[i + 1]);
        best = Math.max(best, v);
      }
    }
    return best;
  };
  st.Vat = atX(st.Vabs);
  st.Vin = (x, dir) => st.Vat(x + dir * 0.01);
  if (st.VzEd) { st.Vzat = atX(st.VzEd); st.Vzin = (x, dir) => st.Vzat(x + dir * 0.01); }
  st.kAt = x => nodeIndex(st.x, x);
  st.supports = st.md.sups.map(p => ({ side: p.idx === 0 ? 'L' : 'R', x: p.x, sup: p }));
}

/* ------------------------------------------ zginanie ukośne – metoda włókien */
// strefy odkształceń (zginanie z siłą osiową): p ∈ [0,3] od czystego rozciągania do czystego ściskania
function pivotStrains(p, h, yA, m) {
  const ecu = m.ecu, ec = m.ec, eud = m.eud;
  if (p <= 1) { const eT = -eud + p * (ecu + eud); const eB = eT + (-eud - eT) * h / yA; return [eT, eB]; }
  if (p <= 2) { const xAB = ecu / (ecu + eud) * yA; const x = xAB + (p - 1) * (h - xAB); return [ecu, ecu * (1 - h / x)]; }
  const yC = (1 - ec / ecu) * h; const eB = (p - 2) * ec; const eT = ec + (ec - eB) * yC / (h - yC); return [eT, eB];
}
// włókna przekroju (y w dół od góry, z w poziomie od osi symetrii)
function fiberize(parts, ny0, nz0) {
  const fib = [], corners = [];
  const H = parts[parts.length - 1].y1 - parts[0].y0;
  parts.forEach(p => {
    const ny = Math.max(4, Math.round(ny0 * (p.y1 - p.y0) / H)), nz = nz0;
    const dy = (p.y1 - p.y0) / ny, dz = p.b / nz;
    for (let i = 0; i < ny; i++) for (let j = 0; j < nz; j++) fib.push({ y: p.y0 + (i + 0.5) * dy, z: -p.b / 2 + (j + 0.5) * dz, A: dy * dz, dy, dz });
    corners.push([p.y0, -p.b / 2], [p.y0, p.b / 2], [p.y1, -p.b / 2], [p.y1, p.b / 2]);
  });
  return { fib, corners };
}
// podział włókna na mniejsze (włókna przecinane przez granicę strefy ściskanej)
const SUBN = 10;
function subFibers(f) {
  const out = [], dy = f.dy / SUBN, dz = f.dz / SUBN, A = dy * dz;
  for (let i = 0; i < SUBN; i++) for (let j = 0; j < SUBN; j++) out.push({ y: f.y - f.dy / 2 + (i + 0.5) * dy, z: f.z - f.dz / 2 + (j + 0.5) * dz, A });
  return out;
}
// udział pola prostokąta (rzuty boków a, b na kierunek u) leżącego poniżej t (t względem środka) – rozkład trapezowy
function rectFrac(t, a, b) {
  if (a < b) { const q = a; a = b; b = q; }
  const T = t + (a + b) / 2;
  if (T <= 0) return 0;
  if (T >= a + b) return 1;
  if (b < 1e-9) return T / a;
  if (T < b) return T * T / (2 * a * b);
  if (T <= a) return (T - b / 2) / a;
  const r = a + b - T; return 1 - r * r / (2 * a * b);
}
// konstrukcja konturu nośności (M_y, M_z) przy zadanej sile N; bars: {y, x (od lewej krawędzi b_eff), A}
function makeBiax(parts, bars, m, beff) {
  const { fib, corners } = fiberize(parts, 40, 16);
  const nf = fib.length;
  const yc = grossProps(parts).yc;
  const bz = bars.map(b => ({ y: b.y, z: b.x - beff / 2, A: b.A }));
  const fcd = m.fcd, rect = m.diag === 'rect', sR = m.eta * fcd;
  const sigP = e => e <= 0 ? 0 : e >= m.ec2 ? fcd : fcd * (1 - Math.pow(1 - e / m.ec2, m.npar));
  const fy = new Float64Array(nf), fz = new Float64Array(nf), fA = new Float64Array(nf), fdy = new Float64Array(nf), fdz = new Float64Array(nf);
  fib.forEach((f, i) => { fy[i] = f.y; fz[i] = f.z; fA[i] = f.A; fdy[i] = f.dy; fdz[i] = f.dz; });
  // przygotowanie kierunku θ (oś obojętna prostopadła do kierunku u = y·cosθ + z·sinθ)
  function prep(theta) {
    const c = Math.cos(theta), s = Math.sin(theta), ac = Math.abs(c), as = Math.abs(s);
    let uMin = Infinity, uMax = -Infinity;
    corners.forEach(([y, z]) => { const v = y * c + z * s; uMin = Math.min(uMin, v); uMax = Math.max(uMax, v); });
    const hu = uMax - uMin;
    const uf = new Float64Array(nf), pa = new Float64Array(nf), pb = new Float64Array(nf);
    for (let i = 0; i < nf; i++) { uf[i] = fy[i] * c + fz[i] * s - uMin; pa[i] = ac * fdy[i]; pb[i] = as * fdz[i]; }
    const ub = bz.map(b => b.y * c + b.z * s - uMin);
    const uA = ub.length ? Math.max(...ub) : hu;
    return { theta, hu, uf, pa, pb, ub, uA };
  }
  function evalP(P, p) {
    const [eT, eB] = pivotStrains(p, P.hu, Math.max(1, P.uA), m);
    const hu = P.hu, g = (eB - eT) / hu;
    let N = 0, My = 0, Mz = 0, blk = -1;
    if (rect && eT > 0) { const x = eB >= 0 ? Infinity : eT * hu / (eT - eB); blk = Math.min(m.lambda * x, hu); }
    const uf = P.uf;
    if (rect) {
      if (blk > 0) for (let i = 0; i < nf; i++) {
        const hw = (P.pa[i] + P.pb[i]) / 2, du = blk - uf[i];
        const fr = du >= hw ? 1 : du <= -hw ? 0 : rectFrac(du, P.pa[i], P.pb[i]);
        if (fr > 0) { const F = sR * fA[i] * fr; N += F; My += F * (yc - fy[i]); Mz -= F * fz[i]; }
      }
    } else {
      for (let i = 0; i < nf; i++) {
        const e = eT + g * uf[i]; if (e <= 0) continue;
        const F = sigP(e) * fA[i]; N += F; My += F * (yc - fy[i]); Mz -= F * fz[i];
      }
    }
    for (let j = 0; j < bz.length; j++) {
      const b = bz[j], uu = P.ub[j], e = eT + g * uu;
      const scc = rect ? (blk > 0 && uu <= blk ? sR : 0) : sigP(e);
      const F = b.A * (clamp(m.Es * e, -m.fyd, m.fyd) - scc);
      N += F; My += F * (yc - b.y); Mz -= F * b.z;
    }
    return { N, My, Mz };
  }
  const prepCache = new Map();
  const prepOf = th => { if (!prepCache.has(th)) prepCache.set(th, prep(th)); return prepCache.get(th); };
  const at = (theta, p) => evalP(prepOf(theta), p);
  const cache = {};
  function contour(N) {
    const key = Math.round(N);
    if (key in cache) return cache[key];
    const pts = [];
    for (let i = 0; i < 72; i++) {
      const P = prepOf(i * Math.PI / 36);
      let a = 0, b = 3, ra = evalP(P, a), rb = evalP(P, b);
      if (N < ra.N - 1 || N > rb.N + 1) { cache[key] = null; return null; }
      let fa = ra.N - N, fb = rb.N - N, side = 0, r = ra;
      // regula falsi (wariant Illinois) – N(p) monotoniczne
      for (let it = 0; it < 60; it++) {
        const c = Math.abs(fb - fa) > 1e-12 ? (a * fb - b * fa) / (fb - fa) : (a + b) / 2;
        r = evalP(P, c); const fc = r.N - N;
        if (Math.abs(fc) < 5 || b - a < 1e-9) break;
        if (fc * fb > 0) { b = c; fb = fc; if (side === -1) fa /= 2; side = -1; }
        else { a = c; fa = fc; if (side === 1) fb /= 2; side = 1; }
      }
      pts.push([r.My, r.Mz]);
    }
    cache[key] = pts; return pts;
  }
  // wykorzystanie = |M| / M_Rd w kierunku wektora (My, Mz)
  function util(N, My, Mz) {
    const pts = contour(N);
    if (!pts) return Infinity;
    const L = Math.hypot(My, Mz); if (L < 1) return 0;
    const dx = My / L, dy = Mz / L;
    let best = Infinity;
    for (let i = 0; i < pts.length; i++) {
      const [ax, ay] = pts[i], [bx, by] = pts[(i + 1) % pts.length];
      const ex = bx - ax, ey = by - ay, den = dx * ey - dy * ex;
      if (Math.abs(den) < 1e-12) continue;
      const s = (ax * ey - ay * ex) / den, t = (ax * dy - ay * dx) / den;
      if (s > 0 && t >= -1e-9 && t <= 1 + 1e-9) best = Math.min(best, s);
    }
    return isFinite(best) ? L / best : Infinity;
  }
  return { at, contour, util };
}
// SGU: naprężenia w przekroju zarysowanym przy zginaniu ukośnym (beton nie przenosi rozciągania)
function elasticBiax(parts, bars, beff, Ec, Es, N, My, Mz) {
  const { fib, corners } = fiberize(parts, 40, 16);
  const yc = grossProps(parts).yc;
  const bz = bars.map(b => ({ y: b.y, z: b.x - beff / 2, A: b.A }));
  let a = [0, 0, 0];
  const strain = (y, z) => a[0] + a[1] * (yc - y) - a[2] * z;
  const solve3 = (J, r) => {
    const M = J.map((row, i) => [...row, r[i]]);
    for (let c = 0; c < 3; c++) {
      let p = c; for (let i = c + 1; i < 3; i++) if (Math.abs(M[i][c]) > Math.abs(M[p][c])) p = i;
      [M[c], M[p]] = [M[p], M[c]]; if (Math.abs(M[c][c]) < 1e-30) return [0, 0, 0];
      for (let i = 0; i < 3; i++) if (i !== c) { const f = M[i][c] / M[c][c]; for (let j = c; j < 4; j++) M[i][j] -= f * M[c][j]; }
    }
    return [M[0][3] / M[0][0], M[1][3] / M[1][1], M[2][3] / M[2][2]];
  };
  for (let it = 0; it < 60; it++) {
    const J = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], F = [0, 0, 0];
    const add = (k, y, z, sg, A) => {
      const v = [1, yc - y, -z];
      for (let i = 0; i < 3; i++) { F[i] += sg * A * v[i]; for (let j = 0; j < 3; j++) J[i][j] += k * A * v[i] * v[j]; }
    };
    const one = f => { const e = strain(f.y, f.z); if (it === 0 || e > 0) add(Ec, f.y, f.z, it === 0 ? 0 : Ec * e, f.A); };
    for (const f of fib) {
      if (it === 0) { one(f); continue; }
      const ec = strain(f.y, f.z), hw = (Math.abs(a[1]) * f.dy + Math.abs(a[2]) * f.dz) / 2;
      if (ec - hw < 0 && ec + hw > 0) subFibers(f).forEach(one); else one(f);
    }
    for (const b of bz) { const e = strain(b.y, b.z); add(Es, b.y, b.z, Es * e, b.A); }
    const res = [N - F[0], My - F[1], Mz - F[2]];
    const d = solve3(J, res);
    a = [a[0] + d[0], a[1] + d[1], a[2] + d[2]];
    if (it > 1 && Math.abs(d[0]) < 1e-9 && Math.abs(d[1]) < 1e-12 && Math.abs(d[2]) < 1e-12) break;
  }
  let sc = 0, ss = 0;
  for (const [y, z] of corners) { const e = strain(y, z); if (e > 0) sc = Math.max(sc, Ec * e); }
  for (const b of bz) { const e = strain(b.y, b.z); ss = Math.max(ss, -Es * e); }
  return { sc, ss, plane: a.slice() };
}
// przekrój obrócony (zginanie względem osi pionowej): "y" = z + b_eff/2
function rotatedParts(g) {
  if (!g.T) return [{ y0: 0, y1: g.bw, b: g.h }];
  const a = (g.beff - g.bw) / 2;
  return [{ y0: 0, y1: a, b: g.hf }, { y0: a, y1: a + g.bw, b: g.h }, { y0: a + g.bw, y1: g.beff, b: g.hf }];
}
const rotatedBars = (bars) => bars.map(b => Object.assign({}, b, { y: b.x }));

/* ------------------------------------------------- pełzanie i skurcz (zał. B) */
function creepShrink(S, m, g) {
  const RH = clamp(S.sls.RH, 20, 100), t0 = Math.max(1, S.sls.t0), cem = S.sls.cem;
  const fcm = m.fcm, h0 = g.h0;
  const tInf = S.sls.t === 'inf';
  const t = tInf ? Infinity : num(S.sls.t, 18250);
  const alpha = { S: -1, N: 0, R: 1 }[cem] ?? 0;
  const a1 = (35 / fcm) ** 0.7, a2 = (35 / fcm) ** 0.2, a3 = (35 / fcm) ** 0.5;
  const phiRH = fcm <= 35 ? 1 + (1 - RH / 100) / (0.1 * Math.cbrt(h0)) : (1 + (1 - RH / 100) / (0.1 * Math.cbrt(h0)) * a1) * a2;
  const bfcm = 16.8 / Math.sqrt(fcm);
  const t0adj = Math.max(0.5, t0 * Math.pow(9 / (2 + Math.pow(t0, 1.2)) + 1, alpha));
  const bt0 = 1 / (0.1 + Math.pow(t0adj, 0.2));
  const phi0 = phiRH * bfcm * bt0;
  const betaH = fcm <= 35 ? Math.min(1.5 * (1 + (0.012 * RH) ** 18) * h0 + 250, 1500) : Math.min(1.5 * (1 + (0.012 * RH) ** 18) * h0 + 250 * a3, 1500 * a3);
  const bc = tInf ? 1 : Math.pow((t - t0) / (betaH + t - t0), 0.3);
  const phiCalc = phi0 * bc;
  const phi = S.sls.phiSel === 'off' ? 0 : S.sls.phiSel === 'manual' ? S.sls.phi : phiCalc;     // 'off' – pełzanie pominięte (E_c,eff = E_cm)
  // skurcz
  const ads1 = { S: 3, N: 4, R: 6 }[cem] ?? 4, ads2 = { S: 0.13, N: 0.12, R: 0.11 }[cem] ?? 0.12;
  const betaRH = 1.55 * (1 - (RH / 100) ** 3);
  const ecd0 = 0.85 * ((220 + 110 * ads1) * Math.exp(-ads2 * fcm / 10)) * 1e-6 * betaRH;
  const kh = interp([[100, 1.0], [200, 0.85], [300, 0.75], [500, 0.70]], h0);
  const ts = Math.max(1, S.sls.ts);
  const bds = tInf ? 1 : (t - ts) / ((t - ts) + 0.04 * Math.sqrt(h0 ** 3));
  const ecd = bds * kh * ecd0;
  const ecaInf = 2.5 * (m.fck - 10) * 1e-6;
  const bas = tInf ? 1 : 1 - Math.exp(-0.2 * Math.sqrt(t));
  const eca = bas * ecaInf;
  return { RH, t0, t, tInf, cem, alpha, h0, a1, a2, a3, phiRH, bfcm, t0adj, bt0, phi0, betaH, bc, phiCalc, phi,
    ads1, ads2, betaRH, ecd0, kh, ts, bds, ecd, ecaInf, bas, eca, ecs: ecd + eca };
}

/* ======================================================================
   GŁÓWNA PROCEDURA
   ====================================================================== */
function calc(S0, opts) {
  opts = opts || {};
  const S = normalize(S0);
  if (opts.acc) { S.coef.gc = S.coef.gcA; S.coef.gs = S.coef.gsA; }
  const R = { S, errors: [], warnings: [], checks: [], ver: '2.9.12', acc: !!opts.acc };
  const m = materials(S); R.m = m;
  const g0 = geometry(S, R); R.g = g0;
  if (R.errors.length) return R;
  const md = beamModel(S); R.md = md;
  if (md.segs.some(sg => !(sg.L > 300))) { R.errors.push('Każde przęsło i wspornik musi mieć długość większą od 0,3 m.'); return R; }
  if (md.unstable && S.scheme !== 'manual') { R.errors.push('Układ geometrycznie zmienny w płaszczyźnie pionowej (Y) – za mało więzów podporowych lub za dużo przegubów (np. wspornik bez utwierdzenia). Zmień podpory lub przeguby na schemacie.'); return R; }
  if (!opts.acc) {
    if (md.noHor) R.warnings.push('Brak podpory blokującej przesuw podłużny x – belka nie jest ustalona w kierunku podłużnym (siła osiowa N_Ed przyjmowana jako zadana).');
    md.sups.filter(p => !p.fy).forEach(p => R.warnings.push(`${p.name[0].toUpperCase() + p.name.slice(1)}: odblokowany przesuw pionowy y – w wymiarowaniu (lico, zakotwienie, ścinanie) miejsce traktowane jak podpora.`));
    md.hinges.forEach(x => R.warnings.push(`Przegub w belce w x = ${(x / 1000).toFixed(2).replace('.', ',')} m – moment zginający równy zero; połączenie wymaga indywidualnego rozwiązania konstrukcyjnego (np. krótki wspornik, łożysko).`));
  }
  // przekroje odcinków (belka ciągła: przęsła o różnych wymiarach b × h; wsporniki jak przęsło sąsiednie)
  const gCache = {};
  const geoOf = ov => {
    const b = ov && ov.b > 0 ? ov.b : S.geom.b, hh = ov && ov.h > 0 ? ov.h : S.geom.h, key = b + 'x' + hh;
    if (!gCache[key]) gCache[key] = (b === S.geom.b && hh === S.geom.h) ? g0 : geometry(Object.assign({}, S, { geom: Object.assign({}, S.geom, { b, h: hh }) }), R);
    return gCache[key];
  };
  md.segs.forEach(sg => { sg.g = md.cont && sg.kind === 'span' ? geoOf(S.cont.geoSpans[sg.si]) : null; });
  md.segs.forEach(sg => { if (!sg.g) sg.g = md.cont && sg.adj !== undefined && md.segs[sg.adj] && md.segs[sg.adj].g ? md.segs[sg.adj].g : g0; });
  if (R.errors.length) return R;
  md.sups.forEach(p => {
    const adj = [p.segL, p.segR].filter(i => i !== null).map(i => md.segs[i]);
    p.gSeg = adj.reduce((a, sg) => (!a || sg.g.h < a.g.h || (sg.g.h === a.g.h && sg.g.bw < a.g.bw) ? sg : a), null);
    p.g = p.gSeg.g;
  });
  const g = (md.segs.find(sg => sg.kind === 'span') || md.segs[0]).g; R.g = g; R.g0 = g0;
  R.gVar = new Set(md.segs.map(sg => sg.g)).size > 1;
  const gMin = md.segs.reduce((a, sg) => (sg.g.bw * sg.g.h < a.bw * a.h ? sg.g : a), g);
  // strzemiona odcinków (puste pola – wartości ogólne)
  const stirOf = ov => { const o = Object.assign({}, S.stir); o.s1Man = !S.stir.sAuto; o.s2Man = !S.stir.sAuto; o.spMan = !S.stir.sAuto; o.sp = +S.stir.sp > 0 ? +S.stir.sp : 0;
    if (ov) ['d', 'legs', 's1', 's2', 'sp', 'hook', 'hookA'].forEach(k => { if (ov[k] !== '' && ov[k] > 0) { o[k] = +ov[k]; if (k === 's1') o.s1Man = true; if (k === 's2') o.s2Man = true; if (k === 'sp') o.spMan = true; } });
    if (ov && ov.kind) o.kind = ov.kind; o.legs = Math.max(2, Math.round(o.legs)); o.d = Math.min(12, o.d); return o; };
  md.segs.forEach(sg => { sg.stir = md.cont && sg.kind === 'span' ? stirOf(S.cont.stirSpans[sg.si]) : null; });
  md.segs.forEach(sg => { if (!sg.stir) sg.stir = md.cont && sg.adj !== undefined && md.segs[sg.adj] && md.segs[sg.adj].stir ? md.segs[sg.adj].stir : stirOf(null); });
  R.stirVar = md.segs.some(sg => ['d', 'legs', 's1', 's2', 'sp', 'kind'].some(k => sg.stir[k] !== md.segs[0].stir[k]));
  const rb = S.reb, dsw = Math.max(...md.segs.map(sg => sg.stir.d)), dg = S.mat.dg;
  const h = g.h;
  g.Ltot = md.Ltot;

  // ---------- otulina
  // para prętów jeden nad drugim jak pręty pojedyncze (8.9.1(4)) – tylko po zaznaczeniu (S.anch.pairSep), w dobrych warunkach przyczepności
  const sepB = S.anch.pairSep && S.anch.bond !== 'poor', sepT = S.anch.pairSep && (S.anch.bond === 'good' || h <= 250);
  const zMax = (z, sp) => z && z.layers ? Math.max(0, ...z.layers.flatMap(l => l.bars.map(q => unitOf(q.d, z.nb, z.shape, sp).d))) : 0;
  const dMain = Math.max(...md.segs.filter(sg => sg.reb).map(sg => zMax(sg.reb, sepB)), zMax(rb.top, sepT), ...md.sups.map(p => zMax(p.reb, sepT)), rb.mid.n > 0 ? rb.mid.d : 0);
  const cov = coverCalc(S, m, dMain, dsw); R.cov = cov;
  const cnom = cov.cnom;
  // otulina krawędzi: dolnej (z betonowaniem na podłożu), górnej i bocznych; podana ręcznie dla krawędzi albo ogólna
  const cAuto = k => cov.manual ? cov.cnom : (k === 'cBot' ? cov.reqR : cov.reqNGR);
  cov.cb = S.env.cBot !== '' ? S.env.cBot : cAuto('cBot'); cov.ct = S.env.cTop !== '' ? S.env.cTop : cAuto('cTop'); cov.cs = S.env.cSide !== '' ? S.env.cSide : cAuto('cSide');
  if (S.fire.R && S.fire.R !== '-' && !cov.manual) {
    const contF = md.cont || md.sups.some(p => p.type === 'fix'), tabF = (contF ? FIRE_CONT : FIRE_SS)[S.fire.R];
    if (tabF) {
      const cs2 = tabF.c, bF = Math.min(...md.segs.map(sg => sg.g.bw)), dB = Math.max(16, ...md.segs.filter(sg => sg.reb).map(sg => zMax(sg.reb, sepB)));
      const aF = bF < cs2[0][0] ? cs2[0][1] : bF >= cs2[cs2.length - 1][0] ? cs2[cs2.length - 1][1] : interp(cs2, bF);
      const cbF = ceilTo(aF - dsw - dB / 2, 5), csF = ceilTo(aF + 10 - dsw - dB / 2, 5);
      if (S.env.cBot === '' && cbF > cov.cb) { cov.cb = cbF; cov.fireB = true; }
      if (S.env.cSide === '' && bF < cs2[cs2.length - 1][0] && csF > cov.cs) { cov.cs = csF; cov.fireS = true; }
      cov.fireA = aF;
    }
  }
  cov.reqB = cov.reqR; cov.reqT = cov.reqNGR; cov.reqS = cov.reqNGR;
  cov.cmin = Math.min(cov.cb, cov.ct, cov.cs); cov.cmax = Math.max(cov.cb, cov.ct, cov.cs);
  cov.faces = !(cov.cb === cov.ct && cov.ct === cov.cs);
  const cvB = { e: cov.cb, s: cov.cs }, cvT = { e: cov.ct, s: cov.cs }, cv3 = { b: cov.cb, t: cov.ct, s: cov.cs };
  R.cv = cv3;

  // ---------- układ prętów
  const ltCache = new Map();
  md.segs.forEach(sg => { if (!ltCache.has(sg.g)) ltCache.set(sg.g, layoutZone(rb.top, sg.g, cvT, dsw, dg, { sep: sepT })); sg.Lt = ltCache.get(sg.g); });
  const LtM = g === md.segs[0].g || !md.segs.find(sg => sg.g === g) ? md.segs[0].Lt : md.segs.find(sg => sg.g === g).Lt;
  R.LtM = LtM;
  const mid = (gg, lb, lt) => midBars(gg, cv3, dsw, rb.mid, lb, lt);
  md.segs.forEach(sg => {
    if (!sg.reb) return;
    sg.Lb = layoutZone(sg.reb, sg.g, cvB, dsw, dg, { sep: sepB });
    sg.LbS = subLayout(sg.Lb, b => b.supp, sg.g);
  });
  md.segs.forEach(sg => { if (!sg.reb) { const a = md.segs[sg.adj]; sg.Lb = a.LbS; sg.LbS = a.LbS; } });
  R.bareSegs = []; R.bareSups = [];
  const virtLay = (eC) => ({ layers: [], bars: [], bClear: 0, x0: 0, issues: [], ok: true, A: 0, eC, n: 0, nBars: 0, dmax: 0, dnMax: 0, dBarMax: 0, desc: '—', open: 0, stacked: false, virt: true });
  for (const sg of md.segs) {
    if (!sg.Lb || !sg.Lb.n) { R.bareSegs.push(sg); sg.Lb = virtLay(cov.cb + dsw + 10); sg.LbS = sg.Lb; continue; }
    if (!sg.LbS.n) { R.errors.push(`Zbrojenie dolne (${sg.label}): co najmniej jeden pręt musi być doprowadzony do podpór.`); return R; }
  }
  md.segs.forEach(sg => { if (!sg.reb && sg.Lb.virt && !R.bareSegs.includes(sg)) R.bareSegs.push(sg); });
  md.segs.forEach(sg => {
    sg.cut = sg.LbS.n < sg.Lb.n;
    sg.mid = mid(sg.g, sg.Lb, sg.Lt);
    sg.barsSpan = [...sideBars(sg.Lb, 'bot', sg.g.h), ...sideBars(sg.Lt, 'top', sg.g.h), ...sg.mid];
    sg.hold = stirLegs(sg.Lb, sg.Lt, sg.g, cov, sg.stir);
  });
  md.sups.forEach(p => {
    p.hasX = p.nX > 0;
    p.LtS = p.hasX ? layoutZone(p.reb, p.g, cvT, dsw, dg, { sep: sepT, base: rb.top, baseSep: sepT, baseLay: p.gSeg.Lt }) : p.gSeg.Lt;
    p.LtX = p.hasX ? subLayout(p.LtS, b => b.tag === 'z', p.g) : null;
    p.dX = p.hasX ? p.LtX.dmax : 0;
    const adj = [p.segL, p.segR].filter(i => i !== null).map(i => md.segs[i]).filter(sg => sg.g === p.g);
    p.LbS = adj.reduce((a, sg) => (!a || sg.LbS.A < a.A ? sg.LbS : a), null) || p.gSeg.LbS;
    p.mid = mid(p.g, p.LbS, p.LtS);
    p.barsSupp = [...sideBars(p.LbS, 'bot', p.g.h), ...sideBars(p.LtS, 'top', p.g.h), ...p.mid];
  });
  R.midA = rb.mid.n > 0 ? 2 * rb.mid.n * area(rb.mid.d) : 0;
  // pręty dolne i górne muszą się zmieścić w wysokości przekroju
  const extOf = L => L && L.bars.length ? Math.max(...L.bars.map(b => b.edge + (b.nb > 1 && b.shape === 'v' ? b.nb * b.dBar : b.nb === 3 && b.shape === 't' ? 1.87 * b.dBar : b.dBar))) : 0;
  const fitChk = (lb, lt, nm, hh) => { const eb = extOf(lb), et = extOf(lt); if (eb + et > hh - 20) R.errors.push(`Zbrojenie nie mieści się w wysokości przekroju (${nm}): pręty dolne zajmują ${Math.round(eb)} mm od spodu, górne ${Math.round(et)} mm od góry, h = ${hh} mm – zmniejsz liczbę warstw lub średnice prętów.`); };
  md.segs.forEach(sg => fitChk(sg.Lb, sg.Lt, sg.label, sg.g.h));
  md.sups.forEach(p => { if (p.hasX) fitChk(p.LbS, p.LtS, p.name, p.g.h); });
  if (R.errors.length) return R;

  // ---------- statyka
  const st = statics(S, g, R, Object.assign({ md }, opts)); R.st = st;
  if (st.hasZ && md.unstableZ) { R.errors.push('Układ geometrycznie zmienny w płaszczyźnie poziomej (Z) – działają obciążenia Z, a podpory nie blokują wystarczająco przesuwu poprzecznego z. Zablokuj kierunek z na podporach.'); return R; }
  const NEd = st.NEd, TEd = st.TEd;

  // ---------- SGN: zginanie – przekroje obliczeniowe
  const secs = [];
  const mkSec = (kind, obj, k) => {
    const isSpan = kind === 'span';
    const sg = isSpan ? obj : null, sp = isSpan ? null : obj;
    const gs = isSpan ? sg.g : sp.g, hS = gs.h;
    const tens = isSpan ? sg.Lb : sp.LtS, comp = isSpan ? sg.Lt : sp.LbS;
    const bars = isSpan ? sg.barsSpan : sp.barsSupp;
    const barsU = S.reb.useComp ? bars : bars.filter(b => b.side !== (isSpan ? 'top' : 'bot'));     // bez prętów ściskanych (przekrój pojedynczo zbrojony)
    const parts = isSpan ? gs.partsS : gs.partsH, barsO = isSpan ? barsU : flipBars(barsU, hS);
    const sec = { kind, seg: sg, sup: sp, g: gs, k, x: st.x[k], tens, comp, bars, parts, barsO, d: tens.n || tens.virt ? hS - tens.eC : hS - ((isSpan ? cov.cb : cov.ct) + dsw + 10), a2: comp.n ? comp.eC : 40, bare: !tens.n,
      loc: isSpan ? sg.label : sp.name, yc: isSpan ? gs.yc : hS - gs.yc, key: isSpan ? 's' + sg.idx : 'p' + sp.idx };
    sec.uls = makeULS(parts, hS, barsO, m);
    sec.MEd = isSpan ? Math.max(0, st.MEdMax[k]) : Math.max(0, -st.MEdMin[k]);
    // redukcja momentu nad podporą (5.3.2.2): monolityczna – moment w licu (≥ 0,65·M w osi), swobodna – ΔM = F_Ed,sup·t/8
    const rq = !isSpan && st.supRed && st.supRed[sp.idx] ? st.supRed[sp.idx].U : null;
    if (rq && sec.MEd > 0) { sec.MEd0 = sec.MEd; sec.MEd = Math.max(0, -st.MEdMinR[k]); sec.red = rq; }
    sec.r = tens.n ? sec.uls.MRd(NEd) : null; sec.MRd = sec.r ? sec.r.M : 0;
    sec.r0 = sec.uls.MRd(0);
    sec.des = designBending({ M: sec.MEd, N: NEd, bf: isSpan ? gs.bFlange : gs.bw, bw: gs.bw, hf: isSpan ? gs.hf : 0, d: sec.d, a2: sec.a2 || 40, yc: sec.yc, m });
    return sec;
  };
  const nodesOf = sg => st.x.map((x, k) => k).filter(k => st.x[k] >= sg.x0 - 1e-6 && st.x[k] <= sg.x1 + 1e-6);
  md.segs.forEach(sg => {
    sg.nodes = nodesOf(sg);
    let kb = sg.nodes[0]; sg.nodes.forEach(k => { if (st.MEdMax[k] > st.MEdMax[kb]) kb = k; });
    if (sg.kind === 'span' || st.MEdMax[kb] > 1e3) { sg.sec = mkSec('span', sg, kb); secs.push(sg.sec); }
  });
  md.sups.forEach(p => {
    const k = st.kAt(p.x); p.k = k;
    if (st.MEdMin[k] < -1e3 || (!opts.acc && st.MkMin[k] < -1e3)) {
      if (!p.LtS.n) R.bareSups.push(p);
      p.sec = mkSec('supp', p, k); secs.push(p.sec);
    }
  });
  secs.sort((a, b) => a.x - b.x || (a.kind === 'supp' ? -1 : 1));
  // redystrybucja automatyczna: δ ≥ k₁ + k₂·x_u/d (k₁ = 0,44, k₂ = 1,25 dla f_ck ≤ 50 MPa) przy rzeczywistym zbrojeniu przekroju podporowego
  if (S.loads.redist === 'auto' && st.redist && st.redist.length && !opts.redistD && !opts.acc) {
    const need = {}; let ch = false;
    st.redist.forEach(q => { const sec = q.sup.sec; if (!sec || !sec.r || !(sec.d > 0)) return; const dmin = Math.min(1, 0.44 + 1.25 * Math.max(0, sec.r.x) / sec.d); need[q.sup.idx] = Math.max(q.delta, Math.ceil(dmin * 100) / 100); if (need[q.sup.idx] > q.delta + 1e-9) ch = true; });
    if (ch) return calc(S0, Object.assign({}, opts, { redistD: Object.assign({}, ...st.redist.map(q => ({ [q.sup.idx]: need[q.sup.idx] || q.delta }))) }));
  }
  R.secs = secs;
  R.bare = R.bareSegs.length > 0 || R.bareSups.length > 0;
  if (R.errors.length) return R;
  const ulsAny = secs[0] ? secs[0].uls : makeULS(md.segs[0].g.partsS, md.segs[0].g.h, md.segs[0].barsSpan, m);
  R.NRdMax = Math.min(...secs.map(s => s.uls.Nmax)); R.NRdMin = Math.max(...secs.map(s => s.uls.Nmin));
  void ulsAny;

  // ---------- SGN: zginanie ukośne (obciążenia w płaszczyźnie Z)
  if (st.hasZ && !R.bare) {
    const biaxCache = new Map();
    const biaxOf = (bars, gg) => { gg = gg || g; if (!biaxCache.has(bars)) biaxCache.set(bars, makeBiax(gg.partsS, bars, m, gg.beff)); return biaxCache.get(bars); };
    const evalAt = (bars, k, signs, gg) => {
      const B = biaxOf(bars, gg); let best = { u: 0 };
      signs.forEach(sy => st.pairs(st.ulsList, k, sy).forEach(([My, Mz], ci) => {
        const u = B.util(NEd, My, Mz); if (u > best.u) best = { u, My, Mz, ci, sy };
      }));
      return best;
    };
    secs.forEach(sec => { sec.biax = evalAt(sec.bars, sec.k, [sec.kind === 'span' ? 1 : -1], sec.g); });
    R.biaxZ = [];
    md.segs.forEach(sg => {
      let kz = sg.nodes[0]; sg.nodes.forEach(k => { if (st.MzEd[k] > st.MzEd[kz]) kz = k; });
      if (st.MzEd[kz] < 1e3) return;
      const near = secs.some(s => Math.abs(s.x - st.x[kz]) < 0.05 * sg.L);
      if (near) return;
      const r = evalAt(sg.barsSpan, kz, [1, -1], sg.g);
      R.biaxZ.push(Object.assign({ seg: sg, k: kz, x: st.x[kz], loc: sg.label }, r));
    });
    R.biaxOf = biaxOf;
  }

  // ---------- SGN: ścinanie (+ skręcanie)
  const sh = { cotSel: S.stir.cot };
  const st0 = md.segs[0].stir;
  const legs = st0.legs;
  const A1 = area(st0.d); sh.legs = legs; sh.A1 = A1; sh.Asw = legs * A1;
  sh.rhoMin = 0.08 * Math.sqrt(m.fck) / m.fywk;
  const bw = g.bw;
  const tor = { on: TEd > 0 };
  {
    const bw = gMin.bw, h = gMin.h;                 // skręcanie – najmniejszy przekrój (bezpiecznie)
    const A = bw * h, u = 2 * (bw + h);
    const dTop = Math.max(LtM.dmax || 0, ...md.sups.map(p => p.LtS.dmax || 0));
    const aEdge = cov.cmin + dsw + Math.max(...md.segs.map(sg => sg.Lb.dmax), dTop) / 2;
    tor.A = A; tor.u = u; tor.tef0 = A / u; tor.aEdge = aEdge;
    tor.tef = Math.min(Math.max(A / u, 2 * aEdge), Math.min(bw, h) / 2);
    tor.bk = bw - tor.tef; tor.hk = h - tor.tef;
    tor.Ak = tor.bk * tor.hk; tor.uk = 2 * (tor.bk + tor.hk);
    tor.TRdc = 2 * tor.Ak * tor.tef * m.fctd;
  }
  const ends = [];
  // redukcja siły poprzecznej (6.2.1(8)): tylko gdy obciążenie działa na górną powierzchnię, a reakcja na dolną (podparcie bezpośrednie);
  // siła skupiona w odległości ≤ d od lica wyklucza redukcję (6.2.2(6) – nie stosowano zmniejszenia β)
  const allPts = st.layout ? [...st.layout.G, ...st.layout.vars, ...st.layout.accs].flatMap(r => r.pts.filter(q => Math.abs(q.Py) > 0)) : [];
  md.segs.forEach(sg => {
    const gs = sg.g, hS = gs.h, bwS = gs.bw;
    [['L', sg.supL, 1], ['R', sg.supR, -1]].forEach(([side, sp, dir]) => {
      if (!sp) return;
      const k = st.kAt(sp.x);
      const hog = st.MEdMin[k] < -1e3;
      const lay = hog && sp.LtS.n ? sp.LtS : sg.LbS;
      const d = hS - lay.eC;
      const Asl = lay.A;
      const reach = sg.kind === 'span' ? sg.L / 2 : sg.L;
      const V0 = st.Vin(sp.x, dir);
      const xr = sp.t / 2 + d;
      const face = sp.x + dir * sp.t / 2;
      const ptNear = allPts.some(q => (q.x - face) * dir >= -1 && (q.x - face) * dir <= d + 1);
      const redWhy = !S.stir.redV ? 'redukcja wyłączona' : st.manual ? '' : !sp.direct ? 'podparcie pośrednie (reakcja nie działa na dolną powierzchnię)' : st.allTop === false ? 'obciążenie przyłożone nie tylko do górnej powierzchni' : ptNear ? 'siła skupiona w odległości ≤ d od lica' : '';
      const red = S.stir.redV && !redWhy;
      const Vred = red ? st.Vin(sp.x + dir * Math.min(xr, reach), dir) : V0;
      const kk = Math.min(2, 1 + Math.sqrt(200 / d));
      const rhol = Math.min(0.02, Asl / (bwS * d));
      const sigcp = Math.min(NEd / gs.Ac, 0.2 * m.fcd);
      const CRdc = 0.18 / m.gc, k1 = 0.15;
      const vmin = 0.035 * kk ** 1.5 * Math.sqrt(m.fck);
      const VRdc1 = (CRdc * kk * Math.cbrt(100 * rhol * m.fck) + k1 * sigcp) * bwS * d;
      const VRdcMin = (vmin + k1 * sigcp) * bwS * d;
      const VRdc = Math.max(VRdc1, VRdcMin);
      const single = !md.cont;
      ends.push({ seg: sg, sup: sp, side, dir, x: sp.x, hog, d, Asl, V0, Vred, xr, red, redWhy, g: gs, bw: bwS, stir: sg.stir, k: kk, rhol, sigcp, CRdc, vmin, VRdc1, VRdcMin, VRdc, z: 0.9 * d, reach,
        name: single ? sp.name : `${sp.name}, ${sg.label}`, key: `e${sg.idx}${side}`,
        simple: sp.end && sp.type !== 'fix' && (st.manual ? st.simpleEnd[side === 'L' ? 0 : 1] : true) });
    });
  });
  sh.ends = ends;
  const VRdmaxOf = (cot, z, bwE) => 1.0 * (bwE || bw) * z * m.nu * m.fcd / (cot + 1 / cot);
  const TRdmaxOf = (cot) => { const th = Math.atan(1 / cot); return 2 * m.nu * 1.0 * m.fcd * tor.Ak * tor.tef * Math.sin(th) * Math.cos(th); };
  const interOk = (cot) => ends.every(e => e.V0 / VRdmaxOf(cot, e.z, e.bw) + (tor.on ? TEd / TRdmaxOf(cot) : 0) <= 1 + 1e-9);
  let cot;
  if (S.stir.cot === 'auto') {
    cot = 2.5;
    if (!interOk(cot)) { let lo = 1, hi = 2.5; if (!interOk(1)) cot = 1; else { for (let i = 0; i < 50; i++) { const mid = (lo + hi) / 2; if (interOk(mid)) lo = mid; else hi = mid; } cot = Math.floor(lo * 100) / 100; } }
  } else cot = clamp(num(S.stir.cot, 2), 1, 2.5);
  sh.cot = cot; sh.theta = Math.atan(1 / cot) * 180 / Math.PI;
  tor.TRdmax = TRdmaxOf(cot);
  tor.tReq = tor.on ? TEd / (2 * tor.Ak * m.fywd * cot) : 0;
  const VRdsEff = (s, z, sti) => { sti = sti || st0; return sti.legs * z * m.fywd * cot * Math.max(0, area(sti.d) / s - tor.tReq); };
  const ETAV = S._eta > 0 && S._eta < 1 ? S._eta : 1;          // wytężenie docelowe (automatyczny dobór przekrojów i zbrojenia)
  // belka ściskana siłą osiową N_Ed > 0 (jak słup): pręty podłużne ściskane – strzemiona w rozstawie ≤ 15⌀ (9.2.1.2(3)), ⌀ – najmniejsza
  // średnica prętów podłużnych; sama strefa ściskana przy zginaniu (bez siły ściskającej) – bez tego ograniczenia
  const compPhi = sgs => {
    const ids = new Set(sgs.map(q => q.idx)), dmin = lay => lay && lay.n && lay.bars && lay.bars.length ? Math.min(...lay.bars.map(b => b.dBar || b.d)) : Infinity;
    const ss = secs.filter(x => (x.kind === 'span' && ids.has(x.seg.idx)) || (x.kind === 'supp' && (ids.has(x.sup.segL) || ids.has(x.sup.segR))));
    let p = Infinity, why = '';
    if (NEd > 1e3) { ss.forEach(x => { p = Math.min(p, dmin(x.tens), dmin(x.comp)); }); if (S.reb.mid && S.reb.mid.n > 0) p = Math.min(p, S.reb.mid.d); why = 'N'; }
    return { phi: p, why };
  };
  sh.compPhi = compPhi;
  {
    const rd = (v, step) => Math.max(50, Math.floor(v / step + 1e-9) * step);
    const sRound = v => v >= 100 ? rd(v, 25) : rd(v, 5);
    const groups = new Map(); md.segs.forEach(sg => { const q = sg.stir; if (!groups.has(q)) groups.set(q, []); groups.get(q).push(sg); });
    // zasięg od lica podpory, na którym V_Ed > V_Rd (siła poprzeczna z obwiedni)
    // przy redukcji 6.2.1(8) odcinek do odległości d od lica wymiarowany na V_Ed(d) – zasięg liczony od d
    const extOf = (e, VRd) => { const face = e.sup.t / 2, avail = Math.max(0, e.reach - face), N = 200, d0 = e.red ? Math.min(e.d, avail) : 0; let l = 0; for (let i = 0; i <= N; i++) { const dx = d0 + (avail - d0) * i / N; if (st.Vat(e.x + e.dir * (face + dx)) > VRd + 1e-6) l = dx + (avail - d0) / N; } return Math.min(l, avail); };
    sh.extOf = extOf;
    const nzSel = S.stir.nz;
    groups.forEach((sgs, q) => {
      const es0 = ends.filter(e => sgs.includes(e.seg));
      if (q.s1Man && q.s2Man) { if (!q.spMan || nzSel === '1' || nzSel === '2' || !(q.sp > q.s1 && q.sp < q.s2)) q.sp = 0; if (nzSel === '1') q.s2 = q.s1; return; }
      const es = es0, A1q = area(q.d), legsq = Math.max(2, q.legs);
      const dS = Math.min(...es.map(e => e.d), ...secs.filter(x => x.kind === 'span' && sgs.includes(x.seg)).map(x => x.d), Infinity);
      const bwq = Math.min(...sgs.map(sg => sg.g.bw));
      let sMx = 0.75 * (isFinite(dS) ? dS : 0.9 * sgs[0].g.h);
      if (tor.on) sMx = Math.min(sMx, tor.u / 8, gMin.bw, gMin.h);
      const pc = compPhi(sgs); if (isFinite(pc.phi)) sMx = Math.min(sMx, 15 * pc.phi);   // pręty ściskane – ≤ 15⌀ (9.2.1.2(3))
      const sRho = legsq * A1q / (sh.rhoMin * bwq);
      const s2 = sRound(Math.min(sMx, sRho, 400));
      const need = es.map(e => { const perLeg = e.Vred / ETAV / (legsq * e.z * m.fywd * cot) + tor.tReq / ETAV; return perLeg > 0 ? A1q / perLeg : Infinity; });
      const s1 = sRound(Math.min(s2, ...need));
      if (!q.s2Man) q.s2 = s2;
      if (!q.s1Man) q.s1 = Math.min(s1, q.s2);
      if (nzSel === '1') { q.s2 = q.s1; q.sp = 0; }
      // strefa pośrednia: rozstaw między s₁ i s₂ minimalizujący liczbę strzemion (auto: gdy oszczędność ≥ 3 szt. i ≥ 4%)
      const cntOf = (sp) => es.reduce((a, e) => { const z = e.z, avail = Math.max(1, e.reach - e.sup.t / 2), V2 = VRdsEff(q.s2, z, q) * ETAV;
        if (!sp) { const l1 = extOf(e, V2); return a + l1 / q.s1 + (avail - l1) / q.s2; }
        const l1 = extOf(e, VRdsEff(sp, z, q) * ETAV), l12 = Math.max(l1, extOf(e, V2)); return a + l1 / q.s1 + (l12 - l1) / sp + (avail - l12) / q.s2; }, 0);
      let spBest = 0;
      if (nzSel !== '1' && nzSel !== '2' && q.s2 - q.s1 >= 50) {
        const base = cntOf(0); let best = base;
        for (let v = q.s1 + 25; v <= q.s2 - 25 + 1e-9; v += 25) { const cnt = cntOf(sRound(v)); if (cnt < best - 1e-6) { best = cnt; spBest = sRound(v); } }
        if (nzSel === 'auto' && !(base - best >= 3 && base - best >= 0.04 * base)) spBest = 0;
      }
      if (!q.spMan || nzSel === '1' || nzSel === '2') q.sp = spBest;
      else if (!(q.sp > q.s1 && q.sp < q.s2)) q.sp = 0;
      q.sAutoInfo = { s1: q.s1, s2: q.s2, sp: q.sp, sMax: sMx, sRho, need: Math.min(...need), cot };
    });
  }
  const l1Sel = S.stir.l1 === 'auto' || S.stir.l1 === undefined || S.stir.l1 === '' ? null : num(S.stir.l1, null) * 1000;
  const lpSel = S.stir.lp === 'auto' || S.stir.lp === undefined || S.stir.lp === '' ? null : num(S.stir.lp, null) * 1000;
  const extOf2 = (e, VRd) => { const face = e.sup.t / 2, avail = Math.max(0, e.reach - face), N = 300, d0 = e.red ? Math.min(e.d, avail) : 0; let l = 0; for (let i = 0; i <= N; i++) { const dx = d0 + (avail - d0) * i / N; if (st.Vat(e.x + e.dir * (face + dx)) > VRd + 1e-6) l = dx + (avail - d0) / N; } return Math.min(l, avail); };
  ends.forEach(e => {
    e.VRdmax = VRdmaxOf(cot, e.z, e.bw);
    e.VRds1 = VRdsEff(e.stir.s1, e.z, e.stir);
    // pręty odgięte (α = 45°, 6.2.3(4), wzór 6.13) – tylko gdy same strzemiona nie wystarczają; strzemiona ≥ 50% wymaganego zbrojenia (9.2.2(4))
    e.bent = null;
    if (S.stir.bent !== 'off' && e.Vred > e.VRds1 + 1 && e.Vred <= e.VRdmax && !tor.on) {
      const dV = e.Vred - e.VRds1, sbMax = 0.6 * e.d * (1 + 1), sb = Math.max(100, Math.floor(sbMax / 25) * 25), ka = e.z * m.fywd * (cot + 1) * Math.SQRT1_2 / sb;
      let pick = null;
      for (const n of [2, 4]) { for (const dB of [12, 16, 20, 25]) { const A = n * Math.PI * dB * dB / 4, V = A * ka; if (V >= dV && (!pick || A < pick.A - 1e-6)) pick = { n, d: dB, A, V }; } }
      if (pick) { const len = Math.max(e.l1 || 0, e.d); const ng = Math.max(1, Math.ceil(Math.max(0, (e.l1req || len) - 0) / sb)); e.bent = Object.assign(pick, { sb, sbMax, ng, VRdb: pick.V, beta3: e.VRds1 / e.Vred }); }
    }
    e.VRds2 = VRdsEff(e.stir.s2, e.z, e.stir);
    e.sp = e.stir.sp > 0 ? e.stir.sp : 0;
    e.VRdsp = e.sp ? VRdsEff(e.sp, e.z, e.stir) : null;
    e.inter = e.V0 / e.VRdmax + (tor.on ? TEd / tor.TRdmax : 0);
    // strefy od lica podpory: s₁ (gdzie V_Ed > V_Rd,s(s_p) lub (s₂)), s_p (gdzie V_Ed > V_Rd,s(s₂)), dalej s₂
    const face = e.sup.t / 2, avail = Math.max(0, e.reach - face);
    e.l1req = extOf2(e, (e.sp ? e.VRdsp : e.VRds2) * ETAV);
    e.l12req = e.sp ? Math.max(e.l1req, extOf2(e, e.VRds2 * ETAV)) : e.l1req;
    // długość strefy: przy tej podporze (S.stir.zl) → wspólna (S.stir.l1 / lp) → automatycznie (zasięg V_Ed > V_Rd,s, w górę co 50 mm)
    e.zkey = `${e.sup.idx}${e.dir > 0 ? 'R' : 'L'}`; const zo = (S.stir.zl || {})[e.zkey] || {};
    const l1S = zo.l1 !== undefined ? +zo.l1 * 1000 : l1Sel, lpS = zo.lp !== undefined ? +zo.lp * 1000 : lpSel;
    e.l1Own = zo.l1 !== undefined; e.lpOwn = zo.lp !== undefined;
    e.l1User = l1S; e.lpUser = e.sp ? lpS : null;
    e.l1 = l1S !== null ? Math.min(l1S, avail) : (e.l1req > 0 ? Math.min(ceilTo(e.l1req, 50), avail) : 0);
    e.lpReq = e.sp ? Math.max(0, e.l12req - e.l1) : 0;
    e.lp = !e.sp ? 0 : lpS !== null ? Math.min(lpS, Math.max(0, avail - e.l1)) : (e.lpReq > 0 ? Math.min(ceilTo(e.lpReq, 50), Math.max(0, avail - e.l1)) : 0);
    e.avail = avail;
    e.aL = e.z * cot / 2;
    e.FE = e.V0 * cot / 2 + (NEd < 0 ? -NEd : 0);
  });
  const dminSh = Math.min(...ends.map(e => e.d), ...secs.filter(s => s.kind === 'span').map(s => s.d));
  sh.sMax = 0.75 * dminSh;
  if (tor.on) sh.sMaxT = Math.min(tor.u / 8, bw, h);
  sh.rho1 = sh.Asw / (st0.s1 * bw); sh.rho2 = sh.Asw / (st0.s2 * bw);
  sh.st = legs > 1 ? (bw - 2 * cov.cs - st0.d) / (legs - 1) : 0;
  sh.stMax = Math.min(0.75 * dminSh, 600);
  // strzemiona odcinków: stopień zbrojenia, rozstaw poprzeczny ramion (9.2.2), wymagana liczba ramion
  sh.segs = md.segs.filter(sg => sg.kind === 'span' || !md.cont).map(sg => {
    const q = sg.stir, Asw = q.legs * area(q.d), bwS = sg.g.bw;
    const dS = Math.min(...ends.filter(e => e.seg === sg).map(e => e.d), sg.sec ? sg.sec.d : Infinity);
    const stMx = Math.min(0.75 * (isFinite(dS) ? dS : dminSh), 600);
    const stv = q.legs > 1 ? (bwS - 2 * cov.cs - q.d) / (q.legs - 1) : 0;
    const legsMin = Math.max(2, Math.ceil((bwS - 2 * cov.cs - q.d) / stMx - 1e-9) + 1);
    return { seg: sg, stir: q, Asw, rho1: Asw / (q.s1 * bwS), rho2: Asw / (q.s2 * bwS), st: stv, stMax: stMx, sMax: 0.75 * (isFinite(dS) ? dS : dminSh), legsMin, comp: compPhi(md.cont ? md.segs.filter(z => z === sg || (z.kind !== 'span' && z.adj === sg.idx)) : md.segs) };
  });
  R.sh = sh;
  // ścinanie w płaszczyźnie Z (poziome)
  if (st.hasZ) {
    ends.forEach(e => {
      const bars = e.hog && e.sup.barsSupp ? e.sup.barsSupp : e.seg.barsSpan;
      const zmax = Math.max(...bars.map(b => b.x));
      const side = bars.filter(b => b.x >= zmax - 1);
      const ge = e.g;
      const z = { bw: ge.h, d: Math.max(20, zmax - (ge.beff - ge.bw) / 2), Asl: side.reduce((s, b) => s + b.A, 0) };
      z.V0 = st.Vzin(e.x, e.dir);
      z.Vred = e.red ? st.Vzin(e.x + e.dir * Math.min(e.sup.t / 2 + z.d, e.reach), e.dir) : z.V0;
      z.k = Math.min(2, 1 + Math.sqrt(200 / z.d));
      z.rhol = Math.min(0.02, z.Asl / (z.bw * z.d));
      z.vmin = 0.035 * z.k ** 1.5 * Math.sqrt(m.fck);
      z.VRdc = Math.max((0.18 / m.gc * z.k * Math.cbrt(100 * z.rhol * m.fck) + 0.15 * e.sigcp) * z.bw * z.d, (z.vmin + 0.15 * e.sigcp) * z.bw * z.d);
      z.zz = 0.9 * z.d;
      z.Asw = 2 * area(e.stir.d);
      z.VRdmax = z.bw * z.zz * m.nu * m.fcd / (cot + 1 / cot);
      z.VRds1 = z.Asw / e.stir.s1 * z.zz * m.fywd * cot;
      z.inter = e.V0 / e.VRdmax + z.V0 / z.VRdmax + (tor.on ? TEd / tor.TRdmax : 0);
      e.zsh = z;
    });
  }
  // skręcanie – zbrojenie podłużne
  if (tor.on) {
    tor.AslReq = TEd * tor.uk * cot / (2 * tor.Ak * m.fyd);
    tor.cond631 = ends.length ? Math.max(...ends.map(e => TEd / tor.TRdc + e.V0 / e.VRdc)) : TEd / tor.TRdc;
    tor.legReq1 = ends.length ? Math.max(...ends.map(e => e.Vred / (e.stir.legs * e.z * m.fywd * cot))) + tor.tReq : tor.tReq;
    tor.legProv1 = Math.min(...md.segs.map(sg => area(sg.stir.d) / sg.stir.s1));
    tor.AslTB = tor.AslReq * tor.bk / tor.uk;
    tor.AslSide = tor.AslReq * tor.hk / tor.uk;
    const spanS = secs.filter(s => s.kind === 'span'), suppS = secs.filter(s => s.kind === 'supp');
    tor.surplusBot = spanS.length ? Math.min(...spanS.map(s => s.tens.A - s.des.As1)) : 0;
    tor.surplusTop = suppS.length ? Math.min(...suppS.map(s => s.tens.A - s.des.As1)) : LtM.A;
  }
  R.tor = tor;

  // ---------- zbrojenie wymagane (SGN + A_s,min, przesunięcie a_l) – dobór prętów i liczba prętów wzdłuż belki
  R.req = reqCalc(R, S, { md, st, m, cov, dsw, dg, sh, tor, gMin, secs });
  if (R.bare) {
    if (S.fire.R && S.fire.R !== '-') {
      const contF = md.cont || md.sups.some(p => p.type === 'fix') || S.scheme === 'manual';
      const tab = (contF ? FIRE_CONT : FIRE_SS)[S.fire.R], cs2 = tab.c, b = gMin.bw;
      const phi = Math.min(...R.req.zones.filter(z => z.kind === 'bot' && z.ch).map(z => z.ch.d), 32);
      const am = cov.cb + dsw + (isFinite(phi) ? phi : 16) / 2;
      R.fire = { R: S.fire.R, cont: contF, tab, b, bmin: cs2[0][0], amin: b < cs2[0][0] ? null : (b >= cs2[cs2.length - 1][0] ? cs2[cs2.length - 1][1] : interp(cs2, b)), am, asd: cov.cs + dsw + (isFinite(phi) ? phi : 16) / 2, oneLayer: true, bwMin: tab.bw, assumed: true };
      R.fire.needAsd = b < cs2[cs2.length - 1][0]; R.fire.asdReq = R.fire.amin !== null ? R.fire.amin + 10 : null;
    }
    bareChecks(R, S, { md, st, m, sh, tor, secs });
    R.stirZones = stirrupZones(R);
    R.checks.forEach(c => { c.key = c.grp + '|' + c.name.replace(/=\s*[\d\s,.]+(?:mm|kNm|kN|MPa|m)?/g, '=…'); });
    R.ok = false;
    R.maxUtil = Math.max(0, ...R.checks.filter(c => c.status !== 'info' && isFinite(c.ratio) && /^SG[NU]/.test(c.grp)).map(c => c.ratio));
    return R;
  }

  // ---------- ścinanie między środnikiem a półką (6.2.4)
  R.flanges = [];
  if (g.T) secs.filter(s => s.kind === 'span' && s.MEd > 0).forEach(sec => {
    const fl = { sec }, g = sec.g;
    const sg = sec.seg; const ks = sg.nodes;
    let xl = sg.x0, xr = sg.x1;
    for (let i = ks.indexOf(sec.k); i >= 0; i--) if (st.MEdMax[ks[i]] <= 0) { xl = st.x[ks[i]]; break; }
    for (let i = ks.indexOf(sec.k); i < ks.length; i++) if (st.MEdMax[ks[i]] <= 0) { xr = st.x[ks[i]]; break; }
    const dists = [sec.x - xl, xr - sec.x].filter(v => v > 1);
    fl.dist = dists.length ? Math.min(...dists) : sg.L / 2;
    fl.dx = fl.dist / 2;
    fl.z = sec.r ? Math.max(0.5 * sec.d, Math.min(0.95 * sec.d, sec.d - (sec.r.block ? sec.r.block[1] / 2 : 0.1 * sec.d))) : 0.9 * sec.d;
    fl.bei = (g.beff - g.bw) / 2;
    fl.dF = sec.MEd / fl.z * fl.bei / g.beff;
    fl.vEd = fl.dF / (g.hf * fl.dx);
    fl.vLim = 0.4 * m.fctd;
    let cf = 2.0;
    const crush = c => { const th = Math.atan(1 / c); return m.nu * m.fcd * Math.sin(th) * Math.cos(th); };
    while (cf > 1.0 && fl.vEd > crush(cf)) cf = Math.round((cf - 0.05) * 100) / 100;
    fl.cot = cf; fl.vRdmax = crush(cf);
    fl.AsfReq = fl.vEd <= fl.vLim ? 0 : fl.vEd * g.hf / (m.fyd * cf);
    fl.AsfProv = area(S.stir.ffd) / S.stir.ffs;
    R.flanges.push(fl);
  });

  // ---------- zakotwienia i zakłady (8.4, 8.7, 8.9)
  const anch = { rows: [] };
  const alpha6 = { '25': 1.0, '33': 1.15, '50': 1.4, '100': 1.5 }[S.anch.lap] || 1.4;
  anch.alpha6 = alpha6;
  const bondOf = (side, layE) => {
    if (S.anch.bond === 'good') return 'good';
    if (S.anch.bond === 'poor') return 'poor';
    if (side === 'bot') return 'good';
    if (h <= 250) return 'good';
    if (h - layE <= 250) return 'good';
    if (h > 600 && layE >= 300) return 'good';
    return 'poor';
  };
  const anchorOf = (dia, bond, sigma, lay, o) => {
    o = o || {};
    const cnom = o.side === 'top' ? cov.ct : o.side === 'bot' || o.side === undefined ? cov.cb : cov.cs;
    const eta1 = bond === 'good' ? 1.0 : 0.7, eta2 = dia <= 32 ? 1.0 : (132 - dia) / 100;
    const fbd = 2.25 * eta1 * eta2 * m.fctdBond;
    const lbrqd = dia / 4 * sigma / fbd;
    const a = lay && lay.layers[0] && lay.layers[0].n > 1 ? lay.layers[0].gap : 999;
    const c1 = cnom + dsw, c = cov.cs + dsw;
    const hook = (o.shape || (S.anch.shape === 'hook' ? 'hook' : 'straight')) === 'hook';
    const cd = hook ? Math.min(a / 2, c1) : Math.min(a / 2, c1, c);
    const al1 = hook && cd > 3 * dia ? 0.7 : 1.0;
    // α₂ (otulina) i α₅ (docisk poprzeczny) < 1 zmniejszają l_bd – stosowane tylko po zaznaczeniu przez projektanta (S.anch.alRed), inaczej 1,0
    const al2c = hook ? clamp(1 - 0.15 * (cd - 3 * dia) / dia, 0.7, 1.0) : clamp(1 - 0.15 * (cd - dia) / dia, 0.7, 1.0);
    const al5c = o.p ? clamp(1 - 0.04 * o.p, 0.7, 1.0) : 1.0, red = !!S.anch.alRed;
    const al2 = red ? al2c : 1.0, al3 = 1.0, al4 = 1.0, al5 = red ? al5c : 1.0;
    const prod235 = Math.max(0.7, al2 * al3 * al5), prodC = Math.max(0.7, al2c * al5c);
    const lbmin = Math.max(0.3 * lbrqd, 10 * dia, 100);
    const lbd = Math.max(al1 * prod235 * al4 * lbrqd, lbmin);
    const l0min = Math.max(0.3 * alpha6 * lbrqd, 15 * dia, 200);
    const l0 = Math.max(al1 * prod235 * alpha6 * lbrqd, l0min);
    const lbdC = Math.max(al1 * prodC * al4 * lbrqd, lbmin);           // l_bd z redukcją α₂, α₅ (informacja, gdy nieuwzględniona)
    return { dia, bond, eta1, eta2, fbd, sigma, lbrqd, a, c1, c, cd, hook, al1, al2, al3, al4, al5, al2c, al5c, prodC, lbdC, alRed: red, p: o.p || 0, prod235, lbmin, lbd, l0min, l0 };
  };
  const ratioMax = (list) => list.length ? Math.max(...list.map(s => s.tens.A > 0 ? s.des.As1 / s.tens.A : 1)) : 1;
  const sigOf = (list) => S.anch.sigma === 'actual' ? m.fyd * clamp(ratioMax(list), 0, 1) : m.fyd;
  const spanSecs = secs.filter(s => s.kind === 'span'), suppSecs = secs.filter(s => s.kind === 'supp');
  const sBot = sigOf(spanSecs), sTop = suppSecs.length ? sigOf(suppSecs) : m.fyd;
  const seen = new Set();
  const nameOf = (pre, b) => b.nb > 1 ? (b.sep ? `${pre} ${b.nb}⌀${b.dBar} (jeden nad drugim – jak pręty pojedyncze, 8.9.1(4))` : `${pre} ${b.nb}⌀${b.dBar} (wiązka, ⌀n = ${b.d.toFixed(1)})`) : `${pre} ⌀${b.dBar}`;
  md.segs.forEach(sg => sg.Lb.bars.forEach(b => {
    const key = 'b' + b.d + '|' + b.nb; if (seen.has(key)) return; seen.add(key);
    anch.rows.push(Object.assign({ name: nameOf('Dolne', b), side: 'bot', dBar: b.dBar }, anchorOf(b.d, bondOf('bot', sg.Lb.layers[0].e), sBot, sg.Lb, { side: 'bot' })));
  }));
  const topLay = md.sups.reduce((a, p) => (p.LtS.A > (a ? a.A : 0) ? p.LtS : a), LtM);
  const tBars = [...LtM.bars, ...md.sups.filter(p => p.hasX).flatMap(p => p.LtX.bars)];
  tBars.forEach(b => {
    const key = 't' + b.d + '|' + b.nb; if (seen.has(key)) return; seen.add(key);
    anch.rows.push(Object.assign({ name: nameOf('Górne', b), side: 'top', dBar: b.dBar }, anchorOf(b.d, bondOf('top', topLay.layers[0] ? topLay.layers[0].e : 50), suppSecs.length ? sTop : m.fyd, topLay, { side: 'top' })));
  });
  // zakotwienia w poszczególnych miejscach belki: pręty dolne przęseł, pręty górne nad podporami skrajnymi i pośrednimi (σ_sd, przyczepność i c_d – lokalnie)
  anch.loc = [];
  const locRow = (where, kind, side, dia, bond, sigma, lay, extra) => { const r = Object.assign({ where, kind, side, name: `${side === 'top' ? 'górne' : 'dolne'} ⌀${dia}`, dBar: dia }, anchorOf(dia, bond, sigma, lay, { side }), extra || {}); anch.loc.push(r); return r; };
  md.segs.forEach(sg => { if (!sg.reb || !sg.Lb || !sg.Lb.n) return; const sig = sg.sec ? sigOf([sg.sec]) : sBot;
    [...new Set(sg.Lb.bars.map(b => b.d))].sort((u, v) => v - u).forEach(d => locRow(sg.label, 'span', 'bot', d, bondOf('bot', sg.Lb.layers[0].e), sig, sg.Lb, { seg: sg.idx, x: sg.x0 + sg.L / 2 })); });
  md.sups.forEach(p => { const lay = p.LtS; if (!lay || !lay.n) return; const sig = p.sec ? sigOf([p.sec]) : m.fyd;
    [...new Set(lay.bars.map(b => b.d))].sort((u, v) => v - u).forEach(d => locRow(p.name, p.end ? 'end' : 'inner', 'top', d, bondOf('top', lay.layers[0] ? lay.layers[0].e : 50), sig, lay, { sup: p.idx, x: p.x })); });
  if (rb.mid.n > 0) {
    const yMin = Math.min(...md.segs[0].mid.map(b => b.y));
    anch.rows.push(Object.assign({ name: `Boczne ⌀${rb.mid.d} (w połowie wysokości)`, side: 'mid', dBar: rb.mid.d }, anchorOf(rb.mid.d, bondOf('top', yMin), m.fyd, null, { side: 'mid' })));
  }
  // zakotwienie na podporach skrajnych swobodnych (9.2.1.4); gdy prosty pręt się nie mieści – odgięcie do góry na wymaganą długość
  anch.ends = [];
  // odgięcie zakotwienia: trzpień φ_m ≥ φ_m,min (tab. 8.1N) i ≥ warunek miażdżenia betonu w zagięciu (8.3(3)); długość rozwinięta wzdłuż osi pręta
  const bendAnch = (dia, sig, rS, rH, avail, lay, legMax) => {
    const bent = S.anch.shape !== 'line' && rS.lbd > avail + 1e-6;
    const ab = Math.min(lay.layers[0] && lay.layers[0].n > 1 ? lay.layers[0].cc / 2 : 1e9, cov.cs + dsw + dia / 2);
    if (!bent) return { bent, leg: 0, phm: 0, rIn: 0, ab };
    const phmMin = mandrelMin(dia);
    let phm = phmMin, s0 = 0, Fbt = 0, phmReq = 0;
    for (let it = 0; it < 3; it++) {
      s0 = Math.max(0, avail - (phm / 2 + dia));
      Fbt = area(dia) * Math.max(0, sig - 4 * rS.fbd * s0 / dia);
      phmReq = Fbt * (1 / ab + 1 / (2 * dia)) / m.fcd;
      phm = Math.max(phmMin, ceilTo(phmReq, 10));
    }
    const rIn = phm / 2, arc = Math.PI * (rIn + dia / 2) / 2;
    const v = Math.max(rH.lbd - s0 - arc, 5 * dia);
    const leg = ceilTo(v + rIn + dia, 10);                       // wymiar zewnętrzny odcinka odgiętego
    return { bent, leg, legV: v, phm, phmMin, phmReq, rIn, s0, arc, Fbt, ab, okBent: leg <= legMax + 1e-6 };
  };
  ends.filter(e => e.simple).forEach(e => {
    const lay = e.seg.LbS;
    const AsReq = e.FE / m.fyd;
    const sig = clamp(e.FE / lay.A, 0, m.fyd);
    const dia = lay.dmax;
    const p = Math.min(e.V0 / (e.g.bw * Math.max(e.sup.t, 1)), 7.5);
    const r = anchorOf(dia, 'good', Math.max(sig, 1), lay, { shape: 'straight', p, side: 'bot' });
    const rh = anchorOf(dia, 'good', Math.max(sig, 1), lay, { shape: 'hook', p, side: 'bot' });
    // pręty skrócone ręcznie na podporze skrajnej (koniec pręta przesunięty w głąb przęsła) – mniejsza długość zakotwienia w podporze
    const dEnd = +(((S.barEdit || {})['b' + e.seg.idx] || {})['d' + e.side]) || 0;
    const avail = e.sup.t - Math.max(cov.cnom_main || 0, cov.cs + dsw) + Math.min(0, dEnd);
    const legMax = e.g.h - cov.cb - cov.ct - 2 * dsw;
    const bd = bendAnch(dia, Math.max(sig, 1), r, rh, avail, lay, legMax);
    anch.ends.push(Object.assign({ e, side: e.side, name: e.sup.name, FE: e.FE, AsReq, AsProv: lay.A, sig, dia, lbd: r.lbd, lbdHook: rh.lbd, r, rh, avail, aL: e.aL, V: e.Vred, legMax, okBent: true }, bd));
  });
  // pręty górne na podporach skrajnych sztywnych (utwierdzenie): zakotwienie w podporze, w razie potrzeby odgięcie w dół (w podporę)
  anch.endsTop = [];
  md.sups.filter(p => p.end && p.type === 'fix').forEach(p => {
    const lay = p.LtS; if (!lay.n) return;
    const dia = lay.dmax, sig = p.sec ? clamp(m.fyd * (p.sec.des.As1 / Math.max(1, lay.A)), 1, m.fyd) : m.fyd * 0.5;
    const bond = bondOf('top', lay.layers[0] ? lay.layers[0].e : 50);
    const r = anchorOf(dia, bond, sig, lay, { shape: 'straight', side: 'top' }), rh = anchorOf(dia, bond, sig, lay, { shape: 'hook', side: 'top' });
    const dEnd = +(((S.barEdit || {}).t || {})['d' + (p.segL === null ? 'L' : 'R')]) || 0;
    const avail = p.t - Math.max(cov.cnom_main || 0, cov.cs + dsw) + Math.min(0, dEnd);
    const bd = bendAnch(dia, sig, r, rh, avail, lay, Infinity);
    anch.endsTop.push(Object.assign({ sup: p, side: p.segL === null ? 'L' : 'R', name: p.name, dia, sig, bond, lbd: r.lbd, lbdHook: rh.lbd, avail, r, rh }, bd));
  });
  // podpory pośrednie (9.2.1.5): pręty dolne ≥ 10⌀ za licem
  anch.inner = md.sups.filter(p => !p.end).map(p => {
    const adj = [p.segL, p.segR].map(i => md.segs[i]);
    const dmax = Math.max(...adj.map(sg => sg.LbS.dmax));
    return { sup: p, dmax, l: 10 * dmax };
  });
  // długości prętów górnych dodatkowych nad podporami (przesunięcie obwiedni o a_l)
  // długości od osi podpory: z obwiedni (|M_Ed| > M_Rd prętów ciągłych) + a_l + l_bd; podpory skrajne ≥ 0,2·L od lica (9.2.1.2(1)); można przedłużyć ręcznie
  anch.topCut = [];
  md.sups.forEach(p => {
    if (!p.hasX) return;
    const mont = makeULS(p.g.partsH, p.g.h, flipBars([...sideBars(p.LbS, 'bot', p.g.h), ...sideBars(p.gSeg.Lt, 'top', p.g.h), ...p.mid], p.g.h), m);
    const MRdMont = p.gSeg.Lt.n || p.mid.length ? (mont.MRd(NEd) || { M: 0 }).M : 0;
    const row = anch.loc.find(r => r.sup === p.idx && r.side === 'top' && r.dia === p.dX) || anch.rows.find(r => r.side === 'top' && r.dia === p.dX) || anchorOf(p.dX, 'poor', m.fyd, p.LtS);
    const dS = p.sec ? p.sec.d : p.g.h - p.LtS.eC;
    const aL = 0.9 * dS * cot / 2;
    const sides = [];
    [['L', p.segL, -1], ['R', p.segR, 1]].forEach(([side, si]) => {
      if (si === null) { sides.push({ side, len: 0, none: true }); return; }
      const sg = md.segs[si];
      if (sg.kind !== 'span') { sides.push({ side, len: sg.L - cov.cs, lenReq: sg.L - cov.cs, cant: true, x0: sg.L, aL, lbd: row.lbd }); return; }
      let xc = 0;
      if (p.sec) {
        // ciągły obszar |M_Ed| > M_Rd prętów ciągłych, licząc od podpory
        const ord = sg.nodes.slice().sort((u, v) => Math.abs(st.x[u] - p.x) - Math.abs(st.x[v] - p.x));
        for (const k of ord) { if (-st.MEdMin[k] > MRdMont + 1e-6) xc = Math.abs(st.x[k] - p.x); else if (Math.abs(st.x[k] - p.x) > 1) break; }
      }
      let lenReq = p.sec ? ceilTo(xc + aL + row.lbd, 50) : 0;
      const minEnd = p.end || !p.sec ? ceilTo(p.t / 2 + 0.2 * sg.L, 50) : 0;
      lenReq = Math.min(Math.max(lenReq, minEnd), sg.L);
      const manV = side === 'L' ? p.lenMan.L : p.lenMan.R;
      const manual = manV !== '' && manV !== undefined && manV !== null;
      // przedłużenie ponad długość wymaganą (z widoku podłużnego – koniec pręta): Δ [m]
      // Δ > 0 – przedłużenie, Δ < 0 – skrócenie (sprawdzane: długość ≥ wymagana)
      const extV = p.extMan ? (side === 'L' ? p.extMan.L : p.extMan.R) : '', ext = !manual && extV !== '' && isFinite(+extV) ? +extV * 1000 : 0;
      const len = manual ? Math.min(manV * 1000, sg.L) : clamp(lenReq + ext, Math.min(lenReq, p.t / 2 + 100), sg.L);
      sides.push({ side, x0: xc, aL, lbd: row.lbd, len, lenReq, manual, ext, minEnd, full: len >= sg.L - 1, seg: sg });
    });
    anch.topCut.push({ sup: p, MRdMont, aL, lbd: row.lbd, sides, noHog: !p.sec });
  });
  // pręty dolne nie doprowadzone do podpór
  anch.botCut = [];
  md.segs.forEach(sg => {
    if (!sg.cut || !sg.sec) return;
    const ulsS = makeULS(sg.g.partsS, sg.g.h, [...sideBars(sg.LbS, 'bot', sg.g.h), ...sideBars(sg.Lt, 'top', sg.g.h), ...sg.mid], m);
    const MRdS = (ulsS.MRd(NEd) || { M: 0 }).M;
    const row = anch.loc.find(r => r.seg === sg.idx && r.side === 'bot' && r.dia === sg.Lb.dmax) || anch.rows.find(r => r.side === 'bot') || anchorOf(sg.Lb.dmax, 'good', m.fyd, sg.Lb);
    const aL = 0.9 * sg.sec.d * cot / 2;
    let xa = Infinity, xb = -Infinity;
    sg.nodes.forEach(k => { if (st.MEdMax[k] > MRdS + 1e-6) { xa = Math.min(xa, st.x[k]); xb = Math.max(xb, st.x[k]); } });
    let none = false;
    if (xb < xa) { xa = sg.sec.x; xb = sg.sec.x; none = true; }
    const start = Math.max(sg.x0, xa - aL - row.lbd), end = Math.min(sg.x1, xb + aL + row.lbd);
    anch.botCut.push({ seg: sg, MRdS, xa, xb, aL, lbd: row.lbd, start, end, len: ceilTo(end - start, 50), none });
  });
  R.anch = anch;
  if (opts.acc) { R.ok = true; return R; }

  // ---------- SGU
  const sls = {};
  const cs = creepShrink(S, m, g); sls.cs = cs;
  const Ecm = m.Ecm, Eeff = Ecm / (1 + cs.phi);
  sls.Eeff = Eeff; sls.aeS = m.Es / Ecm; sls.aeL = m.Es / Eeff;
  sls.k1lim = /^(XD|XS)/.test(cov.exp) || (S.env.expF && S.env.expF !== '-');
  const wmax = S.sls.wSel === 'auto' ? (WMAX[cov.exp] ?? 0.3) : num(S.sls.wSel, 0.3);
  sls.wmax = wmax;
  const secSLS = (sec) => {
    const isSpan = sec.kind === 'span', g = sec.g, h = g.h;
    const parts = sec.parts, bars = sec.barsO;
    let Mk, Mqp;
    if (isSpan) { Mk = Math.max(0, ...sec.seg.nodes.map(k => st.MkMax[k])); Mqp = Math.max(0, ...sec.seg.nodes.map(k => st.MqpMax[k])); }
    else { Mk = Math.max(0, -(st.MkMinR || st.MkMin)[sec.k]); Mqp = Math.max(0, -(st.MqpMinR || st.MqpMin)[sec.k]); }
    const tens = bars.filter(b => b.side === (isSpan ? 'bot' : 'top'));
    const lay = sec.tens;
    const r = { kind: sec.kind, Mk, Mqp };
    r.unS = uncracked(parts, bars, sls.aeS); r.unL = uncracked(parts, bars, sls.aeL);
    r.crS = cracked(parts, bars, sls.aeS); r.crL = cracked(parts, bars, sls.aeL);
    r.Mcr = m.fctm * r.unS.I / (h - r.unS.yc);
    const dT = lay.A > 0 ? h - lay.eC : h;
    r.d = dT;
    const ysT = tens.length ? tens.reduce((s, b) => s + b.A * b.y, 0) / tens.reduce((s, b) => s + b.A, 0) : dT;
    const sig = (M, cr, ae) => ({ sc: M * cr.x / cr.I, ss: ae * M * (ysT - cr.x) / cr.I });
    const kS = sig(Mk, r.crS, sls.aeS), kL = sig(Mk, r.crL, sls.aeL);
    r.sc_k = Math.max(kS.sc, kL.sc); r.ss_k = Math.max(kS.ss, kL.ss);
    r.sc_qp = sig(Mqp, r.crS, sls.aeS).sc;
    r.ss_qp = sig(Mqp, r.crL, sls.aeL).ss;
    r.crackedK = Mk > r.Mcr; r.crackedQP = Mqp > r.Mcr;
    // zginanie ukośne – naprężenia z analizy sprężystej przekroju zarysowanego
    if (st.hasZ) {
      const sy = isSpan ? 1 : -1;
      const kq = sec.k;
      let scK = 0, ssK = 0;
      st.pairs(st.combos.K, kq, sy).forEach(([My, Mz]) => {
        if (Math.abs(Mz) < 1) return;
        [[Ecm, m.Es], [Eeff, m.Es]].forEach(([Ec, Es]) => { const e = elasticBiax(g.partsS, sec.bars, g.beff, Ec, Es, NEd * 0, My, Mz); scK = Math.max(scK, e.sc); ssK = Math.max(ssK, e.ss); });
      });
      const [qpMy, qpMz] = st.pairs(st.combos.QP, kq, sy)[0];
      if (Math.abs(qpMz) >= 1) {
        const eq1 = elasticBiax(g.partsS, sec.bars, g.beff, Ecm, m.Es, 0, qpMy, qpMz), eq2 = elasticBiax(g.partsS, sec.bars, g.beff, Eeff, m.Es, 0, qpMy, qpMz);
        r.sc_qp = Math.max(r.sc_qp, eq1.sc); r.ss_qp = Math.max(r.ss_qp, eq2.ss); r.crackedQP = true; r.biaxQP = true;
      }
      if (scK > r.sc_k || ssK > r.ss_k) r.biax = true;
      r.sc_k = Math.max(r.sc_k, scK); r.ss_k = Math.max(r.ss_k, ssK);
    }
    const w = {};
    w.x = r.crL.x;
    w.hcef = Math.min(2.5 * (h - dT), (h - w.x) / 3, h / 2);
    const ae = areaBetween(parts, h - w.hcef, h); w.Aceff = ae.A;
    const tIn = tens.filter(b => h - b.y <= w.hcef + 1e-6);
    w.As = (tIn.length ? tIn : tens).reduce((s, b) => s + b.A, 0);
    w.rho = w.As / w.Aceff;
    w.ss = r.ss_qp;
    w.kt = 0.4; w.fcteff = m.fctm; w.ae = sls.aeS;
    w.eps1 = (w.ss - w.kt * w.fcteff / w.rho * (1 + w.ae * w.rho)) / m.Es;
    w.eps2 = 0.6 * w.ss / m.Es;
    w.eps = Math.max(w.eps1, w.eps2);
    const ds = tens.map(b => b.d);
    w.phiEq = ds.reduce((s, d) => s + d * d, 0) / Math.max(1e-9, ds.reduce((s, d) => s + d, 0));
    w.c = (isSpan ? cov.cb : cov.ct) + dsw;
    w.k1 = 0.8; w.k2 = 0.5; w.k3 = 3.4; w.k4 = 0.425;
    w.spacing = lay.layers[0] ? lay.layers[0].cc : 0;
    w.spLim = 5 * (w.c + w.phiEq / 2);
    w.srA = w.k3 * w.c + w.k1 * w.k2 * w.k4 * w.phiEq / w.rho;
    w.srB = 1.3 * (h - w.x);
    w.wide = w.spacing > w.spLim;
    w.sr = w.wide ? w.srB : w.srA;
    w.wk = r.crackedQP ? w.sr * w.eps : 0;
    const t72 = { 0.4: [[160, 40], [200, 32], [240, 20], [280, 16], [320, 12], [360, 10], [400, 8], [450, 6]],
      0.3: [[160, 32], [200, 25], [240, 16], [280, 12], [320, 10], [360, 8], [400, 6], [450, 5]],
      0.2: [[160, 25], [200, 16], [240, 12], [280, 8], [320, 6], [360, 5], [400, 4], [450, 4]] };
    const t73 = { 0.4: [[160, 300], [200, 300], [240, 250], [280, 200], [320, 150], [360, 100]],
      0.3: [[160, 300], [200, 250], [240, 200], [280, 150], [320, 100], [360, 50]],
      0.2: [[160, 200], [200, 150], [240, 100], [280, 50], [320, 0], [360, 0]] };
    const wk3 = wmax >= 0.4 ? 0.4 : wmax >= 0.3 ? 0.3 : 0.2;
    w.phiStar = interp(t72[wk3], w.ss);
    w.hcr = h - r.crS.x;
    w.phiMax = w.phiStar * (m.fctm / 2.9) * 0.4 * w.hcr / (2 * (h - dT));
    w.sMaxT = interp(t73[wk3], w.ss);
    r.w = w;
    const gpc = grossProps(parts);
    const kfac = interp([[300, 1.0], [800, 0.65]], h);
    const asmin = { k: kfac, sig: m.fyk, fct: m.fctm, ytc: gpc.yc };
    const tensZone = areaBetween(parts, gpc.yc, h);
    if (!isSpan && g.T) {
      const yfl0 = h - g.hf;
      const Afl = areaBetween(parts, Math.max(yfl0, gpc.yc), h).A;
      const Aw = tensZone.A - Afl;
      const dist = h - gpc.yc;
      const kcFl = Math.max(0.5, 0.9 * (dist - g.hf / 2) / dist);
      asmin.parts = [{ name: 'środnik', kc: 0.4, Act: Aw }, { name: 'półka', kc: kcFl, Act: Afl }];
    } else asmin.parts = [{ name: 'strefa rozciągana', kc: 0.4, Act: tensZone.A }];
    asmin.As = asmin.parts.reduce((s, p) => s + p.kc * kfac * m.fctm * p.Act, 0) / m.fyk;
    r.asmin = asmin;
    const bt = tensZone.A / Math.max(1, h - gpc.yc);
    r.bt = bt;
    r.AsMin = Math.max(0.26 * m.fctm / m.fyk * bt * dT, 0.0013 * bt * dT);
    r.AsProv = lay.A;
    return r;
  };
  secs.forEach(sec => { sec.sls = secSLS(sec); });

  // ----- ugięcia: metoda dokładna (krzywizny + interpolacja ζ, 7.4.3), obciążenie zmienne układane przęsłami
  const defl = {};
  const propsOf = (bars, isSpan, ae, g) => {
    const h = g.h, parts = isSpan ? g.partsS : g.partsH;
    const bOr = isSpan ? bars : flipBars(bars, h);
    const unP = uncracked(g.partsS, bars, ae);
    const un = uncracked(parts, bOr, ae);
    const cr = cracked(parts, bOr, ae);
    const Mcr = m.fctm * un.I / (h - un.yc);
    return { I1: unP.I, I2: cr.I, Mcr, k1cs: cs.ecs * ae * unP.S / unP.I, k2cs: (isSpan ? 1 : -1) * cs.ecs * ae * cr.S / cr.I, x2: cr.x };
  };
  let phiUsed = cs.phi;
  const scqp = Math.max(0, ...secs.map(s => s.sls.sc_qp));
  sls.ksig = scqp / m.fck;
  if (sls.ksig > 0.45) { phiUsed = cs.phi * Math.exp(1.5 * (sls.ksig - 0.45)); sls.phiNL = phiUsed; }
  const EeffD = Ecm / (1 + phiUsed), aeD = m.Es / EeffD;
  const propsS = md.segs.map(sg => propsOf(sg.barsSpan, true, aeD, sg.g));
  const propsH = md.sups.map(p => propsOf(p.barsSupp, false, aeD, p.g));
  defl.pS = propsS; defl.pH = propsH;
  defl.E = EeffD; defl.phi = phiUsed;
  const beta = 0.5;
  const nearestSup = x => md.sups.length ? md.sups.reduce((a, p) => (Math.abs(p.x - x) < Math.abs(a.x - x) ? p : a)).idx : null;
  const curvAt = (M, E, xm, withCs) => {
    const sgi = segAt(md, xm).idx, spi = nearestSup(xm);
    const pp = (M >= 0 || spi === null) ? propsS[sgi] : propsH[spi];
    const zeta = Math.abs(M) > pp.Mcr ? 1 - beta * (pp.Mcr / M) ** 2 : 0;
    const kM = M / E * (zeta / pp.I2 + (1 - zeta) / pp.I1);
    const kcs = withCs ? zeta * pp.k2cs + (1 - zeta) * pp.k1cs : 0;
    return { zeta, kM, kcs, EI: E / (zeta / pp.I2 + (1 - zeta) / pp.I1) };
  };
  const L = md.Ltot;
  defl.spans = [];
  if (!st.manual) {
    const XD = makeMesh(L, Math.max(120, 50 * md.segs.length), st.keyPts), ne = XD.length - 1;
    const xm = XD.slice(0, -1).map((x, i) => (x + XD[i + 1]) / 2);
    const runNL = (la, E, withCs, cfn, sp) => {
      sp = sp || st.sups;
      cfn = cfn || curvAt;
      let EI = xm.map(x => E * propsS[segAt(md, x).idx].I1), k0 = new Array(ne).fill(0), r = null, wPrev = null;
      for (let it = 0; it < 40; it++) {
        r = feSolve(XD, sp, la.q, la.Ps, EI, k0);
        const nEI = [], nk0 = [];
        r.el.forEach((e, i) => { const c = cfn(e.Mm, E, xm[i], withCs); nEI.push(c.EI); nk0.push(c.kcs); });
        const wmaxIt = Math.max(...r.w.map(Math.abs));
        const damp = it > 6 ? 0.5 : 1.0;
        EI = EI.map((v, i) => v + damp * (nEI[i] - v)); k0 = k0.map((v, i) => v + damp * (nk0[i] - v));
        if (wPrev !== null && Math.abs(wmaxIt - wPrev) <= 1e-5 * Math.max(1e-9, wmaxIt) && it > 2) { r = feSolve(XD, sp, la.q, la.Ps, EI, k0); break; }
        wPrev = wmaxIt;
      }
      return r;
    };
    const pats = md.segs.length > 1 ? [0, 1] : [null];
    const res = {};
    pats.forEach(pt => {
      const laQP = st.loadFor(XD, st.qpCombo, pt), laK = st.loadFor(XD, st.chCombo, pt);
      res[pt] = { T: runNL(laQP, EeffD, true), L: runNL(laQP, EeffD, false), K: runNL(laK, Ecm, false) };
    });
    defl.chName = st.chCombo.name;
    const wPlot = new Array(XD.length).fill(0);
    md.segs.forEach(sg => {
      const pt = pats.length > 1 ? sg.idx % 2 : null, rr = res[pt];
      const idx = XD.map((x, i) => i).filter(i => XD[i] >= sg.x0 - 1e-6 && XD[i] <= sg.x1 + 1e-6);
      // ugięcie względem podpór (przy podporach sprężystych – względem cięciwy łączącej osiadania podpór; wspornik – względem nasady)
      const iL = idx[0], iR = idx[idx.length - 1];
      const rel = (r, i) => sg.kind === 'span' ? r.w[i] - (r.w[iL] + (r.w[iR] - r.w[iL]) * (XD[i] - XD[iL]) / Math.max(1e-9, XD[iR] - XD[iL]))
        : r.w[i] - r.w[sg.supL ? iL : iR];
      const fm = r => { let mx = 0, xi = sg.x0; idx.forEach(i => { const v = rel(r, i); if (Math.abs(v) > Math.abs(mx)) { mx = v; xi = XD[i]; } }); return { f: Math.abs(mx), x: xi }; };
      const tot = fm(rr.T), load = fm(rr.L), ch = fm(rr.K);
      idx.forEach(i => { wPlot[i] = rr.T.w[i]; });
      const Lref = sg.kind === 'span' ? sg.L : 2 * sg.L;
      defl.spans.push({ seg: sg, label: sg.label, tot, load, ch, cs: Math.max(0, tot.f - load.f), Lref, lim: Lref / S.sls.lim, pattern: pt });
    });
    defl.x = XD; defl.w = wPlot; defl.patterned = pats.length > 1;
    // ugięcie poziome (płaszczyzna Z)
    if (st.hasZ) {
      const propsZ = md.segs.map(sg => {
        const gz = sg.g, rp = rotatedParts(gz);
        const bz = rotatedBars(sg.barsSpan).map(b => Object.assign({}, b, { side: b.x > gz.beff / 2 ? 'r' : 'l' }));
        const out = {};
        [['E', aeD], ['S', sls.aeS]].forEach(([kk, ae]) => {
          const un = uncracked(rp, bz, ae), cr = cracked(rp, bz, ae);
          out[kk] = { I1: un.I, I2: cr.I, Mcr: m.fctm * un.I / (gz.beff - un.yc) };
        });
        return out;
      });
      const curvZ = (kk) => (M, E, xx) => {
        const pp = propsZ[segAt(md, xx).idx][kk]; const Ma = Math.abs(M);
        const zeta = Ma > pp.Mcr ? 1 - beta * (pp.Mcr / Ma) ** 2 : 0;
        return { zeta, kcs: 0, EI: E / (zeta / pp.I2 + (1 - zeta) / pp.I1) };
      };
      const cK = st.chComboZ || st.chCombo;
      defl.z = [];
      const resZ = {};
      pats.forEach(pt => {
        resZ[pt] = {
          qpE: runNL(st.loadFor(XD, st.qpCombo, pt, 'z'), EeffD, false, curvZ('E'), st.supsZ),
          qpS: runNL(st.loadFor(XD, st.qpCombo, pt, 'z'), Ecm, false, curvZ('S'), st.supsZ),
          K: runNL(st.loadFor(XD, cK, pt, 'z'), Ecm, false, curvZ('S'), st.supsZ),
        };
      });
      const wz = new Array(XD.length).fill(0);
      md.segs.forEach(sg => {
        const pt = pats.length > 1 ? sg.idx % 2 : null, rr = resZ[pt];
        const idx = XD.map((x, i) => i).filter(i => XD[i] >= sg.x0 - 1e-6 && XD[i] <= sg.x1 + 1e-6);
        let mx = 0, xi = sg.x0;
        idx.forEach(i => { const v = Math.abs(rr.qpE.w[i]) + Math.max(0, Math.abs(rr.K.w[i]) - Math.abs(rr.qpS.w[i])); wz[i] = v; if (v > mx) { mx = v; xi = XD[i]; } });
        const Lref = sg.kind === 'span' ? sg.L : 2 * sg.L;
        defl.z.push({ seg: sg, label: sg.label, f: mx, x: xi, Lref, lim: Lref / S.sls.lim });
      });
      defl.wz = wz;
    }
  } else {
    const sg = md.segs[0];
    const n = 400, dx = L / n; let wm = 0, wl = 0;
    const Mp = (() => { const [a, b, c] = S.man.MEqp.map(v => v * 1e6); const k = 4 * (b - (a + c) / 2) / (L * L); return x => a * (1 - x / L) + c * x / L + k * x * (L - x); })();
    const xs = [], ks = [];
    for (let i = 0; i <= n; i++) { const x = i * dx; const c = curvAt(Mp(x), EeffD, x, true); xs.push(x); ks.push(c.kM + c.kcs); }
    for (let i = 0; i < n; i++) {
      const x = (i + 0.5) * dx; const c = curvAt(Mp(x), EeffD, x, true);
      const mbar = x <= L / 2 ? x / 2 : (L - x) / 2;
      wm += (c.kM + c.kcs) * mbar * dx; wl += c.kM * mbar * dx;
    }
    const th = [0], w = [0];
    for (let i = 1; i <= n; i++) { th.push(th[i - 1] + (ks[i - 1] + ks[i]) / 2 * dx); w.push(w[i - 1] + (th[i - 1] + th[i]) / 2 * dx); }
    const corr = w[n] / L;
    defl.x = xs; defl.w = w.map((v, i) => v - corr * xs[i]);
    const tot = { f: Math.abs(wm), x: L / 2 }, load = { f: Math.abs(wl), x: L / 2 };
    defl.spans.push({ seg: sg, label: sg.label, tot, load, ch: null, cs: Math.max(0, tot.f - load.f), Lref: L, lim: L / S.sls.lim });
  }
  // metoda uproszczona L/d (7.4.2) – dla każdego odcinka
  defl.spans.forEach(ds => {
    const sg = ds.seg, ld = {};
    const isCant = sg.kind !== 'span';
    let K;
    if (st.manual) K = st.K;
    else if (isCant) K = 0.4;
    else if (!md.cont) { const nF = md.sups.filter(p => p.type === 'fix').length; K = nF >= 2 ? 1.5 : nF === 1 ? 1.3 : 1.0; }
    else {
      const contL = sg.supL && (!sg.supL.end || sg.supL.type === 'fix' || sg.supL.segL !== null);
      const contR = sg.supR && (!sg.supR.end || sg.supR.type === 'fix' || sg.supR.segR !== null);
      K = contL && contR ? 1.5 : (contL || contR) ? 1.3 : 1.0;
    }
    ld.K = K;
    const sec = isCant ? (sg.supL && sg.supL.sec ? sg.supL.sec : (sg.supR && sg.supR.sec ? sg.supR.sec : null)) : sg.sec;
    if (!sec) { ds.ld = null; return; }
    const dd = sec.d, AsReq = sec.des.As1, As2Req = sec.des.As2, AsProv = sec.tens.A, g = sec.g;
    ld.d = dd; ld.Aref = (!isCant && g.T) ? g.beff * g.hf + g.bw * (dd - g.hf) : g.bw * dd;
    ld.rho0 = Math.sqrt(m.fck) * 1e-3; ld.rho = AsReq / ld.Aref; ld.rhoP = As2Req / ld.Aref;
    const sf = Math.sqrt(m.fck);
    if (ld.rho <= 0) ld.base = Infinity;
    else if (ld.rho <= ld.rho0) ld.base = K * (11 + 1.5 * sf * ld.rho0 / ld.rho + 3.2 * sf * Math.pow(ld.rho0 / ld.rho - 1, 1.5));
    else ld.base = K * (11 + 1.5 * sf * ld.rho0 / (ld.rho - ld.rhoP) + sf / 12 * Math.sqrt(ld.rhoP / ld.rho0));
    ld.fS = Math.min(1.5, AsReq > 0 ? 500 / (m.fyk * AsReq / AsProv) : 1.5);
    ld.fT = (!isCant && g.T && g.beff / g.bw > 3) ? 0.8 : 1.0;
    ld.fL = (S.sls.sens && sg.L > 7000 && !isCant) ? 7000 / sg.L : 1.0;
    ld.lim = ld.base * ld.fS * ld.fT * ld.fL;
    ld.act = sg.L / dd;
    ds.ld = ld;
  });
  sls.defl = defl;
  R.sls = sls;

  // ---------- pożar (EN 1992-1-2, metoda tabelaryczna)
  if (S.fire.R && S.fire.R !== '-') {
    const contF = md.cont || md.sups.some(p => p.type === 'fix') || S.scheme === 'manual';
    const tab = (contF ? FIRE_CONT : FIRE_SS)[S.fire.R];
    const f = { R: S.fire.R, cont: contF, tab };
    const b = gMin.bw; f.b = b;
    const cs2 = tab.c;
    f.bmin = cs2[0][0];
    f.amin = b < f.bmin ? null : (b >= cs2[cs2.length - 1][0] ? cs2[cs2.length - 1][1] : interp(cs2, b));
    const segF = md.segs.filter(sg => sg.kind === 'span');
    const per = (segF.length ? segF : md.segs).map(sg => {
      const tb = sg.Lb.bars;
      return { sg, am: tb.reduce((s, br) => s + br.A * br.e, 0) / Math.max(1e-9, tb.reduce((s, br) => s + br.A, 0)), asd: cov.cs + dsw + sg.Lb.layers[0].dmax / 2, oneLayer: sg.Lb.layers.length === 1 };
    });
    const worst = per.reduce((a, q) => (q.am < a.am ? q : a));
    f.am = worst.am; f.asd = Math.min(...per.map(q => q.asd)); f.oneLayer = per.some(q => q.oneLayer); f.seg = worst.sg;
    f.needAsd = f.oneLayer && b < cs2[cs2.length - 1][0];
    f.asdReq = f.amin !== null ? f.amin + 10 : null;
    f.bwMin = tab.bw;
    R.fire = f;
  }

  // ---------- zbrojenie przypowierzchniowe (9.2.4, zał. J.1)
  {
    const cnomF = Math.max(cov.cb, cov.cs);
    const sf = { dmax: Math.max(...md.segs.map(sg => sg.Lb.dmax), ...md.sups.map(p => p.LtS.dmax || 0)), cnom: cnomF };
    sf.byBar = sf.dmax > 32 + 1e-9;
    sf.byCover = cnomF > 70;
    sf.req = sf.byBar || sf.byCover;
    sf.rho = sf.byBar ? 0.01 : 0.005;
    sf.items = secs.map(sec => {
      const gq = sec.g, hq = gq.h, cE = sec.kind === 'span' ? cov.cb : cov.ct;
      const x = sec.r && isFinite(sec.r.x) ? Math.min(sec.r.x, hq) : 0.4 * hq;
      const hT = Math.max(0, hq - x - cE);
      const A = gq.bw * cE + 2 * cov.cs * hT;
      const per = gq.bw + 2 * hT;
      return { sec, x, Act: A, per };
    });
    const gov = sf.items.reduce((a, q) => (q.Act > (a ? a.Act : -1) ? q : a), null);
    sf.gov = gov;
    sf.Ad = area(S.surf.d); sf.s = S.surf.s;
    if (gov) { sf.AsReq = sf.rho * gov.Act; sf.AsProv = sf.Ad * Math.floor(gov.per / sf.s + 1); sf.perM = sf.Ad / sf.s * 1000; sf.perMReq = sf.rho * cnomF * 1000; }
    R.surf = sf;
  }

  // ---------- SPRAWDZENIA
  checks(R, S, g, m, st, cov, sh, tor, sls, anch);
  if (st.hasAcc) {
    const RA = calc(S0, { acc: true });
    R.accR = RA;
    if (!RA.errors.length) accChecks(R, RA);
  }
  R.stirZones = stirrupZones(R);
  R.checks.forEach(c => { c.key = c.grp + '|' + c.name.replace(/=\s*[\d\s,.]+(?:mm|kNm|kN|MPa|m)?/g, '=…'); });
  R.ok = R.errors.length === 0 && R.checks.every(c => c.status !== 'fail');
  R.maxUtil = Math.max(0, ...R.checks.filter(c => c.status !== 'info' && isFinite(c.ratio) && /^SG[NU]/.test(c.grp)).map(c => c.ratio));
  return R;
}

/* ------------------------------------------------- dobór zbrojenia podłużnego */
// najtańszy układ n×⌀ spełniający A_s ≥ A_s,req: masa stali + koszt robocizny (pręt), 1 warstwa preferowana (2 – z poprawką ramienia),
// odstępy w świetle ≥ max(⌀; d_g + 5; 20) (8.2(2)), w górnej warstwie prześwit na buławę wibratora; o.base – pręty ciągłe w tej samej warstwie
// praktyka budowlana: średnice 12, 16, 20, 25, 28 (bez ⌀14, ⌀18, ⌀22 i ⌀ ≥ 32); w warstwie jednakowe średnice albo inna średnica w narożach
// i jednakowa między nimi; druga warstwa – parzysta liczba prętów w narożach (pod prętami warstwy 1)
const BAR_MAIN = [12, 16, 20, 25, 28];
// strefa zbrojenia z wyniku doboru: warstwa 1 – 2 pręty narożne ⌀dc + środkowe ⌀dm; warstwa 2 – pary prętów ⌀dc nad prętami warstwy 1 (od naroży)
function zoneFromCh(ch) {
  if (!ch) return zoneOf([]);
  const n1 = ch.n1 !== undefined ? ch.n1 : ch.n, n2 = ch.n2 || 0;
  const z = zoneOf(ch.mixed && n1 > 2 ? [{ n: 2, d: ch.d }, { n: n1 - 2, d: ch.dm }] : [{ n: n1, d: ch.d }]);
  if (ch.place === 'min' && z.layers[0]) z.layers[0].place = 'min';     // pręty w odstępach normowych od naroży – prześwit na buławę pośrodku
  if (n2 > 0) z.layers.push({ bars: [{ n: n2, d: ch.d }], place: 'pair', xs: '', gap: '', toSupp: 'all' });
  return z;
}
// dobór prętów wg praktyki: jedna średnica albo 2 pręty narożne + jednakowe pręty środkowe (⌀ ≤ narożnych); ⌀ z typoszeregu 12/16/20/25/28;
// druga warstwa – pary prętów nad prętami narożnymi; każdy wariant sprawdzany rzeczywistym układem (prześwity 8.2(2), obrys strzemion, buława)
function chooseBars(AsReq, o) {
  const base = o.base || { n: 0, d: 0 }, nMin = Math.max(1, o.nMin || 1);
  const D = (o.dList || BAR_MAIN).slice().sort((a, b) => a - b);
  const bz = base.n ? (base.ch ? zoneFromCh(base.ch) : zoneOf([{ n: base.n, d: base.d }])) : null;
  const bD = base.ch ? Math.max(base.ch.d, base.ch.dm || 0) : base.d || 0;
  const legsOk = n1 => !(o.legs > 2) || base.n || (n1 >= o.legs && (n1 - 1) % (o.legs - 1) === 0);
  const layOf = c => { const dmx = Math.max(c.d, bD), cs = o.csOf ? o.csOf(dmx) : o.cs;
    return layoutZone(zoneFromCh(c), { beff: o.bw, bw: o.bw }, { e: cs, s: cs }, o.dsw, o.dg || 16, bz ? { base: bz } : {}); };
  const cands = [];
  D.forEach(dc => D.filter(dm => dm <= dc).forEach(dm => {
    const mixed = dm !== dc;
    if (base.n && mixed) return;
    if (o.same && (mixed || (base.n && dc !== bD))) return;              // jednakowa średnica na krawędzi przekroju (także z prętami ciągłymi)
    const dmaxL = Math.max(dc, bD);
    const bAv = o.bw - 2 * ((o.csOf ? o.csOf(dmaxL) : o.cs) + o.dsw);
    const smin = Math.max(dmaxL, (o.dg || 16) + 5, 20);
    const wOf = n1 => base.n ? base.n * bD + n1 * dc + (base.n + n1 - 1) * smin : (n1 <= 2 ? n1 * dc + (n1 - 1) * smin : 2 * dc + (n1 - 2) * dm + (n1 - 1) * smin);
    let nMax = 0; while (nMax < 40 && wOf(nMax + 1) <= bAv + 1e-6) nMax++;
    const n1min = base.n ? 1 : (mixed ? 3 : 2);
    const A = (n1, n2) => (base.n || !mixed || n1 <= 2 ? n1 * area(dc) : 2 * area(dc) + (n1 - 2) * area(dm)) + n2 * area(dc);
    const sv = Math.max(dc, (o.dg || 16) + 5, 20), f2 = o.dEff > 0 ? o.dEff / Math.max(o.dEff * 0.6, o.dEff - (dc + sv) / 2) : 1.06;
    const mk = (n1, n2, place) => { const n = n1 + n2, c = { n, d: dc, dm: mixed ? dm : dc, n1, n2, mixed, layers: n2 ? 2 : 1, A: A(n1, n2), f2: n2 ? f2 : 1, fit: true };
      if (place) c.place = place;
      c.cost = c.A + 40 * c.n + (c.mixed ? 0.03 * c.A + 80 : 0) + (c.layers > 1 ? 0.1 * c.A + 200 : 0) + (c.d >= 28 ? 120 : 0); return c; };
    // jedna warstwa
    for (let n1 = n1min; n1 <= Math.max(n1min, nMax + 1); n1++) { if ((mixed && n1 <= 2) || !legsOk(n1)) continue; cands.push(mk(n1, 0)); }
    // dwie warstwy: w pierwszej – największa liczba prętów, jaka się mieści (odstępy 8.2(2), z buławą – prześwit na buławę, także
    // przy układzie od naroży), nadmiar – w drugiej warstwie nad prętami pierwszej (liczba nieparzysta tylko przy nieparzystej liczbie kolumn)
    let n1F = 0, plF = '';
    for (let n1 = Math.max(n1min, nMax + 1); n1 >= n1min && !n1F; n1--) {
      if ((mixed && n1 <= 2) || !legsOk(n1)) continue;
      const c = mk(n1, 2), lay = layOf(c); if (!lay.ok) continue;
      if (!o.vib || lay.open >= o.vib + 10) { n1F = n1; break; }
      const cM = mk(n1, 2, 'min'), lM = layOf(cM); if (lM.ok && lM.open >= o.vib + 10) { n1F = n1; plF = 'min'; }
    }
    if (!n1F) for (let n1 = Math.max(n1min, nMax + 1); n1 >= n1min; n1--) { if ((mixed && n1 <= 2) || !legsOk(n1)) continue; if (layOf(mk(n1, 2)).ok) { n1F = n1; break; } }
    if (n1F) { const cols = n1F + (base.n || 0); for (let n2 = 1; n2 <= Math.min(cols, 12); n2++) { if (n2 % 2 && cols % 2 === 0) continue; cands.push(mk(n1F, n2, plF)); } }
  }));
  const meets = c => c.A >= AsReq * c.f2 - 1e-6 && c.n >= nMin;
  // najmniejsza możliwa średnica (odstępy wg 8.2(2) sprawdzane rzeczywistym układem); przy tej samej średnicy – jedna warstwa, najmniejsze pole;
  // układ bez prześwitu na buławę wibratora (8.2(4)) – tylko gdy żaden inny się nie mieści
  const okC = cands.filter(meets).sort((a, b) => a.d - b.d || a.layers - b.layers || a.cost - b.cost);
  let best = null, bestPen = null;
  for (const c of okC) {
    const lay = layOf(c); if (!lay.ok) continue;
    const pen = o.vib && (o.top || base.n || lay.stacked) && lay.open < o.vib + 10;
    if (!pen) { best = c; break; }
    // ta sama średnica, pręty skupione przy narożach w odstępach normowych – prześwit na buławę wibratora pośrodku (8.2(4))
    if (c.n1 > 2 || base.n) { const cM = Object.assign({}, c, { place: 'min' }), lM = layOf(cM); if (lM.ok && lM.open >= o.vib + 10) { best = cM; break; } }
    if (!bestPen) bestPen = c;
  }
  if (best) return best;
  if (bestPen) return Object.assign({}, bestPen, { pen: true });
  // nie da się spełnić A_s,req w szerokości przekroju – największy mieszczący się układ (oznaczony 'over')
  const byA = cands.filter(c => c.n >= nMin).sort((a, b) => b.A - a.A);
  for (const c of byA) { if (layOf(c).ok) return Object.assign({}, c, { over: true }); }
  return { n: nMin, d: D[0], dm: D[0], n1: nMin, n2: 0, A: nMin * area(D[0]), layers: 1, over: true, fit: false };
}
// zbrojenie wymagane w strefach i w każdym miejscu belki (obwiednia M przesunięta o a_l = z·cotθ/2, 9.2.1.3(2)); A_s,min wg 9.2.1.1(1)
function reqCalc(R, S, c) {
  const { md, st, m, cov, dsw, dg, sh, tor, gMin } = c;
  const cot = sh.cot || 2.5, NEd = st.NEd || 0, legs = Math.max(...md.segs.map(sg => sg.stir.legs));
  const cont = md.cont;
  const asMinOf = (bw, d) => Math.max(0.26 * m.fctm / m.fyk, 0.0013) * bw * d;
  // otulina zależna od średnicy (c_min,b = ⌀ + Δ; 4.4.1.2) – gdy otulina nie jest podana ręcznie
  const cOf = (c0, phi, key) => { if (cov.manual || S.env[key] !== '') return c0; const cm = Math.max(phi + (cov.add || 0), cov.cdurNet || 0, 10) + (cov.dcdev || 0); return Math.max(c0, ceilTo(cm - dsw, 5)); };
  const csOf = phi => cOf(cov.cs, phi, 'cSide');
  const dOf = (gg, side, phi) => gg.h - ((side === 'bot' ? cOf(cov.cb, phi, 'cBot') : cOf(cov.ct, phi, 'cTop')) + dsw + phi / 2);
  const AsOf = (M, gg, side, phi) => { const d = dOf(gg, side, phi); if (!(M > 1e3)) return { As1: 0, As2: 0, d };
    const r = designBending({ M, N: NEd, bf: side === 'bot' ? gg.bFlange : gg.bw, bw: gg.bw, hf: side === 'bot' ? gg.hf : 0, d, a2: cov.ct + dsw + 8, yc: side === 'bot' ? gg.yc : gg.h - gg.yc, m });
    return { As1: Math.max(0, r.As1 || 0), As2: Math.max(0, r.As2 || 0), d }; };
  const same = S.reb.sameD !== false;
  const pick = (As, o) => chooseBars(As, Object.assign({ cs: cov.cs, csOf, dsw, dg, same }, o));
  // średnica wybrana przez projektanta dla strefy (wykres M w Danych) – liczba prętów dobierana do niej
  const dSel = S.reb.dSel || {}, dOfPath = pth => { const m1 = /^cont\.rebSpans\.(\d+)$/.exec(pth), m2 = /^cont\.rebSupps\.(\d+)$/.exec(pth);
    const v = pth === 'reb.bot' ? dSel.b0 : pth === 'reb.top' ? dSel.t : pth === 'reb.topX' ? dSel.x : m1 ? dSel['b' + m1[1]] : m2 ? dSel['x' + m2[1]] : undefined;
    return v || (/bot|rebSpans/.test(pth) ? S.reb.dB : S.reb.dT) || undefined; };
  const torTB = tor && tor.on ? tor.AslTB || 0 : 0;
  const zones = [];
  // dół: strefy przęseł
  const botPath = sg => cont ? (sg.reb ? `cont.rebSpans.${sg.si}` : (md.segs[sg.adj] ? `cont.rebSpans.${md.segs[sg.adj].si}` : null)) : 'reb.bot';
  const groups = new Map();
  md.segs.forEach(sg => { const pth = botPath(sg); if (!pth) return; if (!groups.has(pth)) groups.set(pth, []); groups.get(pth).push(sg); });
  let As2Max = 0;
  const botZ = new Map();
  groups.forEach((sgs, pth) => {
    const gg = sgs.reduce((a, q) => (q.g.h < a.h ? q.g : a), sgs[0].g);
    let M = 0; sgs.forEach(sg => sg.nodes.forEach(k => { M = Math.max(M, st.MEdMax[k]); }));
    const nMin = Math.max(2, legs);
    let phi = 20, ch = null, r = null, AsReq = 0;
    for (let it = 0; it < 3; it++) {
      r = AsOf(M, gg, 'bot', phi);
      AsReq = Math.max(r.As1 + torTB, M > 1e3 ? asMinOf(gg.bw, r.d) : 0);
      ch = pick(AsReq, Object.assign({ bw: gg.bw, nMin, dEff: r.d, legs, vib: VIBOF(S) }, dOfPath(pth) ? { dList: [dOfPath(pth)] } : {}));
      if (ch.d === phi) break; phi = ch.d;
    }
    As2Max = Math.max(As2Max, r.As2);
    const z = { kind: 'bot', path: pth, segs: sgs.map(q => q.idx), label: cont ? sgs[0].label : 'dół', M, AsReq, As1: r.As1, d: r.d, ch, dFix: dOfPath(pth), opts: Object.assign({ cs: cov.cs, csOf, dsw, dg, bw: gg.bw, nMin, dEff: r.d, legs, vib: VIBOF(S), same }, dOfPath(pth) ? { dList: [dOfPath(pth)] } : {}) };
    zones.push(z); sgs.forEach(sg => botZ.set(sg.idx, z));
  });
  // góra: pręty ciągłe (montażowe, ściskane w przęśle, skręcanie)
  const topReq = Math.max(As2Max, torTB);
  let topCh = pick(topReq, { bw: gMin.bw, nMin: Math.max(2, legs), dList: [12, 16, 20, 25], vib: VIBOF(S), legs, top: true }), topDL = [12, 16, 20, 25];
  // jednakowa średnica u góry: pręty ciągłe tej samej średnicy co dodatkowe nad podporami – najmniejsza średnica, przy której mieszczą się wszystkie
  const dTop = dSel.t || S.reb.dT;
  if (dTop) { topCh = pick(topReq, { bw: gMin.bw, nMin: Math.max(2, legs), dList: [dTop], vib: VIBOF(S), legs, top: true }); topDL = [dTop]; }
  else if (same) {
    const supNeed = md.sups.map(p => { const M = -st.MEdMinR[st.kAt(p.x)]; return M > 1e3 ? { p, M } : null; }).filter(Boolean);
    const okFor = (tc, one) => supNeed.every(({ p, M }) => { const r = AsOf(M, p.g, 'top', tc.d), ex = Math.max(r.As1, asMinOf(p.g.bw, r.d)) + torTB - tc.A; if (ex <= 1) return true;
      const c2 = pick(ex, { bw: p.g.bw, nMin: 2, base: { n: tc.n, d: tc.d, ch: tc }, vib: VIBOF(S), dEff: r.d, top: true }); return c2 && !c2.over && (!one || c2.layers === 1) && (one !== 'vib' || !c2.pen); });
    // najmniejsza średnica, przy której pręty nad podporami mieszczą się w jednej warstwie; gdy żadna – najmniejsza mieszcząca się w dwóch
    if (supNeed.length && !okFor(topCh, VIBOF(S) ? 'vib' : false)) {
      const tcs = [topCh, ...[16, 20, 25, 28].filter(d => d > topCh.d).map(dT => pick(topReq, { bw: gMin.bw, nMin: Math.max(2, legs), dList: [dT], vib: VIBOF(S), legs, top: true }))].filter(tc => tc && !tc.over);
      // najmniejsza średnica (pręty nad podporami mogą być w dwóch warstwach), najlepiej z prześwitem na buławę wibratora (8.2(4))
      topCh = (VIBOF(S) ? tcs.find(tc => !tc.pen && okFor(tc, 'vib')) : null) || tcs.find(tc => okFor(tc, false)) || topCh;
    }
    if (supNeed.length) topDL = [topCh.d];                     // średnica wspólna z prętami nad podporami
  }
  const zT = { kind: 'top', path: 'reb.top', label: 'góra – pręty ciągłe', AsReq: topReq, ch: topCh, opts: { cs: cov.cs, csOf, dsw, dg, bw: gMin.bw, nMin: Math.max(2, legs), dList: topDL, vib: VIBOF(S), legs, top: true, same } };
  zones.push(zT);
  // góra: pręty dodatkowe nad podporami (moment ujemny)
  const supPath = p => cont ? `cont.rebSupps.${p.idx}` : 'reb.topX';
  const sgr = new Map();
  md.sups.forEach(p => { const k = st.kAt(p.x), M = -st.MEdMinR[k]; if (!(M > 1e3)) return; const pth = supPath(p); if (!sgr.has(pth)) sgr.set(pth, []); sgr.get(pth).push({ p, M }); });
  const supZ = new Map();
  sgr.forEach((list, pth) => {
    const it0 = list.reduce((a, q) => (q.M > a.M ? q : a), list[0]), gg = it0.p.g, M = it0.M, dF = dOfPath(pth);
    const xo = dF ? Object.assign({ dList: [dF] }, dF !== topCh.d ? { same: false } : {}) : {};
    let phi = 20, ch = null, r = null, AsTot = 0, extra = 0;
    for (let it = 0; it < 3; it++) {
      r = AsOf(M, gg, 'top', phi);
      AsTot = Math.max(r.As1, asMinOf(gg.bw, r.d)) + torTB;
      extra = AsTot - topCh.A;
      if (extra <= 1) { ch = null; break; }
      ch = pick(extra, Object.assign({ bw: gg.bw, nMin: 2, base: { n: topCh.n, d: topCh.d, ch: topCh }, vib: VIBOF(S), dEff: r.d, top: true }, xo));
      if (ch.d === phi) break; phi = ch.d;
    }
    const z = { kind: 'supp', path: pth, sups: list.map(q => q.p.idx), label: cont ? it0.p.name : 'góra nad podporami', M, AsReq: AsTot, As1: r.As1, extra, d: r.d, ch, dFix: dF,
      opts: Object.assign({ cs: cov.cs, csOf, dsw, dg, bw: gg.bw, nMin: 2, base: { n: topCh.n, d: topCh.d, ch: topCh }, vib: VIBOF(S), dEff: r.d, top: true, same }, xo) };
    zones.push(z); list.forEach(q => supZ.set(q.p.idx, z));
  });
  // pręty boczne – skręcanie (9.2.3(4): przy każdym boku, rozstaw ≤ 350 mm)
  let mid = null;
  { const hh = gMin.h - cov.cb - cov.ct - 2 * dsw - 40, hMx = Math.max(...md.segs.map(sg => sg.g.h)), hhX = hMx - cov.cb - cov.ct - 2 * dsw - 40;
    const nT = tor && tor.on && tor.AslSide > 0 ? Math.max(1, Math.ceil(tor.AslSide / 2 / area(12) - 1e-9), Math.ceil(hh / 350 - 1e-9) - 1) : 0;
    // zbrojenie przy bocznych powierzchniach belek o wysokości ≥ 1000 mm (7.3.3(3)) – wg najwyższego przekroju, rozstaw ≤ 300 mm
    const nS = hMx >= 1000 ? Math.max(1, Math.ceil(hhX / 300 - 1e-9) - 1) : 0;
    const n = Math.max(nT, nS);
    if (n > 0) mid = { n, d: 12, AsReq: nT ? tor.AslSide : 0, skin: nS >= nT }; }
  // wzdłuż belki: wymagana liczba prętów w każdym miejscu
  const xs = st.x, N = xs.length;
  const sgAt = xs.map(x => segAt(md, x));
  const aL = sgAt.map(sg => 0.45 * dOf(sg.g, 'bot', 20) * cot);
  const shift = (arr, sgn) => xs.map((x, k) => { let v = 0; for (let j = 0; j < N; j++) if (Math.abs(xs[j] - x) <= aL[k] + 1e-6) v = Math.max(v, sgn * arr[j]); return v; });
  const Mp = shift(st.MEdMax, 1), Mn = shift(st.MEdMinR, -1);
  const nearSup = x => md.sups.reduce((a, p) => (!a || Math.abs(p.x - x) < Math.abs(a.x - x) ? p : a), null);
  const pts = xs.map((x, k) => {
    const sg = sgAt[k], zb = botZ.get(sg.idx), o = { x, Mp: Mp[k], Mn: Mn[k], nB: 0, dB: 0, AsB: 0, nX: 0, dX: 0, AsT: 0, nT: 0, dT: topCh.d };
    if (zb && Mp[k] > 1e3) { const r = AsOf(Mp[k], sg.g, 'bot', zb.ch.d); o.AsB = Math.max(r.As1 + torTB, asMinOf(sg.g.bw, r.d)); o.dB = zb.ch.d; o.nB = Math.max(2, Math.ceil(o.AsB / area(zb.ch.d) - 1e-9)); }
    if (Mn[k] > 1e3) {
      const p = nearSup(x), zs = p ? supZ.get(p.idx) : null, dx = zs && zs.ch ? zs.ch.d : topCh.d;
      const r = AsOf(Mn[k], sg.g, 'top', dx); o.AsT = Math.max(r.As1, asMinOf(sg.g.bw, r.d)) + torTB;
      o.nT = topCh.n; o.dX = dx; o.nX = o.AsT > topCh.A + 1 ? Math.ceil((o.AsT - topCh.A) / area(dx) - 1e-9) : 0;
    }
    return o;
  });
  return { zones, top: zT, mid, pts, cot, aL: Math.max(...aL), legs, base: { cs: cov.cs, csOf, dsw, dg } };
}
// sprawdzenia przy braku zbrojenia podłużnego (statyka, zbrojenie wymagane, ścinanie)
function bareChecks(R, S, c) {
  const C = R.checks, { sh, tor, secs } = c;
  const add = (grp, id, name, ref, Ed, Rd, unit, opt) => { opt = opt || {}; const ratio = opt.ratio !== undefined ? opt.ratio : (Rd > 0 ? Ed / Rd : (Ed > 0 ? Infinity : 0));
    C.push({ grp, id, name, ref, Ed, Rd, unit, ratio, status: opt.status || (ratio <= 1 + 1e-6 ? 'ok' : 'fail'), rel: opt.rel || '≤', note: opt.note || '', fmt: opt.fmt, at: opt.at }); };
  const zs = R.req ? R.req.zones : [];
  const zoneTxt = z => z && z.ch ? `${z.ch.n}⌀${z.ch.d} (${z.ch.A.toFixed(0)} mm²)` : '';
  secs.forEach(sec => {
    const z = sec.kind === 'span' ? zs.find(q => q.kind === 'bot' && q.segs.includes(sec.seg.idx)) : zs.find(q => q.kind === 'supp' && q.sups.includes(sec.sup.idx));
    const need = sec.kind === 'span' ? (z ? z.AsReq : sec.des.As1) : (z ? z.AsReq : sec.des.As1);
    add('SGN – zginanie', sec.kind === 'span' ? 'Mspan' : 'Msupp', `Nośność na zginanie (${sec.loc}) – ${sec.tens.n ? 'zbrojenie zadane' : 'brak zbrojenia podłużnego'}: M_Ed ≤ M_Rd`, '6.1', sec.MEd / 1e6, sec.MRd / 1e6, 'kNm',
      { at: sec.key, note: `wymagane A_s ≥ ${need.toFixed(0)} mm²${z && z.ch ? ` – dobór: ${sec.kind === 'span' ? zoneTxt(z) : `${R.req.top.ch.n}⌀${R.req.top.ch.d} ciągłe + ${z.ch ? z.ch.n + '⌀' + z.ch.d : '—'}`}` : ''}; przycisk „Dobierz zbrojenie” w zakładce Przekrój i zbrojenie` });
  });
  sh.ends.forEach(e => {
    add('SGN – ścinanie i skręcanie', 'Vmax', `Ściskanie krzyżulców betonowych (${e.name}) V_Ed ≤ V_Rd,max`, '6.2.3(3)', e.V0 / 1e3, e.VRdmax / 1e3, 'kN', { at: e.key, note: `cotθ = ${sh.cot.toFixed(2)}` });
    add('SGN – ścinanie i skręcanie', 'Vs1', `Strzemiona w strefie przypodporowej (${e.name}) V_Ed ≤ V_Rd,s`, '6.2.3(3)', e.Vred / 1e3, e.VRds1 / 1e3, 'kN', { at: e.key, note: `⌀${e.stir.d} ${e.stir.legs}-cięte co ${e.stir.s1} mm` });
  });
  void tor; void S;
}
// automatyczne zbrojenie: dobór wg zbrojenia wymaganego (SGN, A_s,min, skręcanie), następnie zwiększanie stref, w których nie są spełnione
// warunki zbrojenia podłużnego (nośność, ciągliwość, rysy, naprężenia, ugięcia, zakotwienie na podporze, ramiona strzemion)
function clearReb(S) {
  S.reb.bot = zoneOf([]); S.reb.top = zoneOf([]); S.reb.topX = zoneOf([]); S.reb.mid = Object.assign({}, S.reb.mid, { n: 0 });
  if (S.cont) { S.cont.rebSpans = (S.cont.rebSpans || []).map(() => zoneOf([])); S.cont.rebSupps = (S.cont.rebSupps || []).map(r => Object.assign(zoneOf([]), { lenL: r && r.lenL !== undefined ? r.lenL : '', lenR: r && r.lenR !== undefined ? r.lenR : '', extL: r && r.extL !== undefined ? r.extL : '', extR: r && r.extR !== undefined ? r.extR : '' })); }
  S.barEdit = {};
  return S;
}
// automatyczny dobór: zbrojenie + (opcjonalnie) najniższa klasa betonu spełniająca wszystkie warunki (ekspozycja, SGN, SGU, pożar)
// warunki nośności i SGU objęte wytężeniem docelowym η (automatyczny dobór): η = E_d / R_d ≤ η_doc
const ETA_IDS = new Set(['Mspan', 'Msupp', 'N', 'biax', 'Vmax', 'Vs1', 'Vsp', 'Vb', 'Tmax', 'Tst', 'Tl', 'VzMax', 'VzS', 'sck', 'ssk', 'wk', 'f']);
const overEta = (c, eta) => c.status === 'fail' || (eta < 1 && ETA_IDS.has(c.id) && c.status !== 'info' && isFinite(c.ratio) && c.ratio > eta + 1e-9);
const NOCLS = new Set(['cnom', 'lenMan', 'Lmax', 'sp', 'vib', 'deep', 'slab', 'lapB', 'stepB', 'stepL', 'inner10', 'lbd', 'lbdT', 'minclass', 'Lmin']);
function minClsOf(S) { let c0 = 'C20/25'; [S.env.exp, S.env.expF, S.env.expA].filter(e => e && e !== '-').forEach(e => { const c = MIN_CLASS[e]; if (c && classIdx(c) > classIdx(c0)) c0 = c; }); return c0; }
function autoReb(S0, opts) {
  opts = Object.assign({}, opts || {});
  // „wszystkie warunki” (strict): gdy samym zbrojeniem nie da się ich spełnić (np. pełzanie liniowe przy za małym przekroju), dobór bez wymuszania
  // ostrzeżeń, jeśli daje mniej niespełnionych warunków (albo tyle samo i mniej stali) – nie przezbrajać bez skutku
  if (opts.strict && !opts._one) {
    const a = autoReb(S0, Object.assign({}, opts, { _one: true }));
    if (a.R && !a.R.errors.length && !allBad(a.R, opts.eta || 1).length) return a;
    const b = autoReb(S0, Object.assign({}, opts, { _one: true, strict: false }));
    const sc = r => !r.R || r.R.errors.length ? [1e9, 0, 0] : [r.R.checks.filter(c => overEta(c, opts.eta || 1)).length, r.R.checks.filter(c => c.status === 'warn').length, r.R.sched ? r.R.sched.total : 0];
    const A = sc(a), B = sc(b);
    return A[0] < B[0] || (A[0] === B[0] && (A[1] < B[1] || (A[1] === B[1] && A[2] <= B[2] + 1e-9))) ? a : b;
  }
  if (!opts.deadline) opts.deadline = Date.now() + 5000;   // limit czasu doboru (przekroje wyraźnie za małe – wiele wariantów bez poprawy)
  const S1 = normalize(JSON.parse(JSON.stringify(S0)));
  if (!S1.mat.autoC || opts.noC) return autoReb1(S0, opts);
  const c0 = minClsOf(S1);
  let first = null, okFirst = null;
  const SOFTC = new Set(['scqp']);                           // σ_c,qp > k₂·f_ck (pełzanie nieliniowe) – usuwane wyższą klasą betonu
  const fin = r => { if (r.cls !== S0.mat.concrete) r.log.push(`klasa betonu: ${r.cls}`); return r; };
  // miara niespełnienia: suma przekroczeń (η − 1) warunków niespełnionych – do przerwania pętli klas, gdy wyższa klasa nie pomaga
  const excess = r => (r.R && r.R.checks ? r.R.checks : []).filter(c => c.status === 'fail' && !NOCLS.has(c.id)).reduce((a, c) => a + Math.min(5, isFinite(c.ratio) ? c.ratio - 1 : 5), 0);
  let bestEx = Infinity, noGain = 0; const t0 = Date.now();
  for (let i = classIdx(c0); i <= classIdx('C50/60'); i++) {
    const S = JSON.parse(JSON.stringify(S0)); S.mat.concrete = CONC_NAMES[i]; S.mat.autoC = true;
    const r = autoReb1(S, opts); r.cls = CONC_NAMES[i];
    if (!first) first = r;
    if (!r.ok) { const ex = excess(r); if (ex < bestEx - 0.02) { bestEx = ex; noGain = 0; } else noGain++;
      if ((noGain >= (opts.fullCls ? 99 : 2) || Date.now() - t0 > (opts.fullCls ? 12000 : 6000)) && !okFirst) return fin(first); }      // dwie kolejne klasy bez poprawy (lub długo) – dalsze podnoszenie klasy nie pomoże
    if (r.ok && !(r.R.checks || []).some(c => c.status === 'warn' && SOFTC.has(c.id))) return fin(r);
    if (r.ok) { if (!okFirst) okFirst = r; continue; }
    if (okFirst) { if (Date.now() - t0 > 6000) break; continue; }        // jest już wariant spełniający warunki – szukaj klasy bez σ_c,qp > k₂·f_ck
    if (!opts.fullCls && (!r.fails || !r.fails.some(id => !NOCLS.has(id)))) return fin(i === classIdx(c0) ? r : first);   // pozostałe niespełnione warunki nie zależą od klasy betonu
  }
  return fin(okFirst || first);
}
function autoReb1(S0, opts) {
  opts = opts || {};
  const S = normalize(JSON.parse(JSON.stringify(S0)));
  clearReb(S);
  const getP = (o, p) => p.split('.').reduce((a, k) => (a ? a[k] : undefined), o);
  const setP = (o, p, v) => { const ks = p.split('.'); let a = o; ks.slice(0, -1).forEach(k => { a = a[k]; }); const last = ks[ks.length - 1]; const old = a[last]; a[last] = Object.assign(v, old && old.lenL !== undefined ? { lenL: old.lenL, lenR: old.lenR, extL: old.extL === undefined ? '' : old.extL, extR: old.extR === undefined ? '' : old.extR } : {}); };
  const share = S.anch.toEnd === '25' ? 0.25 : S.anch.toEnd === '50' ? 0.5 : 1;
  const zone = (ch, bot) => {
    const n1 = ch.n1 !== undefined ? ch.n1 : ch.n, n2 = ch.n2 || 0;
    const z = zoneFromCh(ch);
    if (bot && share < 1 && z.layers[0]) { z.layers[0].toSupp = Math.min(n1, Math.max(2, Math.ceil(share * (n1 + n2)))); if (z.layers[1]) z.layers[1].toSupp = 0; }   // pręty doprowadzone do podpór (9.2.1.4(1))
    return z;
  };
  let R = calc(S);
  if (R.errors.length || !R.req) return { S: S0, R, ok: false, log: R.errors.slice(), iters: 0 };
  if (R.sh && R.sh.segs) { const lm = Math.max(...R.sh.segs.map(q => q.legsMin || 2)); if (lm > S.stir.legs && !(S.cont && (S.cont.stirSpans || []).some(q => q && q.legs > 0))) { S.stir.legs = Math.min(8, lm); R = calc(S); if (R.errors.length || !R.req) return { S: S0, R, ok: false, log: R.errors.slice(), iters: 0 }; } }
  const req = R.req, opt = {}, cur = {};
  req.zones.forEach(z => { opt[z.path] = z.opts; if (z.ch) { setP(S, z.path, zone(z.ch, z.kind === 'bot')); cur[z.path] = z.ch; } });
  if (req.mid) S.reb.mid = Object.assign({}, S.reb.mid, { n: req.mid.n, d: req.mid.d });
  const crackP = new Set();                                   // strefy z niespełnionym w_k – zwiększanie zbrojenia bez zwiększania średnicy
  const bump = (pth, nMin, defl) => {
    const o = opt[pth]; if (!o) return false;
    const c0 = cur[pth] || { A: 0, n: 0 };
    const o2 = Object.assign({}, o, { nMin: Math.max(o.nMin || 1, nMin || 0) });
    if (crackP.has(pth) && c0.d) { const dl = (o.dList || BAR_MAIN).filter(d => d <= c0.d); if (dl.length) o2.dList = dl; }
    if (o.base && cur['reb.top']) o2.base = { n: cur['reb.top'].n, d: cur['reb.top'].d, ch: cur['reb.top'] };
    const ch = chooseBars(nMin && c0.n < nMin ? Math.max(c0.A, 1) : c0.A + 1, o2);
    if (!ch || ch.over || (ch.A <= c0.A + 1e-6 && !(nMin && ch.n > c0.n))) return false;
    const dE = o.dEff || 500, cap = defl ? 0.02 * o.bw * dE : 0.04 * o.bw * (dE + 50);      // ugięcie: do ρ ≈ 2% (dalej – zwiększ przekrój); A_s,max = 0,04·A_c
    if (ch.A > cap) return false;
    cur[pth] = ch; setP(S, pth, zone(ch, /cont\.rebSpans|reb\.bot/.test(pth)));
    if (pth === 'reb.top') Object.keys(cur).filter(k => opt[k] && opt[k].base).forEach(k => refitLater.add(k));
    return true;
  };
  const refitLater = new Set();
  const cont = R.md.cont, segs = R.md.segs, sups = R.md.sups;
  const botOf = i => { const sg = segs[i]; if (!sg) return null; return cont ? (sg.reb ? `cont.rebSpans.${sg.si}` : (segs[sg.adj] ? `cont.rebSpans.${segs[sg.adj].si}` : null)) : 'reb.bot'; };
  const supOf = i => cont ? `cont.rebSupps.${i}` : 'reb.topX';
  const ensureSup = i => { const pth = supOf(i); if (!opt[pth]) { const p = sups[i]; opt[pth] = { cs: req.base.cs, csOf: req.base.csOf, dsw: req.base.dsw, dg: req.base.dg, bw: p.g.bw, nMin: 2, base: cur['reb.top'] ? { n: cur['reb.top'].n, d: cur['reb.top'].d, ch: cur['reb.top'] } : null, vib: VIBOF(S), dEff: p.g.h - 60, top: true, same: S.reb.sameD !== false };
    const dF = (S.reb.dSel || {})[cont ? 'x' + i : 'x'] || S.reb.dT; if (dF) { opt[pth].dList = [dF]; if (!cur['reb.top'] || dF !== cur['reb.top'].d) opt[pth].same = false; } } return pth; };
  const BUMP = new Set(['Mspan', 'Msupp', 'asmin', 'ascr', 'wk', 'ssk', 'sck', 'scqp', 'f', 'ld', 'FE', 'Tl', 'biax', 'N']);
  const log = []; let it = 0; const prevF = {}, blockF = new Set();
  for (; it < (opts.maxIt || 24); it++) {
    if (opts.deadline && Date.now() > opts.deadline && it > 2) break;
    R = calc(S);
    if (R.errors.length) { log.push('błąd: ' + R.errors[0]); break; }
    // ostrzeżenia usuwane zbrojeniem; przy doborze „wszystkie warunki” (strict) także pełzanie liniowe, σ_c (char.) i ciągliwość
    const fails = R.checks.filter(c => overEta(c, opts.eta || 1) || (c.status === 'warn' && (c.id === 'Tl' || c.id === 'skin' || c.id === 'tops' || c.id === 'Tside' || (opts.strict && (c.id === 'scqp' || c.id === 'sck' || c.id === 'duct')))));
    const todo = new Map();
    const want = (pth, nMin) => { if (pth) todo.set(pth, Math.max(todo.get(pth) || 0, nMin || 0)); };
    const deflOnly = new Set(), refit = new Set();
    fails.forEach(c => {
      const at = String(c.at || '');
      if (c.id === 'hold') { const i = +at.replace(/^st/, ''); const lg = segs[i] ? segs[i].stir.legs : 2; want(botOf(i), lg); want('reb.top', lg); return; }
      if (c.id === 'duct') { if (at[0] === 's') want('reb.top'); else if (at[0] === 'p') { const p = sups[+at.slice(1)]; if (p) [p.segL, p.segR].filter(q => q !== null).forEach(q => want(botOf(q))); } return; }
      if (c.id === 'Tl') { segs.forEach(sg => want(botOf(sg.idx))); want('reb.top'); return; }
      if (c.id === 'tops') { if (/^p\d/.test(at) && sups[+at.slice(1)]) want(ensureSup(+at.slice(1)), 2); return; }   // zbrojenie górne przy podporze skrajnej ≥ 0,15·A_s (9.2.1.2(1))
      if (c.id === 'Tside') { S.reb.mid.n = Math.min(6, (S.reb.mid.n || 0) + 1); todo.set('mid', 0); return; }
      if (c.id === 'skin') { const m0 = S.reb.mid; if ((m0.n || 0) < 1) m0.n = 1; else if (m0.d < 16) m0.d = m0.d < 12 ? 12 : 16; else if (m0.n < 6) m0.n++; else return; todo.set('mid', 0); return; }   // pręty przy bocznych powierzchniach (7.3.3(3))
      if (c.id === 'lbd' || c.id === 'lbdT') {
        const pth = c.id === 'lbd' ? botOf(parseInt(at.slice(1), 10)) : (/^p\d/.test(at) ? (cur[supOf(+at.slice(1))] ? supOf(+at.slice(1)) : 'reb.top') : null);
        if (pth && cur[pth] && opt[pth]) { const c0 = cur[pth], o = Object.assign({}, opt[pth], { dList: (opt[pth].dList || BAR_MAIN).filter(d => d < c0.d) }); if (o.dList.length) { const nc = chooseBars(c0.A, o); if (nc && !nc.over) { cur[pth] = nc; setP(S, pth, zone(nc, /cont\.rebSpans|reb\.bot/.test(pth))); opt[pth] = Object.assign({}, opt[pth], { dList: o.dList }); refit.add('#'); log.push(`${pth}: ${nc.n}⌀${nc.d} (zakotwienie)`); } } }
        return;
      }
      if (c.id === 'sck') { if (at[0] === 's') want('reb.top'); else if (at[0] === 'p') { const p = sups[+at.slice(1)]; if (p) [p.segL, p.segR].filter(q => q !== null).forEach(q => want(botOf(q))); } }
      if (c.id === 'sp') { const pth = at === 'LtM' ? 'reb.top' : /^L\d/.test(at) ? botOf(+at.slice(1)) : /^T\d/.test(at) ? supOf(+at.slice(1)) : null; if (pth && opt[pth]) refit.add(pth); return; }
      if (!BUMP.has(c.id)) return;
      if (c.id === 'f' || c.id === 'ld') {                    // ugięcie: zwiększaj zbrojenie tylko, gdy wyraźnie pomaga
        const kk = c.id + at;
        if (blockF.has(kk)) {                                  // zbrojenie rozciągane już nie pomaga – zbrojenie ściskane w przęśle (mniejsze ugięcie od pełzania i skurczu)
          const kt = 'T' + kk; if (blockF.has(kt) || !opt['reb.top']) return;
          if (prevF[kt] !== undefined && c.ratio > 0.97 * prevF[kt]) { blockF.add(kt); return; }
          prevF[kt] = c.ratio; if (!todo.has('reb.top')) deflOnly.add('reb.top'); want('reb.top'); return;
        }
        if (prevF[kk] !== undefined && c.ratio > 0.97 * prevF[kk]) { blockF.add(kk); prevF['T' + kk] = c.ratio; want('reb.top'); deflOnly.add('reb.top'); return; }
        prevF[kk] = c.ratio; const pth = botOf(+at.slice(1)); if (pth && !todo.has(pth)) deflOnly.add(pth); want(pth); return;
      }
      if (c.id === 'wk') { if (/^s\d/.test(at) || /^d\d/.test(at)) crackP.add(botOf(+at.slice(1))); else if (/^p\d/.test(at)) crackP.add(ensureSup(+at.slice(1))); }
      deflOnly.forEach(q => { if (q === botOf(+at.slice(1))) deflOnly.delete(q); });
      if (/^s\d/.test(at) || /^d\d/.test(at)) want(botOf(+at.slice(1)));
      else if (/^e\d/.test(at)) want(botOf(parseInt(at.slice(1), 10)));
      else if (/^p\d/.test(at)) want(ensureSup(+at.slice(1)));
    });
    let ch = false;
    if (refit.has('#')) { refit.delete('#'); ch = true; }
    refitLater.forEach(k => refit.add(k)); refitLater.clear();
    refit.forEach(pth => { const c0 = cur[pth]; if (!c0) return; const o = Object.assign({}, opt[pth], { cs: R.cov.cs, csOf: null, dsw: Math.max(...R.md.segs.map(sg => sg.stir.d)) });
      if (o.base && cur['reb.top']) o.base = { n: cur['reb.top'].n, d: cur['reb.top'].d, ch: cur['reb.top'] };
      const nc = chooseBars(c0.A, o); if (nc && !nc.over && (nc.n !== c0.n || nc.d !== c0.d || nc.layers !== c0.layers)) { cur[pth] = nc; setP(S, pth, zone(nc, /cont\.rebSpans|reb\.bot/.test(pth))); ch = true; log.push(`${pth}: ${nc.n}⌀${nc.d} (rozstaw)`); } });
    if (!todo.size && !ch) break;
    let topTried = false;
    todo.forEach((nMin, pth) => { if (pth === 'mid') { ch = true; return; } if (bump(pth, nMin, deflOnly.has(pth))) { ch = true; log.push(`${pth}: ${cur[pth].n}⌀${cur[pth].d}`); }
      else if (deflOnly.has(pth) && pth !== 'reb.top' && !topTried && !todo.has('reb.top')) { topTried = true; if (bump('reb.top', 0, true)) { ch = true; log.push(`reb.top: ${cur['reb.top'].n}⌀${cur['reb.top'].d} (zbrojenie ściskane – ugięcie)`); } } });
    if (!ch) break;
  }
  if (R.errors.length) { // np. pręty nie mieszczą się w wysokości – wróć do ostatniego poprawnego układu
    return { S, R, ok: false, log, iters: it };
  }
  // strzemiona: gdy nośność V_Rd,s przy s₁ = 50 mm nie wystarcza albo rozstaw s₁ < 75 mm (zbyt gęsto) – większa średnica strzemion
  const nFail = rr => rr.R.checks.filter(c => c.status === 'fail').length;
  if (S.stir.sAuto && !(S.cont && (S.cont.stirSpans || []).some(q => q && (q.d > 0 || q.legs > 0)))) {
    const fV = R.checks.some(c => overEta(c, opts.eta || 1) && ['Vs1', 'Vb', 'b3', 'Tst', 'VzS'].includes(c.id)) || ((R.sh && R.sh.ends) || []).some(e => e.bent), dense = ((R.sh && R.sh.segs) || []).some(z => z.stir && z.stir.s1 < 75);
    const nd = [6, 8, 10, 12].find(d => d > S.stir.d);
    if ((fV || dense) && nd && !(opts.deadline && Date.now() > opts.deadline)) { const S2 = JSON.parse(JSON.stringify(S0)); S2.stir.d = nd; const r2 = autoReb1(S2, opts);
      if (r2.R && !r2.R.errors.length && nFail(r2) <= nFail({ R })) { if (!r2.log.some(t => /^strzemiona ⌀/.test(t))) r2.log.unshift(`strzemiona ⌀${r2.S.stir.d} (${fV ? 'nośność na ścinanie' : 'rozstaw s₁ ≥ 75 mm'})`); return r2; } }
  }
  // strzemiona wielocięte w wąskim przekroju: pręty pod każdą gałęzią nie mieszczą się – strzemiona 2-cięte (gdy wystarczają, 9.2.2(8))
  if (!opts.legsDone && S.stir.legs > 2 && R.checks.some(c => c.status === 'fail' && !NOCLS.has(c.id) || c.id === 'sp') && !(S.cont && (S.cont.stirSpans || []).some(q => q && q.legs > 0))) {
    const lm = R.sh && R.sh.segs ? Math.max(2, ...R.sh.segs.map(q => q.legsMin || 2)) : 2;
    if (lm < S.stir.legs && !(opts.deadline && Date.now() > opts.deadline + 1500)) { const S2 = JSON.parse(JSON.stringify(S0)); S2.stir.legs = lm; const r2 = autoReb1(S2, Object.assign({}, opts, { legsDone: true }));
      if (r2.R && !r2.R.errors.length && r2.R.checks.filter(c => c.status === 'fail').length < R.checks.filter(c => c.status === 'fail').length) { r2.log.unshift(`strzemiona ${lm}-cięte (pręty pod gałęziami strzemion ${S.stir.legs}-ciętych nie mieszczą się w szerokości)`); return r2; } }
  }
  return { S, R, ok: R.checks.every(c => !overEta(c, opts.eta || 1)), log, iters: it, fails: R.checks.filter(c => overEta(c, opts.eta || 1)).map(c => c.id) };
}

// minimalne wymiary przekroju wg wytycznych normy (szacunkowo, dla każdego przęsła): zginanie bez zbrojenia ściskanego (ξ ≤ ξ_eff,lim),
// A_s ≤ 0,04·A_c i pręty w ≤ 2 warstwach, krzyżulce V_Ed ≤ V_Rd,max (cot θ = 1), ugięcie L/d ≤ (L/d)_lim (7.4.2), zwichrzenie (5.9(3)),
// odporność ogniowa b ≥ b_min (EN 1992-1-2, tab. 5.5/5.6); otulina z klasy ekspozycji; ciężar własny przeliczany dla wymiarów kandydujących
function suggestDims(S0) {
  const base = normalize(JSON.parse(JSON.stringify(S0))); clearReb(base);
  const Ra = calc(base); if (Ra.errors.length || !Ra.st || !Ra.sh) return null;
  if (Ra.st.manual) return null;
  let Rb = Ra;
  if (base.loads.sw) { const S2 = JSON.parse(JSON.stringify(base)); S2.loads.sw = false; const r = calc(S2); if (!r.errors.length && r.st) Rb = r; }
  const md = Ra.md, m = Ra.m, cov = Ra.cov, st = Ra.st, stB = Rb.st, cont = md.cont;
  const dsw = Math.max(...md.segs.map(sg => sg.stir.d)), dg = base.mat.dg;
  const cbM = Math.max(cov.cb + dsw, cov.cnom_main || 0) + 10, ctM = Math.max(cov.ct + dsw, cov.cnom_main || 0) + 10;
  const NEd = st.NEd || 0;
  const fire = base.fire.R && base.fire.R !== '-' ? ((cont || md.sups.some(p => p.type === 'fix')) ? FIRE_CONT : FIRE_SS)[base.fire.R] : null;
  const bFire = fire ? fire.c[0][0] : 0;
  const BS = [200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800];
  const own = cont ? md.segs.filter(sg => sg.kind === 'span') : md.segs.slice(0, 1);
  const out = own.map(sg => {
    const segsZ = cont ? md.segs.filter(q => q === sg || (q.kind !== 'span' && q.adj === sg.idx)) : md.segs;
    const g0 = sg.g, T = g0.T, sw0 = g0.selfW || 1e-9;
    const maxOver = (stt, f) => { let v = 0; segsZ.forEach(q => q.nodes.forEach(k => { v = Math.max(v, f(stt, k)); })); return v; };
    const MpA = maxOver(st, (t, k) => t.MEdMax[k]), MpB = maxOver(stB, (t, k) => t.MEdMax[k]);
    const sups = [...new Set(segsZ.flatMap(q => [q.supL, q.supR]).filter(Boolean))];
    const MnA = Math.max(0, ...sups.map(p => -st.MEdMinR[st.kAt(p.x)])), MnB = Math.max(0, ...sups.map(p => -stB.MEdMinR[stB.kAt(p.x)]));
    const ends = Ra.sh.ends.filter(e => segsZ.includes(e.seg)), endsB = Rb.sh ? Rb.sh.ends.filter(e => segsZ.map(q => q.idx).includes(e.seg.idx)) : ends;
    const VA = Math.max(0, ...ends.map(e => e.V0)), VB = Math.max(0, ...endsB.map(e => e.V0));
    const swOn = base.loads.sw && Rb !== Ra;
    const kMp = swOn ? (MpA - MpB) / sw0 : 0, kMn = swOn ? (MnA - MnB) / sw0 : 0, kV = swOn ? (VA - VB) / sw0 : 0;
    const Lsp = sg.L, isCant = sg.kind !== 'span';
    let K;
    if (isCant) K = 0.4; else if (!cont) { const nF = md.sups.filter(p => p.type === 'fix').length; K = nF >= 2 ? 1.5 : nF === 1 ? 1.3 : 1.0; }
    else { const cL = sg.supL && (!sg.supL.end || sg.supL.type === 'fix' || sg.supL.segL !== null), cR = sg.supR && (!sg.supR.end || sg.supR.type === 'fix' || sg.supR.segR !== null); K = cL && cR ? 1.5 : (cL || cR) ? 1.3 : 1.0; }
    const l0t = g0.l0t || Lsp;
    const test = (b, h) => {
      const bf = T ? Math.max(g0.beff, b) : b, hf = T ? g0.hf : 0;
      const swN = 25e-6 * (T ? b * (h - hf) : b * h) + (T ? 25e-6 * (bf - b) * hf * 0 : 0);
      const Mp = MpB + kMp * swN, Mn = MnB + kMn * swN, V = VB + kV * swN;
      const d = h - cbM, dT = h - ctM;
      if (d < 100) return 'wysokość';
      const des = Mp > 1e3 ? designBending({ M: Mp, N: NEd, bf, bw: b, hf, d, a2: ctM, yc: h / 2, m }) : null;
      const desT = Mn > 1e3 ? designBending({ M: Mn, N: NEd, bf: b, bw: b, hf: 0, d: dT, a2: cbM, yc: h / 2, m }) : null;
      const Ac = T ? b * h + (bf - b) * hf : b * h;
      // zginanie: dobór prętów i ponowne obliczenie z rzeczywistą wysokością użyteczną (otulina zależna od ⌀, druga warstwa)
      const cOf = (c0, phi) => cov.manual ? c0 : Math.max(c0, ceilTo(Math.max(phi + (cov.add || 0), cov.cdurNet || 0, 10) + (cov.dcdev || 0) - dsw, 5));
      for (const [q0, top] of [[des, false], [desT, true]]) {
        let q = q0; if (!q) continue;
        if (q.double || q.As1 > 0.04 * Ac) return 'zginanie';
        let dd = top ? dT : d;
        for (let it = 0; it < 2; it++) {
          const ch = chooseBars(Math.max(q.As1, Math.max(0.26 * m.fctm / m.fyk, 0.0013) * b * dd), { bw: b, cs: cov.cs, csOf: phi => cOf(cov.cs, phi), dsw, dg, nMin: 2, dEff: dd });
          if (ch.over || ch.layers > 2) return 'zginanie';
          const sv = Math.max(ch.d, dg + 5, 20), n2 = ch.n - (ch.layers > 1 ? ch.n1 : ch.n);
          dd = h - (cOf(top ? cov.ct : cov.cb, ch.d) + dsw + ch.d / 2) - (n2 > 0 ? (ch.d + sv) * n2 / ch.n : 0);
          q = designBending({ M: top ? Mn : Mp, N: NEd, bf: top ? b : bf, bw: b, hf: top ? 0 : hf, d: dd, a2: top ? cbM : ctM, yc: h / 2, m });
          if (q.double || q.As1 > 0.04 * Ac) return 'zginanie';
          if (q.As1 <= ch.A + 1e-6) break;
          if (it === 1) { const ch2 = chooseBars(q.As1, { bw: b, cs: cov.cs, csOf: phi => cOf(cov.cs, phi), dsw, dg, nMin: 2, dEff: dd }); if (ch2.over || ch2.layers > 2) return 'zginanie'; }
        }
        if (top) desT.As1 = q.As1; else des.As1 = q.As1;
      }
      if (V > b * 0.9 * d * m.nu * m.fcd / 2) return 'ścinanie';
      if (des && !isCant) {
        const Aref = T ? bf * hf + b * (d - hf) : b * d, rho = Math.max(1e-6, des.As1 / Aref), rho0 = Math.sqrt(m.fck) * 1e-3, sf = Math.sqrt(m.fck);
        const bas = rho <= rho0 ? K * (11 + 1.5 * sf * rho0 / rho + 3.2 * sf * Math.pow(rho0 / rho - 1, 1.5)) : K * (11 + 1.5 * sf * rho0 / rho);
        const lim = bas * ((T && bf / b > 3) ? 0.8 : 1) * ((base.sls.sens && Lsp > 7000) ? 7000 / Lsp : 1);
        if (Lsp / d > lim) return 'ugięcie';
      } else if (isCant && desT) {
        const rho = Math.max(1e-6, desT.As1 / (b * dT)), rho0 = Math.sqrt(m.fck) * 1e-3, sf = Math.sqrt(m.fck);
        const lim = rho <= rho0 ? K * (11 + 1.5 * sf * rho0 / rho + 3.2 * sf * Math.pow(rho0 / rho - 1, 1.5)) : K * (11 + 1.5 * sf * rho0 / rho);
        if (Lsp / dT > lim) return 'ugięcie';
      }
      const bc = T ? bf : b, hb = h / bc;
      if (hb > 2.5 || l0t / bc > 50 / Math.cbrt(hb)) return 'zwichrzenie';
      if (!isCant && Lsp < 3 * h) return 'belka-ściana';
      return '';
    };
    const GOV = { 'zginanie': 'zginanie (ξ ≤ ξ_eff,lim, A_s ≤ 0,04·A_c, pręty w ≤ 2 warstwach)', 'ścinanie': 'ściskanie krzyżulców V_Ed ≤ V_Rd,max (6.2.3)', 'ugięcie': 'ugięcie L/d ≤ (L/d)_lim (7.4.2)', 'zwichrzenie': 'zwichrzenie, h/b ≤ 2,5 (5.9(3))', 'wysokość': 'wysokość użyteczna', 'belka-ściana': 'belka, nie belka-ściana: L ≥ 3h (5.3.1(3))' };
    const minH = b => { let prev = ''; for (let h = Math.max(250, Math.ceil(0.8 * b / 50) * 50, Math.ceil(b / 5 / 50) * 50); h <= 2500; h += 50) { const f = test(b, h); if (f === 'belka-ściana') return null; if (!f) return { b, h, gov: prev || 'wymiary minimalne konstrukcyjne' }; prev = f; } return null; };
    const cands = BS.filter(b => b >= bFire && (!T || b <= g0.beff)).map(minH).filter(Boolean);
    const best = cands.reduce((a, q) => (!a || q.b * q.h < a.b * a.h - 1e-6 || (Math.abs(q.b * q.h - a.b * a.h) < 1e-6 && q.h < a.h) ? q : a), null);
    const atB = g0.bw >= bFire ? minH(g0.bw) : null;
    const curOk = !test(g0.bw, g0.h) && g0.bw >= bFire;
    return { seg: sg.idx, si: sg.si, label: sg.label, cur: { b: g0.bw, h: g0.h }, best: best && Object.assign(best, { govTxt: GOV[best.gov] || best.gov }), atB: atB && Object.assign(atB, { govTxt: GOV[atB.gov] || atB.gov }), curOk, curFail: test(g0.bw, g0.h), M: Math.max(MpA, MnA), V: VA, cands: cands.map(q => ({ b: q.b, h: q.h })), bMin: Math.max(200, bFire) };
  });
  let fireTxt = null;
  if (fire) { const aAv = cov.cb + dsw + 10; fireTxt = { R: base.fire.R, bmin: bFire, tab: fire.c, aAv, cReq: (b) => { const a = b >= fire.c[fire.c.length - 1][0] ? fire.c[fire.c.length - 1][1] : interp(fire.c, Math.max(b, bFire)); return Math.max(0, Math.ceil((a - dsw - 10) / 5) * 5); } }; }
  return { spans: out, fire: fireTxt, cov: { cb: cov.cb, ct: cov.ct, cs: cov.cs }, dsw };
}

// weryfikacja wymiarów proponowanych: dobór zbrojenia i pełne obliczenia (ugięcie metodą dokładną); w razie potrzeby h zwiększane co 50 mm
// niespełnione warunki dotyczące przęsła (z przyległymi wspornikami i podporami), zależne od wymiarów przekroju
function spanFails(R, seg, eta) {
  const own = c => { if (!R.md.cont) return true; const at = String(c.at || ''), sg = R.md.segs[seg]; if (!sg) return true;
    const ids = new Set(R.md.segs.filter(q => q === sg || (q.kind !== 'span' && q.adj === sg.idx)).map(q => q.idx)); const n = parseInt(at.replace(/^[a-zA-Z]+/, ''), 10);
    if (/^[sdeLb]\d/.test(at) || /^st\d/.test(at)) return ids.has(n); if (/^[pT]\d/.test(at)) { const p = R.md.sups[n]; return !!p && (ids.has(p.segL) || ids.has(p.segR)); } return true; };
  return (R.checks || []).filter(c => overEta(c, eta || 1) && !NOCLS.has(c.id) && own(c));
}
// warunki niespełnione po doborze zbrojenia, które dotyczą wymiarów przekroju (do sprawdzania proponowanych wymiarów): wszystkie niespełnione
// (także rozstaw prętów 8.2(2) i zakotwienia), bez wynikających wyłącznie z danych (otulina, długości ręczne, długość pręta, uskok, klasa min.);
// ostrzeżenia: prześwit na buławę (8.2(4)), zbrojenie górne przy podporze skrajnej (9.2.1.2(1)), liniowość pełzania (7.2(3) – gdy klasa betonu
// ustalona ręcznie; przy doborze klasy usuwa ją wyższa klasa)
const NODIM = new Set(['cnom', 'lenMan', 'Lmax', 'Lmin', 'lapB', 'stepB', 'stepL', 'inner10', 'minclass']);
function dimFails(R, seg, eta, S, all) {
  const autoC = !S || !S.mat || S.mat.autoC !== false;
  const own = c => { if (!R.md.cont || seg === null || seg === undefined) return true; const at = String(c.at || ''), sg = R.md.segs[seg]; if (!sg) return true;
    const ids = new Set(R.md.segs.filter(q => q === sg || (q.kind !== 'span' && q.adj === sg.idx)).map(q => q.idx)); const n = parseInt(at.replace(/^[a-zA-Z]+/, ''), 10);
    if (/^[sdeLb]\d/.test(at) || /^st\d/.test(at)) return ids.has(n); if (/^[pT]\d/.test(at)) { const p = R.md.sups[n]; return !!p && (ids.has(p.segL) || ids.has(p.segR)); } return true; };
  // all – „Dobierz wszystko”: każde ostrzeżenie (status warn) też jest niespełnieniem
  return (R.checks || []).filter(c => ((overEta(c, eta || 1) && !NODIM.has(c.id)) || (c.status === 'warn' && !NODIM.has(c.id) && (all || c.id === 'vib' || c.id === 'tops' || (c.id === 'scqp' && !autoC)))) && own(c));
}
const DIMB = new Set(['sp', 'Vmax', 'hold', 'lat', 'Tmax', 'Tl', 'vib', 'slab', 'fz']);           // niespełnione warunki usuwane raczej przez zwiększenie szerokości
function verifyDims(S0, seg, b, h, eta) {
  const set = (S, bb, hh) => { if (S.scheme === 'cont') { const md = beamModel(normalize(JSON.parse(JSON.stringify(S)))), sg = md.segs[seg]; if (!sg || sg.si === undefined) return false; S.cont.geoSpans = S.cont.geoSpans || []; for (let i = 0; i < S.cont.spans.length; i++) S.cont.geoSpans[i] = Object.assign({ b: S.geom.b, h: S.geom.h }, S.cont.geoSpans[i] || {}); S.cont.geoSpans[sg.si] = Object.assign({}, S.cont.geoSpans[sg.si], { b: bb, h: hh }); } else { S.geom.b = bb; S.geom.h = hh; } return true; };
  let last = null, bb = b, hh = h; const t0 = Date.now();
  for (let k = 0; k < 16 && Date.now() - t0 < 12000; k++) {
    const S = JSON.parse(JSON.stringify(S0)); if (!set(S, bb, hh)) return null;
    if (S.mat.autoC) S.mat.concrete = minClsOf(normalize(JSON.parse(JSON.stringify(S))));
    const r = autoReb(S, { noC: true, eta }); if (!r.R || r.R.errors.length) return { b: bb, h: hh, ok: false, fails: ['błąd'] };
    const fl = dimFails(r.R, seg, eta, S);
    last = { b: bb, h: hh, ok: !fl.length, fails: fl.map(c => c.id), names: fl.map(c => c.name), dh: hh - h, db: bb - b, reb: r };
    if (!fl.length) return last;
    // szerokość: warunki od niej zależne; pręty niemieszczące się (8.2(2), buława) – dopiero przy h/b ≥ 2 (wyższy przekrój = mniej prętów)
    const wB = fl.some(c => DIMB.has(c.id) && c.id !== 'sp' && c.id !== 'vib') || (fl.some(c => c.id === 'sp' || c.id === 'vib') && hh >= 2 * bb - 1e-6);
    if ((wB || hh + 50 > 2.5 * bb) && bb < 800 && !fl.some(c => c.id === 'f' || c.id === 'ld')) bb += 50; else hh += 50;
    if (r.R.md.segs.some(q => q.kind === 'span' && q.L < 3 * hh)) return last;
  }
  return last;
}

// automatyczny dobór wymiarów przekrojów (b × h) dla zadanych obciążeń i ZADANEJ klasy betonu (klasa bez zmian) – najmniejsze pole przekroju,
// przy którym dobrane zbrojenie spełnia wszystkie warunki z wytężeniem ≤ η, także prześwit na zadaną buławę (8.2(4)), liniowość pełzania (7.2(3))
// i zbrojenie górne przy podporze skrajnej (9.2.1.2(1)); przekrój jednakowy – wspólne wymiary; przęsła o różnych przekrojach – najpierw wspólny
// przekrój spełniający warunki, potem zmniejszanie wysokości każdego przęsła (każdy wariant sprawdzany pełnym doborem zbrojenia i kompletem
// warunków całej belki); gdy końcowe sprawdzenie nie przechodzi – wysokość +50 mm (szerokość, gdy h/b > 2,5)
function designDims(S0, o) {
  o = o || {}; const eta = o.eta > 0 && o.eta < 1 ? o.eta : 1, t0 = Date.now(), tMax = o.tMax || 40000;
  const base = normalize(JSON.parse(JSON.stringify(S0))); base.mat.autoC = false; if (eta < 1) base._eta = eta; else delete base._eta;
  clearReb(base);
  const D = suggestDims(base); if (!D || !D.spans.length) return null;
  const cont = base.scheme === 'cont', cls = base.mat.concrete;
  const uniform = !cont || !(base.cont.geoSpans || []).some(q => q && ((q.b !== '' && q.b !== undefined && q.b !== null) || (q.h !== '' && q.h !== undefined && q.h !== null)));
  const bLow = Math.max(200, ...D.spans.map(q => q.bMin || 200)), HB = 2.5, BMAX = 1200;           // h/b ≤ 2,5 – stateczność boczna (5.9(3))
  const estH = (q, b) => { const c = (q.cands || []).find(x => x.b === b); return c ? c.h : (q.best ? q.best.h : 400); };
  const c50 = v => Math.ceil(v / 50 - 1e-9) * 50;
  const setAll = (S, b, h) => { S.geom.b = b; S.geom.h = h; if (cont) S.cont.geoSpans = (S.cont.geoSpans || []).map(q => Object.assign({}, q, { b: '', h: '' })); };
  const setSpan = (S, si, b, h) => { S.cont.geoSpans = S.cont.geoSpans || []; for (let i = 0; i < S.cont.spans.length; i++) S.cont.geoSpans[i] = Object.assign({ b: S.geom.b, h: S.geom.h }, S.cont.geoSpans[i] || {}); S.cont.geoSpans[si] = Object.assign({}, S.cont.geoSpans[si], { b, h }); };
  const AR = (S, ms) => autoReb(S, { noC: true, eta, strict: true, _one: true, deadline: Date.now() + ms });
  // ocena wariantu: pełny dobór zbrojenia (klasa zadana) i wszystkie warunki całej belki (dimFails) – błąd „nie mieści się” = przekrój za mały
  const evalS = T => { const r = AR(T, 3000); if (!r.R) return { ok: false, fails: [{ id: 'err' }], maxR: 1.3 };
    if (r.R.errors.length) return { ok: false, fails: [{ id: 'fit' }], maxR: 1.3 };
    const fl = dimFails(r.R, null, eta, r.S || T, o.all); return { ok: !fl.length, fails: fl, maxR: Math.max(1, ...fl.map(c => (isFinite(c.ratio) ? c.ratio : 1.5) / eta)) }; };
  const deepOf = (T, h) => !cont && T.geom.L * 1000 < 3 * h;                      // belka-ściana (L < 3h) – zamiast wysokości rośnie szerokość
  // najmniejsza wysokość (co 50 mm) przy danej szerokości: wzrost skokowy do spełnienia, potem połowienie przedziału; szerokość +50 mm, gdy
  // decydują warunki od niej zależne (pręty niemieszczące się – dopiero przy h/b ≥ 2), gdy h/b > 2,5 albo L < 3h
  const tryDims = (ev, b, h) => {
    let bb = b, hh = Math.max(h, 250), lo = null, hi = null;
    for (let k = 0; k < 36 && Date.now() - t0 < tMax; k++) {
      if (hh > HB * bb + 1e-6) { if (bb >= BMAX) break; bb += 50; lo = null; hi = null; continue; }
      const v = ev(bb, hh);
      if (v.deep) { if (bb >= BMAX) break; bb += 50; hh = Math.max(250, (lo || hh) - 50); lo = null; hi = null; continue; }
      if (v.ok) { hi = hh; const nx = lo === null ? hh - 50 : c50((lo + hi) / 2); if (nx < Math.max(250, c50(0.8 * bb)) || (lo !== null && nx <= lo) || nx >= hi) break; hh = nx; }
      else {
        const wB = v.fails.some(c => DIMB.has(c.id) && c.id !== 'sp' && c.id !== 'vib') || (v.fails.some(c => c.id === 'sp' || c.id === 'vib') && hh >= 2 * bb - 1e-6);
        if (wB && !v.fails.some(c => c.id === 'f' || c.id === 'ld') && bb < BMAX) { bb += 50; lo = null; hi = null; continue; }
        lo = hh; const nx = hi === null ? c50(hh * Math.min(1.4, Math.max(1.1, Math.sqrt(v.maxR)))) : c50((lo + hi) / 2); if (hi !== null && nx >= hi) break; hh = nx;
      }
    }
    return hi !== null ? { b: bb, h: hi } : null;
  };
  let S = JSON.parse(JSON.stringify(base)); const out = [];
  // A. wspólny przekrój wszystkich przęseł
  const bBest = Math.max(bLow, ...D.spans.map(q => (q.best ? q.best.b : 250)));
  const evU = (b, h) => { const T = JSON.parse(JSON.stringify(base)); setAll(T, b, h); if (deepOf(T, h)) return { ok: false, deep: true, fails: [], maxR: 1 }; return evalS(T); };
  let best = null;
  for (const b of [...new Set([bBest, bBest + 50].filter(x => x >= bLow && x <= BMAX))]) {
    if (best && Date.now() - t0 > tMax * 0.5) break;
    const v = tryDims(evU, b, Math.max(250, c50(0.8 * b), ...D.spans.map(q => estH(q, b)))); if (!v) continue;
    if (!best || v.b * v.h < best.b * best.h - 1 || (Math.abs(v.b * v.h - best.b * best.h) < 1 && v.h < best.h)) best = v;
  }
  if (!best) return { ok: false, msg: `Nie udało się dobrać przekroju przy klasie ${cls} (szerokość do ${BMAX} mm, h/b ≤ 2,5) – zmień schemat statyczny, obciążenia albo klasę betonu.` };
  setAll(S, best.b, best.h);
  if (uniform) out.push({ label: cont ? 'wszystkie przęsła' : 'belka', b: best.b, h: best.h });
  else {
    // B. przęsła o różnych przekrojach: od wspólnego przekroju – zmniejszanie wysokości każdego przęsła (warunki całej belki)
    D.spans.forEach(q => { if (q.si !== undefined) setSpan(S, q.si, best.b, best.h); });
    D.spans.forEach(q => {
      if (q.si === undefined) return;
      const b = best.b; let hi = best.h, lo = Math.max(250, c50(0.8 * b)) - 50;
      const ev = h => { const T = JSON.parse(JSON.stringify(S)); setSpan(T, q.si, b, h); return evalS(T); };
      while (hi - lo > 50 && Date.now() - t0 < tMax) { const mid = c50((lo + hi) / 2); if (mid >= hi) break; if (ev(mid).ok) hi = mid; else lo = mid; }
      setSpan(S, q.si, b, hi); out.push({ label: q.label, b, h: hi, si: q.si });
    });
  }
  // C. zbrojenie dla przyjętych wymiarów (klasa zadana) – kontrola kompletu warunków; w razie potrzeby h + 50 mm (najwyżej 6 razy)
  let r = null, fl = [];
  for (let k = 0; k < 7; k++) {
    r = AR(S, 6000);
    fl = r.R && !r.R.errors.length ? dimFails(r.R, null, eta, r.S || S, o.all) : [{ id: 'err', name: (r.R && r.R.errors[0]) || 'błąd' }];
    if (!fl.length || Date.now() - t0 > tMax + 20000) break;
    out.forEach(q => { q.h += 50; if (q.h > HB * q.b + 1e-6) q.b += 50; if (q.si !== undefined) setSpan(S, q.si, q.b, q.h); else setAll(S, q.b, q.h); });
  }
  const ok = !fl.length;
  const Sout = r && r.S ? r.S : S; delete Sout._eta; Sout.mat.concrete = cls; Sout.mat.autoC = false;
  // wytężenie docelowe < 100%: rozstawy strzemion i długości stref z doboru zapisane jako ręczne (przy przeliczeniu bez η wytężenie nie wzrośnie)
  if (eta < 1 && r && r.R && r.R.md && r.R.sh) {
    const segs = r.R.md.segs, q0 = (segs.find(sg => sg.kind === 'span') || segs[0]).stir;
    if (Sout.stir.sAuto) { Sout.stir.sAuto = false; Sout.stir.s1 = q0.s1; Sout.stir.s2 = q0.s2; Sout.stir.sp = q0.sp > 0 ? q0.sp : ''; }
    if (cont) segs.forEach(sg => { if (sg.kind !== 'span' || sg.si === undefined || !sg.stir) return; Sout.cont.stirSpans = Sout.cont.stirSpans || []; Sout.cont.stirSpans[sg.si] = Object.assign({}, Sout.cont.stirSpans[sg.si] || {}, { s1: sg.stir.s1, s2: sg.stir.s2, sp: sg.stir.sp > 0 ? sg.stir.sp : '' }); });
    Sout.stir.zl = {}; r.R.sh.ends.forEach(e => { Sout.stir.zl[e.zkey] = Object.assign({ l1: String(Math.ceil(e.l1 / 50 - 1e-9) * 50 / 1000) }, e.sp ? { lp: String(Math.ceil(e.lp / 50 - 1e-9) * 50 / 1000) } : {}); });
  }
  return { ok, S: Sout, R: r ? r.R : null, cls, dims: out, uniform, eta, t: Date.now() - t0, fails: fl.map(c => c.name || c.id), soft: [] };
}

// „Dobierz wszystko”: dane przygotowane do doboru – klasa betonu ≥ minimalnej dla ekspozycji (zał. E), strzemiona i długości prętów
// automatycznie (bez ręcznych rozstawów, stref i długości), otulina ręczna mniejsza od wymaganej – automatyczna
function designAllPrep(S0) {
  const S = normalize(JSON.parse(JSON.stringify(S0))), notes = [];
  const c0 = minClsOf(S); if (classIdx(S.mat.concrete) < classIdx(c0)) { notes.push(`klasa betonu ${S.mat.concrete} → ${c0} (minimalna dla ekspozycji, zał. E)`); S.mat.concrete = c0; }
  S.mat.autoC = false;
  if (!S.stir.sAuto || Object.keys(S.stir.zl || {}).length) notes.push('rozstaw strzemion i długości stref – automatycznie');
  S.stir.sAuto = true; S.stir.zl = {}; S.stir.l1 = 'auto'; S.stir.lp = 'auto'; S.stir.nz = 'auto';
  if (S.cont) { S.cont.stirSpans = (S.cont.stirSpans || []).map(() => ({}));
    S.cont.rebSupps = (S.cont.rebSupps || []).map(r => Object.assign({}, r, { lenL: '', lenR: '', extL: '', extR: '' })); }
  S.reb.taLen = ''; S.barEdit = {};
  // otulina ręczna: sprawdzenie z dobranym zbrojeniem – gdy za mała, otulina automatyczna (wymagana)
  const manC = S.env.cnomSel === 'manual' || ['cBot', 'cTop', 'cSide'].some(k => S.env[k] !== '');
  if (manC) { let bad = true; try { const r = autoReb(S, { noC: true, deadline: Date.now() + 3000 }); bad = !r.R || r.R.checks.some(c => c.id === 'cnom' && c.status === 'fail'); } catch (e) { bad = true; }
    if (bad) { S.env.cnomSel = 'auto'; S.env.cBot = ''; S.env.cTop = ''; S.env.cSide = ''; notes.push('otulina – wymagana (automatycznie), ręczna była za mała'); } }
  return { S: normalize(S), notes };
}
// warunki niespełnione w Podsumowaniu (status fail lub warn) albo z wytężeniem > η (warunki nośności i SGU)
function allBad(R, eta) { return (R && R.checks ? R.checks : []).filter(c => c.status === 'fail' || c.status === 'warn' || overEta(c, eta || 1)); }

/* ------------------------------------------------------------ sprawdzenia */
function checks(R, S, g, m, st, cov, sh, tor, sls, anch) {
  const C = R.checks, md = R.md, secs = R.secs, LtM = R.LtM;
  const add = (grp, id, name, ref, Ed, Rd, unit, opt) => {
    opt = opt || {};
    const ratio = opt.ratio !== undefined ? opt.ratio : (Rd > 0 ? Ed / Rd : (Ed > 0 ? Infinity : 0));
    const status = opt.status || (ratio <= 1 + 1e-6 ? 'ok' : (opt.soft ? 'warn' : 'fail'));
    C.push({ grp, id, name, ref, Ed, Rd, unit, ratio, status, rel: opt.rel || '≤', note: opt.note || '', fmt: opt.fmt, at: opt.at !== undefined ? opt.at : AT });
    return C[C.length - 1];
  };
  let AT = null;                                   // miejsce sprawdzenia (przekrój / podpora / odcinek) – do raportu
  const multi = md.cont;
  const spanSegs = md.segs.filter(sg => sg.kind === 'span');
  const lbl = (sg) => multi ? ` (${sg.label})` : '';
  // --- Otulina i konstrukcja
  const gk = 'Otulina i konstrukcja';
  if (!cov.faces && cov.cb === cov.cnom && !(cov.ground && !cov.manual)) add(gk, 'cnom', 'Otulina nominalna c_nom (do strzemion)', '4.4.1', cov.reqR, cov.cnom, 'mm', { rel: '≥', note: cov.manual ? `przyjęto ręcznie; wymagane ${cov.req.toFixed(0)} mm → ${cov.reqR} mm` : `wymagane ${cov.req.toFixed(0)} mm → zaokr. ${cov.reqR} mm` });
  else [['cb', 'reqB', 'dolnej'], ['ct', 'reqT', 'górnej'], ['cs', 'reqS', 'bocznych']].forEach(([k, rq, nm]) => add(gk, 'cnom', `Otulina nominalna krawędzi ${nm} c_nom (do strzemion)`, '4.4.1', cov[rq], cov[k], 'mm', { rel: '≥', at: 'cov', note: `wymagane ${cov[rq]} mm` + (k === 'cb' && cov.ground ? ` (w tym betonowanie na podłożu ≥ ${cov.ground} mm)` : '') }));
  const mc = add(gk, 'minclass', 'Minimalna klasa betonu dla ekspozycji', 'Zał. E', classIdx(cov.minCls), classIdx(S.mat.concrete), '',
    { rel: '≥', soft: true, ratio: cov.minOk ? 0 : 1.01, status: cov.minOk ? 'ok' : 'warn', note: `${S.mat.concrete} vs min. ${cov.minCls} (${cov.minFrom})`, fmt: 'text' });
  mc.EdTxt = cov.minCls; mc.RdTxt = S.mat.concrete;
  const vibReq = S.reb.vib + 10, vibOn = S.reb.vibOn !== false;
  const spacing = (nm, lay, at, top) => {
    if (!lay || !lay.n) return;
    if (!lay.ok) { add(gk, 'sp', nm, '8.2(2)', 1, 0, 'mm', { ratio: Infinity, status: 'fail', note: (lay.issues || []).join('; ') + ' – zmień rozmieszczenie, średnice lub dodaj warstwę', at }); return; }
    const l0 = lay.layers.filter(l => l.n > 1);
    if (l0.length) {
      const worst = l0.reduce((a, b) => (b.gap / b.smin < a.gap / a.smin ? b : a));
      add(gk, 'sp', nm, '8.2(2)', worst.smin, worst.gap, 'mm', { rel: '≥', at, note: `${lay.layers.length} warstw(y): ${lay.layers.map(l => l.n).join('+')} ${lay.bars.some(b => b.nb > 1) ? 'wiązek' : 'prętów'}` + (lay.layers.length > 1 ? '; pręty kolejnych warstw nad prętami warstwy 1 (8.2(4))' : '') + (lay.layers.some(l => l.touch || l.touchUp) ? '; warstwy w styku – prześwit ≥ max(1,5⌀; d_g + 5; 30 mm)' : '') + (lay.bundle ? `; ${lay.bundle}` : '') });
    }
    // dostęp buławy wibratora: zbrojenie górne – zawsze; dolne – gdy kilka warstw lub pręty jeden nad drugim
    if (vibOn && (top || lay.stacked)) add(gk, 'vib', nm.replace('Rozstaw prętów', 'Prześwit na buławę wibratora –').replace(' w świetle', ''), '8.2(4)', vibReq, lay.open, 'mm', { rel: '≥', soft: true, at,
      note: `największy prześwit między ${lay.stacked && !top ? 'kolumnami prętów' : 'prętami'}; buława ⌀${S.reb.vib} mm + 10 mm luzu` });
  };
  md.segs.forEach(sg => { if (sg.kind === 'span') spacing('Rozstaw prętów dolnych w świetle' + lbl(sg), sg.Lb, 'L' + sg.idx); });
  spacing('Rozstaw prętów górnych w świetle (przęsło)', LtM, 'LtM', true);
  md.sups.forEach(p => { if (p.hasX) spacing(`Rozstaw prętów górnych w świetle (${p.name})`, p.LtS, 'T' + p.idx, true); });
  // wiązki: ⌀n ≤ 55 mm (8.9.1(2))
  {
    const dn = Math.max(...md.segs.map(sg => sg.Lb.dnMax || 0), ...md.sups.map(p => p.LtS.dnMax || 0));
    const allB = [...md.segs.flatMap(sg => sg.Lb.bars), ...md.sups.flatMap(p => p.LtS.bars)];
    if (allB.some(b => b.nb > 1)) add(gk, 'phin', 'Wiązki prętów: średnica zastępcza ⌀_n = ⌀·√n_b ≤ 55 mm', '8.9.1(2)', dn, 55, 'mm', { note: allB.some(b => b.sep) ? 'pary prętów jeden nad drugim w dobrych warunkach przyczepności – odstępy i zakotwienie jak dla prętów pojedynczych (8.9.1(4))' : 'odstępy, otulina i zakotwienie z ⌀_n, prześwit od obrysu wiązki (8.9.1(3))' });
  }
  // pręty boczne (w połowie wysokości): odstęp pionowy w świetle
  const MD = S.reb.mid;
  if (MD.n > 0 && md.segs[0].mid.length) {
    const sg0 = md.segs.find(q => q.kind === 'span') || md.segs[0], mb = sg0.mid;
    const ys = Array.from(new Set(mb.map(b => Math.round(b.y)))).sort((u, v) => u - v);
    const dT = sg0.Lt.n ? sg0.Lt.layers[0].dmax : MD.d, dB = sg0.Lb.layers[0].dmax;
    const yT = sg0.Lt.n ? sg0.Lt.layers[0].e : null, yB = sg0.g.h - sg0.Lb.layers[0].e;
    let gmin = Infinity;
    for (let i = 0; i < ys.length - 1; i++) gmin = Math.min(gmin, ys[i + 1] - ys[i] - MD.d);
    if (yT !== null) gmin = Math.min(gmin, ys[0] - yT - (MD.d + dT) / 2);
    gmin = Math.min(gmin, yB - ys[ys.length - 1] - (MD.d + dB) / 2);
    const smin = Math.max(MD.d, dT, dB, S.mat.dg + 5, 20);
    add(gk, 'midsp', `Pręty boczne ${2 * MD.n}⌀${MD.d}: odstęp pionowy w świetle`, '8.2(2)', smin, gmin, 'mm', { rel: '≥', note: `${MD.n} rząd(y) przy każdym boku, ` + (MD.ys ? 'położenie podane ręcznie' : 'rozmieszczone równomiernie na wysokości') });
  }
  secs.forEach(sec => (AT = sec.key) && add(gk, 'asmin', sec.kind === 'span' ? 'Zbrojenie dolne ≥ A_s,min' + (multi ? ` (${sec.loc})` : '') : `Zbrojenie górne ≥ A_s,min (${sec.loc})`, '9.2.1.1(1)', sec.sls ? sec.sls.AsMin : 0, sec.tens.A, 'mm²', { rel: '≥' }));
  AT = null;
  const asmaxL = [...md.segs.map(sg => [sg.Lb.A + sg.Lt.A + (R.midA || 0), 0.04 * sg.g.Ac]), ...md.sups.map(p => [p.LbS.A + p.LtS.A + (R.midA || 0), 0.04 * p.g.Ac])];
  const asmaxW = asmaxL.reduce((a, q) => (q[0] / q[1] > a[0] / a[1] ? q : a));
  add(gk, 'asmax', 'Zbrojenie podłużne ≤ A_s,max = 0,04·A_c', '9.2.1.1(3)', asmaxW[0], asmaxW[1], 'mm²');
  spanSegs.forEach(sg => add(gk, 'bots', 'Zbrojenie dolne przy podporze ≥ 0,25·A_s,przęsło' + lbl(sg), '9.2.1.4(1)', 0.25 * sg.Lb.A, sg.LbS.A, 'mm²', { rel: '≥' }));
  md.sups.filter(p => p.end && p.type !== 'fix' && (p.segL === null ? md.segs[p.segR].kind === 'span' : md.segs[p.segL].kind === 'span') && !p.sec).forEach(p => {
    const sg = md.segs[p.segL !== null ? p.segL : p.segR];
    add(gk, 'tops', `Zbrojenie górne przy podporze skrajnej ≥ 0,15·A_s,przęsło (${p.name})`, '9.2.1.2(1)', 0.15 * sg.Lb.A, p.LtS.A, 'mm²', { rel: '≥', soft: true, at: 'p' + p.idx, note: 'dotyczy podpór monolitycznych (częściowe utwierdzenie)' });
  });
  (st.redist || []).forEach(q => { const sec = q.sup.sec; if (!sec || !sec.r || !(sec.d > 0)) return; AT = 'p' + q.sup.idx;
    const xu = Math.max(0, sec.r.x), dmin = Math.max(st.redistK5 || 0.7, 0.44 + 1.25 * xu / sec.d);
    add('SGN – zginanie z siłą osiową', 'redist', `Redystrybucja momentu nad podporą (${q.sup.name}): δ ≥ k₁ + k₂·x_u/d, δ ≥ k₅`, '5.5(4)', dmin, q.delta, '', { rel: '≥', ratio: dmin / q.delta, fmt: 2,
      note: `δ = ${q.delta.toFixed(2)}: M = ${(q.M0 / 1e6).toFixed(1)} → ${(q.M / 1e6).toFixed(1)} kNm; x_u/d = ${(xu / sec.d).toFixed(3)}; k₁ = 0,44, k₂ = 1,25, k₅ = ${(st.redistK5 || 0.7).toFixed(1)} (stal klasy ${(STEEL_LIST.find(z => z.id === S.mat.steel) || {}).cls || 'B'}); momenty przęsłowe i siły poprzeczne zwiększone (równowaga)` }); });
  md.segs.filter(sg => sg.kind === 'span').forEach(sg => { AT = 'd' + sg.idx;
    add(gk, 'deep', `Element belkowy, nie belka-ściana: L ≥ 3·h${lbl(sg)}`, '5.3.1(3)', 3 * sg.g.h / 1000, sg.L / 1000, 'm', { rel: '≥', soft: true, note: `L = ${(sg.L / 1000).toFixed(2)} m, h = ${sg.g.h} mm; przy L < 3h element jest belką-ścianą – model belkowy nie ma zastosowania (stosuj model kratownicowy, 6.5)` });
    add(gk, 'slab', `Element belkowy, nie płyta: b < 5·h${lbl(sg)}`, '5.3.1(4)', sg.g.bw, 5 * sg.g.h, 'mm', { soft: true, ratio: sg.g.bw / (5 * sg.g.h), status: sg.g.bw < 5 * sg.g.h ? 'ok' : 'warn', note: `b = ${sg.g.bw} mm, h = ${sg.g.h} mm; przy b ≥ 5h element jest płytą (pasmem płytowym)` }); });
  AT = null;
  {
    const gL = md.segs.reduce((a, sg) => (sg.g.h / sg.g.bFlange > a.h / a.bFlange ? sg.g : a), g);
    const b = gL.bFlange, hb = gL.h / b;
    const lim = 50 / Math.cbrt(hb);
    const l0t = gL.l0t / b;
    const c = add(gk, 'lat', 'Stateczność boczna (zwichrzenie): l_0t/b', '5.9(3)', l0t, lim, '', { soft: true, note: `h/b = ${hb.toFixed(2)} ${hb <= 2.5 ? '≤' : '>'} 2,5` + (hb > 2.5 ? ' – wymagana dokładniejsza analiza' : '') });
    if (hb > 2.5) c.status = 'warn';
  }
  if (secs.some(q => q.g.h >= 1000)) {
    // 7.3.3(3): zbrojenie przypowierzchniowe boków między zbrojeniem rozciąganym a osią obojętną; A_s ≥ k_c·k·f_ct,eff·A_ct/f_yk, k = 0,5
    const sec0 = secs.filter(q => q.sls && q.g.h >= 1000).reduce((a, q) => (!a || q.sls.Mk > a.sls.Mk ? q : a), null);
    const g = sec0 ? sec0.g : R.g;
    let req = 0, prov = 0, note = '';
    if (sec0) {
      const xI = sec0.sls.unS.yc, isS = sec0.kind === 'span';
      const Act = g.bw * (g.h - (isS ? xI : g.h - xI));
      req = 0.4 * 0.5 * R.m.fctm * Act / R.m.fyk;
      const xII = sec0.sls.crS.x;
      prov = (isS ? sec0.bars : sec0.bars).filter(b => b.side === 'mid' && (isS ? b.y > xII : b.y < g.h - xII)).reduce((a, b) => a + b.A, 0);
      note = `k = 0,5; σ_s = f_yk; pręty boczne w strefie rozciąganej (${sec0.loc})` + (S.reb.mid.n ? '' : ' – dodaj pręty boczne');
    }
    add(gk, 'skin', 'Zbrojenie przy bocznych powierzchniach (h ≥ 1000 mm)', '7.3.3(3)', req, prov, 'mm²', { rel: '≥', soft: true, note });
  }
  // zbrojenie przypowierzchniowe 9.2.4 / J.1
  {
    const sf = R.surf;
    if (!sf.req) add(gk, 'surf0', 'Zbrojenie przypowierzchniowe (siatka) – nie jest wymagane', '9.2.4, zał. J', 0, 0, '', { status: 'info', ratio: 0, note: `⌀_max = ${sf.dmax.toFixed(0)} mm ≤ 32 mm, c_nom = ${sf.cnom} mm ≤ 70 mm` });
    else if (sf.gov) {
      const why = [sf.byBar ? `pręty/wiązki ⌀ > 32 mm (⌀ = ${sf.dmax.toFixed(1)} mm)` : '', sf.byCover ? `c_nom = ${sf.cnom} mm > 70 mm` : ''].filter(Boolean).join('; ');
      add(gk, 'surf', `Zbrojenie przypowierzchniowe: siatka ⌀${S.surf.d} co ${S.surf.s} mm, A_s,surf ≥ ${sf.rho === 0.01 ? '0,01' : '0,005'}·A_ct,ext`, '9.2.4, zał. J', sf.AsReq, sf.AsProv, 'mm²', { rel: '≥', note: `wymagane: ${why}; A_ct,ext = ${sf.gov.Act.toFixed(0)} mm² (${sf.gov.sec.loc}); w obu kierunkach` });
      add(gk, 'surft', 'Zbrojenie przypowierzchniowe: pręty poprzeczne siatki (na 1 m długości)', '9.2.4, zał. J', sf.perMReq, sf.perM, 'mm²/m', { rel: '≥', note: `${sf.rho === 0.01 ? '0,01' : '0,005'}·c_nom·1000 mm` });
      add(gk, 'surfs', 'Zbrojenie przypowierzchniowe: oczko siatki ≤ 150 mm', '9.2.4, zał. J', sf.s, 150, 'mm');
    }
  }

  // --- SGN zginanie
  const gb = 'SGN – zginanie z siłą osiową';
  secs.forEach(sec => {
    AT = sec.key;
    const nm = sec.kind === 'span' ? `Zginanie – ${multi ? sec.loc : 'przekrój przęsłowy'} M_Ed ≤ M_Rd` : `Zginanie – ${multi ? sec.loc : 'przekrój podporowy'} |M_Ed| ≤ M_Rd`;
    if (sec.kind === 'span' && sec.MEd <= 0 && secs.some(s => s.kind === 'supp')) return;
    add(gb, sec.kind === 'span' ? 'Mspan' : 'Msupp', nm, '6.1', sec.MEd / 1e6, sec.r ? sec.MRd / 1e6 : 0, 'kNm', sec.r ? (multi ? { note: `x = ${(sec.x / 1000).toFixed(2)} m` } : {}) : { ratio: Infinity, status: 'fail', note: 'N_Ed poza zakresem nośności przekroju' });
  });
  secs.forEach(sec => {
    AT = sec.key;
    if (!sec.r || sec.MEd <= 0 || !sec.r0 || !isFinite(sec.r0.x)) return;
    const xi = sec.r0.x / sec.d;
    add(gb, 'duct', `Ciągliwość (${sec.kind === 'span' && !multi ? 'przęsło' : sec.kind === 'supp' && !multi ? 'podpora' : sec.loc}): ξ = x/d ≤ ξ_lim`, '6.1 / 5.6.3', xi, R.m.xiLim, '', { soft: true, note: xi > R.m.xiLim ? 'przekrój przezbrojony – stal nie uplastycznia się' : 'stal rozciągana uplastyczniona' });
  });
  AT = null;
  if (Math.abs(st.NEd) > 0) {
    if (st.NEd > 0) add(gb, 'N', 'Ściskanie osiowe N_Ed ≤ N_Rd,max', '6.1', st.NEd / 1e3, R.NRdMax / 1e3, 'kN');
    else add(gb, 'N', 'Rozciąganie osiowe |N_Ed| ≤ N_Rd,t', '6.1', -st.NEd / 1e3, -R.NRdMin / 1e3, 'kN');
  }
  if (st.hasZ) {
    secs.forEach(sec => {
      AT = sec.key;
      if (!sec.biax || !(sec.biax.Mz > 1e3)) return;
      add(gb, 'biax', `Zginanie ukośne (Y+Z) – ${sec.loc}: |M_Ed| ≤ M_Rd w kierunku wektora momentu`, '6.1 (zginanie ukośne)', sec.biax.u, 1, '', { note: `M_y = ${(sec.biax.My / 1e6).toFixed(1)}, M_z = ${(sec.biax.Mz / 1e6).toFixed(1)} kNm; kontur M_y–M_z przy N_Ed (metoda włókien)` });
    });
    (R.biaxZ || []).forEach(b => (AT = 'z' + b.seg.idx) && add(gb, 'biaxZ', `Zginanie ukośne (Y+Z) – ${b.loc}, max M_z`, '6.1 (zginanie ukośne)', b.u, 1, '', { note: `x = ${(b.x / 1000).toFixed(2)} m; M_y = ${(b.My / 1e6).toFixed(1)}, M_z = ${(b.Mz / 1e6).toFixed(1)} kNm` }));
  }
  // --- SGN ścinanie
  AT = null;
  const sg = 'SGN – ścinanie i skręcanie';
  sh.ends.forEach(e => {
    AT = e.key;
    add(sg, 'Vmax', `Ściskanie krzyżulców betonowych (${e.name}) V_Ed ≤ V_Rd,max` + (tor.on ? ' (z T_Ed)' : ''), tor.on ? '6.3.2(4)' : '6.2.3(3)', tor.on ? e.inter : e.V0 / 1e3, tor.on ? 1 : e.VRdmax / 1e3, tor.on ? '' : 'kN',
      { note: `cotθ = ${sh.cot.toFixed(2)}` + (tor.on ? '; V/V_Rd,max + T/T_Rd,max' : '') });
    if (e.bent) {
      add(sg, 'Vb', `Strzemiona i pręty odgięte (${e.name}) V_Ed ≤ V_Rd,s + V_Rd,s,α`, '6.2.3(4), wzór 6.13', e.Vred / 1e3, (e.VRds1 + e.bent.VRdb) / 1e3, 'kN', { note: `odgięcia 45°: ${e.bent.ng} × ${e.bent.n}⌀${e.bent.d} co s_b = ${e.bent.sb} mm (≤ 0,6·d·(1 + cot α) = ${e.bent.sbMax.toFixed(0)} mm, 9.2.2(7)); V_Rd,s,α = A_sb/s_b·z·f_ywd·(cot θ + cot α)·sin α = ${(e.bent.VRdb / 1e3).toFixed(1)} kN; strzemiona V_Rd,s = ${(e.VRds1 / 1e3).toFixed(1)} kN` });
      add(sg, 'b3', `Udział strzemion w zbrojeniu na ścinanie (${e.name}) ≥ 50% (β₃ = 0,5)`, '9.2.2(4)', 0.5 * e.Vred / 1e3, e.VRds1 / 1e3, 'kN', { rel: '≥', note: 'co najmniej połowa wymaganego zbrojenia na ścinanie w postaci strzemion' });
    } else
    add(sg, 'Vs1', `Strzemiona w strefie przypodporowej (${e.name}) V_Ed ≤ V_Rd,s`, '6.2.3(3)', e.Vred / 1e3, e.VRds1 / 1e3, 'kN',
      { note: (e.red ? `V_Ed w odl. d = ${e.d.toFixed(0)} mm od lica (6.2.1(8))` : `V_Ed przy podporze bez redukcji${e.redWhy ? ' – ' + e.redWhy : ''}`) + `; ⌀${e.stir.d} ${e.stir.legs}-cięte co ${e.stir.s1} mm` + (e.Vred <= e.VRdc ? '; V_Ed ≤ V_Rd,c – wystarczy zbrojenie minimalne' : '') });
    if (e.l1User !== null && e.l1User !== undefined) add(sg, 'l1', `Długość strefy s₁ od lica (${e.name}) ≥ wymagana`, '6.2.3', e.l1req / 1000, e.l1 / 1000, 'm', { rel: '≥' });
    if (e.sp) {
      const Vb = e.l1 > 0 ? st.Vat(e.x + e.dir * (e.sup.t / 2 + e.l1)) : e.Vred;
      add(sg, 'Vsp', `Strzemiona w strefie pośredniej (${e.name}) V_Ed ≤ V_Rd,s(s_p)`, '6.2.3(3)', Math.min(Vb, e.Vred) / 1e3, e.VRdsp / 1e3, 'kN', { note: `V_Ed na końcu strefy s₁ (${(e.l1 / 1000).toFixed(2)} m od lica); ⌀${e.stir.d} ${e.stir.legs}-cięte co ${e.sp} mm na ${(e.lp / 1000).toFixed(2)} m` });
      if (e.lpUser !== null && e.lpUser !== undefined) add(sg, 'lp', `Długość stref s₁ + s_p od lica (${e.name}) ≥ wymagana`, '6.2.3', e.l12req / 1000, (e.l1 + e.lp) / 1000, 'm', { rel: '≥' });
    }
  });
  if (st.hasZ) sh.ends.forEach(e => {
    AT = e.key;
    const z = e.zsh; if (!z || z.V0 < 1) return;
    add(sg, 'VzMax', `Ścinanie poziome (Z) – krzyżulce (${e.name}) V_Ed,z ≤ V_Rd,max,z`, '6.2.3(3) (kierunek Z)', z.V0 / 1e3, z.VRdmax / 1e3, 'kN', { note: `b_w,z = h = ${z.bw.toFixed(0)} mm, d_z = ${z.d.toFixed(0)} mm` });
    add(sg, 'VzS', `Ścinanie poziome (Z) – gałęzie poziome strzemion (${e.name}) V_Ed,z ≤ V_Rd,s,z`, '6.2.3(3) (kierunek Z)', z.Vred / 1e3, z.VRds1 / 1e3, 'kN', { note: `2 gałęzie poziome ⌀${e.stir.d} co ${e.stir.s1} mm` + (z.Vred <= z.VRdc ? '; V_Ed,z ≤ V_Rd,c,z' : '') });
    add(sg, 'VzI', `Krzyżulce – interakcja Y i Z (${e.name}) V_y/V_Rd,max,y + V_z/V_Rd,max,z` + (tor.on ? ' + T/T_Rd,max' : '') + ' ≤ 1', '6.2.3 / 6.3.2(4)', z.inter, 1, '');
  });
  AT = null;
  const multiSt = sh.segs.length > 1 && (R.stirVar || R.gVar);
  sh.segs.forEach(q => {
    AT = 'st' + q.seg.idx;
    const sfx = multiSt ? ` (${q.seg.label})` : '';
    add(sg, 'rho1', 'Stopień zbrojenia strzemionami ρ_w (s₁) ≥ ρ_w,min' + sfx, '9.2.2(5)', sh.rhoMin * 1000, q.rho1 * 1000, '‰', { rel: '≥' });
    add(sg, 'rho2', 'Stopień zbrojenia strzemionami ρ_w (s₂) ≥ ρ_w,min' + sfx, '9.2.2(5)', sh.rhoMin * 1000, q.rho2 * 1000, '‰', { rel: '≥' });
    const sMaxAll = tor.on ? Math.min(q.sMax, sh.sMaxT) : q.sMax;
    add(sg, 'smax', `Rozstaw podłużny strzemion max(s₁${q.stir.sp ? ', s_p' : ''}, s₂) ≤ s_l,max` + sfx, tor.on ? '9.2.2(6), 9.2.3(3)' : '9.2.2(6)', Math.max(q.stir.s1, q.stir.s2, q.stir.sp || 0), sMaxAll, 'mm');
    if (q.comp && isFinite(q.comp.phi)) add(sg, 'scomp', `Belka ściskana siłą N_Ed: rozstaw strzemion max(s₁${q.stir.sp ? ', s_p' : ''}, s₂) ≤ 15⌀ (⌀${q.comp.phi})` + sfx, '9.2.1.2(3)', Math.max(q.stir.s1, q.stir.s2, q.stir.sp || 0), 15 * q.comp.phi, 'mm',
      { note: `siła ściskająca N_Ed = ${(st.NEd / 1e3).toFixed(1)} kN (jak w słupie) – pręty podłużne ściskane; ⌀ – najmniejsza średnica prętów podłużnych` });
    if (q.stir.legs > 1) add(sg, 'st', 'Rozstaw poprzeczny ramion strzemion s_t ≤ s_t,max' + sfx, '9.2.2(8)', q.st, q.stMax, 'mm', { note: `${q.stir.legs}-cięte; minimalna liczba ramion dla b_w = ${q.seg.g.bw} mm: ${q.legsMin}` });
    const hd = q.seg.hold;
    if (hd && q.stir.legs >= 2) add(sg, 'hold', `Ramiona strzemion ${q.stir.legs}-ciętych obejmują pręty podłużne w narożach` + sfx, '9.2.2(8), 9.2.1', q.stir.legs, Math.max(hd.maxLegs, 0), '', { status: hd.ok ? 'ok' : 'fail', ratio: hd.ok ? 0 : Infinity, fmt: 0, rel: '≤',
      note: `warstwa 1: dół ${hd.nB}, góra ${hd.nT} prętów → maks. ${hd.maxLegs || 0} ramion` + (hd.ok ? '' : (hd.nB < q.stir.legs || hd.nT < q.stir.legs ? ` – dodaj pręty ${hd.nT < q.stir.legs ? 'górne (montażowe)' : 'dolne'} w miejscach ramion lub zmniejsz liczbę ramion` : ` – pręty górne i dolne nie leżą w tych samych pionach (ramiona ${hd.miss.join(', ')}) – rozmieść pręty równo lub ręcznie`)) });
    if (tor.on && +q.stir.hookA === 90 && q.stir.kind !== 'tors') add(sg, 'Thook', 'Skręcanie: strzemiona zamknięte hakami 135° lub zakładem (haki 90° niedopuszczalne)' + sfx, '9.2.3(1), rys. 9.6', 1, 0, '', { ratio: Infinity, status: 'fail', note: 'zmień kąt haków na 135° albo rodzaj strzemion na „na skręcanie (zakład)”' });
    if (tor.on && q.stir.kind === 'open') add(sg, 'Tclosed', 'Skręcanie: strzemiona muszą być zamknięte' + sfx, '9.2.3(1)', 1, 0, '', { ratio: Infinity, status: 'fail', note: 'zmień rodzaj strzemion na zamknięte (zakład lub haki 135°)' });
  });
  AT = null;

  anch.ends.forEach(a => (AT = a.e.key) && add(sg, 'FE', `Zbrojenie dolne na podporze skrajnej (${a.name}): F_E/f_yd ≤ A_s`, '9.2.1.4(2)', a.AsReq, a.AsProv, 'mm²', { note: `F_E = ${(a.FE / 1e3).toFixed(1)} kN, a_l = ${a.aL.toFixed(0)} mm` }));
  AT = null;
  if (tor.on) {
    add(sg, 'T631', 'Skręcanie: T_Ed/T_Rd,c + V_Ed/V_Rd,c (≤ 1 → tylko zbrojenie minimalne)', '6.3.2(5)', tor.cond631, 1, '', { status: tor.cond631 <= 1 ? 'ok' : 'info', ratio: tor.cond631 <= 1 ? tor.cond631 : 0, note: tor.cond631 <= 1 ? 'zbrojenie minimalne wystarcza' : 'wymagane zbrojenie obliczeniowe na skręcanie' });
    add(sg, 'Tst', 'Skręcanie + ścinanie: Asw/s jednej gałęzi (strefa s₁)', '6.3.2(3)', tor.legReq1, tor.legProv1, 'mm²/mm', { rel: '≥', fmt: 3 });
    const surplus = Math.max(0, tor.surplusBot) + Math.max(0, tor.surplusTop);
    add(sg, 'Tl', 'Skręcanie: dodatkowe zbrojenie podłużne (góra+dół) ΣA_sl,TB', '6.3.2(3)', 2 * tor.AslTB, surplus, 'mm²', { rel: '≥', soft: true, note: `ΣA_sl = ${tor.AslReq.toFixed(0)} mm²` });
    add(sg, 'Tside', 'Skręcanie: zbrojenie podłużne przy każdym boku (pręty boczne)', '6.3.2(3), 9.2.3(4)', tor.AslSide, S.reb.mid.n * area(S.reb.mid.d), 'mm²', { rel: '≥', soft: true, note: S.reb.mid.n ? `${S.reb.mid.n}⌀${S.reb.mid.d} przy każdym boku` : 'dodaj pręty boczne (w połowie wysokości)' });
  }
  R.flanges.forEach(f => {
    AT = f.sec.key;
    const s = multi ? ` (${f.sec.loc})` : '';
    add(sg, 'fl1', 'Ścinanie półka–środnik: v_Ed ≤ v_Rd,max (krzyżulce w półce)' + s, '6.2.4(4)', f.vEd, f.vRdmax, 'MPa', { note: `cotθ_f = ${f.cot.toFixed(2)}, Δx = ${(f.dx / 1000).toFixed(2)} m` });
    add(sg, 'fl2', 'Ścinanie półka–środnik: zbrojenie poprzeczne półki A_sf/s_f' + s, '6.2.4(4)', f.AsfReq * 1000, f.AsfProv * 1000, 'mm²/m', { rel: '≥', note: f.vEd <= f.vLim ? `v_Ed ≤ 0,4·f_ctd = ${f.vLim.toFixed(2)} MPa – zbrojenie nie jest wymagane obliczeniowo` : '' });
  });
  // --- SGU naprężenia i rysy
  AT = null;
  const sgu = 'SGU – naprężenia', sgr = 'SGU – zarysowanie';
  const nmS = sec => multi ? sec.loc : (sec.kind === 'span' ? 'przęsło' : (md.sups.filter(p => p.sec).length > 1 ? sec.loc : 'podpora'));
  secs.forEach(sec => {
    AT = sec.key;
    const r = sec.sls; if (!r || r.Mk <= 0) return;
    const k1 = S.coef.k1, k2 = S.coef.k2, k3 = S.coef.k3, nm = nmS(sec), zz = r.biax ? ' (zginanie ukośne)' : '';
    add(sgu, 'sck', `σ_c (kombinacja charakterystyczna, ${nm}) ≤ k₁·f_ck${zz}`, '7.2(2)', r.sc_k, k1 * m.fck, 'MPa', sls.k1lim ? {} : { soft: true, status: r.sc_k <= k1 * m.fck ? 'ok' : 'info', note: 'wymagane dla klas XD, XF, XS – tu informacyjnie' });
    if (S.sls.phiSel !== 'off') add(sgu, 'scqp', `σ_c (kombinacja quasi-stała, ${nm}) ≤ k₂·f_ck (pełzanie liniowe)`, '7.2(3)', r.sc_qp, k2 * m.fck, 'MPa', { soft: true, note: r.sc_qp > k2 * m.fck ? 'uwzględniono pełzanie nieliniowe 3.1.4(4)' : '' });   // pełzanie pominięte – warunek liniowości pełzania nie dotyczy
    add(sgu, 'ssk', `σ_s (kombinacja charakterystyczna, ${nm}) ≤ k₃·f_yk${zz}`, '7.2(5)', r.ss_k, k3 * m.fyk, 'MPa');
  });
  secs.forEach(sec => {
    AT = sec.key;
    const r = sec.sls; if (!r || r.Mk <= 0) return;
    const nm = nmS(sec);
    add(sgr, 'ascr', `Zbrojenie minimalne ze względu na rysy (${nm}) A_s ≥ A_s,min`, '7.3.2(2)', r.asmin.As, r.AsProv, 'mm²', { rel: '≥' });
    add(sgr, 'wk', `Szerokość rys w_k (${nm}) ≤ w_max`, '7.3.4', r.w.wk, sls.wmax, 'mm', { fmt: 3, note: r.crackedQP ? `s_r,max = ${r.w.sr.toFixed(0)} mm, σ_s = ${r.w.ss.toFixed(0)} MPa` + (r.biaxQP ? ' (zginanie ukośne)' : '') : 'M_qp < M_cr – przekrój niezarysowany' });
  });
  // --- SGU ugięcia
  const sgd = 'SGU – ugięcia';
  const dfl = sls.defl;
  dfl.spans.forEach(ds => {
    AT = 'd' + ds.seg.idx;
    const sfx = multi ? ` – ${ds.label}` : '';
    const Lref = ds.lim * S.sls.lim, w0max = Lref / 250;
    // odwrotna strzałka w₀ (7.4.1(4)): kompensuje ugięcie od obciążeń quasi-stałych (wygląd, ogólna użytkowalność, L/250…L/400); w₀ ≤ L/250;
    // przy ugięciu granicznym L/500 (ugięcie po wykonaniu elementów wrażliwych, 7.4.1(5)) strzałka nie zmniejsza ugięcia
    const cOwn = (S.sls.camberSeg || {})[ds.seg.idx], cSel = cOwn !== undefined ? cOwn : S.sls.camber;       // strzałka w tym odcinku albo ogólna
    ds.camberOwn = cOwn !== undefined;
    ds.camber = cSel === 'auto' ? Math.min(Math.floor(w0max / 5) * 5, Math.max(0, Math.floor(ds.tot.f / 5) * 5)) : +cSel > 0 ? Math.min(+cSel, ds.tot.f > 0 ? Infinity : 0) : 0;
    ds.w0max = w0max; ds.camberUse = ds.camber > 0 && S.sls.lim < 500;
    if (ds.camber > 0) add(sgd, 'w0', `Odwrotna strzałka (podniesienie deskowania) w₀ ≤ L/250${sfx}`, '7.4.1(4)', ds.camber, w0max, 'mm', { note: ds.camberUse ? 'ugięcie od obciążeń quasi-stałych skompensowane podniesieniem deskowania' : `przy L/${S.sls.lim} (7.4.1(5) – ugięcie po wykonaniu elementów wrażliwych) strzałka nie zmniejsza ugięcia` });
    if (ds.camberUse) {
      add(sgd, 'f', `Ugięcie długotrwałe po kompensacji f − w₀ ≤ L/${S.sls.lim}${sfx}`, '7.4.1(4), 7.4.3', ds.tot.f - ds.camber, ds.lim, 'mm', { note: `f = ${ds.tot.f.toFixed(1)} mm (obciążenie ${ds.load.f.toFixed(1)} + skurcz ${ds.cs.toFixed(1)}) − w₀ = ${ds.camber.toFixed(0)} mm` });
      return;
    }
    add(sgd, 'f', `Ugięcie długotrwałe (quasi-stałe + skurcz) f ≤ L/${S.sls.lim}${sfx}`, '7.4.1(4), 7.4.3', ds.tot.f, ds.lim, 'mm', { note: `od obciążenia ${ds.load.f.toFixed(1)} mm + od skurczu ${ds.cs.toFixed(1)} mm` + (ds.seg.kind !== 'span' ? '; wspornik: L_ref = 2·l' : '') + (dfl.patterned ? '; obciążenie zmienne na przęsłach naprzemiennych' : '') });
  });
  dfl.spans.forEach(ds => {
    AT = 'd' + ds.seg.idx;
    const ld = ds.ld; if (!ld || !isFinite(ld.lim)) return;
    add(sgd, 'ld', `Uproszczone: L/d ≤ (L/d)_lim (informacyjnie)${multi ? ' – ' + ds.label : ''}`, '7.4.2', ld.act, ld.lim, '', { soft: true, status: ld.act <= ld.lim ? 'ok' : 'info', note: `K = ${ld.K}; jeśli niespełnione – decyduje obliczenie dokładne` });
  });
  (dfl.z || []).forEach(dz => {
    AT = 'd' + dz.seg.idx;
    if (dz.f < 1e-3) return;
    add(sgd, 'fz', `Ugięcie poziome (Z) f_z ≤ L/${S.sls.lim}${multi ? ' – ' + dz.label : ''}`, '7.4.1(4) (kierunek Z)', dz.f, dz.lim, 'mm', { soft: true, note: 'kombinacja charakterystyczna (E_cm) + część długotrwała (E_c,eff); przekrój z interpolacją ζ' });
  });
  // --- zakotwienia
  AT = null;
  const sga = 'Zakotwienia i zakłady';
  anch.ends.forEach(a => {
    AT = a.e.key;
    if (!a.bent) add(sga, 'lbd', `Zakotwienie prętów dolnych za licem podpory (${a.name}) l_bd ≤ t − c_nom`, '9.2.1.4(3), 8.4.4', a.lbd, a.avail, 'mm', { note: `pręty proste, σ_sd = ${a.sig.toFixed(0)} MPa` });
    else {
      add(sga, 'lbd', `Zakotwienie prętów dolnych za licem podpory (${a.name}) – pręty odgięte: l_bd ≤ długość rozwinięta`, '9.2.1.4(3), 8.4.4', a.lbdHook, a.s0 + a.arc + Math.min(a.legV, Math.max(0, a.legMax - a.rIn - a.dia)), 'mm',
        { note: `prosty ${a.s0.toFixed(0)} + łuk ${a.arc.toFixed(0)} + pionowy ${a.legV.toFixed(0)} mm; odgięcie do góry ${a.leg} mm (wymiar zewn.), φ_m = ${a.phm} mm (α₁ = ${a.rh.al1.toFixed(2)})` + (a.okBent ? '' : `; odgięcie > ${a.legMax.toFixed(0)} mm – nie mieści się w wysokości belki`) });
      add(sga, 'phm', `Średnica trzpienia przy odgięciu (${a.name}) φ_m ≥ φ_m,min`, '8.3(2), 8.3(3)', Math.max(a.phmMin, a.phmReq), a.phm, 'mm', { rel: '≥', note: `tab. 8.1N: ${a.dia <= 16 ? '4' : '7'}⌀ = ${a.phmMin} mm; miażdżenie betonu (8.3(3)): F_bt = ${(a.Fbt / 1e3).toFixed(1)} kN, a_b = ${a.ab.toFixed(0)} mm → ${a.phmReq.toFixed(0)} mm` });
    }
  });
  (anch.endsTop || []).forEach(a => {
    AT = 'p' + a.sup.idx;
    if (!a.bent) add(sga, 'lbdT', `Zakotwienie prętów górnych w podporze sztywnej (${a.name}) l_bd ≤ t − c_nom`, '8.4.4, 9.2.1.2', a.lbd, a.avail, 'mm', { note: `pręty proste, σ_sd = ${a.sig.toFixed(0)} MPa` });
    else {
      add(sga, 'lbdT', `Zakotwienie prętów górnych w podporze sztywnej (${a.name}) – pręty odgięte w dół: l_bd ≤ długość rozwinięta`, '8.4.4, 9.2.1.2', a.lbdHook, a.s0 + a.arc + a.legV, 'mm', { note: `prosty ${a.s0.toFixed(0)} + łuk ${a.arc.toFixed(0)} + pionowy ${a.legV.toFixed(0)} mm; odgięcie w dół (w podporę) ${a.leg} mm, φ_m = ${a.phm} mm` });
      add(sga, 'phm', `Średnica trzpienia przy odgięciu prętów górnych (${a.name}) φ_m ≥ φ_m,min`, '8.3(2), 8.3(3)', Math.max(a.phmMin, a.phmReq), a.phm, 'mm', { rel: '≥', note: `tab. 8.1N: ${a.dia <= 16 ? '4' : '7'}⌀ = ${a.phmMin} mm; 8.3(3): ${a.phmReq.toFixed(0)} mm` });
    }
  });
  anch.inner.forEach(q => (AT = 'p' + q.sup.idx) && add(sga, 'inner', `Pręty dolne na podporze pośredniej (${q.sup.name}): zakotwienie ≥ 10⌀ = ${q.l.toFixed(0)} mm za licem`, '9.2.1.5(1)', 0, 0, '', { status: 'info', ratio: 0, note: S.anch.innerB === 'anch' ? 'pręty dolne każdego przęsła zakończone ≥ 10⌀ za licem podpory (bez zakładu); do podpory doprowadzone ≥ 25% prętów przęsła, nie mniej niż 2 szt. (9.2.1.4(1), 9.2.1.5(1))' : 'pręty z sąsiednich przęseł łączone na zakład l₀ nad podporą (ciągłość zbrojenia dolnego, 9.2.1.5(3))' }));
  // zestawienie prętów: długość ≤ L_max (z odgięciami), zakłady nad podporami pośrednimi, ręczne odgięcia, haki strzemion
  let schC = null; try { schC = steelSchedule(R); } catch (e) { schC = null; }
  R.sched = schC;
  if (schC) (schC.laps || []).filter(l => l.man).forEach(l => { AT = 'bar' + (l.key || ''); add(sga, 'lapMan', `Zakład ustawiony ręcznie (x = ${(l.c / 1000).toFixed(2)} m): l₀ ≥ l₀,wymagane`, '8.7.3', l.l0req, l.l0, 'mm', { rel: '≥', note: 'położenie i długość zakładu zmienione ręcznie w wyciągu pręta' }); });
  if (schC) {
    const LmaxC = S.anch.Lmax > 0 ? S.anch.Lmax * 1000 : Infinity;
    (schC.short || []).forEach(q => { const r = schC.rows.find(z => z.key === q.key); AT = 'bar' + q.key;
      add(sga, 'lenMan', `Długość pręta${r ? ` poz. ${r.pos} (${r.name.replace(/, odcinek.*$/, '')})` : ''} przyjęta ręcznie ≥ wymagana z zakotwienia i zasięgu zbrojenia`, '8.4.4, 9.2.1.3', q.need / 1000, q.got / 1000, 'm', { rel: '≥', note: 'pręt skrócony ręcznie nie sięga do wymaganego zakotwienia (za licem podpory / poza punkt odcięcia) – wydłuż pręt albo przywróć wymiar automatyczny' }); });
    schC.rows.filter(r => r.overMax).forEach(r => { AT = r.key ? 'bar' + r.key : null; add(sga, 'Lmax', `Długość pręta poz. ${r.pos} (${r.name}) l ≤ L_max`, '—', r.len / 1000, LmaxC / 1000, 'm', { note: 'długość rozwinięta: odcinek prosty + odgięcia' + (r.man ? '; wymiary zmienione ręcznie – skróć pręt lub dodaj zakład' : '') }); });
    md.sups.filter(p => !p.end && p.segL !== null && p.segR !== null).forEach(p => {
      const rl = schC.rows.find(r => r.side === 'bot' && r.seg === p.segL && !r.cut && (r.npc ? r.piece === r.npc - 1 : true));
      const rr = schC.rows.find(r => r.side === 'bot' && r.seg === p.segR && !r.cut && (r.piece || 0) === 0);
      if (!rl || !rr) return;
      const stp = (schC.steps || []).find(q => (q.R && q.R.sup === p) || (q.L && q.L.sup === p));
      if (stp) {
        const deep = stp.R && stp.R.sup === p ? rl : rr, shal = deep === rl ? rr : rl, sd = deep === rl ? 'R' : 'L', leg = deep['leg' + sd];
        const lbdS = (anch.rows.find(z => z.side === 'bot' && z.dBar === shal.d) || anch.rows.find(z => z.side === 'bot') || { lbd: 40 * shal.d }).lbd;
        const extS = deep === rl ? p.x - shal.x0 : shal.x1 - p.x;
        AT = 'p' + p.idx;
        add(sga, 'stepB', `Uskok belki nad podporą (${p.name}): pręty dolne przęsła płytszego przedłużone za oś ≥ l_bd`, '8.4.4, 9.2.1.5', lbdS, extS, 'mm', { rel: '≥', note: `pręty płytszego przęsła w betonie przęsła głębszego; pręty przęsła głębszego (h = ${md.segs[deep.seg].g.h} mm) zakończone przy licu uskoku i odgięte do góry o ${leg} mm` });
        add(sga, 'stepL', `Uskok belki nad podporą (${p.name}): odgięcie prętów dolnych przęsła głębszego ≥ 10⌀`, '9.2.1.5(1), rys. 9.4', 10 * deep.d, leg || 0, 'mm', { rel: '≥', note: 'pręty nie mogą wyjść poza obrys płytszego przęsła – odgięte do góry przy licu uskoku' });
        return;
      }
      const ds = [rl.d, rr.d], l0r = Math.max(...ds.map(d => { const q = anch.rows.find(z => z.side === 'bot' && z.dBar === d) || anch.rows.find(z => z.side === 'bot'); return q ? q.l0 : 50 * d; }));
      AT = 'p' + p.idx;
      if (S.anch.innerB === 'anch') {
        const tf = p.t / 2, eL = rl.x1 - (p.x - tf), eR = (p.x + tf) - rr.x0, gL = 10 * rl.d / Math.max(eL, 1), gR = 10 * rr.d / Math.max(eR, 1), lft = gL >= gR;
        add(sga, 'inner10', `Pręty dolne na podporze pośredniej (${p.name}): zakotwienie za licem ≥ 10⌀ (⌀${lft ? rl.d : rr.d}, przęsło ${lft ? 'lewe' : 'prawe'})`, '9.2.1.5(1), rys. 9.4', 10 * (lft ? rl.d : rr.d), lft ? eL : eR, 'mm', { rel: '≥', note: `przęsło lewe ${eL.toFixed(0)} mm, prawe ${eR.toFixed(0)} mm za licem; pręty nie łączone na zakład nad podporą` });
        return;
      }
      add(sga, 'lapB', `Zakład prętów dolnych nad podporą pośrednią (${p.name}) l ≥ l₀`, '8.7.3, 9.2.1.5', l0r, rl.x1 - rr.x0, 'mm', { rel: '≥', note: `pręty z obu przęseł zachodzą na siebie symetrycznie względem osi podpory` + (rl.man || rr.man ? '; wymiary zmienione ręcznie' : '') });
    });
    const doneL = new Set();
    schC.rows.filter(r => r.side === 'bot' && (r.manL || r.manR)).forEach(r => [['L', r.manL, r.legL], ['R', r.manR, r.legR]].forEach(([sd, man, lg]) => {
      if (!man || doneL.has(r.seg + sd)) return; doneL.add(r.seg + sd);
      const a = anch.ends.find(q => q.e.seg.idx === r.seg && q.side === sd); if (!a || !a.bent) return;
      AT = a.e.key;
      add(sga, 'legMan', `Odgięcie prętów dolnych przyjęte ręcznie (${a.name}) ≥ wymagane z zakotwienia`, '8.4.4, 9.2.1.4(3)', a.leg, lg, 'mm', { rel: '≥' });
    }));
    const doneH = new Set();
    md.segs.forEach(sg => { const q = sg.stir; if (!(q.hook > 0) || doneH.has(q)) return; doneH.add(q); const ss = stirSet(q, sg.g, cov, sg.hold && sg.hold.xs); AT = 'st' + sg.idx; add(sga, 'hook', `Haki strzemion 135° przyjęte ręcznie${multi ? ` (${sg.label})` : ''} ≥ max(5⌀; 50 mm)`, '8.5 (rys. 8.5)', ss.extMin, ss.ext, 'mm', { rel: '≥', note: `zalecane ${ss.extAuto} mm (10⌀, ≥ 70 mm)` }); });
  }
  (anch.topCut || []).forEach(tc => tc.sides.forEach(sd => {
    if (!sd.manual && !(sd.ext < -1e-6)) return;
    AT = 'p' + tc.sup.idx;
    add(sga, 'topLen', `Pręty górne dodatkowe – ${tc.sup.name}, ${sd.side === 'L' ? 'w lewo' : 'w prawo'}: długość od osi ≥ wymagana`, '9.2.1.3, 9.2.1.2(1)', sd.lenReq / 1000, sd.len / 1000, 'm', { rel: '≥', note: (sd.manual ? 'długość przyjęta ręcznie' : `pręt skrócony ręcznie o ${Math.round(-sd.ext)} mm`) + (sd.len > sd.lenReq + 1 ? ' (przedłużenie)' : '') });
  }));
  anch.rows.forEach(r => (AT = 'r' + r.name) && add(sga, 'lap', `${r.name}: l_bd = ${r.lbd.toFixed(0)} mm, zakład l₀ = ${r.l0.toFixed(0)} mm`, '8.4.4, 8.7.3', 0, 0, '', { status: 'info', ratio: 0, note: `przyczepność ${r.bond === 'good' ? 'dobra' : 'średnia'}, f_bd = ${r.fbd.toFixed(2)} MPa, α₆ = ${anch.alpha6}` }));
  AT = null;
  // --- pożar
  if (R.fire) {
    const f = R.fire, sf = `Odporność ogniowa ${f.R} (EN 1992-1-2, tab. ${f.cont ? '5.6' : '5.5'})`;
    add(sf, 'fb', 'Szerokość belki b ≥ b_min', 'EN 1992-1-2 5.6', f.bmin, f.b, 'mm', { rel: '≥' });
    if (f.amin !== null) add(sf, 'fa', 'Odległość osiowa zbrojenia a ≥ a_min' + (multi ? ` (${f.seg.label})` : ''), 'EN 1992-1-2 5.6', f.amin, f.am, 'mm', { rel: '≥' });
    if (f.needAsd && f.amin !== null) add(sf, 'fasd', 'Odległość osiowa prętów narożnych a_sd ≥ a + 10 mm', 'EN 1992-1-2 5.6.3', f.asdReq, f.asd, 'mm', { rel: '≥' });
    if (g.T) add(sf, 'fbw', 'Grubość środnika b_w ≥ b_w,min (klasa WA)', 'EN 1992-1-2 5.6', f.bwMin, g.bw, 'mm', { rel: '≥' });
  }
}

/* ------------------------------------------- sytuacja wyjątkowa (6.11b) */
function accChecks(R, RA) {
  const grp = 'SGN – sytuacja wyjątkowa (PN-EN 1990, 6.11b)';
  const add = (id, name, ref, Ed, Rd, unit, opt) => {
    opt = opt || {};
    const ratio = opt.ratio !== undefined ? opt.ratio : (Rd > 0 ? Ed / Rd : (Ed > 0 ? Infinity : 0));
    R.checks.push({ grp, id: 'A_' + id, name, ref, Ed, Rd, unit, ratio, status: opt.status || (ratio <= 1 + 1e-6 ? 'ok' : 'fail'), rel: opt.rel || '≤', note: opt.note || '', fmt: opt.fmt });
  };
  const st = RA.st;
  const gnote = `γ_c = ${RA.m.gc}, γ_s = ${RA.m.gs}`;
  RA.secs.forEach(sec => {
    if (sec.MEd <= 0) return;
    add('M' + sec.key, `Zginanie – ${sec.loc} |M_Ed,A| ≤ M_Rd`, '6.1', sec.MEd / 1e6, sec.r ? sec.MRd / 1e6 : 0, 'kNm', sec.r ? { note: gnote } : { ratio: Infinity, status: 'fail', note: 'N_Ed,A poza zakresem nośności' });
    if (sec.biax && sec.biax.Mz > 1e3) add('B' + sec.key, `Zginanie ukośne (Y+Z) – ${sec.loc}`, '6.1 (zginanie ukośne)', sec.biax.u, 1, '');
  });
  if (st.NEd > 0) add('N', 'Ściskanie N_Ed,A ≤ N_Rd,max', '6.1', st.NEd / 1e3, RA.NRdMax / 1e3, 'kN');
  else if (st.NEd < 0) add('N', 'Rozciąganie |N_Ed,A| ≤ N_Rd,t', '6.1', -st.NEd / 1e3, -RA.NRdMin / 1e3, 'kN');
  RA.sh.ends.forEach(e => {
    const eP = R.sh.ends.find(x => x.key === e.key);
    add('Vmax' + e.key, `Krzyżulce betonowe (${e.name}) V_Ed,A ≤ V_Rd,max` + (RA.tor.on ? ' (z T_Ed,A)' : ''), '6.2.3(3)', RA.tor.on ? e.inter : e.V0 / 1e3, RA.tor.on ? 1 : e.VRdmax / 1e3, RA.tor.on ? '' : 'kN', { note: `cotθ = ${RA.sh.cot.toFixed(2)}` });
    add('Vs' + e.key, `Strzemiona s₁ (${e.name}) V_Ed,A ≤ V_Rd,s`, '6.2.3(3)', e.Vred / 1e3, e.VRds1 / 1e3, 'kN');
    if (eP && e.l1req > 0) add('l1' + e.key, `Długość strefy s₁ (${e.name}) ≥ wymagana w sytuacji wyjątkowej`, '6.2.3', e.l1req / 1000, eP.l1 / 1000, 'm', { rel: '≥' });
  });
  RA.anch.ends.forEach(a => add('FE' + a.e.key, `Zbrojenie dolne na podporze (${a.name}): F_E,A/f_yd ≤ A_s`, '9.2.1.4(2)', a.AsReq, a.AsProv, 'mm²'));
  if (RA.tor.on) add('T', 'Skręcanie + ścinanie: Asw/s jednej gałęzi (strefa s₁)', '6.3.2(3)', RA.tor.legReq1, RA.tor.legProv1, 'mm²/mm', { rel: '≥', fmt: 3 });
  RA.flanges.forEach(f => {
    add('fl1' + f.sec.key, `Ścinanie półka–środnik (${f.sec.loc}): v_Ed,A ≤ v_Rd,max`, '6.2.4(4)', f.vEd, f.vRdmax, 'MPa');
    add('fl2' + f.sec.key, `Ścinanie półka–środnik (${f.sec.loc}): A_sf/s_f`, '6.2.4(4)', f.AsfReq * 1000, f.AsfProv * 1000, 'mm²/m', { rel: '≥' });
  });
}

/* ----------------------------------------------------------- zestawienie stali */
function steelSchedule(R) {
  if (R.bare || !R.anch) return { rows: [], byD: {}, total: 0, Lb: R.md ? R.md.Ltot : 0, xL: 0, xR: R.md ? R.md.Ltot : 0, nSt: 0, lenSt: 0, vol: 0, laps: [], Lmax: Infinity, steps: [], short: [], bare: true };
  const S = R.S, g = R.g, md = R.md, rb = S.reb, h = g.h;
  // końce prętów podłużnych (czoło belki, lico uskoku – bez strzemion): otulina do powierzchni pręta ≥ max(c_nom (pręty główne); c_s + ⌀_w), c – do osi pręta
  const dswS = Math.max(...md.segs.map(sg => (sg.stir || S.stir).d)), dLmax = Math.max(12, ...md.segs.filter(sg => sg.Lb).flatMap(sg => sg.Lb.bars.map(b => b.dBar)), ...(R.LtM ? R.LtM.bars.map(b => b.dBar) : []));
  const cSurf = Math.max(R.cov.cnom_main || 0, R.cov.cs + dswS), c = Math.round(cSurf + dLmax / 2);
  const kgm = d => 0.00617 * d * d;
  const rows = [];
  const s0 = md.sups[0], sN = md.sups[md.sups.length - 1];
  const xL = s0 && s0.x < 1 ? -s0.t / 2 : 0;
  const xR = sN && sN.x > md.Ltot - 1 ? md.Ltot + sN.t / 2 : md.Ltot;
  const Lb = xR - xL;
  const multi = md.cont;
  // długość rozwinięta: wymiary zewnętrzne minus odliczenia na gięcie 90° (promień wewnętrzny r = φ_m/2)
  const dedOf = (r, d) => 2 * (r + d) - Math.PI * (r + d / 2) / 2;      // odliczenie na gięcie 90° (wymiary zewnętrzne → oś)
  const BE = S.barEdit || {};
  const manLap = key => { const e = BE[key]; return e && +e.lapC > 0 ? { c: +e.lapC * 1000, l: +e.lapL > 0 ? +e.lapL : 0 } : null; };
  const addRow = o => { o.legL = o.legL || 0; o.legR = o.legR || 0;
    const ded = r => dedOf(r, o.d);
    o.len = o.len !== undefined ? o.len : Math.round((o.x1 - o.x0) + o.legL + o.legR - (o.legL ? ded(o.rL || 0) : 0) - (o.legR ? ded(o.rR || 0) : 0));
    if (o.n > 0 && o.len > 0) rows.push(Object.assign(o, { tot: o.n * o.len / 1000, mass: o.n * o.len / 1000 * kgm(o.d) })); };
  // grupowanie prętów układu: warstwa → (⌀, wiązka, doprowadzony/skrócony)
  const groupsOf = (lay, filt) => {
    const m = new Map();
    lay.bars.filter(filt || (() => true)).forEach(b => { const k = [b.layer, b.dBar, b.nb, b.supp === false ? 0 : 1].join('|'); const q = m.get(k) || { layer: b.layer, d: b.dBar, nb: b.nb, supp: b.supp !== false, n: 0, e: b.e }; q.n += b.nb; m.set(k, q); });
    return Array.from(m.values()).sort((p, q) => p.layer - q.layer || q.d - p.d);
  };
  const nLay = lay => new Set(lay.bars.map(b => b.layer)).size;
  // zakłady prętów dłuższych od handlowej długości L_max – w miejscach najmniejszych momentów rozciągających dany pręt
  const st = R.st, Lmax = S.anch.Lmax > 0 ? S.anch.Lmax * 1000 : Infinity;
  const tensFn = side => side === 'none' ? (() => 0) : (x => { const k = st.kAt(clamp(x, 0, md.Ltot)); return side === 'top' ? Math.max(0, -st.MEdMin[k]) : Math.max(0, st.MEdMax[k]); });
  const l0Of = (side, ds) => Math.max(0, ...ds.map(d => { const r = R.anch.rows.find(q => q.side === side && q.dBar === d) || R.anch.rows.find(q => q.side === side); return r ? r.l0 : 50 * d; }));
  const laps = [];
  // eL / eR – długość rozwinięta odgięć na końcach (wliczana do L_max: pręt = odcinek prosty + odgięcia)
  const lapPlan = (x0, x1, side, l0, info, eL, eR, man) => {
    eL = eL || 0; eR = eR || 0;
    if (!(x1 - x0 + eL + eR > Lmax + 1) || !(l0 > 0)) return [];
    // zakład ustawiony ręcznie (środek x i długość) – pierwszy zakład pręta
    if (man && man.c > 0) { const lm = man.l > 0 ? man.l : l0, cc = clamp(man.c, x0 + lm / 2 + 100, x1 - lm / 2 - 100);
      if (cc - lm / 2 - x0 + eL <= Lmax + 1 && x1 - (cc - lm / 2) + eR <= Lmax + 1) { const lp = Object.assign({ c: Math.round(cc), a: Math.round(cc - lm / 2), b: Math.round(cc + lm / 2), l0: Math.round(lm), l0req: Math.round(l0), M: 0, side, man: true }, info || {}); laps.push(lp); return [lp]; } }
    const tf = tensFn(side), xsN = st.x.filter(x => x > x0 && x < x1), Mref = Math.max(1, ...xsN.map(tf));
    const cost = cc => { let mm = 0; for (let j = 0; j <= 8; j++) mm = Math.max(mm, tf(cc - l0 / 2 + l0 * j / 8)); return mm; };
    const out = []; let start = x0, guard = 0, eS = eL;
    while (x1 - start + eS + eR > Lmax + 1 && guard++ < 40) {
      const lo = start + l0 / 2 + 300, hi = Math.min(start + Lmax - eS - l0 / 2, x1 - l0 / 2 - 300);
      if (hi <= lo) break;
      const cand = []; for (let i = 0; i <= 80; i++) cand.push(lo + (hi - lo) * i / 80);
      xsN.forEach(x => { if (x >= lo && x <= hi) cand.push(x); });
      const cs = cand.map(cc => [cc, cost(cc)]), mn = Math.min(...cs.map(q => q[1]));
      const cc = Math.max(...cs.filter(q => q[1] <= mn + 0.02 * Mref).map(q => q[0]));
      const lp = Object.assign({ c: Math.round(cc), a: Math.round(cc - l0 / 2), b: Math.round(cc + l0 / 2), l0: Math.round(l0), M: cost(cc), side }, info || {});
      out.push(lp); laps.push(lp); start = lp.a; eS = 0;
    }
    return out;
  };
  // ręczna zmiana odcinka prostego: koniec przy krawędzi belki zostaje, drugi się przesuwa; pręt wewnątrz belki – symetrycznie
  const shorts = [];                                // pręty skrócone ręcznie poniżej długości wymaganej (zakotwienie / zasięg)
  const applyLen = (x0, x1, e) => {
    if (!e || !(e.len > 0)) return [x0, x1];
    const L = e.len, atL = x0 <= xL + c + 1, atR = x1 >= xR - c - 1;
    let a, b;
    if (atL && !atR) { a = x0; b = x0 + L; } else if (atR && !atL) { b = x1; a = x1 - L; } else { const m = (x0 + x1) / 2; a = m - L / 2; b = m + L / 2; }
    if (a < xL + c) { b += xL + c - a; a = xL + c; } if (b > xR - c) { a -= b - (xR - c); b = xR - c; }
    const r = [Math.max(xL + c, a), Math.min(xR - c, b)];
    if (r[1] - r[0] < x1 - x0 - 1) shorts.push({ e, need: x1 - x0, got: r[1] - r[0] });
    return r;
  };
  // ręczne przedłużenie (+) / skrócenie (−) końców pręta (e.dL, e.dR [mm]) – w granicach belki (otulina czoła), pręt ≥ 200 mm
  const endAdj = (x0, x1, e) => { if (!e || (!e.dL && !e.dR)) return [x0, x1];
    let a = x0 - (+e.dL || 0), b = x1 + (+e.dR || 0); a = Math.max(xL + c, a); b = Math.min(xR - c, b);
    if (b - a < 200) { if (e.dL && !e.dR) a = b - 200; else if (e.dR && !e.dL) b = a + 200; else { const mm = (a + b) / 2; a = mm - 100; b = mm + 100; } }
    return [a, b]; };
  // odgięcie: automatyczne (zakotwienie) albo ręczne (e.legL / e.legR; 0 – pręt prosty)
  const legOf = (e, side, auto, rAuto, dirAuto, d) => {
    const man = e && e['leg' + side] !== '' && e['leg' + side] !== undefined;
    const leg = man ? +e['leg' + side] : auto, r = leg > 0 ? (man && !(auto > 0) ? mandrelMin(d) / 2 : rAuto || mandrelMin(d) / 2) : 0;
    return { leg, r, dir: (e && e['dir' + side]) || dirAuto, man, ext: leg > 0 ? leg - dedOf(r, d) : 0 };
  };
  // zakład prętów dolnych nad podporą pośrednią: pręty z obu przęseł zachodzą na siebie na długości l₀ (symetrycznie względem osi), nie mniej niż 10⌀ za lico
  const lapInner = p => { const ds = [p.segL, p.segR].filter(i => i !== null).map(i => md.segs[i]).filter(q => q && q.Lb).flatMap(q => q.Lb.bars.filter(b => b.supp !== false).map(b => b.dBar)); return l0Of('bot', ds.length ? ds : [16]); };
  const piecesOf = (x0, x1, lp) => { const out = []; let a = x0; lp.forEach(l => { out.push([a, l.b]); a = l.a; }); out.push([a, x1]); return out; };
  // pręty dolne
  const cov0b = R.cov.cb !== undefined ? R.cov.cb : c, steps = [];
  // pręty dolne ciągłe przez podpory pośrednie (opcja „bez podziału”): kolejne przęsła o tym samym zbrojeniu dolnym i wysokości, bez przegubu
  const sig = q => q.Lb ? q.Lb.bars.filter(b => b.supp !== false).map(b => [b.layer, b.dBar, b.nb].join(':')).sort().join(',') + '|' + q.g.h : '';
  const chainNext = {}, inChain = new Set();
  if (S.anch.innerB === 'cont') md.segs.forEach(q => { const p = q.supR; if (!q.reb || !p || p.end || p.hinge || p.segR === null) return; const n = md.segs[p.segR]; if (!n || !n.reb || n.kind !== 'span' || q.kind !== 'span') return; if (sig(q) && sig(q) === sig(n) && !(BE['b' + q.idx] && BE['b' + q.idx].len) && !(BE['b' + n.idx] && BE['b' + n.idx].len)) { chainNext[q.idx] = n.idx; inChain.add(n.idx); } });
  const chainEnd = q => { let z = q; while (chainNext[z.idx] !== undefined) z = md.segs[chainNext[z.idx]]; return z; };
  md.segs.forEach(sg => {
    if (inChain.has(sg.idx)) return;                       // przęsło objęte prętami ciągłymi z przęsła poprzedniego
    const sgE = chainEnd(sg), chained = sgE !== sg;
    const lay = sg.Lb, sfx = multi ? ` – ${chained ? `przęsła ${sg.label.replace('przęsło ', '')}–${sgE.label.replace('przęsło ', '')} (ciągłe)` : sg.label}` : '';
    const dB = sg.LbS.dmax;
    const endAnch = side => (R.anch.ends || []).find(a => a.e.seg === sg && a.side === side);
    // uskok belki nad podporą pośrednią (różne wysokości przęseł, górna krawędź wspólna):
    //  – przęsło głębsze: pręty dolne kończą się przy licu uskoku (oś podpory − otulina) i są odgięte do góry w głąb przekroju,
    //  – przęsło płytsze: pręty dolne przedłużone w przęsło głębsze (wewnątrz betonu) o max(l₀/2; l_bd) za oś podpory
    const yB0 = sg.g.h - (lay.layers && lay.layers[0] ? lay.layers[0].e : cov0b + 20);
    const nbOf = (sup, side) => { if (!sup || sup.end) return null; const ni = side === 'L' ? sup.segL : sup.segR; return ni === null || ni === undefined ? null : md.segs[ni] || null; };
    const stepOf = (sup, side) => { const nb = nbOf(sup, side); if (!nb || !(nb.g.h < sg.g.h - 1) || yB0 + dB / 2 <= nb.g.h - cov0b + 1) return null;
      const yN = nb.Lb && nb.Lb.layers && nb.Lb.layers[0] ? nb.g.h - nb.Lb.layers[0].e : nb.g.h - cov0b - 20;
      const legMax = Math.max(5 * dB, yB0 - R.cov.ct - 60);
      return { x: sup.x + (side === 'R' ? 1 : -1) * sup.t / 2, nb, leg: Math.round(Math.min(legMax, ceilTo(Math.max(yB0 - yN, 0) + 10 * dB, 10))), dy: yB0 - yN, sup }; };
    const deeper = (sup, side) => { const nb = nbOf(sup, side); return nb && nb.g.h > sg.g.h + 1 && (nb.g.h - (nb.Lb && nb.Lb.layers[0] ? nb.Lb.layers[0].e : 50)) + dB / 2 > sg.g.h - cov0b + 1 ? nb : null; };
    const lbdB = (R.anch.rows.find(q => q.side === 'bot' && q.dBar === dB) || R.anch.rows.find(q => q.side === 'bot') || { lbd: 40 * dB }).lbd;
    const stL = stepOf(sg.supL, 'L'), stR = chained ? null : stepOf(sg.supR, 'R');
    const ext = sup => Math.max(lapInner(sup) / 2, lbdB);
    const anchIn = S.anch.innerB === 'anch', l10 = ceilTo(10 * dB, 10);
    let xa0 = sg.supL ? (sg.supL.end ? sg.x0 - sg.supL.t / 2 + c : deeper(sg.supL, 'L') ? sg.x0 - ext(sg.supL) : anchIn ? sg.x0 + sg.supL.t / 2 - l10 : Math.min(sg.x0 - lapInner(sg.supL) / 2, sg.x0 + sg.supL.t / 2 - 10 * dB)) : sg.x0 + c;
    let xb0 = sg.supR ? (sg.supR.end ? sg.x1 + sg.supR.t / 2 - c : deeper(sg.supR, 'R') ? sg.x1 + ext(sg.supR) : anchIn ? sg.x1 - sg.supR.t / 2 + l10 : Math.max(sg.x1 + lapInner(sg.supR) / 2, sg.x1 - sg.supR.t / 2 + 10 * dB)) : sg.x1 - c;
    if (chained) { const p = sgE.supR; xb0 = p ? (p.end ? sgE.x1 + p.t / 2 - c : Math.max(sgE.x1 + lapInner(p) / 2, sgE.x1 - p.t / 2 + 10 * dB)) : sgE.x1 - c; }
    if (stL) xa0 = stL.x + c; if (stR) xb0 = stR.x - c;
    const key = 'b' + sg.idx, e = BE[key];
    let [xa, xb] = applyLen(Math.max(xL + c, xa0), Math.min(xR - c, xb0), e);
    const axa = xa, axb = xb;                                // położenie końców bez ręcznego przedłużenia / skrócenia
    [xa, xb] = endAdj(xa, xb, e);
    if (stL) xa = Math.max(xa, stL.x + c); if (stR) xb = Math.min(xb, stR.x - c);      // pręt nie może wyjść poza beton przęsła głębszego
    const aL = endAnch('L'), aR = chained ? (R.anch.ends || []).find(a => a.e.seg === sgE && a.side === 'R') : endAnch('R');
    const gL = legOf(e, 'L', stL ? stL.leg : aL && aL.bent ? aL.leg : 0, aL && aL.bent ? aL.rIn : 0, 'up', dB), gR = legOf(e, 'R', stR ? stR.leg : aR && aR.bent ? aR.leg : 0, aR && aR.bent ? aR.rIn : 0, 'up', dB);
    if (stL || stR) steps.push({ seg: sg, L: stL, R: stR });
    const cut = (R.anch.botCut || []).find(q => q.seg === sg);
    const ml = nLay(lay) > 1;
    const lpB = lapPlan(xa, xb, 'bot', l0Of('bot', lay.bars.filter(b => b.supp !== false).map(b => b.dBar)), { seg: sg.idx, key }, gL.ext, gR.ext, manLap(key)), pcB = piecesOf(xa, xb, lpB);
    groupsOf(lay).forEach(q => {
      const nm = `Zbrojenie dolne${sfx}${ml ? `, warstwa ${q.layer + 1}` : ''}${q.supp ? (sg.cut ? ' (do podpór)' : '') : ' (skrócone)'}`;
      const bL = j => j === 0 && gL.leg > 0, bR = j => j === pcB.length - 1 && gR.leg > 0;
      if (q.supp) pcB.forEach(([u, v], j) => addRow({ autoX0: axa, autoX1: axb, name: nm + (pcB.length > 1 ? `, odcinek ${j + 1}/${pcB.length}` : ''), d: q.d, n: q.n, x0: u, x1: v, y: sg.g.h - q.e, side: 'bot', layer: q.layer, legL: bL(j) ? gL.leg : 0, legR: bR(j) ? gR.leg : 0, rL: bL(j) ? gL.r : 0, rR: bR(j) ? gR.r : 0, dirL: gL.dir, dirR: gR.dir, seg: sg.idx, piece: j, npc: pcB.length, key, man: !!e, manL: bL(j) && gL.man, manR: bR(j) && gR.man }));
      else addRow({ name: nm, d: q.d, n: q.n, x0: cut ? cut.start : xa, x1: cut ? cut.end : xb, y: sg.g.h - q.e, side: 'bot', layer: q.layer, seg: sg.idx, cut: true });
    });
  });
  // pręty górne ciągłe (przy podporach sztywnych skrajnych – odgięte w dół w podporę)
  const topEnd = side => (R.anch.endsTop || []).find(a => a.side === side);
  const tL = topEnd('L'), tR = topEnd('R');
  const eT = BE.t, dT = Math.max(12, ...R.LtM.bars.map(b => b.dBar));
  const [atx0, atx1] = applyLen(xL + c, xR - c, eT), [xt0, xt1] = endAdj(atx0, atx1, eT);
  const mlT = nLay(R.LtM) > 1;
  const gTL = legOf(eT, 'L', tL && tL.bent ? tL.leg : 0, tL && tL.bent ? tL.rIn : 0, 'down', dT), gTR = legOf(eT, 'R', tR && tR.bent ? tR.leg : 0, tR && tR.bent ? tR.rIn : 0, 'down', dT);
  const lpT = lapPlan(xt0, xt1, 'top', l0Of('top', R.LtM.bars.map(b => b.dBar)), { key: 't' }, gTL.ext, gTR.ext, manLap('t')), pcT = piecesOf(xt0, xt1, lpT);
  groupsOf(R.LtM).forEach(q => pcT.forEach(([u, v], j) => addRow({ autoX0: atx0, autoX1: atx1, name: `Zbrojenie górne ciągłe${mlT ? `, warstwa ${q.layer + 1}` : ''}${pcT.length > 1 ? `, odcinek ${j + 1}/${pcT.length}` : ''}`, d: q.d, n: q.n, x0: u, x1: v, y: q.e, side: 'top', layer: q.layer,
    legL: j === 0 ? gTL.leg : 0, legR: j === pcT.length - 1 ? gTR.leg : 0, rL: j === 0 ? gTL.r : 0, rR: j === pcT.length - 1 ? gTR.r : 0, dirL: gTL.dir, dirR: gTR.dir, piece: j, npc: pcT.length, key: 't', man: !!eT, manL: j === 0 && gTL.man, manR: j === pcT.length - 1 && gTR.man })));
  // pręty górne dodatkowe nad podporami
  (R.anch.topCut || []).forEach(tc => {
    const p = tc.sup, sl = tc.sides.find(z => z.side === 'L'), sr = tc.sides.find(z => z.side === 'R');
    const key = 'x' + p.idx, e = BE[key];
    // przedłużenie / skrócenie: nad podporą pośrednią belki ciągłej – w długości od osi (Δ w cont.rebSupps, sprawdzenie topLen); w pozostałych – Δ końca
    const ax0 = sl.none ? xL + c : Math.max(xL + c, p.x - (sl.ext ? sl.len - sl.ext : sl.len)), ax1 = sr.none ? xR - c : Math.min(xR - c, p.x + (sr.ext ? sr.len - sr.ext : sr.len));
    let [x0, x1] = applyLen(sl.none ? xL + c : Math.max(xL + c, p.x - sl.len), sr.none ? xR - c : Math.min(xR - c, p.x + sr.len), e);
    { const e2 = e ? { dL: !multi || sl.none ? e.dL : 0, dR: !multi || sr.none ? e.dR : 0 } : null, r0x = [x0, x1]; [x0, x1] = endAdj(x0, x1, e2); if (x1 - x0 < r0x[1] - r0x[0] - 1) shorts.push({ key, need: r0x[1] - r0x[0], got: x1 - x0 }); }
    const ta = p.end && p.type === 'fix' ? (R.anch.endsTop || []).find(a => a.sup === p) : null;
    const dX = Math.max(12, ...p.LtX.bars.map(b => b.dBar));
    const gXL = legOf(e, 'L', sl.none && ta && ta.bent ? ta.leg : 0, sl.none && ta && ta.bent ? ta.rIn : 0, 'down', dX), gXR = legOf(e, 'R', sr.none && ta && ta.bent ? ta.leg : 0, sr.none && ta && ta.bent ? ta.rIn : 0, 'down', dX);
    const lpX = lapPlan(x0, x1, 'top', l0Of('top', p.LtX.bars.map(b => b.dBar)), { sup: p.idx, key }, gXL.ext, gXR.ext, manLap(key)), pcX = piecesOf(x0, x1, lpX);
    groupsOf(p.LtX).forEach(q => pcX.forEach(([u, v], j) => addRow({ autoX0: ax0, autoX1: ax1, name: `Zbrojenie górne dodatkowe – ${p.name}${nLay(p.LtX) > 1 ? `, warstwa ${q.layer + 1}` : ''}${pcX.length > 1 ? `, odcinek ${j + 1}/${pcX.length}` : ''}`, d: q.d, n: q.n, x0: u, x1: v, y: q.e, side: 'top', layer: q.layer, sup: p.idx,
      legL: j === 0 ? gXL.leg : 0, legR: j === pcX.length - 1 ? gXR.leg : 0, rL: j === 0 ? gXL.r : 0, rR: j === pcX.length - 1 ? gXR.r : 0, dirL: gXL.dir, dirR: gXR.dir, piece: j, npc: pcX.length, key, man: !!e, manL: j === 0 && gXL.man, manR: j === pcX.length - 1 && gXR.man })));
  });
  // pręty boczne
  if (rb.mid.n > 0 && md.segs[0].mid.length) {
    if (!R.gVar) {
      const ys = Array.from(new Set(md.segs[0].mid.map(b => Math.round(b.y))));
      const lpM = lapPlan(xL + c, xR - c, 'none', l0Of('mid', [rb.mid.d]), { mid: true }), pcM = piecesOf(xL + c, xR - c, lpM);
      ys.forEach((y, i) => pcM.forEach(([u, v], j) => addRow({ name: `Pręty boczne${ys.length > 1 ? `, rząd ${i + 1}` : ''} (przy obu bokach)${pcM.length > 1 ? `, odcinek ${j + 1}/${pcM.length}` : ''}`, d: rb.mid.d, n: 2, x0: u, x1: v, y, side: 'mid', layer: i, piece: j, npc: pcM.length })));
    } else md.segs.forEach(sg => {          // różne wysokości przęseł – pręty boczne w każdym przęśle osobno (zakotwione za licami)
      const ys = Array.from(new Set(sg.mid.map(b => Math.round(b.y)))), l0m = l0Of('mid', [rb.mid.d]);
      const fits = (sup, side, y) => { if (!sup || sup.end) return true; const ni = side === 'L' ? sup.segL : sup.segR, nb = ni === null || ni === undefined ? null : md.segs[ni]; return !nb || y + rb.mid.d / 2 <= nb.g.h - cov0b - 1; };
      ys.forEach((y, i) => {
      const u = sg.supL ? (sg.supL.end ? sg.x0 - sg.supL.t / 2 + c : fits(sg.supL, 'L', y) ? sg.x0 - l0m / 2 : sg.x0 - sg.supL.t / 2 + c) : sg.x0 + c, v = sg.supR ? (sg.supR.end ? sg.x1 + sg.supR.t / 2 - c : fits(sg.supR, 'R', y) ? sg.x1 + l0m / 2 : sg.x1 + sg.supR.t / 2 - c) : sg.x1 - c;
      const lpS = lapPlan(u, v, 'none', l0m, { mid: true }), pcS = piecesOf(u, v, lpS);
      pcS.forEach(([a1, b1], j) => addRow({ name: `Pręty boczne – ${sg.label}${ys.length > 1 ? `, rząd ${i + 1}` : ''} (przy obu bokach)${pcS.length > 1 ? `, odcinek ${j + 1}/${pcS.length}` : ''}`, d: rb.mid.d, n: 2, x0: a1, x1: b1, y, side: 'mid', layer: i, seg: sg.idx, piece: j, npc: pcS.length }));
      });
    });
  }
  // strzemiona (od lica podpór) – grupy odcinków o tych samych strzemionach i przekroju
  const zones = R.stirZones || stirrupZones(R);
  const grpSt = new Map();
  zones.forEach(z => {
    const sg = z.seg, set = stirSet(sg.stir, sg.g, R.cov, sg.hold && sg.hold.xs), key = [sg.stir.kind, sg.stir.d, sg.stir.legs, set.B, set.H, set.pieces.map(pc => pc.B).join(',')].join('|');
    const q = grpSt.get(key) || { set, stir: sg.stir, n: 0, segs: [] }; q.n += z.n; q.segs.push(sg); grpSt.set(key, q);
  });
  let nSt = 0, lenSt = 0;
  const PCN = { closed: 'zamknięte', tors: 'zamknięte na skręcanie (zakład)', inner: 'wewnętrzne zamknięte', pin: 'szpilki', open: 'otwarte (U)' };
  grpSt.forEach(q => {
    const sfx = grpSt.size > 1 ? ` – ${q.segs.map(sg => sg.label).join(', ')}` : '';
    if (!nSt) { nSt = q.n; lenSt = q.set.pieces[0].len; }
    q.set.pieces.forEach(pc => addRow({ name: `Strzemiona ${q.set.legs}-cięte, ${PCN[pc.type]}${sfx}`, d: q.set.d, n: q.n * pc.n, len: pc.len, side: pc.type === 'pin' || pc.type === 'inner' ? 'stir2' : 'stir', shape: pc, set: q.set, segs: q.segs.map(sg => sg.idx) }));
  });
  if (R.surf && R.surf.req && R.surf.gov) addRow({ name: 'Siatka przypowierzchniowa – pręty podłużne', d: S.surf.d, n: Math.floor(R.surf.gov.per / S.surf.s + 1), x0: xt0, x1: xt1, side: 'surf' });
  // pręty odgięte na ścinanie (45°): odcinek ukośny + zakotwienia: w strefie rozciąganej 1,3·l_bd, w ściskanej 0,7·l_bd (8.4.1, 9.2.1.3)
  ((R.sh && R.sh.ends) || []).forEach(e => { if (!e.bent) return; const sg = e.seg, hs = sg.g.h - R.cov.cb - R.cov.ct - 2 * sg.stir.d - e.bent.d;
    const row = (R.anch.rows || []).find(q => q.side === 'bot' && q.dBar === e.bent.d), lbd = row ? row.lbd : 40 * e.bent.d;
    addRow({ name: `Pręty odgięte 45° (ścinanie) – ${e.name}`, d: e.bent.d, n: e.bent.n * e.bent.ng, len: Math.round(hs * Math.SQRT2 + 2 * lbd), side: 'bent', bent: { hs, lbd, e: e.key } }); });
  const byD = {};
  rows.forEach((r, i) => { r.pos = i + 1; byD[r.d] = (byD[r.d] || 0) + r.mass; r.overMax = r.side !== 'stir' && r.side !== 'stir2' && r.len > Lmax + 1; });
  const total = rows.reduce((a, r) => a + r.mass, 0);
  const short = shorts.map(q => ({ key: q.key || Object.keys(BE).find(k => BE[k] === q.e), need: q.need, got: q.got })).filter(q => q.key);
  return { rows, byD, total, Lb, xL, xR, nSt, lenSt, vol: g.Ac * Lb / 1e9, laps, Lmax, steps, short };
}
// rozmieszczenie strzemion między licami: odstęp pierwszego strzemienia od lica e ∈ [10; 50] mm (lub podany),
// strefy od lica podpór: s₁ (długość l1), strefa pośrednia s_p (długość lp), część środkowa – rozstaw równy, możliwie bliski s₂ (≤ s₂),
// najlepiej okrągły (co 5 mm); wynik: położenia strzemion i odcinki stref (parts: x0, x1, rozstaw, liczba odstępów)
function layStirrups(a0, b0, o) {
  const s1 = o.s1, s2 = o.s2, sp = o.sp > s1 && o.sp < s2 ? o.sp : 0;
  const cand = [];
  const rng = r => { const out = []; for (let v = Math.ceil(r[0]); v <= Math.floor(r[1]) + 1e-9; v++) out.push(v); return out.length ? out : [r[0]]; };
  const symm = o.supL && o.supR && o.rL[0] === o.rR[0] && o.rL[1] === o.rR[1] && o.l1L === o.l1R && (o.lpL || 0) === (o.lpR || 0);
  const EL = rng(o.rL), ER = rng(o.rR);
  const pairs = symm ? EL.map(e => [e, e]) : EL.flatMap(eL => ER.map(eR => [eL, eR]));
  const mid = (o.rL[0] + o.rL[1]) / 2;
  const tier = v => Math.abs(v / 5 - Math.round(v / 5)) < 1e-6 ? 0 : Math.abs(v - Math.round(v)) < 1e-6 ? 1 : 2;
  pairs.forEach(([eL, eR]) => {
    const xA = a0 + eL, xB = b0 - eR, D0 = xB - xA;
    if (D0 <= 0) { const xc = (a0 + b0) / 2; cand.push({ eL, eR, xs: [xc], n: 1, score: [1, 0, 0], nL: 0, nR: 0, sm: 0, xA: xc, xB: xc, uniform: true, parts: [], npL: 0, npR: 0 }); return; }
    const nL = o.l1L > 0 ? Math.max(1, Math.ceil((o.l1L - eL) / s1 - 1e-9)) : 0;
    const nR = o.l1R > 0 ? Math.max(1, Math.ceil((o.l1R - eR) / s1 - 1e-9)) : 0;
    let npL = sp && o.lpL > 0 ? Math.max(1, Math.ceil((a0 + o.l1L + o.lpL - (xA + nL * s1)) / sp - 1e-9)) : 0;
    let npR = sp && o.lpR > 0 ? Math.max(1, Math.ceil((xB - nR * s1 - (b0 - o.l1R - o.lpR)) / sp - 1e-9)) : 0;
    let xs = [], sm, uniform = false, nm, parts = [];
    const pushP = (x0, x1, s, n) => { if (n > 0 && x1 > x0 + 1e-6) parts.push({ x0, x1, s, n }); };
    if ((nL + nR) * s1 >= D0 - 1e-6 || s1 >= s2) {
      const sl = (nL + nR) > 0 ? Math.min(s1, s2) : s2;
      nm = Math.max(1, Math.ceil(D0 / sl - 1e-9)); sm = D0 / nm; uniform = true; npL = npR = 0;
      for (let i = 0; i <= nm; i++) xs.push(xA + i * sm);
      pushP(xA, xB, sm, nm);
    } else {
      if ((nL + nR) * s1 + (npL + npR) * sp >= D0 - 1e-6) { npL = npR = 0; }       // strefy pośrednie się nie mieszczą – część środkowa z rozstawem ≤ s_p
      const D = D0 - (nL + nR) * s1 - (npL + npR) * sp;
      const sMid = sp && !(npL + npR) && (o.lpL > 0 || o.lpR > 0) ? sp : s2;
      nm = Math.max(1, Math.ceil(D / sMid - 1e-9)); sm = D / nm;
      for (let i = 0; i < nL; i++) xs.push(xA + i * s1);
      const p0 = xA + nL * s1;
      for (let i = 0; i < npL; i++) xs.push(p0 + i * sp);
      const m0 = p0 + npL * sp;
      for (let i = 0; i <= nm; i++) xs.push(m0 + i * sm);
      const q0 = m0 + nm * sm;
      for (let i = 1; i <= npR; i++) xs.push(q0 + i * sp);
      const r0 = q0 + npR * sp;
      for (let i = 1; i <= nR; i++) xs.push(r0 + i * s1);
      pushP(xA, p0, s1, nL); pushP(p0, m0, sp, npL); pushP(m0, q0, sm, nm); pushP(q0, r0, sp, npR); pushP(r0, xB, s1, nR);
    }
    cand.push({ eL, eR, xs, n: xs.length, nL, nR, npL, npR, sm, nm, xA, xB, uniform, parts, score: [xs.length, tier(sm), Math.abs(eL - mid) + Math.abs(eR - mid)] });
  });
  cand.sort((p, q) => p.score[0] - q.score[0] || p.score[1] - q.score[1] || p.score[2] - q.score[2]);
  const c = cand[0];
  c.sp = sp;
  c.zEndL = c.uniform ? (o.l1L > 0 ? c.xB : c.xA) : c.xA + c.nL * s1 + c.npL * sp;
  c.zStartR = c.uniform ? (o.l1R > 0 ? c.xA : c.xB) : c.xB - c.nR * s1 - c.npR * sp;
  c.z1EndL = c.uniform ? c.zEndL : c.xA + c.nL * s1; c.z1StartR = c.uniform ? c.zStartR : c.xB - c.nR * s1;
  return c;
}
function stirrupZones(R) {
  const S = R.S, md = R.md, c = R.cov.cs !== undefined ? R.cov.cs : R.cov.cnom;
  const eMan = S.stir.e0 === '' ? null : clamp(num(S.stir.e0, 30), 0, 50);
  const rSup = eMan === null ? [10, 50] : [eMan, eMan];
  const out = [];
  md.segs.forEach(sg => {
    const q = sg.stir || S.stir, s1 = q.s1, s2 = q.s2, eFree = c + q.d / 2;
    const endL = R.sh.ends.find(e => e.seg === sg && e.side === 'L'), endR = R.sh.ends.find(e => e.seg === sg && e.side === 'R');
    const a0 = sg.supL ? sg.x0 + sg.supL.t / 2 : sg.x0, b0 = sg.supR ? sg.x1 - sg.supR.t / 2 : sg.x1;
    if (b0 - a0 < 20) return;
    const l1L = endL ? endL.l1 : 0, l1R = endR ? endR.l1 : 0, lpL = endL ? endL.lp || 0 : 0, lpR = endR ? endR.lp || 0 : 0;
    const z = layStirrups(a0, b0, { s1, s2, sp: q.sp || 0, l1L, l1R, lpL, lpR, supL: !!sg.supL, supR: !!sg.supR, rL: sg.supL ? rSup : [eFree, eFree], rR: sg.supR ? rSup : [eFree, eFree] });
    out.push({ seg: sg, a: z.xA, b: z.xB, xs: z.xs, n: z.xs.length, l1L, l1R, lpL, lpR, zEndL: sg.supL ? z.zEndL : -Infinity, zStartR: sg.supR ? z.zStartR : Infinity,
      eL: sg.supL ? z.eL : null, eR: sg.supR ? z.eR : null, sm: z.sm, nm: z.nm, nL: z.nL, nR: z.nR, npL: z.npL, npR: z.npR, sp: z.sp, parts: z.parts, uniform: z.uniform, auto: eMan === null });
  });
  return out;
}
// przekrój poprzeczny w dowolnym miejscu x (rzeczywiste zbrojenie w tym miejscu) – do podglądu z widoku podłużnego
function sectionAt(R, x) {
  const S = R.S, md = R.md, st = R.st, m = R.m, c = R.cov.cnom;
  x = clamp(x, 0, md.Ltot);
  const sg = segAt(md, x);
  const inS = md.sups.find(p => Math.abs(x - p.x) <= p.t / 2);
  const g = inS ? inS.g : sg.g, h = g.h;
  // dolne: skrócone pręty tylko w swoim zasięgu
  const bc = ((R.anch && R.anch.botCut) || []).find(q => q.seg === sg);
  const botFull = !sg.cut || (bc && x >= bc.start - 1 && x <= bc.end + 1);
  const lb = botFull ? sg.Lb : sg.LbS;
  // górne: dodatkowe pręty nad podporą w zasięgu długości od osi
  let tc = null, best = Infinity;
  ((R.anch && R.anch.topCut) || []).forEach(q => {
    const p = q.sup, sl = q.sides.find(z => z.side === 'L'), sr = q.sides.find(z => z.side === 'R');
    const a = p.x - (sl.none ? p.t / 2 : sl.len), b = p.x + (sr.none ? p.t / 2 : sr.len);
    if (x >= a - 1 && x <= b + 1 && Math.abs(x - p.x) < best) { best = Math.abs(x - p.x); tc = q; }
  });
  // przekrój nad podporą o innej geometrii niż odcinek – układ prętów z przekroju podporowego
  const lbX = inS && inS.g !== sg.g ? inS.LbS : lb;
  const lt = tc ? tc.sup.LtS : (inS ? inS.gSeg.Lt : sg.Lt);
  const mid = midBars(g, R.cv || c, (sg.stir || S.stir).d, S.reb.mid, lbX, lt);
  const bars = [...sideBars(lbX, 'bot', h), ...sideBars(lt, 'top', h), ...mid];
  const NEd = st.NEd;
  const uS = makeULS(g.partsS, h, bars, m), uH = makeULS(g.partsH, h, flipBars(bars, h), m);
  const rS = uS.MRd(NEd), rH = uH.MRd(NEd);
  const k = st.kAt(x);
  const Mp = Math.max(0, st.MEdMax[k]), Mn = Math.max(0, -(st.MEdMinR || st.MEdMin)[k]);
  const MRdP = rS ? rS.M : 0, MRdN = rH ? rH.M : 0;
  const etaP = MRdP > 0 ? Mp / MRdP : (Mp > 0 ? Infinity : 0), etaN = MRdN > 0 ? Mn / MRdN : (Mn > 0 ? Infinity : 0);
  const neg = Mn > 1e3 && etaN >= etaP;
  const tens = neg ? lt : lbX, comp = neg ? lbX : lt;
  // strzemiona w tym miejscu
  const z = stirrupZones(R).find(q => q.seg === sg);
  let sw = null;
  if (z && z.xs.length > 1 && x >= z.xs[0] - 1 && x <= z.xs[z.xs.length - 1] + 1) {
    let i = 0; while (i < z.xs.length - 1 && z.xs[i + 1] < x) i++;
    sw = { s: z.xs[Math.min(i + 1, z.xs.length - 1)] - z.xs[i], inZone: x <= z.zEndL + 1 || x >= z.zStartR - 1 };
  }
  const inSupp = md.sups.find(p => Math.abs(x - p.x) <= p.t / 2);
  return { kind: neg ? 'supp' : 'span', x, seg: sg, sup: tc ? tc.sup : null, key: 'at', loc: `x = ${(x / 1000).toFixed(2).replace('.', ',')} m – ${sg.label}`,
    bars, barsO: neg ? flipBars(bars, h) : bars, parts: neg ? g.partsH : g.partsS, tens, comp, d: tens.n ? h - tens.eC : 0,
    r: neg ? rH : rS, MRd: neg ? MRdN : MRdP, MEd: neg ? Mn : Mp, MEdPos: Mp, MEdNeg: Mn, MRdPos: MRdP, MRdNeg: MRdN, etaPos: etaP, etaNeg: etaN,
    V: st.Vat(x), T: st.TEdAbs ? st.TEdAbs[Math.min(st.TEdAbs.length - 1, 2 * Math.max(0, k - 1))] : 0, sw, inSupp: inSupp || null, botFull, topExtra: !!tc, mid, g, stir: sg.stir };
}
const dsw0 = S => S.stir.d / 2;

const API = { hasVal, calc, autoReb, clearReb, chooseBars, spanFails, dimFails, designAllPrep, allBad, minClsOf, classIdx, segEdge, suggestDims, verifyDims, designDims, ETA_IDS, mandrelMin, devLen, stirSet, stirLegs, STIR_KIND, feTorsion, feSups, mechanism, SUP_DOF, sectionAt, layStirrups, layoutZone, midBars, sideBars, subLayout, zoneOf, normZone, zoneBars, SUP_NAME, SUP_DEF, defaultState, normalize, materials, coverCalc, VAR_KINDS, psiOf, normItem, normPt, hasLoad, loadLayout, absX, makeMesh, beamModel, stirrupZones, unitOf, makeBiax, elasticBiax, rotatedParts,
  CONCRETE, CONC_NAMES, STEEL, STEEL_LIST, BAR_DIAS, EXPOSURES, EXP_DESC,
  PSI, IMP_EC1, SCHEMES, WMAX, MIN_CLASS, CMIN_DUR, FIRE_SS, FIRE_CONT, area, num, steelSchedule, feSolve, makeULS, cracked, uncracked, designBending };
if (typeof module !== 'undefined' && module.exports) module.exports = API;
root.EC2 = API;
})(typeof window !== 'undefined' ? window : globalThis);
