// weryfikacja statyki (MES 2D) z rozwiązaniami analitycznymi – node tests/statyka.js
const E = require('../web/engine.js');
const q = 10, P = 50;                                 // kN/m, kN
let bad = 0, n = 0;
const near = (a, b, tol, msg) => { n++; const ok = Math.abs(a - b) <= tol * Math.max(1, Math.abs(b)); if (!ok) { bad++; console.log('✖', msg, a.toFixed(3), '≠', b.toFixed(3)); } else console.log('✔', msg, a.toFixed(3)); };
function run(f) {
  const s = E.defaultState(); s.loads.sw = false; s.loads.gG = 1; s.loads.comb = '610'; s.loads.redM = false; s.geom.t = 0; s.stir.redV = false;
  s.loads.perm = [{ name: 'G', q: 0, span: 0, x1: '', x2: '', pts: [] }]; s.loads.var = [];
  f(s); const R = E.calc(s); if (R.errors.length) throw new Error(R.errors.join('; '));
  const st = R.st, M = k => st.MEdMax[k] / 1e6, Mn = k => st.MEdMin[k] / 1e6, kAt = x => st.kAt(x * 1000);
  return { R, st, Mmax: Math.max(...st.MEdMax) / 1e6, Mmin: Math.min(...st.MEdMin) / 1e6, Vmax: Math.max(...st.Vabs) / 1e3, reac: st.reac ? st.reac.G.map(v => v / 1e3) : null, M, Mn, kAt };
}
const L = 6;
// 1. belka swobodnie podparta – obciążenie równomierne: M = qL²/8, V = qL/2
let r = run(s => { s.scheme = 'ss'; s.geom.L = L; s.loads.perm[0].q = q; });
near(r.Mmax, q * L * L / 8, 0.005, 'ss q: M_max = qL²/8'); near(r.Vmax, q * L / 2, 0.005, 'ss q: V_max = qL/2');
// 2. swobodnie podparta – siła w środku: M = PL/4
r = run(s => { s.scheme = 'ss'; s.geom.L = L; s.loads.perm[0].pts = [{ P, a: L / 2, ref: 'L' }]; });
near(r.Mmax, P * L / 4, 0.005, 'ss P: M_max = PL/4'); near(r.Vmax, P / 2, 0.005, 'ss P: V = P/2');
// 3. siła w 1/3: M = P·a·b/L
r = run(s => { s.scheme = 'ss'; s.geom.L = L; s.loads.perm[0].pts = [{ P, a: 2, ref: 'L' }]; });
near(r.Mmax, P * 2 * 4 / L, 0.005, 'ss P(a=2): M = Pab/L');
// 4. obustronnie utwierdzona: M_podp = −qL²/12, M_przęsło = qL²/24
r = run(s => { s.scheme = 'ff'; s.geom.L = L; s.loads.perm[0].q = q; });
near(r.Mmin, -q * L * L / 12, 0.005, 'ff q: M_podp = −qL²/12'); near(r.Mmax, q * L * L / 24, 0.01, 'ff q: M_przęsło = qL²/24');
// 5. utwierdzona-przegubowa: M_utw = −qL²/8, M_przęsło = 9qL²/128
r = run(s => { s.scheme = 'pf'; s.geom.L = L; s.loads.perm[0].q = q; });
near(r.Mmin, -q * L * L / 8, 0.005, 'pf q: M_utw = −qL²/8'); near(r.Mmax, 9 * q * L * L / 128, 0.01, 'pf q: M_max = 9qL²/128');
// 6. wspornik: M = −qL²/2, V = qL
r = run(s => { s.scheme = 'cant'; s.geom.L = 2.5; s.loads.perm[0].q = q; });
near(r.Mmin, -q * 2.5 * 2.5 / 2, 0.005, 'cant q: M = −qL²/2'); near(r.Vmax, q * 2.5, 0.005, 'cant q: V = qL');
// 7. belka ciągła 2 × L: M_B = −qL²/8, R_B = 1,25qL, R_A = 0,375qL
r = run(s => { s.scheme = 'cont'; s.cont.spans = [L, L]; s.loads.perm[0].q = q; });
near(r.Mmin, -q * L * L / 8, 0.005, 'cont2 q: M_B = −qL²/8');
if (r.reac) { near(r.reac[1], 1.25 * q * L, 0.005, 'cont2 q: R_B = 1,25qL'); near(r.reac[0], 0.375 * q * L, 0.005, 'cont2 q: R_A = 0,375qL'); }
// 8. belka ciągła 3 × L: M_B = −0,1qL², M_przęsła skrajnego = 0,08qL², środkowego = 0,025qL²
r = run(s => { s.scheme = 'cont'; s.cont.spans = [L, L, L]; s.loads.perm[0].q = q; });
near(r.Mmin, -0.1 * q * L * L, 0.005, 'cont3 q: M_B = −0,1qL²'); near(r.Mmax, 0.08 * q * L * L, 0.01, 'cont3 q: M_1 = 0,08qL²');
near(r.M(r.kAt(1.5 * L)), 0.025 * q * L * L, 0.03, 'cont3 q: M_2 = 0,025qL²');
// 9. równowaga: suma reakcji = suma obciążeń (belka ciągła z siłą i obciążeniem na odcinku)
r = run(s => { s.scheme = 'cont'; s.cont.spans = [5, 7, 4]; s.loads.perm[0].q = q; s.loads.perm.push({ name: 'P', q: 0, span: 2, x1: '', x2: '', pts: [{ P, a: 3, ref: 'L' }] }, { name: 'q2', q: 8, span: 3, x1: 1, x2: 3, pts: [] }); });
if (r.reac) near(r.reac.reduce((a, b) => a + b, 0), q * 16 + P + 8 * 2, 0.002, 'równowaga ΣR = ΣF');
// 10. obciążenie trójkątne? – brak (wersja 2.8: obciążenia równomierne na odcinkach); ciężar własny 25 kN/m³
r = run(s => { s.scheme = 'ss'; s.geom.L = L; s.loads.sw = true; s.geom.b = 300; s.geom.h = 600; });
near(r.Mmax, 25 * 0.3 * 0.6 * L * L / 8, 0.005, 'ss ciężar własny: M = γbhL²/8');
// 11. obciążenie trójkątne 0 → q: R_A = qL/6, R_B = qL/3, M_max = qL²/(9√3)
r = run(s => { s.scheme = 'ss'; s.geom.L = L; Object.assign(s.loads.perm[0], { shape: 't', q: 0, q2: q }); });
near(r.Mmax, q * L * L / (9 * Math.sqrt(3)), 0.003, 'trójkąt: M_max = qL²/(9√3)'); if (r.reac) { near(r.reac[0], q * L / 6, 0.003, 'trójkąt: R_A = qL/6'); near(r.reac[1], q * L / 3, 0.003, 'trójkąt: R_B = qL/3'); }
// 12. trójkąt symetryczny (0 – q – 0): M_max = qL²/12
r = run(s => { s.scheme = 'ss'; s.geom.L = L; Object.assign(s.loads.perm[0], { shape: 'p', q: 0, prof: `0:0; ${L / 2}:${q}; ${L}:0` }); });
near(r.Mmax, q * L * L / 12, 0.003, 'trójkąt symetryczny: M = qL²/12');
// 13. trapez q → 2q: R_A = 4qL/6·… (R_A = qL/2 + qL/6, R_B = qL/2 + qL/3)
r = run(s => { s.scheme = 'ss'; s.geom.L = L; Object.assign(s.loads.perm[0], { shape: 't', q, q2: 2 * q }); });
if (r.reac) { near(r.reac[0], q * L / 2 + q * L / 6, 0.003, 'trapez: R_A'); near(r.reac[1], q * L / 2 + q * L / 3, 0.003, 'trapez: R_B'); }
// 14. obciążenie odchylone od pionu o α = 30°: M_y = cos α·qL²/8, M_z = sin α·qL²/8
r = run(s => { s.scheme = 'ss'; s.geom.L = L; Object.assign(s.loads.perm[0], { q, ang: 30 }); });
near(r.Mmax, Math.cos(Math.PI / 6) * q * L * L / 8, 0.003, 'α = 30°: M_y = cos α·qL²/8'); near(Math.max(...r.st.MzEd) / 1e6, 0.5 * q * L * L / 8, 0.003, 'α = 30°: M_z = sin α·qL²/8');
console.log(`\n${n - bad}/${n} zgodnych`); process.exit(bad ? 1 : 0);
