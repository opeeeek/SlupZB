/* BelkaŻB – raport obliczeniowy (notka) */
(function () {
'use strict';
const BZR = window.BZR = {};
// raport uproszczony: dane podstawowe, schemat, wykresy, zbiorcze SGN i SGU z najważniejszymi sprawdzeniami, uproszczone sprawdzenie zbrojenia
BZR.buildSimple = function (R, S) {
  const U = window.BZ, E = window.EC2;
  const { fmt, sym, esc } = U;
  const m = R.m, g = R.g, st = R.st, cov = R.cov, md = R.md, multi = md.cont;
  const f = (v, d) => fmt(v, d === undefined ? 2 : d);
  const cap = t => t ? t[0].toUpperCase() + t.slice(1) : t;
  let hn = 0; const H2 = t => `<h2>${++hn}. ${t}</h2>`;
  const line = (t, ref) => `<div class="eq">${t}${ref ? `<span class="r">[${ref}]</span>` : ''}</div>`;
  const stl = c => `<span class="${c.status}">${c.status === 'ok' ? '✔' : c.status === 'warn' ? '⚠' : c.status === 'fail' ? '✖' : 'ℹ'}</span>`;
  const ckLine = c => line(`${sym(c.name)}: ${U.ckCond(c)}${c.status !== 'info' && isFinite(c.ratio) ? `, η = ${f(c.ratio * 100, 0)}%` : ''} ${stl(c)}`, c.ref);
  const C = R.checks, by = re => C.filter(c => re.test(c.grp) && c.status !== 'info');
  const worst = list => list.reduce((a, c) => (!a || (isFinite(c.ratio) ? c.ratio : 9) > (isFinite(a.ratio) ? a.ratio : 9) ? c : a), null);
  const sum = (title, list) => { const nF = list.filter(c => c.status === 'fail').length, nW = list.filter(c => c.status === 'warn').length, w = worst(list.filter(c => /^SG[NU]/.test(c.grp)));
    return line(`<b>${title}</b>: ${list.length} sprawdzeń – ${nF ? `<span class="fail">niespełnione: ${nF}</span>` : '<span class="ok">wszystkie spełnione</span>'}${nW ? `, uwagi: ${nW}` : ''}${w && isFinite(w.ratio) ? `; największe wykorzystanie η = ${f(w.ratio * 100, 0)}% (${sym(w.name.replace(/ ≤.*$| ≥.*$/, ''))})` : ''}`); };
  const sch = E.SCHEMES[S.scheme] || E.SCHEMES.ss;
  let o = '';
  /* 1. dane */
  o += H2('Dane podstawowe');
  const geoTxt = gg => gg.T ? `teowy b<sub>w</sub>×h = ${gg.bw}×${gg.h} mm, b<sub>eff</sub> = ${f(gg.beff, 0)} mm, h<sub>f</sub> = ${gg.hf} mm` : `b×h = ${gg.bw}×${gg.h} mm`;
  o += line(`Schemat: ${esc(sch.name)}${multi ? ` – ${md.segs.filter(q => q.kind === 'span').length} przęsła` : ''}; rozpiętości: ${md.segs.map(q => `${esc(q.label)} ${f(q.L / 1000, 2)} m`).join(', ')}`);
  o += line(`Przekrój: ${R.gVar ? md.segs.map(q => `${esc(q.label)}: ${geoTxt(q.g)}`).join('; ') : geoTxt(g)}`);
  o += line(`Beton ${S.mat.concrete}: f<sub>ck</sub> = ${f(m.fck, 0)} MPa, f<sub>cd</sub> = ${f(m.fcd, 2)} MPa, f<sub>ctm</sub> = ${f(m.fctm, 2)} MPa, E<sub>cm</sub> = ${f(m.Ecm / 1000, 0)} GPa`);
  o += line(`Stal ${esc(m.st.name)}: f<sub>yk</sub> = ${m.fyk} MPa, f<sub>yd</sub> = ${f(m.fyd, 1)} MPa; strzemiona f<sub>ywd</sub> = ${f(m.fywd, 1)} MPa`);
  o += line(`Otulina do strzemion: ${cov.faces ? `dół ${cov.cb}, góra ${cov.ct}, boki ${cov.cs} mm` : `c<sub>nom</sub> = ${cov.cnom} mm`} (klasa ekspozycji ${cov.exps.join(', ')})`);
  R.secs.forEach(sec => { o += line(`Zbrojenie – ${esc(sec.loc)}: rozciągane ${sec.tens.desc} (${f(sec.tens.A, 0)} mm²)${sec.comp && sec.comp.n ? `, ściskane ${sec.comp.desc} (${f(sec.comp.A, 0)} mm²)` : ''}`); });
  const KIND = { closed: 'zamknięte', pins: 'zamknięte + szpilki', open: 'otwarte (U)', tors: 'na skręcanie' };
  o += line(`Strzemiona: ${[...new Set(md.segs.map(q => `⌀${q.stir.d} ${q.stir.legs}-cięte ${KIND[q.stir.kind] || ''}, s₁ = ${q.stir.s1}${q.stir.sp ? ` / s_p = ${q.stir.sp}` : ''} / s₂ = ${q.stir.s2} mm`))].join('; ')}`);
  /* 2. schemat */
  o += H2('Schemat statyczny i obciążenia');
  if (!st.manual) o += `<div class="fig">${U.schemeSVG(900)}</div>`;
  /* 3. wykresy */
  o += H2('Wykresy sił wewnętrznych, reakcje i ugięcia');
  try {
    const cd = U.chartsData();
    o += `<div class="fig">${U.lineChart(Object.assign(cd.M, { W: 900, H: 210 }))}${U.lineChart(Object.assign(cd.V, { W: 900, H: 190 }))}${U.lineChart(Object.assign(cd.N, { W: 900, H: cd.N.zero ? 110 : 150 }))}</div>`;
    if (U.reactionsSVG && st.reac) o += `<div class="fig">${U.reactionsSVG(900)}</div>`;
    o += `<div class="fig">${U.lineChart(Object.assign(cd.D, { W: 900, H: 190 }))}</div>`;
  } catch (e) { /* */ }
  /* 4. SGN */
  o += H2('Stan graniczny nośności (SGN)');
  const sgn = by(/^SGN/);
  o += sum('SGN – zbiorczo', sgn);
  o += `<h3>Zginanie</h3>` + C.filter(c => c.id === 'Mspan' || c.id === 'Msupp' || c.id === 'biax').map(ckLine).join('');
  o += `<h3>Ścinanie</h3>` + C.filter(c => c.id === 'Vmax' || c.id === 'Vs1').map(ckLine).join('');
  o += line(`Redukcja siły poprzecznej wg 6.2.1(8): ${S.stir.redV ? 'uwzględniona tam, gdzie dopuszczalna (obciążenie górą, podparcie bezpośrednie)' : 'nie uwzględniona'}`);
  o += `<h3>Ściskanie</h3>`;
  const cN = C.find(c => c.id === 'N');
  o += cN ? ckLine(cN) : line('N<sub>Ed</sub> = 0 – ściskanie osiowe nie występuje (nośność przekroju sprawdzono przy zginaniu).');
  if (st.TEd > 0) o += `<h3>Skręcanie</h3>` + C.filter(c => /^T/.test(c.id) && /ścinanie/.test(c.grp)).map(ckLine).join('');
  /* 5. SGU */
  o += H2('Stan graniczny użytkowalności (SGU)');
  const sgu = by(/^SGU/);
  o += sum('SGU – zbiorczo', sgu);
  o += `<h3>Rysy</h3>` + C.filter(c => c.id === 'wk').map(ckLine).join('');
  o += `<h3>Ugięcia</h3>` + C.filter(c => c.id === 'f' || c.id === 'fz').map(ckLine).join('') + line(`Ugięcie graniczne L/${S.sls.lim}.`);
  /* 6. zbrojenie */
  o += H2('Zbrojenie – sprawdzenie uproszczone');
  R.secs.forEach(sec => {
    const gg = sec.g || g, Amin = sec.sls ? sec.sls.AsMin : 0, Amax = 0.04 * gg.Ac, A = sec.tens.A, A2 = sec.comp ? sec.comp.A : 0;
    const ok1 = A >= Amin - 0.5, ok2 = A + A2 <= Amax + 0.5;
    o += line(`${esc(cap(sec.loc))} – ${sec.kind === 'span' ? 'dołem' : 'górą'}: A<sub>s,min</sub> = ${f(Amin, 0)} mm² ≤ A<sub>s,zadane</sub> = <b>${f(A, 0)} mm²</b> (${esc(sec.tens.desc)}) ${ok1 ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>'}; A<sub>s1</sub> + A<sub>s2</sub> = ${f(A + A2, 0)} mm² ≤ A<sub>s,max</sub> = 0,04·A<sub>c</sub> = ${f(Amax, 0)} mm² ${ok2 ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>'}`, '9.2.1.1');
  });
  (R.sh.segs || []).forEach(z => { const q = z.stir || S.stir; o += line(`Strzemiona${multi ? ' – ' + esc(z.seg.label) : ''}: ρ<sub>w,min</sub> = ${f(R.sh.rhoMin * 1000, 3)}‰ ≤ ρ<sub>w</sub>(s₂ = ${q.s2}) = <b>${f(z.rho2 * 1000, 3)}‰</b> ${z.rho2 >= R.sh.rhoMin ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>'}`, '9.2.2(5)'); });
  /* wniosek */
  const nF = C.filter(c => c.status === 'fail').length;
  o += `<p class="verdict"><span class="${nF ? 'fail' : 'ok'}">${nF ? `✖ Niespełnione warunki: ${nF} (szczegóły w raporcie pełnym).` : `✔ Warunki SGN i SGU są spełnione. Maksymalne wykorzystanie η = ${f((R.maxUtil || 0) * 100, 0)}%.`}</span></p>`;
  return o;
};
// opis reakcji podporowych (forma opisowa) – wspólny dla raportów
BZR.reacDesc = function (R) {
  const U = window.BZ, E = window.EC2, { fmt, esc } = U, md = R.md, st = R.st;
  if (!st.reac || !U.reacData) return '';
  const f1 = v => fmt(v / 1e3, 1), f2m = v => fmt(v / 1e6, 2);
  const kind = p => (E.SUP_NAME && E.SUP_NAME[p.type]) || p.type;
  let o = '';
  md.sups.forEach((p, i) => {
    const q = U.reacData(i);
    const pos = p.segL === null ? 'skrajna lewa' : p.segR === null ? 'skrajna prawa' : 'pośrednia';
    const own = p.name && p.name.trim().toLowerCase() !== ('podpora ' + p.label).toLowerCase();
    let t = `<b>Podpora ${esc(p.label)}</b> (${own ? esc(p.name) + '; ' : ''}${pos}, ${esc(kind(p))}, x = ${fmt(p.x / 1000, 2)} m): `;
    t += `maksymalna obliczeniowa reakcja pionowa <b>R<sub>Ed,max</sub> = ${f1(q.V.max)} kN</b>, minimalna R<sub>Ed,min</sub> = ${f1(q.V.min)} kN`;
    if (q.K) t += `; maksymalna charakterystyczna <b>R<sub>k,max</sub> = ${f1(q.K.max)} kN</b>${Math.abs(q.K.min - q.K.max) > 50 ? ` (minimalna R<sub>k,min</sub> = ${f1(q.K.min)} kN)` : ''}`;
    t += `; w tym od obciążeń stałych R<sub>k,G</sub> = ${f1(q.G)} kN`;
    if (q.Q.length) t += `, od obciążeń zmiennych: ${q.Q.map(z => `${esc(z.id)} – ${esc(z.name)}: ${f1(z.max)} kN${z.min < -50 ? ` / ${f1(z.min)} kN` : ''}`).join('; ')}`;
    t += '.';
    if (q.V.min < -50) t += ` <span class="warn">⚠ Reakcja ujemna – odrywanie belki od podpory; należy zakotwić belkę w podporze.</span>`;
    if (q.H !== undefined) t += ` Reakcja pozioma (podpora nieprzesuwna w kierunku osi belki): H<sub>Ed</sub> = ${f1(q.H)} kN${q.H ? (q.Hshare ? ' – od siły osiowej N<sub>Ed</sub>, przyjęto przeniesienie przez pierwszą podporę nieprzesuwną (przy kilku podporach nieprzesuwnych rozkład zależy od sztywności podpór)' : ' – równoważy siłę osiową N<sub>Ed</sub>') : ' (brak obciążeń poziomych wzdłuż osi)'}.`;
    else t += ' Podpora przesuwna – brak reakcji poziomej wzdłuż osi belki.';
    if (q.Z !== undefined) t += ` Reakcja pozioma w płaszczyźnie Z (prostopadle do układu): R<sub>z,Ed</sub> = ${f1(q.Z)} kN.`;
    if (q.M) t += ` Moment ${p.type === 'fix' ? 'utwierdzenia' : 'w podporze sprężystej'}: M<sub>Ed</sub> = ${f2m(q.M.min)} kNm${Math.abs(q.M.max - q.M.min) > 1e3 ? ` ÷ ${f2m(q.M.max)} kNm` : ''}${q.M.kmin !== null && q.M.kmin !== undefined ? `, charakterystyczny M<sub>k</sub> = ${f2m(q.M.kmin)}${Math.abs(q.M.kmax - q.M.kmin) > 1e3 ? ` ÷ ${f2m(q.M.kmax)}` : ''} kNm` : ''}.`;
    if (q.VL !== undefined) t += ` Siły poprzeczne przy podporze (obwiednia SGN): po lewej stronie V<sub>Ed,L</sub> = ${f1(q.VL)} kN, po prawej V<sub>Ed,P</sub> = ${f1(q.VR)} kN.`;
    o += `<div class="eq">${t}</div>`;
  });
  const sumG = st.reac.G.reduce((a, b) => a + b, 0), sumK = st.reac.K ? st.reac.K.max.reduce((a, b) => a + b, 0) : 0;
  o += `<p class="note">Reakcje dodatnie skierowane w górę (podpora podtrzymuje belkę); R<sub>Ed</sub> – obwiednia kombinacji SGN (PN-EN 1990, 6.10 / 6.10a,b), R<sub>k</sub> – kombinacja charakterystyczna (6.14b) oraz wartości od poszczególnych oddziaływań; ΣR<sub>k,G</sub> = ${f1(sumG)} kN${st.reac.K ? `, ΣR<sub>k,max</sub> = ${f1(sumK)} kN (suma maksimów – nie zawsze z jednej kombinacji)` : ''}.</p>`;
  return o;
};
// raport „statyka”: dane materiałowe, wymiary przekrojów, schemat statyczny, wykresy sił wewnętrznych, reakcje (opisowo)
BZR.buildStatic = function (R, S) {
  const U = window.BZ, E = window.EC2;
  const { fmt, esc } = U;
  const m = R.m, g = R.g, st = R.st, md = R.md, multi = md.cont;
  const f = (v, d) => fmt(v, d === undefined ? 2 : d);
  let hn = 0; const H2 = t => `<h2>${++hn}. ${t}</h2>`;
  const line = (t, ref) => `<div class="eq">${t}${ref ? `<span class="r">[${ref}]</span>` : ''}</div>`;
  const sch = E.SCHEMES[S.scheme] || E.SCHEMES.ss;
  let o = '';
  o += H2('Dane materiałowe');
  o += line(`Beton ${S.mat.concrete}: f<sub>ck</sub> = ${f(m.fck, 0)} MPa, f<sub>cm</sub> = ${f(m.fcm, 0)} MPa, f<sub>cd</sub> = ${f(m.fcd, 2)} MPa, f<sub>ctm</sub> = ${f(m.fctm, 2)} MPa, E<sub>cm</sub> = ${f(m.Ecm / 1000, 0)} GPa, ciężar objętościowy żelbetu 25 kN/m³`, 'tab. 3.1');
  o += line(`Stal zbrojeniowa ${esc(m.st.name)}: f<sub>yk</sub> = ${m.fyk} MPa, f<sub>yd</sub> = ${f(m.fyd, 1)} MPa, E<sub>s</sub> = 200 GPa; strzemiona ${esc(m.sw.id)}: f<sub>ywd</sub> = ${f(m.fywd, 1)} MPa`, '3.2.7');
  o += H2('Wymiary przekrojów');
  const geoTxt = gg => gg.T ? `przekrój teowy: b<sub>w</sub> = ${gg.bw} mm, h = ${gg.h} mm, b<sub>eff</sub> = ${f(gg.beff, 0)} mm, h<sub>f</sub> = ${gg.hf} mm; A<sub>c</sub> = ${f(gg.Ac / 1e6, 4)} m²` : `przekrój prostokątny: b = ${gg.bw} mm, h = ${gg.h} mm; A<sub>c</sub> = ${f(gg.Ac / 1e6, 4)} m²`;
  if (R.gVar || multi) md.segs.forEach(sg => { o += line(`${esc(sg.label)} (L = ${f(sg.L / 1000, 2)} m): ${geoTxt(sg.g)}; ciężar własny ${f(sg.g.selfW, 2)} kN/m`); });
  else o += line(`${geoTxt(g)}; ciężar własny ${f(g.selfW, 2)} kN/m`);
  o += line(`Szerokości podpór t: ${md.sups.map(p => `${esc(p.label)} – ${f(p.t, 0)} mm`).join(', ')}`);
  o += H2('Schemat statyczny');
  o += line(`Schemat: <b>${esc(sch.name)}</b>${multi ? ` – ${md.nSpan} przęs${md.nSpan === 1 ? 'ło' : md.nSpan < 5 ? 'ła' : 'eł'}` : ''}; długość całkowita ${f(md.Ltot / 1000, 2)} m; rozpiętości: ${md.segs.map(q => `${esc(q.label)} ${f(q.L / 1000, 2)} m`).join(', ')}`);
  o += md.sups.map(p => line(`Podpora <b>${esc(p.label)}</b>${p.name && p.name.trim().toLowerCase() !== ('podpora ' + p.label).toLowerCase() ? ' – ' + esc(p.name) : ''}: x = ${f(p.x / 1000, 2)} m; ${esc((E.SUP_NAME && E.SUP_NAME[p.type]) || p.type)}${p.hinge ? '; przegub w belce' : ''}; blokady: ${[['x', p.fx], ['y', p.fy], ['z', p.fz], ['φ', p.type === 'fix']].filter(q => q[1]).map(q => q[0]).join(', ') || '—'}${p.kv > 0 ? `; k<sub>v</sub> = ${f(p.kv, 0)} kN/m` : ''}${p.kr > 0 ? `; k<sub>φ</sub> = ${f(p.kr, 0)} kNm/rad` : ''}`)).join('');
  if (md.unodes && md.unodes.length) o += `<p class="note">Węzły dodatkowe: ${md.unodes.map(q => `${q.hinge ? 'przegub' : 'węzeł'} x = ${f(q.x / 1000, 2)} m`).join('; ')}.</p>`;
  if (st.manual) {
    o += `<p class="note">Siły wewnętrzne zadane ręcznie – schemat obciążeń i reakcje nie są wyznaczane.</p>`;
    o += line(`M<sub>Ed</sub> = ${(S.man.MEd || []).map(v => f(v, 1)).join(' / ')} kNm; M<sub>Ek</sub> = ${(S.man.MEk || []).map(v => f(v, 1)).join(' / ')} kNm; M<sub>Eqp</sub> = ${(S.man.MEqp || []).map(v => f(v, 1)).join(' / ')} kNm; V<sub>Ed,L</sub> = ${f(S.man.VL, 1)} kN, V<sub>Ed,P</sub> = ${f(S.man.VR, 1)} kN; N<sub>Ed</sub> = ${f(S.man.NEd, 1)} kN; T<sub>Ed</sub> = ${f(S.man.TEd, 1)} kNm`);
    return o;
  }
  o += `<div class="fig">${U.schemeSVG(900)}</div>`;
  o += H2('Wykresy sił wewnętrznych');
  try {
    const cd = U.chartsData();
    // tylko siły wewnętrzne – bez nośności (M_Rd, V_Rd, T_Rd) i stref strzemion
    const cM = Object.assign({}, cd.M, { W: 900, H: 210, hseg: [], title: 'Momenty zginające M [kNm] – obwiednie SGN i charakterystyczne, po stronie włókien rozciąganych' });
    const cV = Object.assign({}, cd.V, { W: 900, H: 190, hseg: [], bands: [], title: 'Siły poprzeczne V [kN] – obwiednia SGN' });
    const cT = cd.T ? Object.assign({}, cd.T, { W: 900, H: 170, hl: [], title: 'Momenty skręcające T [kNm]' + (st.TEdAdd ? ` – w tym podany wprost T_Ed = ${f(st.TEdAdd / 1e6, 1)} kNm` : '') }) : null;
    o += `<div class="fig">${U.lineChart(cM)}${cd.MZ ? U.lineChart(Object.assign({}, cd.MZ, { W: 900, H: 170 })) : ''}${U.lineChart(cV)}${U.lineChart(Object.assign({}, cd.N, { W: 900, H: cd.N.zero ? 110 : 150 }))}${cT ? U.lineChart(cT) : ''}</div>`;
    if (!cT) o += line('Moment skręcający T<sub>Ed</sub> = 0.');
  } catch (e) { /* */ }
  o += line(`Ekstrema (obwiednia SGN): M<sub>Ed,max</sub> = <b>${f(st.MEdPos / 1e6, 2)} kNm</b>${st.MEdNeg < 0 ? `, M<sub>Ed,min</sub> = <b>${f(st.MEdNeg / 1e6, 2)} kNm</b>` : ''}; |V<sub>Ed</sub>|<sub>max</sub> = <b>${f(Math.max(...st.Vabs) / 1e3, 1)} kN</b>; N<sub>Ed</sub> = ${f((st.NEd || 0) / 1e3, 1)} kN${st.TEd > 0 ? `; T<sub>Ed,max</sub> = ${f(st.TEd / 1e6, 2)} kNm` : ''}; charakterystyczne: M<sub>k,max</sub> = ${f(st.MkPos / 1e6, 2)} kNm${st.MkNeg < 0 ? `, M<sub>k,min</sub> = ${f(st.MkNeg / 1e6, 2)} kNm` : ''}`);
  o += H2('Reakcje podporowe');
  if (U.reactionsSVG && st.reac) o += `<div class="fig">${U.reactionsSVG(900)}</div>`;
  return o;
};
// przekroje bez zbrojenia podłużnego: statyka i zbrojenie wymagane (raport pełny / uproszczony w tym stanie)
BZR.buildBare = function (R, S) {
  const U = window.BZ, { fmt, esc } = U, f = (v, d) => fmt(v, d === undefined ? 2 : d);
  let o = `<p class="note"><b>Zbrojenie podłużne nie zostało zadane</b> – raport zawiera dane, statykę i zbrojenie wymagane. Pełny tok sprawdzeń (SGN, SGU, zakotwienia) – po zadaniu zbrojenia (zakładka Przekrój i zbrojenie: „Dobierz zbrojenie wymagane”).</p>`;
  o += BZR.buildStatic(R, S);
  const req = R.req; if (!req) return o;
  o += `<h2>Zbrojenie wymagane</h2>`;
  o += `<p class="note">A<sub>s,req</sub> – z warunku nośności na zginanie z siłą podłużną (metoda uproszczona, prostokątny rozkład naprężeń), nie mniej niż A<sub>s,min</sub> = max(0,26·f<sub>ctm</sub>/f<sub>yk</sub>; 0,0013)·b<sub>t</sub>·d (9.2.1.1(1))${req.mid ? '; z dodatkowym zbrojeniem podłużnym na skręcanie (6.3.2(3))' : ''}; wysokość użyteczna d dla dobranej średnicy w jednej warstwie. Dobór: najmniejsza masa stali i liczba prętów przy odstępach ≥ max(⌀; d<sub>g</sub> + 5; 20 mm) (8.2(2)).</p>`;
  req.zones.forEach(z => {
    if (z.kind === 'bot') o += `<div class="eq">Dół – ${esc(z.label)}: M<sub>Ed</sub> = ${f(z.M / 1e6, 1)} kNm, d = ${f(z.d, 0)} mm → A<sub>s,req</sub> = <b>${f(z.AsReq, 0)} mm²</b> → <b>${z.ch.n}⌀${z.ch.d}</b> (${f(z.ch.A, 0)} mm²${z.ch.layers > 1 ? ', 2 warstwy' : ''})</div>`;
    else if (z.kind === 'top') o += `<div class="eq">Góra – pręty ciągłe: ${z.AsReq > 1 ? `A<sub>s,req</sub> = ${f(z.AsReq, 0)} mm² → ` : 'montażowe (narożniki strzemion) → '}<b>${z.ch.n}⌀${z.ch.d}</b> (${f(z.ch.A, 0)} mm²)</div>`;
    else o += `<div class="eq">Góra – ${esc(z.label)}: |M<sub>Ed</sub>| = ${f(z.M / 1e6, 1)} kNm, d = ${f(z.d, 0)} mm → A<sub>s,req</sub> = <b>${f(z.AsReq, 0)} mm²</b> → ${z.ch ? `<b>${req.top.ch.n}⌀${req.top.ch.d} + ${z.ch.n}⌀${z.ch.d}</b> (${f(req.top.ch.A + z.ch.A, 0)} mm²)` : `pręty ciągłe wystarczają`}</div>`;
  });
  if (req.mid) o += `<div class="eq">Pręty boczne (skręcanie): A<sub>sl,boki</sub> = ${f(req.mid.AsReq, 0)} mm² → 2×${req.mid.n}⌀${req.mid.d}</div>`;
  return o;
};
BZR.build = function (R, S) {
  const U = window.BZ, E = window.EC2;
  const { fmt, sym, esc } = U;
  const m = R.m, g = R.g, st = R.st, cov = R.cov, md = R.md, multi = md.cont;
  const cap = t => t ? t[0].toUpperCase() + t.slice(1) : t;
  // raport pełny: wszystkie obliczenia i sprawdzenia (spełnione i niespełnione)
  const ticked = R.checks.slice();
  const has = (ids, at) => ticked.some(c => ids.includes(c.id) && (at === undefined || c.at === at));
  const hasP = (re) => ticked.some(c => re.test(c.id));
  let hn = 0; const H2 = t => `<h2>${++hn}. ${t}</h2>`;
  const f = (v, d) => fmt(v, d === undefined ? 2 : d);
  let o = '';
  // linia równania: lhs = wzór = podstawienie = wynik [jedn.] (ref) status
  const eq = (lhs, fx, sub, val, unit, ref, stt) => {
    let s = `<div class="eq">${sym(lhs)}`;
    if (fx) s += ` = ${sym(fx)}`;
    if (sub) s += ` = ${sym(sub)}`;
    if (val !== undefined && val !== null && val !== '') s += ` = <b>${val}</b>`;
    if (unit) s += ` ${unit}`;
    if (stt) s += ` <span class="${stt[0]}">${stt[1]}</span>`;
    if (ref) s += `<span class="r">[${ref}]</span>`;
    return s + '</div>';
  };
  const line = (t, ref) => `<div class="eq">${t}${ref ? `<span class="r">[${ref}]</span>` : ''}</div>`;
  const ok = (cond, txt) => cond ? ['ok', '✔ ' + (txt || 'warunek spełniony')] : ['fail', '✖ ' + (txt || 'warunek NIESPEŁNIONY')];
  const cmp = (a, rel, b, unit, d, okTxt) => {
    const good = rel === '≤' ? a <= b + 1e-9 : a >= b - 1e-9;
    return `<div class="eq">${f(a, d)} ${rel} ${f(b, d)} ${unit || ''} <span class="${good ? 'ok' : 'fail'}">${good ? '✔ ' + (okTxt || 'warunek spełniony') : '✖ warunek NIESPEŁNIONY'}</span></div>`;
  };
  // zestawienia jako wiersze tekstu (bez tabel i obramowań): „nagłówek: wartość; …”
  const tbl = (head, rows) => rows.map(r => `<div class="eq">${r.map((c, i) => c === '' || c === undefined ? '' : (i === 0 ? `${c}` : `${head[i]}: ${c}`)).filter(Boolean).join('; ')}</div>`).join('');
  const kv = pairs => pairs.filter(q => q && q[1] !== '' && q[1] !== undefined).map(([k, v]) => `<div class="eq">${k}: ${v}</div>`).join('');
  const gSwTxt = () => Array.isArray(st.gSelf) ? st.gSelf.map(v => f(v, 2)).join(' / ') : f(st.gSelf, 2);
  const comboDescQP = () => { if (!st.qpCombo) return ''; let t = 'G'; st.qpCombo.q.forEach(([i, k]) => { t += ` + ${f(k, 1)}·${st.vars[i].id}`; }); return t; };
  const today = new Date();
  const dstr = today.toLocaleDateString('pl-PL');
  const sch = E.SCHEMES[S.scheme];

  void dstr;

  /* ---------------- 1. dane */
  o += H2('Dane wejściowe');
  const bunL = [...md.segs.filter(sg => sg.reb && sg.Lb).map(sg => sg.Lb), R.LtM, ...md.sups.filter(p => p.hasX && p.LtX).map(p => p.LtX)].find(l => l && l.bundle);
  const bunTxt = bunL ? `${bunL.bundle}; ⌀<sub>n</sub> = ⌀·√n<sub>b</sub> (8.9.1)` : 'brak – pręty pojedyncze';
  const LtxT = multi ? md.segs.map(sg => `${sg.label}: ${f(sg.L / 1000, 2)} m`).join('; ') : `${f(md.Ltot / 1000, 2)} m`;
  const geoTxt = gg => gg.T ? `teowy b<sub>w</sub>×h = ${gg.bw}×${gg.h} mm, b<sub>eff</sub> = ${f(gg.beff, 0)} mm, h<sub>f</sub> = ${gg.hf} mm` : `prostokątny b×h = ${gg.bw}×${gg.h} mm`;
  const KIND = { closed: 'zamknięte', pins: 'zamknięte + szpilki', open: 'otwarte (U)', tors: 'zamknięte na skręcanie (zakład)' };
  const stTxt = q => `⌀${q.d}, ${q.legs}-cięte, ${KIND[q.kind] || 'zamknięte'}, s₁ = ${q.s1} mm${q.sp ? `, s_p = ${q.sp} mm (strefa pośrednia)` : ''}, s₂ = ${q.s2} mm`;
  o += kv([
    ['Schemat statyczny', esc(sch.name) + (multi ? ` – ${md.nSpan} przęs${md.nSpan === 1 ? 'ło' : md.nSpan < 5 ? 'ła' : 'eł'}${S.cont.cantL > 0 ? ', wspornik lewy' : ''}${S.cont.cantR > 0 ? ', wspornik prawy' : ''}` : '')],
    [multi ? 'Rozpiętości' : 'Rozpiętość L<sub>eff</sub>', LtxT],
    ['Przekrój', R.gVar ? md.segs.map(sg => `${esc(sg.label)}: ${geoTxt(sg.g)}`).join('; ') : geoTxt(g)],
    ['Szerokość podpór t', new Set(md.sups.map(p => p.t)).size > 1 ? md.sups.map(p => `${p.label}: ${f(p.t, 0)}`).join(', ') + ' mm' : `${f(md.sups[0] ? md.sups[0].t : g.t, 0)} mm`],
    ['Beton', `${S.mat.concrete}`], ['Stal podłużna / strzemion', `${m.st.name} / ${m.sw.name || m.sw.id}`],
    ['Klasa ekspozycji', `${cov.exps.join(', ')}`], ['Okres użytkowania', `${S.env.life} lat`],
    ['Otulina do strzemion c<sub>nom</sub>', cov.faces ? `dół ${cov.cb} mm, góra ${cov.ct} mm, boki ${cov.cs} mm` : `${cov.cnom} mm`],
    ['Zbrojenie górne ciągłe', R.LtM.n ? `${R.LtM.desc} (${f(R.LtM.A, 0)} mm²)` : '—'], ['Wiązki prętów', bunTxt],
    ['Pręty boczne', S.reb.mid.n > 0 ? `2×${S.reb.mid.n}⌀${S.reb.mid.d} (${S.reb.mid.n} rz. przy każdym boku)` : 'brak'], ['Buława wibratora', S.reb.vibOn !== false ? `⌀${S.reb.vib} mm (prześwit ≥ ${S.reb.vib + 10} mm)` : 'nie uwzględniana (prześwit 8.2(4) nie sprawdzany)'],
    ['Strzemiona', R.stirVar ? md.segs.filter(sg => sg.kind === 'span' || !md.cont).map(sg => `${esc(sg.label)}: ${stTxt(sg.stir)}`).join('; ') + ' (od lica podpór)' : stTxt(md.segs[0].stir || S.stir) + ' (od lica podpór)'],
    ['Sytuacje obliczeniowe', st.hasAcc ? 'trwała/przejściowa + wyjątkowa' : 'trwała / przejściowa'],
  ]);
  o += `<h3>Podpory</h3>` + tbl(['Podpora', 'x [m]', 'rodzaj', 'blokady', 't [mm]', 'podatność'], md.sups.map(p => [`<b>${esc(p.label)}</b> – ${esc(p.name)}`, f(p.x / 1000, 2), esc(E.SUP_NAME[p.type]) + (p.hinge ? '; przegub w belce' : ''),
    [['x', p.fx], ['y', p.fy], ['z', p.fz], ['φ', p.type === 'fix']].filter(q => q[1]).map(q => q[0]).join(', ') || '—', f(p.t, 0),
    [p.kv > 0 ? `k<sub>v</sub> = ${f(p.kv, 0)} kN/m` : '', p.kr > 0 ? `k<sub>φ</sub> = ${f(p.kr, 0)} kNm/rad` : ''].filter(Boolean).join('; ') || (p.type === 'fix' ? 'sztywna (pełne utwierdzenie)' : 'niepodatna')]));
  if (md.unodes && md.unodes.length) o += `<p class="note">Węzły dodatkowe: ${md.unodes.map(q => `${q.hinge ? '<b>przegub</b>' : 'węzeł'} x = ${f(q.x / 1000, 2)} m (${esc(md.segs[q.seg].label)}, a = ${f(q.a / 1000, 2)} m)`).join('; ')}. Przegub – moment zginający równy zeru.</p>`;
  o += `<h3>Zbrojenie przekrojów obliczeniowych</h3>` + tbl(['Odcinek / podpora', 'rozciągane', 'ściskane', 'd [mm]'], R.secs.map(sec => [esc(cap(sec.loc)) + (sec.kind === 'span' ? ' (M > 0)' : ' (M < 0)'), `${sec.tens.desc} = ${f(sec.tens.A, 0)} mm²`, sec.comp && sec.comp.n ? `${sec.comp.desc} = ${f(sec.comp.A, 0)} mm²` : '—', f(sec.d, 0)]));
  if (!st.manual) {
    const refTxt = p => p.ref === 'R' ? `${f(num(p.a), 3)} m od prawej` : p.ref === 'rel' ? `x/L = ${f(num(p.a), 3)}` : '';
    const num = v => (v === '' || v === undefined ? NaN : +v);
    const segTxt = r => r.seg !== null && r.seg !== undefined && md.segs[r.seg] ? `${md.segs[r.seg].label}${r.el !== null && r.el !== undefined ? `, element ${r.el + 1}` : ''}, ` : '';
    const comp = r => [r.qy ? (r.prof ? `q<sub>Y</sub> = ${r.prof.map(q => f(q[1] * (r.cy || 1), 2)).join(' → ')} kN/m (zmienne liniowo między x = ${r.prof.map(q => f(q[0] / 1000, 2)).join('; ')} m)` : `q<sub>Y</sub> = ${f(r.qy, 2)} kN/m`) : '', r.qz ? `q<sub>Z</sub> = ${f(r.qz, 2)} kN/m` : '', r.mt ? `m<sub>t</sub> = ${f(r.mt, 2)} kNm/m` : ''].filter(Boolean).map(t => `${t} (${segTxt(r)}${r.partial ? `x = ${f(r.x1 / 1000, 3)}÷${f(r.x2 / 1000, 3)} m` : 'cała długość'})`)
      .concat((r.pts || []).map(p => [p.Py ? `P<sub>Y</sub> = ${f(p.Py, 2)} kN` : '', p.Pz ? `P<sub>Z</sub> = ${f(p.Pz, 2)} kN` : '', p.T ? `T = ${f(p.T, 2)} kNm` : ''].filter(Boolean).join(', ') + ` w x = <b>${f(p.x / 1000, 3)} m</b>` + (p.a === '' ? ' (środek odcinka)' : refTxt(p) ? ` (${refTxt(p)})` : ''))).join('<br>');
    const lay = st.layout;
    const gSw = R.gVar ? md.segs.map(sg => f(sg.g.selfW, 2)).join(' / ') : (Array.isArray(st.gSelf) ? st.gSelf.map(v => f(v, 2)).join(' / ') : f(st.gSelf, 2));
    const rows = [
      ...(S.loads.gk ? [['G', 'Stałe g<sub>k</sub>', `${f(S.loads.gk, 2)} kN/m`, 'obciążenie dodatkowe, cała długość']] : []),
      ['G₀', 'Ciężar własny', `${gSw} kN/m`, S.loads.sw ? `25 kN/m³ · ${g.T ? 'b<sub>w</sub>·(h−h<sub>f</sub>)' : 'b·h'}${R.gVar ? ' (kolejne odcinki)' : ''}` : 'nie uwzględniono'],
      ...lay.G.filter(r => r.si !== undefined).map(r => ['G', esc(r.name), comp(r), 'obciążenie stałe']),
      ...st.vars.map(v => [v.id, esc(v.name), comp(v.r), `${esc(v.psi.name)}: ψ₀ = ${f(v.psi.p0, 1)}, ψ₁ = ${f(v.psi.p1, 1)}, ψ₂ = ${f(v.psi.p2, 1)}`]),
      ...st.accs.map(a => [a.id, esc(a.name), comp(a.r), 'oddziaływanie wyjątkowe – wartość obliczeniowa A<sub>d</sub>']),
      ...(st.NEd ? [['', 'Siła osiowa N<sub>Ed</sub>', `${f(st.NEd / 1e3, 1)} kN`, 'wartość obliczeniowa (+ ściskanie)']] : []),
      ...(st.TEd ? [['', 'Moment skręcający T<sub>Ed</sub>', `${f(st.TEd / 1e6, 1)} kNm`, 'wartość obliczeniowa']] : []),
      ...(st.hasAcc && (S.loads.accN || S.loads.accT) ? [['', 'N<sub>Ed,A</sub> / T<sub>Ed,A</sub>', `${f(S.loads.accN, 1)} kN / ${f(S.loads.accT, 1)} kNm`, 'sytuacja wyjątkowa']] : []),
    ];
    o += `<h3>Obciążenia (wartości charakterystyczne)</h3>` + rows.map(r => `<div class="eq">${r[0] ? `<b>${r[0]}</b> – ` : ''}${r[1]}: ${r[2]}${r[3] ? ` (${r[3]})` : ''}</div>`).join('');
  }

  /* ---------------- 2. materiały */
  o += H2('Parametry materiałowe') + `<h3>Beton ${S.mat.concrete}</h3>`;
  o += eq('f_{ck}', '', '', f(m.fck, 0), 'MPa', 'tab. 3.1') + eq('f_{cm}', 'f_{ck} + 8', '', f(m.fcm, 0), 'MPa');
  o += eq('f_{cd}', 'α_{cc}·f_{ck}/γ_{c}', `${f(m.acc, 2)}·${f(m.fck, 0)}/${f(m.gc, 2)}`, f(m.fcd, 2), 'MPa', '3.1.6(1)');
  o += eq('f_{ctm}', '', '', f(m.fctm, 2), 'MPa', 'tab. 3.1') + eq('f_{ctk,0,05}', '', '', f(m.fctk05, 2), 'MPa');
  o += eq('f_{ctd}', 'α_{ct}·f_{ctk,0,05}/γ_{c}', `${f(m.act, 2)}·${f(m.fctk05, 2)}/${f(m.gc, 2)}`, f(m.fctd, 3), 'MPa', '3.1.6(2)');
  o += eq('E_{cm}', '', '', f(m.Ecm / 1000, 0), 'GPa') + eq('ε_{cu3}', '', '', f(m.ecu3 * 1000, 2), '‰') + eq('λ', '', '', f(m.lambda, 3), '') + eq('η', '', '', f(m.eta, 3), '', '3.1.7(3)');
  o += `<h3>Stal ${esc(m.st.name)}</h3>`;
  o += eq('f_{yd}', 'f_{yk}/γ_{s}', `${m.fyk}/${f(m.gs, 2)}`, f(m.fyd, 2), 'MPa', '3.2.7') + eq('ε_{yd}', 'f_{yd}/E_{s}', `${f(m.fyd, 1)}/200000`, f(m.eyd * 1000, 3), '‰');
  o += eq('ε_{ud}', '0,9·ε_{uk}', `0,9·${f(m.euk * 100, 1)}%`, f(m.eud * 1000, 1), '‰', '3.2.7(2), ZK');
  o += eq('f_{ywd}', 'f_{ywk}/γ_{s}', `${m.fywk}/${f(m.gs, 2)}`, f(m.fywd, 2), 'MPa');
  o += eq('ξ_{eff,lim}', 'λ·ε_{cu3}/(ε_{cu3}+ε_{yd})', `${f(m.lambda, 2)}·${f(m.ecu3 * 1000, 2)}/(${f(m.ecu3 * 1000, 2)}+${f(m.eyd * 1000, 3)})`, f(m.xiEffLim, 3), '');

  /* ---------------- 3. otulina */
  if (has(['cnom', 'minclass'])) {
  o += H2('Otulina zbrojenia (4.4.1)');
  o += `<p>Klasa konstrukcji: ${cov.mods.map(esc).join('; ')} → <b>S${cov.sc}</b> (tab. 4.3N).</p>`;
  o += eq('c_{min,dur}', '', `tab. 4.4N, ${cov.exp}, S${cov.sc}`, cov.cdur, 'mm', '4.4.1.2(5)');
  o += eq('c_{min,b}', '⌀ (strzemiona / pręty główne)', `${cov.dSw} / ${cov.dMain}` + (cov.add ? ' + 5 (d_{g} > 32 mm)' : ''), `${cov.cminb_sw} / ${cov.cminb_main}`, 'mm', 'tab. 4.2');
  o += eq('c_{min}', 'max\\{c_{min,b}; c_{min,dur}+Δc_{dur,γ}−Δc_{dur,st}−Δc_{dur,add}; 10 mm\\}'.replace(/\\/g, ''), '', `${cov.cmin_sw} / ${cov.cmin_main}`, 'mm (strzemiona / pręty główne)', '4.4.1.2(2)');
  o += eq('c_{nom}', 'c_{min} + Δc_{dev}', `${cov.cmin_sw} + ${cov.dcdev} / ${cov.cmin_main} + ${cov.dcdev}`, `${cov.cnom_sw} / ${cov.cnom_main}`, 'mm', '4.4.1.1(2)');
  o += line(`Wymagana otulina strzemion: c<sub>nom,w</sub> ≥ max{${cov.cnom_sw}; ${cov.cnom_main} − ${cov.dSw}${cov.ground ? `; ${cov.ground} (betonowanie na podłożu)` : ''}} = <b>${f(cov.req, 0)} mm</b> → ${cov.manual ? `wymagane ${cov.reqR} mm; przyjęto ręcznie` : 'przyjęto'} <b>c<sub>nom</sub> = ${cov.cnom} mm</b> ` +
    `<span class="${cov.cnom >= cov.reqR ? 'ok' : 'fail'}">${cov.cnom >= cov.reqR ? '✔' : '✖ za mała otulina'}</span>`);
  if (cov.faces) o += line(`Otulina poszczególnych krawędzi (do strzemion): dół c<sub>nom,b</sub> = <b>${cov.cb} mm</b> (wymagane ${cov.reqB} mm) <span class="${cov.cb >= cov.reqB ? 'ok' : 'fail'}">${cov.cb >= cov.reqB ? '✔' : '✖'}</span>; góra c<sub>nom,t</sub> = <b>${cov.ct} mm</b> (wymagane ${cov.reqT} mm) <span class="${cov.ct >= cov.reqT ? 'ok' : 'fail'}">${cov.ct >= cov.reqT ? '✔' : '✖'}</span>; boki c<sub>nom,s</sub> = <b>${cov.cs} mm</b> (wymagane ${cov.reqS} mm) <span class="${cov.cs >= cov.reqS ? 'ok' : 'fail'}">${cov.cs >= cov.reqS ? '✔' : '✖'}</span>`, '4.4.1');
  o += line(`Minimalna klasa betonu ze względu na trwałość (zał. E, tab. E.1N): ${cov.minCls} (${cov.minFrom}) – przyjęto ${S.mat.concrete} <span class="${cov.minOk ? 'ok' : 'warn'}">${cov.minOk ? '✔' : '⚠ klasa niższa od zalecanej'}</span>`);
  }

  /* ---------------- 4. statyka */
  o += H2('Obciążenia i siły wewnętrzne');
  if (!st.manual) {
    o += `<h3>Schemat obciążeń</h3><p class="note">Położenia x mierzone od lewego końca belki${S.scheme === 'cant' ? ' (utwierdzenia)' : multi ? '' : ' (oś lewej podpory)'}; wartości charakterystyczne, A – obliczeniowe; [Z] – obciążenia w płaszczyźnie prostopadłej do układu (poziome).</p><div class="fig">${U.schemeSVG(900)}</div>`;
    if (S.loads.gk) o += eq('g_{k}', 'g_{k,dod} + g_{k,cw}', `${f(S.loads.gk, 2)} + ${gSwTxt()}`, Array.isArray(st.gk) ? st.gk.map(v => f(v, 2)).join(' / ') : f(st.gk, 2), 'kN/m');
    o += `<p>Każde obciążenie zmienne traktowano jako niezależne oddziaływanie. Rozpatrzono wszystkie kombinacje z kolejnymi obciążeniami jako wiodącymi; obciążenia zmienne uwzględniano tylko w miejscach, gdzie działają niekorzystnie, a obciążenia stałe z γ<sub>G,sup</sub> = ${f(S.loads.gG, 2)} (niekorzystnie) lub γ<sub>G,inf</sub> = 1,0 (korzystnie)` +
      (st.combos && st.vars.some(v => v.it.kind === 'imp' && v.it.cat === 'H') && st.vars.some(v => v.it.kind === 'snow' || v.it.kind === 'wind') ? '. Obciążenia dachu kat. H nie łączono ze śniegiem i wiatrem (PN-EN 1991-1-1, 3.3.2(1))' : '') + `.</p>`;
    if (S.loads.comb === '610') o += line(`E<sub>d</sub> = Σγ<sub>G,j</sub>·G<sub>k,j</sub> + γ<sub>Q,1</sub>·Q<sub>k,1</sub> + Σγ<sub>Q,i</sub>·ψ<sub>0,i</sub>·Q<sub>k,i</sub>`, 'PN-EN 1990 (6.10)');
    else o += line(`E<sub>d</sub> = max{ Σγ<sub>G,j</sub>·G<sub>k,j</sub> + Σγ<sub>Q,i</sub>·ψ<sub>0,i</sub>·Q<sub>k,i</sub> ; Σξ·γ<sub>G,j</sub>·G<sub>k,j</sub> + γ<sub>Q,1</sub>·Q<sub>k,1</sub> + Σγ<sub>Q,i</sub>·ψ<sub>0,i</sub>·Q<sub>k,i</sub> }, ξ = ${f(S.loads.xi, 2)}`, '(6.10a), (6.10b)');
    o += line(`Charakterystyczna: G<sub>k</sub> + Q<sub>k,1</sub> + Σψ<sub>0,i</sub>·Q<sub>k,i</sub>; quasi-stała: G<sub>k</sub> + Σψ<sub>2,i</sub>·Q<sub>k,i</sub> = ${esc(comboDescQP())}`, '(6.14b), (6.16b)');
    if (st.hasAcc) o += line(`Wyjątkowa: G<sub>k</sub> + A<sub>d</sub> + ${S.loads.accPsi === 'psi2' ? 'ψ<sub>2,1</sub>' : 'ψ<sub>1,1</sub>'}·Q<sub>k,1</sub> + Σψ<sub>2,i</sub>·Q<sub>k,i</sub> (każde A<sub>d</sub> osobno)`, '(6.11b)');
    const cmbLines = (title, rows, sx) => rows && rows.length ? `<p><i>${title}:</i></p>` + rows.map(r => line(`${esc(r.name)}: ${esc(r.desc)} → M<sub>${sx}</sub> max = ${r.govMpos ? '<b>' : ''}${f(r.Mpos / 1e6, 2)}${r.govMpos ? '</b>' : ''} kNm${st.hasNeg ? `, M<sub>${sx}</sub> min = ${r.govMneg ? '<b>' : ''}${f(r.Mneg / 1e6, 2)}${r.govMneg ? '</b>' : ''} kNm` : ''}, |V<sub>${sx}</sub>| max = ${r.govVmax ? '<b>' : ''}${f(r.Vmax / 1e3, 1)}${r.govVmax ? '</b>' : ''} kN${st.hasZ ? `, |M<sub>z,${sx}</sub>| = ${f(r.Mz / 1e6, 2)} kNm` : ''}`)).join('') : '';
    o += cmbLines('Kombinacje SGN – sytuacja trwała/przejściowa (6.10)', st.tabU, 'Ed') + (st.tabA ? cmbLines('Kombinacje SGN – sytuacja wyjątkowa (6.11b)', st.tabA, 'Ed,A') : '') + cmbLines('Kombinacje SGU – charakterystyczne (6.14b)', st.tabK, 'Ek');
    o += `<p class="note">Oznaczenia: G – obciążenia stałe; ${st.vars.map(v => `${v.id} – ${esc(v.name)}`).join('; ')}. Pogrubiono wartości decydujące.</p>`;
    o += `<p class="note">Siły wewnętrzne wyznaczono metodą elementów skończonych dla całej belki (${st.mesh.length - 1} elementów belkowych, węzły w podporach, w punktach przyłożenia sił skupionych i na granicach obciążeń) osobno dla każdego obciążenia${multi ? ', a obciążenia zmienne – osobno dla każdego przęsła (wspornika), co pozwala uwzględnić najniekorzystniejszy układ obciążenia na przęsłach' : ''}; analiza liniowo-sprężysta, bez redystrybucji. Obwiednie z kombinacji punkt po punkcie${st.hasZ ? '; obciążenia w płaszczyźnie Z analizowano tym samym modelem (zginanie względem osi pionowej)' : ''}.</p>`;
  } else o += `<p>Siły wewnętrzne wprowadzone ręcznie; rozkład M(x) – parabola przez wartości w punktach x = 0, L/2, L; V(x) – liniowy.</p>`;
  o += `<h3>Momenty i siły poprzeczne w przekrojach obliczeniowych</h3>`;
  R.secs.forEach(sec => { const r = sec.sls; o += line(`${esc(cap(sec.loc))} (${sec.kind === 'span' ? 'M > 0' : 'M < 0'}), x = ${f(sec.x / 1000, 2)} m: |M<sub>Ed</sub>| = <b>${f(sec.MEd / 1e6, 1)} kNm</b>, M<sub>Ek</sub> = ${r ? f(r.Mk / 1e6, 1) : '—'} kNm, M<sub>Eqp</sub> = ${r ? f(r.Mqp / 1e6, 1) : '—'} kNm${st.hasZ ? `, |M<sub>z,Ed</sub>| = ${f(st.MzEd[sec.k] / 1e6, 1)} kNm` : ''}`); });
  R.sh.ends.forEach(e => { o += line(`${esc(cap(e.name))}: V<sub>Ed</sub> w osi = <b>${f(e.V0 / 1e3, 1)} kN</b>; do wymiarowania strzemion ${e.red ? `V<sub>Ed,red</sub> = <b>${f(e.Vred / 1e3, 1)} kN</b> (w odległości d od lica, ${f(e.xr / 1000, 3)} m od osi)` : `V<sub>Ed</sub> = <b>${f(e.Vred / 1e3, 1)} kN</b> – bez redukcji${e.redWhy ? ` (${esc(e.redWhy)})` : ''}`}${st.hasZ && e.zsh ? `; V<sub>z,Ed</sub> = ${f(e.zsh.V0 / 1e3, 1)} kN` : ''}`); });
  if (st.reac && !st.manual) {
    o += `<h3>Reakcje podporowe</h3>`;
    o += BZR.reacDesc(R);
  }
  if (st.TEd > 0) o += line(`Moment skręcający: T<sub>Ed,max</sub> = <b>${f(st.TEd / 1e6, 2)} kNm</b>${st.TEdAdd ? ` (w tym podany wprost ${f(st.TEdAdd / 1e6, 2)} kNm)` : ''}${st.hasT ? ' – z analizy pręta skręcanego (podparcie widełkowe w podporach)' : ''}`);
  if (st.NEd) o += line(`Siła osiowa: N<sub>Ed</sub> = <b>${f(st.NEd / 1e3, 1)} kN</b> (${st.NEd > 0 ? 'ściskanie' : 'rozciąganie'}), stała na długości belki`);
  try {
    const cd = U.chartsData();
    o += `<div class="fig">${U.lineChart(Object.assign(cd.M, { W: 900, H: 210 }))}${cd.MZ ? U.lineChart(Object.assign(cd.MZ, { W: 900, H: 170 })) : ''}${U.lineChart(Object.assign(cd.V, { W: 900, H: 190 }))}${cd.T ? U.lineChart(Object.assign(cd.T, { W: 900, H: 170 })) : ''}${U.lineChart(Object.assign(cd.N, { W: 900, H: cd.N.zero ? 110 : 150 }))}</div>`;
    if (U.reactionsSVG && st.reac) o += `<div class="fig">${U.reactionsSVG(900)}</div>`;
  } catch (e) { /* */ }

  /* ---------------- 5. zginanie */
  const show5 = has(['Mspan', 'Msupp', 'duct', 'biax', 'biaxZ', 'N']);
  if (show5) o += H2('SGN – zginanie z siłą osiową');
  const n5 = hn;
  const bendSec = (b, nm) => {
    const isSpan = b.kind === 'span';
    let s = `<h3>${nm}</h3>`;
    const tens = b.tens, comp = b.comp;
    const a1 = tens.eC, a2 = comp && comp.n ? comp.eC : 0;
    if (b.red) {          // redukcja momentu nad podporą (5.3.2.2)
      const q = b.red;
      s += line(`x = ${f(b.x / 1000, 2)} m; |M<sub>Ed</sub>| w osi podpory = ${f(q.M0 / 1e6, 2)} kNm (obwiednia SGN); szerokość podpory t = ${f(q.t, 0)} mm`);
      s += q.kind === 'free'
        ? eq('ΔM_{Ed}', 'F_{Ed,sup}·t/8', `${f(q.F / 1e3, 1)}·${f(q.t / 1000, 3)}/8`, f(q.dM / 1e6, 2), 'kNm', '5.3.2.2(4)') + line(`F<sub>Ed,sup</sub> – reakcja podpory w kombinacji dającej największy moment ujemny; podpora swobodna (obrót możliwy)`)
          + eq('M_{Ed}', '|M_{Ed,oś}| − ΔM_{Ed}', `${f(q.M0 / 1e6, 2)} − ${f(q.dM / 1e6, 2)}`, f(b.MEd / 1e6, 2), 'kNm')
        : eq('M_{Ed,lico}', '', 'moment w licu podpory (obwiednia SGN, t/2 od osi)', f(q.Mf / 1e6, 2), 'kNm', '5.3.2.2(3)')
          + eq('M_{Ed}', 'max(M_{Ed,lico}; 0,65·|M_{Ed,oś}|)', `max(${f(q.Mf / 1e6, 2)}; 0,65·${f(q.M0 / 1e6, 2)})`, f(b.MEd / 1e6, 2), 'kNm') + line('podpora monolityczna – moment obliczeniowy w licu podpory, nie mniejszy niż 0,65 momentu w osi');
    } else s += line(`x = ${f(b.x / 1000, 2)} m; |M<sub>Ed</sub>| = ${f(b.MEd / 1e6, 2)} kNm (obwiednia SGN)`);
    s += eq('a_{1}', '', `środek ciężkości zbrojenia rozciąganego ${tens.desc}`, f(a1, 1), 'mm') + eq('d', 'h − a_{1}', `${(b.g || g).h} − ${f(a1, 1)}`, f(b.d, 1), 'mm') + (R.gVar && b.g ? line(`Przekrój: ${geoTxt(b.g)}`) : '');
    if (comp && comp.n) s += eq('a_{2}', '', `zbrojenie ściskane ${comp.desc}`, f(a2, 1), 'mm');
    const ds = b.des;
    s += `<p><i>a) Wymiarowanie – metoda uproszczona (prostokątny rozkład naprężeń, λ = ${f(m.lambda, 2)}, η = ${f(m.eta, 2)}):</i></p>`;
    if (st.NEd) s += eq('M_{Eds}', 'M_{Ed} + N_{Ed}·(d − y_{c})', `${f(b.MEd / 1e6, 2)} + ${f(st.NEd / 1e3, 1)}·(${f(b.d, 1)} − ${f(b.yc, 1)})·10^{−3}`, f(ds.Ms / 1e6, 2), 'kNm');
    if (ds.Mf !== undefined) s += eq('M_{f}', 'η·f_{cd}·b_{eff}·h_{f}·(d − 0,5·h_{f})', `${f(m.eta, 2)}·${f(m.fcd, 2)}·${f(g.beff, 0)}·${g.hf}·(${f(b.d, 1)} − ${f(g.hf / 2, 1)})`, f(ds.Mf / 1e6, 1), 'kNm') +
      line(ds.T ? `M<sub>Eds</sub> > M<sub>f</sub> → oś obojętna w środniku (przekrój rzeczywiście teowy): F<sub>f</sub> = η·f<sub>cd</sub>·(b<sub>eff</sub> − b<sub>w</sub>)·h<sub>f</sub> = <b>${f(ds.Ff / 1e3, 1)} kN</b>` : `M<sub>Eds</sub> ≤ M<sub>f</sub> → oś obojętna w półce – przekrój pozornie teowy, b = b<sub>eff</sub>`);
    s += eq('μ_{eff}', (ds.T ? '(M_{Eds} − F_{f}·(d − h_{f}/2))' : 'M_{Eds}') + '/(η·f_{cd}·b·d^{2})', `${f(ds.Mw / 1e6, 2)}·10^{6}/(${f(m.eta, 2)}·${f(m.fcd, 2)}·${f(ds.b, 0)}·${f(b.d, 1)}^{2})`, f(ds.mu, 4), '', '');
    s += eq('μ_{eff,lim}', 'ξ_{eff,lim}·(1 − 0,5·ξ_{eff,lim})', '', f(ds.muLim, 4), '');
    if (!ds.double) {
      s += eq('ξ_{eff}', '1 − √(1 − 2·μ_{eff})', '', f(ds.xi, 4), '') + line(`ξ<sub>eff</sub> = ${f(ds.xi, 3)} ≤ ξ<sub>eff,lim</sub> = ${f(m.xiEffLim, 3)} → zbrojenie pojedyncze`);
      s += eq('A_{s1,req}', '(ξ_{eff}·b·d·η·f_{cd}' + (ds.T ? ' + F_{f}' : '') + (st.NEd ? ' − N_{Ed}' : '') + ')/f_{yd}', '', f(ds.As1, 0), 'mm²', '');
    } else {
      s += line(`μ<sub>eff</sub> > μ<sub>eff,lim</sub> → wymagane zbrojenie ściskane (podwójne).`);
      s += eq('M_{lim}', 'μ_{eff,lim}·η·f_{cd}·b·d^{2}', '', f(ds.Mlim / 1e6, 2), 'kNm') + eq('σ_{s2}', 'min(f_{yd}; E_{s}·ε_{cu3}·(x_{lim} − a_{2})/x_{lim})', '', f(ds.ss2, 1), 'MPa');
      s += eq('A_{s2,req}', '(M_{Eds} − M_{lim})/(σ_{s2}·(d − a_{2}))', '', f(ds.As2, 0), 'mm²') + eq('A_{s1,req}', '(ξ_{eff,lim}·b·d·η·f_{cd} + A_{s2}·σ_{s2}' + (st.NEd ? ' − N_{Ed}' : '') + ')/f_{yd}', '', f(ds.As1, 0), 'mm²');
    }
    s += line(`Przyjęto: A<sub>s1,prov</sub> = ${tens.desc} = <b>${f(tens.A, 0)} mm²</b> ${tens.A >= ds.As1 ? '≥' : '<'} A<sub>s1,req</sub> = ${f(ds.As1, 0)} mm² <span class="${tens.A >= ds.As1 ? 'ok' : 'fail'}">${tens.A >= ds.As1 ? '✔' : '✖'}</span>` + (ds.As2 > 0 ? `; A<sub>s2,prov</sub> = ${f(comp ? comp.A : 0, 0)} mm² ${(comp ? comp.A : 0) >= ds.As2 ? '≥' : '<'} ${f(ds.As2, 0)} mm²` : ''));
    s += `<p><i>b) Sprawdzenie nośności – metoda ogólna (zgodność odkształceń, przekrój z rzeczywistym zbrojeniem rozciąganym i ściskanym):</i></p>`;
    if (b.r) {
      const bs = b.r;
      const eT = isSpan ? bs.eT : bs.eB, eB = isSpan ? bs.eB : bs.eT;
      const es1 = Math.abs(Math.min(...bs.bs.map(q => q.e)));
      s += line(`Stan graniczny przy N<sub>Ed</sub> = ${f(st.NEd / 1e3, 1)} kN: x = <b>${f(bs.x, 1)} mm</b>, ε<sub>c</sub> = ${f(Math.max(eT, eB) * 1000, 3)}‰, ε<sub>s1</sub> = ${f(es1 * 1000, 2)}‰ ${es1 >= m.eyd ? '≥ ε<sub>yd</sub> (stal uplastyczniona)' : '< ε<sub>yd</sub> (stal sprężysta)'}`);
      const comps = bs.bs.map((q, i) => ({ q, b: b.barsO[i] })).filter(o2 => o2.b.side === (isSpan ? 'top' : 'bot'));
      if (comps.length) s += line(`Zbrojenie ściskane: ε<sub>s2</sub> = ${f(comps[0].q.e * 1000, 3)}‰, σ<sub>s2</sub> = ${f(comps[0].q.s, 1)} MPa`);
      s += eq('M_{Rd}', '', '∫σ_{c}·b·(y_{c} − y)dy + ΣA_{si}·σ_{si}·(y_{c} − y_{i})', f(b.MRd / 1e6, 2), 'kNm', '6.1');
      s += cmp(b.MEd / 1e6, '≤', b.MRd / 1e6, 'kNm', 2, `η = ${f(b.MEd / b.MRd * 100, 1)}%`);
      const r0 = b.r0;
      if (r0 && isFinite(r0.x)) s += line(`Ciągliwość (N = 0): ξ = x/d = ${f(r0.x / b.d, 3)} ${r0.x / b.d <= m.xiLim ? '≤' : '>'} ξ<sub>lim</sub> = ε<sub>cu3</sub>/(ε<sub>cu3</sub>+ε<sub>yd</sub>) = ${f(m.xiLim, 3)} <span class="${r0.x / b.d <= m.xiLim ? 'ok' : 'warn'}">${r0.x / b.d <= m.xiLim ? '✔' : '⚠ przekrój przezbrojony'}</span>`);
    } else s += line(`<span class="fail">✖ Siła osiowa N<sub>Ed</sub> przekracza nośność przekroju (N<sub>Rd</sub> ∈ ⟨${f(R.NRdMin / 1e3, 0)}; ${f(R.NRdMax / 1e3, 0)}⟩ kN).</span>`);
    if (b.biax && b.biax.Mz > 1e3) {
      s += `<p><i>c) Zginanie ukośne (obciążenia w płaszczyźnie Z):</i></p>`;
      s += line(`Decydująca kombinacja: M<sub>y</sub> = ${f(b.biax.My / 1e6, 2)} kNm, |M<sub>z</sub>| = ${f(b.biax.Mz / 1e6, 2)} kNm → |M<sub>Ed</sub>| = ${f(Math.hypot(b.biax.My, b.biax.Mz) / 1e6, 2)} kNm`);
      s += line(`Nośność w kierunku wektora momentu (kontur M<sub>y</sub>–M<sub>z</sub> przy N<sub>Ed</sub>, metoda włókien, oś obojętna ukośna): η = |M<sub>Ed</sub>|/M<sub>Rd</sub> = <b>${f(b.biax.u, 3)}</b> ${b.biax.u <= 1 ? '≤' : '>'} 1,0 <span class="${b.biax.u <= 1 ? 'ok' : 'fail'}">${b.biax.u <= 1 ? '✔' : '✖'}</span>`, '6.1');
    }
    return s;
  };
  let i5 = 0;
  R.secs.forEach(sec => { if (has(['Mspan', 'Msupp', 'duct', 'biax'], sec.key)) o += bendSec(sec, `${n5}.${++i5}. ${cap(sec.loc)} – ${sec.kind === 'span' ? 'rozciągane włókna dolne' : 'rozciągane włókna górne'}`); });
  (R.biaxZ || []).forEach(bz => {
    if (!has(['biaxZ'], 'z' + bz.seg.idx)) return;
    o += `<h3>Zginanie ukośne – ${esc(bz.loc)}, przekrój największego M<sub>z</sub> (x = ${f(bz.x / 1000, 2)} m)</h3>`;
    o += line(`M<sub>y</sub> = ${f(bz.My / 1e6, 2)} kNm, |M<sub>z</sub>| = ${f(bz.Mz / 1e6, 2)} kNm → η = <b>${f(bz.u, 3)}</b> <span class="${bz.u <= 1 ? 'ok' : 'fail'}">${bz.u <= 1 ? '✔' : '✖'}</span>`, '6.1');
  });
  if (st.NEd && has(['N'])) {
    o += `<h3>Krzywa interakcji M–N</h3><div class="fig">${U.mnSVG(U.mnCurves(), 560, 420)}</div>`;
    o += st.NEd > 0 ? cmp(st.NEd / 1e3, '≤', R.NRdMax / 1e3, 'kN', 1) : cmp(-st.NEd / 1e3, '≤', -R.NRdMin / 1e3, 'kN', 1);
  }

  /* ---------------- 6. ścinanie */
  const sh = R.sh, tor = R.tor;
  const show6 = ticked.some(c => c.grp === 'SGN – ścinanie i skręcanie');
  if (show6) {
  o += H2(`SGN – ścinanie${tor.on ? ' i skręcanie' : ''} (6.2${tor.on ? ', 6.3' : ''})`);
  (sh.segs && sh.segs.length > 1 ? sh.segs : [sh.segs ? sh.segs[0] : { stir: S.stir, Asw: sh.Asw }]).forEach(z => { const q = z.stir || S.stir; o += eq('A_{sw}', 'n·π·⌀_{w}^{2}/4', `${multi && z.seg ? esc(z.seg.label) + ': ' : ''}${q.legs}·π·${q.d}^{2}/4 (${KIND[q.kind] || 'zamknięte'})`, f(z.Asw || sh.Asw, 1), 'mm²'); });
  o += line(`Kąt nachylenia krzyżulców betonowych: ${S.stir.cot === 'auto' ? 'dobrany automatycznie (największy dopuszczalny z przedziału 1,0 ≤ cot θ ≤ 2,5)' : 'przyjęty'}: <b>cot θ = ${f(sh.cot, 2)}</b> (θ = ${f(sh.theta, 1)}°)`, '6.2.3(2)');
  const zs = R.stirZones || [];
  if (zs.length) o += line(`Rozmieszczenie strzemion od lica podpór: ${zs.map(z => `${multi ? esc(z.seg.label) + ': ' : ''}${z.eL !== null ? `e = ${f(z.eL, 0)} mm, ` : ''}${z.n} szt.${z.nL || z.nR ? `, strefy s₁: ${z.nL}+${z.nR} odstępów po ${(z.seg.stir || S.stir).s1} mm` : ''}${z.npL || z.npR ? `, strefy pośrednie s_p: ${z.npL}+${z.npR} odstępów po ${z.sp} mm` : ''}, część środkowa ${z.nm} × ${f(z.sm, Math.abs(z.sm - Math.round(z.sm)) < 1e-6 ? 0 : 1)} mm`).join('; ')} (odstęp pierwszego strzemienia ${S.stir.e0 === '' ? 'dobrany z przedziału 10–50 mm dla równomiernego rozstawu' : 'przyjęty ręcznie'})`, '9.2.2');
  sh.ends.forEach(sp => {
    if (!has(['Vmax', 'Vs1', 'l1', 'VzMax', 'VzS', 'VzI'], sp.key)) return;
    o += `<h3>${esc(cap(sp.name))}${sp.hog ? ' (moment ujemny – ρ<sub>l</sub> ze zbrojenia górnego)' : ''}</h3>`;
    const qs = sp.stir || S.stir, bwS = sp.bw || g.bw, AswS = Math.max(2, qs.legs) * Math.PI * qs.d * qs.d / 4;
    o += eq('V_{Ed}', '', `w osi podpory`, f(sp.V0 / 1e3, 1), 'kN');
    o += sp.red ? eq('V_{Ed,red}', '', `w odległości t/2 + d = ${f(sp.xr, 0)} mm od osi (obciążenie na górnej powierzchni, reakcja na dolnej – podparcie bezpośrednie)`, f(sp.Vred / 1e3, 1), 'kN', '6.2.1(8)')
      : line(`Bez redukcji siły poprzecznej przy podporze${sp.redWhy ? ` – ${esc(sp.redWhy)}` : ''}: do wymiarowania V<sub>Ed</sub> = ${f(sp.Vred / 1e3, 1)} kN`, '6.2.1(8)');
    o += eq('k', '1 + √(200/d) ≤ 2,0', `1 + √(200/${f(sp.d, 0)})`, f(sp.k, 3), '') + eq('ρ_{l}', 'A_{sl}/(b_{w}·d) ≤ 0,02', `${f(sp.Asl, 0)}/(${bwS}·${f(sp.d, 0)})`, f(sp.rhol, 5), '');
    if (sp.sigcp) o += eq('σ_{cp}', 'N_{Ed}/A_{c} < 0,2·f_{cd}', '', f(sp.sigcp, 3), 'MPa');
    o += eq('V_{Rd,c}', '[C_{Rd,c}·k·(100·ρ_{l}·f_{ck})^{1/3} + k_{1}·σ_{cp}]·b_{w}·d', `[${f(sp.CRdc, 4)}·${f(sp.k, 3)}·(100·${f(sp.rhol, 5)}·${m.fck})^{1/3}${sp.sigcp ? ` + 0,15·${f(sp.sigcp, 2)}` : ''}]·${bwS}·${f(sp.d, 0)}`, f(sp.VRdc1 / 1e3, 1), 'kN', '(6.2a)');
    o += eq('V_{Rd,c,min}', '(v_{min} + k_{1}·σ_{cp})·b_{w}·d', `(${f(sp.vmin, 4)}${sp.sigcp ? ` + 0,15·${f(sp.sigcp, 2)}` : ''})·${bwS}·${f(sp.d, 0)}`, f(sp.VRdcMin / 1e3, 1), 'kN', '(6.2b)');
    o += line(sp.Vred <= sp.VRdc ? `V<sub>Ed</sub> = ${f(sp.Vred / 1e3, 1)} kN ≤ V<sub>Rd,c</sub> = ${f(sp.VRdc / 1e3, 1)} kN → wystarczy zbrojenie minimalne (w belkach zawsze stosuje się strzemiona, 9.2.2(5))` : `V<sub>Ed</sub> = ${f(sp.Vred / 1e3, 1)} kN > V<sub>Rd,c</sub> = ${f(sp.VRdc / 1e3, 1)} kN → wymagane obliczeniowe zbrojenie na ścinanie`);
    o += eq('z', '0,9·d', `0,9·${f(sp.d, 1)}`, f(sp.z, 1), 'mm') + eq('ν_{1}', '0,6·(1 − f_{ck}/250)', `0,6·(1 − ${m.fck}/250)`, f(m.nu, 3), '', '(6.6N)');
    o += eq('V_{Rd,max}', 'α_{cw}·b_{w}·z·ν_{1}·f_{cd}/(cotθ + tanθ)', `1,0·${bwS}·${f(sp.z, 1)}·${f(m.nu, 3)}·${f(m.fcd, 2)}/(${f(sh.cot, 2)} + ${f(1 / sh.cot, 3)})`, f(sp.VRdmax / 1e3, 1), 'kN', '(6.9)');
    o += tor.on ? line(`Interakcja: V<sub>Ed</sub>/V<sub>Rd,max</sub> + T<sub>Ed</sub>/T<sub>Rd,max</sub> = ${f(sp.V0 / sp.VRdmax, 3)} + ${f(st.TEd / tor.TRdmax, 3)} = <b>${f(sp.inter, 3)}</b> ≤ 1,0 <span class="${sp.inter <= 1 ? 'ok' : 'fail'}">${sp.inter <= 1 ? '✔' : '✖'}</span>`, '(6.29)') : cmp(sp.V0 / 1e3, '≤', sp.VRdmax / 1e3, 'kN', 1);
    o += eq('V_{Rd,s}(s_{1})', 'A_{sw}/s_{1}·z·f_{ywd}·cotθ' + (tor.on ? ' (pomniejszone o udział skręcania)' : ''), `${f(AswS, 1)}/${qs.s1}·${f(sp.z, 1)}·${f(m.fywd, 1)}·${f(sh.cot, 2)}`, f(sp.VRds1 / 1e3, 1), 'kN', '(6.8)');
    o += cmp(sp.Vred / 1e3, '≤', sp.VRds1 / 1e3, 'kN', 1);
    o += eq('V_{Rd,s}(s_{2})', 'A_{sw}/s_{2}·z·f_{ywd}·cotθ', `${f(AswS, 1)}/${qs.s2}·${f(sp.z, 1)}·${f(m.fywd, 1)}·${f(sh.cot, 2)}`, f(sp.VRds2 / 1e3, 1), 'kN');
    if (sp.sp) {
      o += eq('V_{Rd,s}(s_{p})', 'A_{sw}/s_{p}·z·f_{ywd}·cotθ', `${f(AswS, 1)}/${sp.sp}·${f(sp.z, 1)}·${f(m.fywd, 1)}·${f(sh.cot, 2)}`, f(sp.VRdsp / 1e3, 1), 'kN');
      o += line(`Strefa s₁ = ${qs.s1} mm wymagana na długości ${f(sp.l1req / 1000, 3)} m od lica (V<sub>Ed</sub>(x) > V<sub>Rd,s</sub>(s<sub>p</sub>)); przyjęto <b>${f(sp.l1 / 1000, 2)} m</b> <span class="${sp.l1 >= sp.l1req - 1 ? 'ok' : 'fail'}">${sp.l1 >= sp.l1req - 1 ? '✔' : '✖'}</span>; strefa pośrednia s<sub>p</sub> = ${sp.sp} mm do ${f(sp.l12req / 1000, 3)} m od lica (V<sub>Ed</sub>(x) > V<sub>Rd,s</sub>(s₂)); przyjęto <b>${f((sp.l1 + sp.lp) / 1000, 2)} m</b> <span class="${sp.l1 + sp.lp >= sp.l12req - 1 ? 'ok' : 'fail'}">${sp.l1 + sp.lp >= sp.l12req - 1 ? '✔' : '✖'}</span>; dalej s₂ = ${qs.s2} mm`);
    } else o += line(`Strefa strzemion s₁ = ${qs.s1} mm wymagana na długości ${f(sp.l1req / 1000, 3)} m od lica podpory (V<sub>Ed</sub>(x) > V<sub>Rd,s</sub>(s₂)); przyjęto <b>${f(sp.l1 / 1000, 2)} m</b> od lica <span class="${sp.l1 >= sp.l1req - 1 ? 'ok' : 'fail'}">${sp.l1 >= sp.l1req - 1 ? '✔' : '✖'}</span>`);
    const z = sp.zsh;
    if (z && z.V0 >= 1 && has(['VzMax', 'VzS', 'VzI'], sp.key)) {
      o += `<p><i>Ścinanie w płaszczyźnie Z (poziome) – przekrój „obrócony”: b<sub>w,z</sub> = h = ${f(z.bw, 0)} mm, d<sub>z</sub> = ${f(z.d, 0)} mm, nośność dają 2 poziome ramiona strzemion:</i></p>`;
      o += eq('V_{Ed,z}', '', 'w osi podpory / do strzemion', `${f(z.V0 / 1e3, 1)} / ${f(z.Vred / 1e3, 1)}`, 'kN') + eq('V_{Rd,c,z}', '', `k = ${f(z.k, 3)}, ρ_{l} = ${f(z.rhol, 5)}`, f(z.VRdc / 1e3, 1), 'kN', '(6.2)');
      o += eq('V_{Rd,max,z}', 'h·z_{z}·ν_{1}·f_{cd}/(cotθ + tanθ)', `${f(z.bw, 0)}·${f(z.zz, 1)}·${f(m.nu, 3)}·${f(m.fcd, 2)}/(${f(sh.cot, 2)} + ${f(1 / sh.cot, 3)})`, f(z.VRdmax / 1e3, 1), 'kN', '(6.9)') + cmp(z.V0 / 1e3, '≤', z.VRdmax / 1e3, 'kN', 1);
      o += eq('V_{Rd,s,z}', '2·A_{sw1}/s_{1}·z_{z}·f_{ywd}·cotθ', `2·${f(sh.A1, 1)}/${S.stir.s1}·${f(z.zz, 1)}·${f(m.fywd, 1)}·${f(sh.cot, 2)}`, f(z.VRds1 / 1e3, 1), 'kN', '(6.8)') + cmp(z.Vred / 1e3, '≤', z.VRds1 / 1e3, 'kN', 1);
      o += line(`Krzyżulce – interakcja kierunków: V<sub>Ed,y</sub>/V<sub>Rd,max,y</sub> + V<sub>Ed,z</sub>/V<sub>Rd,max,z</sub>${tor.on ? ' + T<sub>Ed</sub>/T<sub>Rd,max</sub>' : ''} = <b>${f(z.inter, 3)}</b> ≤ 1,0 <span class="${z.inter <= 1 ? 'ok' : 'fail'}">${z.inter <= 1 ? '✔' : '✖'}</span>`);
    }
  });
  if (has(['rho1', 'rho2', 'smax', 'st', 'scomp'])) o += `<h3>Wymagania konstrukcyjne dla strzemion (9.2.2, 9.2.1.2(3))</h3>`;
  if (has(['rho1', 'rho2'])) o += eq('ρ_{w,min}', '0,08·√f_{ck}/f_{ywk}', `0,08·√${m.fck}/${m.fywk}`, f(sh.rhoMin * 1000, 3), '‰', '(9.5N)');
  (sh.segs || []).forEach((z, zi) => {
    const q = z.stir || S.stir, bwz = z.seg && z.seg.g ? z.seg.g.bw : g.bw, pre = multi && z.seg ? esc(z.seg.label) + ': ' : '', at = 'st' + (z.seg ? z.seg.idx : zi);
    if (has(['rho1'], at)) o += eq('ρ_{w}(s_{1})', 'A_{sw}/(s_{1}·b_{w})', `${pre}${f(z.Asw, 1)}/(${q.s1}·${bwz})`, f(z.rho1 * 1000, 3), '‰', '', ok(z.rho1 >= sh.rhoMin));
    if (has(['rho2'], at)) o += eq('ρ_{w}(s_{2})', 'A_{sw}/(s_{2}·b_{w})', `${pre}${f(z.Asw, 1)}/(${q.s2}·${bwz})`, f(z.rho2 * 1000, 3), '‰', '', ok(z.rho2 >= sh.rhoMin));
    if (has(['st'], at) && q.legs > 1) o += eq('s_{t}', '', `${pre}rozstaw poprzeczny ramion (${q.legs}-cięte)`, f(z.st, 0), 'mm', '9.2.2(8)') + cmp(z.st, '≤', z.stMax, 'mm = min(0,75·d; 600)', 0);
  });
  const sLim = tor.on ? Math.min(sh.sMax, sh.sMaxT) : sh.sMax;
  if (has(['smax'])) o += tor.on ? eq('s_{l,max}', 'min\{0,75·d; u/8; min(b, h)\}'.replace(/\\/g, ''), `min{${f(sh.sMax, 0)}; ${f(tor.u / 8, 0)}; ${f(Math.min(g.bw, g.h), 0)}}`, f(sLim, 0), 'mm', '(9.6N), 9.2.3(3)')
    : eq('s_{l,max}', '0,75·d', '', f(sh.sMax, 0), 'mm', '(9.6N)');
  if (has(['smax'])) (sh.segs && sh.segs.length ? sh.segs : [{ stir: S.stir }]).forEach(z => { const q = z.stir || S.stir; o += cmp(Math.max(q.s1, q.s2), '≤', z.sMax && !tor.on ? z.sMax : sLim, `mm (max(s₁, s₂)${multi && z.seg ? ', ' + esc(z.seg.label) : ''})`, 0); });
  if (has(['scomp'])) (sh.segs || []).forEach(z => { if (!z.comp || !isFinite(z.comp.phi)) return; const q = z.stir || S.stir;
    o += line(`Belka ściskana siłą osiową N<sub>Ed</sub> = ${f(st.NEd / 1e3, 1)} kN (jak słup) – pręty podłużne ściskane${multi && z.seg ? ', ' + esc(z.seg.label) : ''}; strzemiona w rozstawie ≤ 15⌀ (⌀ – najmniejsza średnica prętów podłużnych):`, '9.2.1.2(3)')
      + eq('s_{max}', '15·⌀', `15·${z.comp.phi}`, f(15 * z.comp.phi, 0), 'mm') + cmp(Math.max(q.s1, q.s2, q.sp || 0), '≤', 15 * z.comp.phi, 'mm (max(s₁, s₂))', 0); });
  if (tor.on && has(['Tclosed'])) o += line(`Skręcanie: strzemiona muszą być zamknięte i zakotwione zakładem lub hakami 135° (9.2.3(1), rys. 9.6) – przyjęto: ${[...new Set(md.segs.map(sg => KIND[(sg.stir || S.stir).kind] || 'zamknięte'))].join(', ')}`, '9.2.3(1)');
  if (R.anch.ends.some(e => has(['FE'], e.e.key))) {
    o += `<h3>Zbrojenie dolne na podporach skrajnych swobodnych (9.2.1.4(2))</h3>`;
    R.anch.ends.forEach(e => {
      if (!has(['FE'], e.e.key)) return;
      o += eq('F_{E}', '|V_{Ed}|·a_{l}/z + N_{Ed}', `|V_{Ed}|·cotθ/2 = ${f(e.e.V0 / 1e3, 1)}·${f(sh.cot, 2)}/2`, f(e.FE / 1e3, 1), 'kN', e.name);
      o += eq('A_{s,req}', 'F_{E}/f_{yd}', '', f(e.AsReq, 0), 'mm²') + cmp(e.AsReq, '≤', e.AsProv, 'mm²', 0);
    });
  }
  if (tor.on && has(['T631', 'Tst', 'Tl', 'Tside'])) {
    o += `<h3>Skręcanie (6.3) – przekrój zastępczy cienkościenny b<sub>w</sub>×h</h3>`;
    o += eq('t_{ef}', 'max(A/u; 2·a)', `max(${f(tor.A, 0)}/${f(tor.u, 0)}; 2·${f(tor.aEdge, 1)})`, f(tor.tef, 1), 'mm', '6.3.2(1)');
    o += eq('A_{k}', '(b − t_{ef})·(h − t_{ef})', '', f(tor.Ak, 0), 'mm²') + eq('u_{k}', '2·[(b − t_{ef}) + (h − t_{ef})]', '', f(tor.uk, 0), 'mm');
    o += eq('T_{Rd,c}', '2·A_{k}·t_{ef}·f_{ctd}', '', f(tor.TRdc / 1e6, 2), 'kNm') + line(`T<sub>Ed</sub>/T<sub>Rd,c</sub> + V<sub>Ed</sub>/V<sub>Rd,c</sub> = ${f(tor.cond631, 3)} ${tor.cond631 <= 1 ? '≤ 1 → wystarczy zbrojenie minimalne' : '> 1 → wymagane zbrojenie obliczeniowe'}`, '(6.31)');
    o += eq('T_{Rd,max}', '2·ν·α_{cw}·f_{cd}·A_{k}·t_{ef}·sinθ·cosθ', '', f(tor.TRdmax / 1e6, 2), 'kNm', '(6.30)');
    o += eq('A_{sw,T}/s', 'T_{Ed}/(2·A_{k}·f_{ywd}·cotθ)', '', f(tor.tReq, 4), 'mm²/mm (1 gałąź)', '(6.28)');
    o += line(`Wymagane A<sub>sw1</sub>/s (ścinanie + skręcanie, gałąź zewnętrzna, strefa s₁) = ${f(tor.legReq1, 4)} mm²/mm ≤ ${f(tor.legProv1, 4)} mm²/mm <span class="${tor.legReq1 <= tor.legProv1 ? 'ok' : 'fail'}">${tor.legReq1 <= tor.legProv1 ? '✔' : '✖'}</span>`);
    o += eq('ΣA_{sl}', 'T_{Ed}·u_{k}·cotθ/(2·A_{k}·f_{yd})', '', f(tor.AslReq, 0), 'mm²', '(6.28)') + line(`Rozdział: na krawędź górną i dolną po ${f(tor.AslTB, 0)} mm², na każdy bok ${f(tor.AslSide, 0)} mm²; rozstaw strzemion ≤ u/8 = ${f(tor.u / 8, 0)} mm (9.2.3(3)).`);
    if (has(['Tside'])) o += cmp(tor.AslSide, '≤', S.reb.mid.n * Math.PI * S.reb.mid.d * S.reb.mid.d / 4, `mm² (pręty boczne przy każdym boku: ${S.reb.mid.n ? S.reb.mid.n + '⌀' + S.reb.mid.d : 'brak'})`, 0);
  }
  R.flanges.forEach(fl => {
    if (!has(['fl1', 'fl2'], fl.sec.key)) return;
    o += `<h3>Ścinanie między środnikiem a półką (6.2.4)${multi ? ' – ' + esc(fl.sec.loc) : ''}</h3>`;
    o += eq('Δx', '0,5·(odległość między M = 0 i M_{max})', `0,5·${f(fl.dist, 0)}`, f(fl.dx, 0), 'mm') + eq('ΔF_{d}', 'M_{Ed}/z·b_{e,i}/b_{eff}', `${f(fl.sec.MEd / 1e6, 1)}·10^{6}/${f(fl.z, 0)}·${f(fl.bei, 0)}/${f(g.beff, 0)}`, f(fl.dF / 1e3, 1), 'kN');
    o += eq('v_{Ed}', 'ΔF_{d}/(h_{f}·Δx)', '', f(fl.vEd, 3), 'MPa', '(6.20)') + line(`v<sub>Ed</sub> ${fl.vEd <= fl.vLim ? '≤' : '>'} k·f<sub>ctd</sub> = 0,4·${f(m.fctd, 3)} = ${f(fl.vLim, 3)} MPa`, '6.2.4(6)');
    o += eq('v_{Rd,max}', 'ν·f_{cd}·sinθ_{f}·cosθ_{f}', `cotθ_{f} = ${f(fl.cot, 2)}`, f(fl.vRdmax, 3), 'MPa', '(6.22)', ok(fl.vEd <= fl.vRdmax));
    o += eq('A_{sf}/s_{f}', 'v_{Ed}·h_{f}/(f_{yd}·cotθ_{f})', '', f(fl.AsfReq * 1000, 0), 'mm²/m', '(6.21)') + line(`Przyjęto ⌀${S.stir.ffd} co ${S.stir.ffs} mm = ${f(fl.AsfProv * 1000, 0)} mm²/m <span class="${fl.AsfProv >= fl.AsfReq ? 'ok' : 'fail'}">${fl.AsfProv >= fl.AsfReq ? '✔' : '✖'}</span>`);
  });
  }

  /* ---------------- sytuacja wyjątkowa */
  const accT = ticked.filter(c => c.id.startsWith('A_'));
  if (R.accR && !R.accR.errors.length && accT.length) {
    const A = R.accR, mA = A.m;
    o += H2('SGN – sytuacja wyjątkowa (PN-EN 1990, 6.11b)');
    o += line(`Współczynniki materiałowe dla sytuacji wyjątkowej (tab. 2.1N): γ<sub>c</sub> = ${f(mA.gc, 2)}, γ<sub>s</sub> = ${f(mA.gs, 2)} → f<sub>cd</sub> = ${f(mA.fcd, 2)} MPa, f<sub>yd</sub> = ${f(mA.fyd, 1)} MPa, f<sub>ywd</sub> = ${f(mA.fywd, 1)} MPa`, '2.4.2.4');
    accT.forEach(c => { o += line(`${sym(c.name)}: ${U.ckCond(c)}${c.status === 'info' || !isFinite(c.ratio) ? '' : `, η = ${f(c.ratio * 100, 0)}%`} <span class="${c.status}">${U.STL[c.status]}</span>`, c.ref); });
  }

  /* ---------------- 7. zakotwienia */
  const an = R.anch;
  const rowsT = an.rows.filter(r => has(['lap'], 'r' + r.name));
  const tcT = (an.topCut || []).filter(tc => has(['topLen', 'Msupp'], 'p' + tc.sup.idx) || has(['Msupp'], tc.sup.sec ? tc.sup.sec.key : '-'));
  const bcT = (an.botCut || []).filter(bc => has(['Mspan'], 's' + bc.seg.idx));
  const show7 = rowsT.length || an.ends.some(e => has(['lbd'], e.e.key)) || (an.endsTop || []).some(e => has(['lbdT'], 'p' + e.sup.idx)) || (an.inner || []).some(q => has(['inner'], 'p' + q.sup.idx)) || tcT.length || bcT.length;
  if (show7) {
  o += H2('Zakotwienie i zakłady prętów (8.4, 8.7)');
  if (rowsT.length) o += eq('f_{bd}', '2,25·η_{1}·η_{2}·f_{ctd}', `f_{ctd} = ${f(m.fctdBond, 3)} MPa (≤ C60/75)`, '', '', '(8.2)');
  rowsT.forEach(r => { o += line(`${r.name}: η₁ = ${f(r.eta1, 1)}, f<sub>bd</sub> = ${f(r.fbd, 2)} MPa, σ<sub>sd</sub> = ${f(r.sigma, 0)} MPa, l<sub>b,rqd</sub> = ⌀/4·σ<sub>sd</sub>/f<sub>bd</sub> = ${f(r.lbrqd, 0)} mm, c<sub>d</sub> = ${f(r.cd, 1)} mm, α₁ = ${f(r.al1, 2)}, α₂ = ${f(r.al2, 3)}, l<sub>b,min</sub> = ${f(r.lbmin, 0)} mm → <b>l<sub>bd</sub> = ${f(r.lbd, 0)} mm</b>; l<sub>0,min</sub> = ${f(r.l0min, 0)} mm → <b>l<sub>0</sub> = ${f(r.l0, 0)} mm</b> (α₆ = ${an.alpha6})`, '8.4.3, 8.7.3'); });
  if (rowsT.length) o += `<p class="note">l<sub>bd</sub> = α₁·α₂·α₃·α₄·α₅·l<sub>b,rqd</sub> ≥ l<sub>b,min</sub> (8.4); l<sub>0</sub> = α₁·α₂·α₃·α₅·α₆·l<sub>b,rqd</sub> ≥ l<sub>0,min</sub> (8.10). Przyjęto bezpiecznie α₃ = α₄ = 1,0; α₅ = 1,0 (poza podporami).</p>`;
  an.ends.forEach(e => {
    if (!has(['lbd'], e.e.key)) return;
    o += line(`${esc(cap(e.name))} – pręty dolne ⌀${e.dia}: σ<sub>sd</sub> = F<sub>E</sub>/A<sub>s</sub> = ${f(e.FE / 1e3, 1)}·10³/${f(e.AsProv, 0)} = ${f(e.sig, 1)} MPa; docisk p = ${f(e.r.p, 2)} MPa → α₅ = ${f(e.r.al5, 3)}; l<sub>bd</sub> = <b>${f(e.lbd, 0)} mm</b> ${e.lbd <= e.avail ? '≤' : '>'} t − c<sub>nom</sub> = ${f(e.avail, 0)} mm ` +
      (e.bent ? `→ pręty <b>odgięte do góry</b>: l<sub>bd</sub> z odgięciem (α₁ = ${f(e.rh.al1, 2)}) = ${f(e.lbdHook, 0)} mm, odcinek pionowy ${e.leg} mm ≥ max(l<sub>bd</sub> − (t − c<sub>nom</sub>); 5⌀) <span class="${e.okBent ? 'ok' : 'fail'}">${e.okBent ? '✔' : `✖ odgięcie > ${f(e.legMax, 0)} mm (wysokość belki)`}</span>` : '<span class="ok">✔ pręty proste</span>'), '9.2.1.4(3), 8.4.4');
    if (e.bent) o += line(`Gięcie prętów ⌀${e.dia}: φ<sub>m,min</sub> = ${e.dia <= 16 ? '4' : '7'}⌀ = ${f(e.phmMin, 0)} mm (tab. 8.1N); miażdżenie betonu w zgięciu: F<sub>bt</sub> = ${f(e.Fbt / 1e3, 1)} kN, a<sub>b</sub> = ${f(e.ab, 0)} mm → φ<sub>m,min</sub> = F<sub>bt</sub>·(1/a<sub>b</sub> + 1/(2⌀))/f<sub>cd</sub> = ${f(e.phmReq, 0)} mm (8.1); przyjęto <b>φ<sub>m</sub> = ${f(e.phm, 0)} mm</b> (promień wewnętrzny ${f(e.phm / 2, 0)} mm) <span class="${e.phm >= Math.max(e.phmMin, e.phmReq) - 1e-6 ? 'ok' : 'fail'}">${e.phm >= Math.max(e.phmMin, e.phmReq) - 1e-6 ? '✔' : '✖'}</span>`, '8.3(2), 8.3(3)');
  });
  (an.endsTop || []).forEach(e => {
    if (!has(['lbdT'], 'p' + e.sup.idx)) return;
    o += line(`${esc(cap(e.name))} (podpora sztywna) – pręty górne ⌀${e.dia}: σ<sub>sd</sub> = ${f(e.sig, 0)} MPa, przyczepność ${e.bond === 'good' ? 'dobra' : 'średnia'}; l<sub>bd</sub> = <b>${f(e.lbd, 0)} mm</b> ${e.lbd <= e.avail ? '≤' : '>'} t − c<sub>nom</sub> = ${f(e.avail, 0)} mm ` +
      (e.bent ? `→ pręty <b>odgięte w dół, w podporę</b>: l<sub>bd</sub> z odgięciem (α₁ = ${f(e.rh.al1, 2)}) = ${f(e.lbdHook, 0)} mm, odcinek pionowy ${e.leg} mm <span class="ok">✔</span>; gięcie na trzpieniu φ<sub>m</sub> = <b>${f(e.phm, 0)} mm</b> (tab. 8.1N: ${f(e.phmMin, 0)} mm; 8.3(3): ${f(e.phmReq, 0)} mm)` : '<span class="ok">✔ pręty proste</span>'), '8.4.4, 9.2.1.2');
  });
  (an.inner || []).filter(q => has(['inner'], 'p' + q.sup.idx)).forEach(q => o += line(`${esc(cap(q.sup.name))} (pośrednia): pręty dolne przedłużone za lico o ≥ 10⌀ = ${f(q.l, 0)} mm (pręty proste) lub ciągłe / łączone na zakład`, '9.2.1.5(1)'));
  tcT.forEach(tc => {
    const sd = tc.sides.filter(q => !q.none).map(q => q.cant ? `${q.side === 'L' ? 'w lewo' : 'w prawo'} – na całym wsporniku ${f(q.len, 0)} mm` : `${q.side === 'L' ? 'w lewo' : 'w prawo'}: ${tc.noHog ? `≥ t/2 + 0,2·L = ${f(q.minEnd, 0)} mm (9.2.1.2(1))` : `x = ${f(q.x0, 0)} + a<sub>l</sub> ${f(q.aL, 0)} + l<sub>bd</sub> ${f(q.lbd, 0)}${q.minEnd ? `, ≥ t/2 + 0,2·L = ${f(q.minEnd, 0)}` : ''} → ${f(q.lenReq, 0)} mm`}${q.manual ? `; przyjęto ręcznie <b>${f(q.len, 0)} mm</b> <span class="${q.len >= q.lenReq - 1 ? 'ok' : 'fail'}">${q.len >= q.lenReq - 1 ? '✔' : '✖ za krótkie'}</span>` : ` → <b>${f(q.len, 0)} mm</b>`}${q.full ? ' (całe przęsło)' : ''}`).join('; ');
    o += line(`Pręty górne dodatkowe – ${esc(tc.sup.name)} (${tc.sup.LtX ? tc.sup.LtX.desc : ''}): ${tc.noHog ? 'brak momentu ujemnego – długość konstrukcyjna' : `zbędne obliczeniowo tam, gdzie |M<sub>Ed</sub>| ≤ M<sub>Rd</sub> prętów ciągłych = ${f(tc.MRdMont / 1e6, 1)} kNm`}; długości od osi podpory – ${sd}`, '9.2.1.3');
  });
  bcT.forEach(bc => {
    o += bc.none
      ? line(`${esc(cap(bc.seg.label))}: pręty dolne nie doprowadzone do podpór nie są potrzebne obliczeniowo (M<sub>Rd</sub> prętów doprowadzonych = ${f(bc.MRdS / 1e6, 1)} kNm ≥ M<sub>Ed</sub>); przyjęto długość minimalną 2·(a<sub>l</sub> + l<sub>bd</sub>) → ${f(bc.len / 1000, 2)} m`, '9.2.1.3')
      : line(`${esc(cap(bc.seg.label))}: pręty dolne nie doprowadzone do podpór potrzebne między x = ${f(bc.xa / 1000, 2)} a ${f(bc.xb / 1000, 2)} m (M<sub>Ed</sub> > M<sub>Rd</sub> = ${f(bc.MRdS / 1e6, 1)} kNm prętów doprowadzonych), przedłużone o a<sub>l</sub> + l<sub>bd</sub> = ${f(bc.aL + bc.lbd, 0)} mm → długość ${f(bc.len / 1000, 2)} m`, '9.2.1.3');
  });
  }

  /* ---------------- wymagania konstrukcyjne */
  const ids8 = ['asmin', 'asmax', 'sp', 'vib', 'phin', 'midsp', 'lat', 'skin', 'surf0', 'surf', 'surft', 'surfs'];
  if (has(ids8)) {
  o += H2('Wymagania konstrukcyjne');
  R.secs.forEach(sec => {
    const rs = sec.sls; if (!rs || !has(['asmin'], sec.key)) return;
    o += eq('A_{s,min}', 'max(0,26·f_{ctm}/f_{yk}·b_{t}·d; 0,0013·b_{t}·d)', `${esc(sec.loc)}: max(0,26·${f(m.fctm, 2)}/${m.fyk}·${f(rs.bt, 0)}·${f(rs.d, 0)}; 0,0013·${f(rs.bt, 0)}·${f(rs.d, 0)})`, f(rs.AsMin, 0), 'mm²', '(9.1N)') + cmp(rs.AsMin, '≤', sec.tens.A, 'mm²', 0);
  });
  if (has(['asmax'])) { const c = R.checks.find(q => q.id === 'asmax'); o += eq('A_{s,max}', '0,04·A_{c}', `0,04·${f(g.Ac, 0)}`, f(0.04 * g.Ac, 0), 'mm²', '9.2.1.1(3)') + cmp(c.Ed, '≤', c.Rd, 'mm² (całkowite zbrojenie podłużne)', 0); }
  const lays = [];
  md.segs.forEach(sg => { if (sg.kind === 'span') lays.push([`dolnych – ${sg.label}`, sg.Lb, 'L' + sg.idx]); });
  lays.push(['górnych ciągłych', R.LtM, 'LtM']);
  md.sups.forEach(p => { if (p.hasX) lays.push([`górnych – ${p.name}`, p.LtS, 'T' + p.idx]); });
  lays.forEach(([n, lay, key]) => {
    if (!lay || !lay.n) return;
    if (has(['sp'], key)) lay.layers.forEach((ly, i) => { if (ly.n > 1) o += line(`Prześwit między ${lay.bars.some(q => q.nb > 1) ? 'wiązkami' : 'prętami'} ${esc(n)}, warstwa ${i + 1} (${ly.n} szt.${ly.aligned ? ', nad prętami warstwy 1' : ''}): a = ${f(ly.gap, 1)} mm ${ly.gap >= ly.smin ? '≥' : '<'} s<sub>min</sub> = max(⌀; d<sub>g</sub> + 5; 20) = ${f(ly.smin, 0)} mm <span class="${ly.ok ? 'ok' : 'fail'}">${ly.ok ? '✔' : '✖'}</span>`, '8.2(2)'); });
    if (has(['vib'], key)) o += line(`Prześwit na buławę wibratora ⌀${S.reb.vib} mm – pręty ${esc(n)}: największy prześwit ${f(lay.open, 0)} mm ${lay.open >= S.reb.vib + 10 ? '≥' : '<'} ${S.reb.vib} + 10 = ${S.reb.vib + 10} mm <span class="${lay.open >= S.reb.vib + 10 ? 'ok' : 'warn'}">${lay.open >= S.reb.vib + 10 ? '✔' : '⚠ utrudnione zagęszczanie'}</span>`, '8.2(4)');
  });
  if (has(['phin'])) { const c = R.checks.find(q => q.id === 'phin'); o += line(`Wiązki prętów: ⌀<sub>n</sub> = ⌀·√n<sub>b</sub> = ${f(c.Ed, 1)} mm ≤ 55 mm <span class="ok">✔</span>; ${esc(c.note)}`, '8.9.1'); }
  if (has(['midsp'])) { const c = R.checks.find(q => q.id === 'midsp'); o += line(`${sym(c.name)}: ${f(c.Rd, 0)} mm ${c.Rd >= c.Ed ? '≥' : '<'} s<sub>min</sub> = ${f(c.Ed, 0)} mm <span class="${c.status}">${c.status === 'ok' ? '✔' : '✖'}</span>`, '8.2(2)'); }
  if (has(['skin'])) { const c = R.checks.find(q => q.id === 'skin'); o += eq('A_{s,boczne}', 'k_{c}·k·f_{ct,eff}·A_{ct}/f_{yk}', `0,4·0,5·${f(m.fctm, 2)}·A_{ct}/${m.fyk}`, f(c.Ed, 0), 'mm²', '7.3.3(3)') + cmp(c.Ed, '≤', c.Rd, 'mm² (pręty boczne w strefie rozciąganej)', 0); }
  const lat = R.checks.find(c => c.id === 'lat');
  if (lat && has(['lat'])) o += line(`Zwichrzenie: l<sub>0t</sub>/b = ${f(lat.Ed, 1)} ≤ 50/(h/b)<sup>1/3</sup> = ${f(lat.Rd, 1)}; ${esc(lat.note)} <span class="${lat.status}">${lat.status === 'ok' ? '✔' : '⚠'}</span>`, '5.9(3)');
  const sf = R.surf;
  if (has(['surf0', 'surf', 'surft', 'surfs'])) {
  o += `<h3>Zbrojenie przypowierzchniowe (9.2.4, zał. J.1)</h3>`;
  if (!sf.req) o += line(`Nie jest wymagane: największa średnica pręta / zastępcza wiązki ⌀ = ${f(sf.dmax, 1)} mm ≤ 32 mm oraz c<sub>nom</sub> = ${sf.cnom} mm ≤ 70 mm.`, '9.2.4');
  else if (sf.gov) {
    const q = sf.gov;
    o += line(`Wymagane: ${[sf.byBar ? `⌀ = ${f(sf.dmax, 1)} mm > 32 mm` : '', sf.byCover ? `c<sub>nom</sub> = ${sf.cnom} mm > 70 mm` : ''].filter(Boolean).join('; ')} – siatka na zewnątrz strzemion, oczko ≤ 150 mm.`, '9.2.4');
    o += eq('A_{ct,ext}', 'b_{w}·c_{nom} + 2·c_{nom}·(h − x − c_{nom})', `${g.bw}·${sf.cnom} + 2·${sf.cnom}·(${g.h} − ${f(q.x, 0)} − ${sf.cnom}) – ${esc(q.sec.loc)}`, f(q.Act, 0), 'mm²', 'J.1');
    if (has(['surf'])) o += eq('A_{s,surf,req}', `${sf.rho === 0.01 ? '0,01' : '0,005'}·A_{ct,ext}`, '', f(sf.AsReq, 0), 'mm²') + eq('A_{s,surf,prov}', `⌀${S.surf.d} co ${S.surf.s} mm na obwodzie strefy rozciąganej ${f(q.per, 0)} mm`, '', f(sf.AsProv, 0), 'mm²') + cmp(sf.AsReq, '≤', sf.AsProv, 'mm² (w obu kierunkach)', 0);
    if (has(['surft'])) o += eq('a_{s,surf,⊥}', `${sf.rho === 0.01 ? '0,01' : '0,005'}·c_{nom}·1000`, '', f(sf.perMReq, 0), 'mm²/m') + cmp(sf.perMReq, '≤', sf.perM, `mm²/m (pręty poprzeczne ⌀${S.surf.d} co ${S.surf.s} mm)`, 0);
    if (has(['surfs'])) o += cmp(S.surf.s, '≤', 150, 'mm (oczko siatki)', 0);
  }
  }
  }

  /* ---------------- 9. SGU */
  const sl = R.sls, cs = sl.cs;
  const showSLS = has(['sck', 'scqp', 'ssk', 'ascr', 'wk', 'f', 'ld', 'fz']);
  if (showSLS) {
  o += H2('SGU – parametry reologiczne (zał. B)');
  o += eq('h_{0}', '2·A_{c}/u', `2·${f(g.Ac, 0)}/${f(g.u, 0)}`, f(cs.h0, 1), 'mm') + line(`RH = ${cs.RH}%, t<sub>0</sub> = ${cs.t0} dni, cement klasy ${cs.cem}, t = ${cs.tInf ? '∞' : f(cs.t, 0) + ' dni'}`);
  o += eq('φ_{RH}', m.fcm <= 35 ? '1 + (1 − RH/100)/(0,1·h_{0}^{1/3})' : '[1 + (1 − RH/100)/(0,1·h_{0}^{1/3})·α_{1}]·α_{2}', '', f(cs.phiRH, 3), '', '(B.3)');
  o += eq('β(f_{cm})', '16,8/√f_{cm}', '', f(cs.bfcm, 3), '', '(B.4)') + eq('β(t_{0})', '1/(0,1 + t_{0,adj}^{0,20})', `t_{0,adj} = ${f(cs.t0adj, 2)}`, f(cs.bt0, 3), '', '(B.5, B.9)');
  o += eq('φ_{0}', 'φ_{RH}·β(f_{cm})·β(t_{0})', '', f(cs.phi0, 3), '') + (cs.tInf ? '' : eq('β_{c}(t,t_{0})', '', `β_{H} = ${f(cs.betaH, 0)}`, f(cs.bc, 3), ''));
  o += S.sls.phiSel === 'off' ? eq('φ(t,t_{0})', 'pełzanie pominięte (wybór użytkownika)', '', '0', '', '') : eq('φ(t,t_{0})', S.sls.phiSel === 'manual' ? 'przyjęto ręcznie' : 'φ_{0}·β_{c}(t,t_{0})', '', f(cs.phi, 3), '', '(B.1)');
  if (sl.phiNL) o += line(`σ<sub>c,qp</sub>/f<sub>ck</sub> = ${f(sl.ksig, 3)} > 0,45 → pełzanie nieliniowe: φ<sub>nl</sub> = φ·exp(1,5·(k<sub>σ</sub> − 0,45)) = <b>${f(sl.phiNL, 3)}</b>`, '(3.7)');
  o += eq('ε_{cd,0}', '0,85·[(220 + 110·α_{ds1})·exp(−α_{ds2}·f_{cm}/f_{cm0})]·10^{−6}·β_{RH}', `β_{RH} = ${f(cs.betaRH, 3)}`, f(cs.ecd0 * 1e6, 1) + '·10<sup>−6</sup>', '', '(B.11)');
  o += eq('ε_{cd}', 'β_{ds}·k_{h}·ε_{cd,0}', `${f(cs.bds, 3)}·${f(cs.kh, 3)}·${f(cs.ecd0 * 1e6, 1)}·10^{−6}`, f(cs.ecd * 1e6, 1) + '·10<sup>−6</sup>', '', '(3.9)');
  o += eq('ε_{ca}', 'β_{as}·2,5·(f_{ck} − 10)·10^{−6}', '', f(cs.eca * 1e6, 1) + '·10<sup>−6</sup>', '', '(3.11, 3.12)') + eq('ε_{cs}', 'ε_{cd} + ε_{ca}', '', f(cs.ecs * 1e6, 1) + '·10<sup>−6</sup>', '', '(3.8)');
  o += eq('E_{c,eff}', 'E_{cm}/(1 + φ)', `${f(m.Ecm, 0)}/(1 + ${f(cs.phi, 3)})`, f(sl.Eeff, 0), 'MPa', '(7.20)') + eq('α_{e}', 'E_{s}/E_{cm}', '', f(sl.aeS, 3), '') + eq('α_{e,t}', 'E_{s}/E_{c,eff}', '', f(sl.aeL, 3), '');
  }

  if (has(['sck', 'scqp', 'ssk'])) o += H2('SGU – naprężenia (7.2)');
  R.secs.forEach(sec => {
    const r = sec.sls, nm = esc(cap(sec.loc));
    if (!r || r.Mk <= 0 || !has(['sck', 'scqp', 'ssk'], sec.key)) return;
    o += `<h3>${nm}: M<sub>Ek</sub> = ${f(r.Mk / 1e6, 2)} kNm, M<sub>Eqp</sub> = ${f(r.Mqp / 1e6, 2)} kNm</h3>`;
    o += eq('M_{cr}', 'f_{ctm}·I_{I}/(h − x_{I})', `${f(m.fctm, 2)}·${f(r.unS.I / 1e8, 1)}·10^{8}/(${g.h} − ${f(r.unS.yc, 1)})`, f(r.Mcr / 1e6, 2), 'kNm');
    o += line(`Przekrój w fazie II (bez betonu rozciąganego): x<sub>II</sub> = ${f(r.crS.x, 1)} mm (α<sub>e</sub>), ${f(r.crL.x, 1)} mm (α<sub>e,t</sub>); I<sub>II</sub> = ${f(r.crS.I / 1e8, 1)}·10⁸ / ${f(r.crL.I / 1e8, 1)}·10⁸ mm⁴`);
    o += eq('σ_{c}', 'M_{Ek}·x_{II}/I_{II}', '(obwiednia α_{e} / α_{e,t})', f(r.sc_k, 2), 'MPa') + cmp(r.sc_k, '≤', S.coef.k1 * m.fck, `MPa = k₁·f<sub>ck</sub>${sl.k1lim ? '' : ' (informacyjnie – wymagane dla XD/XF/XS)'}`, 2);
    o += eq('σ_{c,qp}', '', 'przy obciążeniu quasi-stałym, α_{e}', f(r.sc_qp, 2), 'MPa') + cmp(r.sc_qp, '≤', S.coef.k2 * m.fck, 'MPa = k₂·f<sub>ck</sub>', 2);
    o += eq('σ_{s}', 'α_{e}·M_{Ek}·(d − x_{II})/I_{II}', '', f(r.ss_k, 1), 'MPa') + cmp(r.ss_k, '≤', S.coef.k3 * m.fyk, 'MPa = k₃·f<sub>yk</sub>', 1);
    if (r.biax) o += line(`Uwzględniono zginanie ukośne (M<sub>y</sub> + M<sub>z</sub>): naprężenia z analizy sprężystej przekroju zarysowanego (beton nie przenosi rozciągania, oś obojętna ukośna) – wartości maksymalne w narożach.`);
  });

  if (has(['ascr', 'wk'])) o += H2('SGU – zarysowanie (7.3)');
  R.secs.forEach(sec => {
    const r = sec.sls, nm = esc(cap(sec.loc));
    if (!r || r.Mk <= 0 || !has(['ascr', 'wk'], sec.key)) return;
    const w = r.w, a = r.asmin;
    o += `<h3>${nm}</h3>`;
    o += eq('k', '', `h = ${g.h} mm`, f(a.k, 3), '', '7.3.2(2)');
    a.parts.forEach(p => { o += line(`${p.name}: k<sub>c</sub> = ${f(p.kc, 3)}, A<sub>ct</sub> = ${f(p.Act, 0)} mm²`); });
    o += eq('A_{s,min}', 'Σk_{c}·k·f_{ct,eff}·A_{ct}/σ_{s}', `σ_{s} = f_{yk} = ${m.fyk} MPa`, f(a.As, 0), 'mm²', '(7.1)') + cmp(a.As, '≤', r.AsProv, 'mm²', 0);
    if (!r.crackedQP) { o += line(`M<sub>Eqp</sub> = ${f(r.Mqp / 1e6, 2)} kNm ≤ M<sub>cr</sub> = ${f(r.Mcr / 1e6, 2)} kNm → przekrój niezarysowany pod obciążeniem quasi-stałym, w<sub>k</sub> = 0`); return; }
    o += eq('h_{c,ef}', 'min\\{2,5·(h − d); (h − x)/3; h/2\\}'.replace(/\\/g, ''), `min{${f(2.5 * (g.h - r.d), 1)}; ${f((g.h - w.x) / 3, 1)}; ${f(g.h / 2, 1)}}`, f(w.hcef, 1), 'mm', '7.3.2(3)');
    o += eq('ρ_{p,eff}', 'A_{s}/A_{c,eff}', `${f(w.As, 0)}/${f(w.Aceff, 0)}`, f(w.rho, 5), '', '(7.10)');
    o += eq('σ_{s}', '', `M_{Eqp} = ${f(r.Mqp / 1e6, 2)} kNm, faza II, α_{e,t}`, f(w.ss, 1), 'MPa');
    o += eq('ε_{sm} − ε_{cm}', '[σ_{s} − k_{t}·f_{ct,eff}/ρ_{p,eff}·(1 + α_{e}·ρ_{p,eff})]/E_{s} ≥ 0,6·σ_{s}/E_{s}', `max{${f(w.eps1 * 1e3, 4)}; ${f(w.eps2 * 1e3, 4)}}‰`, f(w.eps * 1e3, 4), '‰', '(7.9)');
    o += eq('⌀_{eq}', '', '', f(w.phiEq, 1), 'mm') + eq('c', 'c_{nom} + ⌀_{w}', '', f(w.c, 0), 'mm');
    o += w.wide ? eq('s_{r,max}', '1,3·(h − x)', `rozstaw ${f(w.spacing, 0)} mm > 5·(c + ⌀/2) = ${f(w.spLim, 0)} mm`, f(w.sr, 1), 'mm', '(7.14)')
      : eq('s_{r,max}', 'k_{3}·c + k_{1}·k_{2}·k_{4}·⌀/ρ_{p,eff}', `3,4·${f(w.c, 0)} + 0,8·0,5·0,425·${f(w.phiEq, 1)}/${f(w.rho, 5)}`, f(w.sr, 1), 'mm', '(7.11)');
    o += eq('w_{k}', 's_{r,max}·(ε_{sm} − ε_{cm})', '', f(w.wk, 3), 'mm', '(7.8)') + cmp(w.wk, '≤', sl.wmax, 'mm = w<sub>max</sub> (tab. 7.1N)', 3);
    o += `<p class="note">Kontrola bez bezpośredniego obliczania (informacyjnie): przy σ<sub>s</sub> = ${f(w.ss, 0)} MPa – ⌀*<sub>s</sub> = ${f(w.phiStar, 0)} mm (tab. 7.2N), ⌀<sub>s,max</sub> = ${f(w.phiMax, 1)} mm (7.6N); s<sub>max</sub> = ${f(w.sMaxT, 0)} mm (tab. 7.3N).</p>`;
  });

  const d = sl.defl;
  const spF = d.spans.filter(q => has(['f'], 'd' + q.seg.idx));
  if (has(['f', 'ld', 'fz'])) o += H2('SGU – ugięcia (7.4)');
  if (spF.length) {
  o += `<h3>Metoda dokładna – całkowanie krzywizn (7.4.3)</h3>`;
  o += line(`Krzywizna od obciążenia: 1/r = ζ·M/(E<sub>c,eff</sub>·I<sub>II</sub>) + (1 − ζ)·M/(E<sub>c,eff</sub>·I<sub>I</sub>), ζ = 1 − β·(M<sub>cr</sub>/M)², β = 0,5`, '(7.18, 7.19)');
  o += line(`Krzywizna od skurczu: 1/r<sub>cs</sub> = ε<sub>cs</sub>·α<sub>e,t</sub>·S/I (interpolacja ζ jak wyżej)`, '(7.21)');
  const prow = (nm, p) => [nm, f(p.I1 / 1e8, 2), f(p.I2 / 1e8, 2), f(p.Mcr / 1e6, 1), f(p.k1cs * 1e6, 3), f(p.k2cs * 1e6, 3)];
  md.segs.map((sg, i) => prow(`${esc(cap(sg.label))} (M > 0)`, d.pS[i])).concat(md.sups.filter(p => p.sec).map(p => prow(`${esc(cap(p.name))} (M < 0)`, d.pH[p.idx]))).forEach(r => { o += line(`${r[0]}: I<sub>I</sub> = ${r[1]}·10⁸ mm⁴, I<sub>II</sub> = ${r[2]}·10⁸ mm⁴, M<sub>cr</sub> = ${r[3]} kNm, 1/r<sub>cs,I</sub> = ${r[4]}·10⁻⁶/mm, 1/r<sub>cs,II</sub> = ${r[5]}·10⁻⁶/mm`); });
  o += `<p class="note">${st.manual ? 'Ugięcie w środku przęsła względem cięciwy podpór wyznaczono z twierdzenia redukcyjnego (całkowanie numeryczne krzywizn).' : 'Linię ugięcia wyznaczono MES z iteracyjną aktualizacją sztywności siecznej elementów (uwzględnia redystrybucję momentów od zarysowania w układach statycznie niewyznaczalnych).'}${d.patterned ? ' Obciążenia zmienne (część quasi-stała) przyłożono na przęsłach naprzemiennych – dla każdego przęsła przyjęto układ dający jego największe ugięcie.' : ''}</p>`;
  spF.forEach(q => {
    const w0 = q.camber > 0 && q.camberUse ? q.camber : 0, fe = q.tot.f - w0, okF = fe <= q.lim + 1e-9;
    o += line(`${esc(cap(q.label))}${q.seg.kind !== 'span' ? ' (L<sub>ref</sub> = 2·l)' : ''}: f<sub>qp</sub> = ${f(q.load.f, 2)} mm, f<sub>cs</sub> = ${f(q.cs, 2)} mm → f = f<sub>qp</sub> + f<sub>cs</sub> = <b>${f(q.tot.f, 2)} mm</b>`
      + (w0 ? `; odwrotna strzałka w<sub>0</sub> = ${f(w0, 0)} mm → f − w<sub>0</sub> = <b>${f(fe, 2)} mm</b>` : '') + ` ${okF ? '≤' : '>'} f<sub>lim</sub> = L<sub>ref</sub>/${S.sls.lim} = ${f(q.lim, 2)} mm ${okF ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>'}`, '7.4.1');
    if (q.camber > 0) o += line(`Odwrotna strzałka (podniesienie deskowania) w<sub>0</sub> = ${f(q.camber, 0)} mm ${q.camber <= q.w0max + 1e-9 ? '≤' : '>'} L<sub>ref</sub>/250 = ${f(q.w0max, 1)} mm ${q.camber <= q.w0max + 1e-9 ? '<span class="ok">✔</span>' : '<span class="fail">✖</span>'}`
      + (q.camberUse ? ' – kompensuje ugięcie od obciążeń quasi-stałych (wygląd i ogólna użytkowalność)' : ` – przy ugięciu granicznym L/${S.sls.lim} (ugięcie po wykonaniu elementów wrażliwych, 7.4.1(5)) strzałka odwrotna nie zmniejsza ugięcia`), '7.4.1(4)');
  });
  o += `<p class="note">Ugięcie graniczne L/${S.sls.lim}: L/250 – wygląd i ogólna użytkowalność (7.4.1(4)); L/500 – ugięcie po wykonaniu elementów wrażliwych na uszkodzenia (7.4.1(5)).</p>`;
  spF.forEach(q => { if (q.ch) o += line(`${esc(cap(q.label))}: ugięcie natychmiastowe od obciążenia charakterystycznego (E<sub>cm</sub>, ${esc(d.chName || '')}): ${f(q.ch.f, 2)} mm (informacyjnie).`); });
  o += `<div class="fig">${U.lineChart({ W: 900, H: 190, title: 'Linia ugięcia w(x) [mm]', yl: 'w [mm]', series: [{ x: d.x.map(v => v / 1000), y: d.w, c: '#1d5bb8', l: 'w(x)', w: 1.8, fill: 'rgba(29,91,184,.08)' }].concat(d.wz && d.wz.some(v => v > 1e-3) ? [{ x: d.x.map(v => v / 1000), y: d.wz.map(v => -v), c: '#1d7f3c', l: '|w_z(x)|', w: 1.4, dash: '5 3' }] : []), hl: [{ y: -Math.min(...d.spans.map(q => q.lim)), l: '−f_lim', c: '#c0262d' }], vl: md.sups.map(p => ({ x: p.x / 1000 })) })}</div>`;
  }
  const zT = (d.z || []).filter(q => has(['fz'], 'd' + q.seg.idx));
  if (zT.length) {
    o += `<h3>Ugięcie poziome – płaszczyzna Z</h3>`;
    o += line(`Przekrój „obrócony” (zginanie względem osi pionowej), interpolacja ζ; część długotrwała (quasi-stała, E<sub>c,eff</sub>) + przyrost od kombinacji charakterystycznej (E<sub>cm</sub>); skurcz pominięto (symetria).`);
    zT.forEach(q => { o += line(`${esc(cap(q.label))}: f<sub>z</sub> = <b>${f(q.f, 2)} mm</b> ${q.f <= q.lim + 1e-9 ? '≤' : '>'} f<sub>lim</sub> = ${f(q.lim, 2)} mm ${q.f <= q.lim + 1e-9 ? '<span class="ok">✔</span>' : '<span class="warn">⚠</span>'}`); });
  }
  if (has(['ld'])) o += `<h3>Metoda uproszczona – smukłość L/d (7.4.2), informacyjnie</h3>`;
  d.spans.forEach(q => {
    if (!has(['ld'], 'd' + q.seg.idx)) return;
    const ld = q.ld;
    if (multi) o += `<p><b>${esc(cap(q.label))}</b></p>`;
    if (!ld) { o += `<p>Brak przekroju wymiarującego dla tego odcinka.</p>`; return; }
    if (!isFinite(ld.lim)) { o += `<p>Zbrojenie rozciągane nie jest wymagane obliczeniowo (A<sub>s,req</sub> = 0) – metoda uproszczona nie ma zastosowania.</p>`; return; }
    o += eq('ρ_{0}', '√f_{ck}·10^{−3}', '', f(ld.rho0 * 100, 3), '%') + eq('ρ', 'A_{s,req}/A_{c,ref}', '', f(ld.rho * 100, 3), '%') + (ld.rhoP > 0 ? eq("ρ'", '', '', f(ld.rhoP * 100, 3), '%') : '');
    o += eq('(L/d)_{bazowe}', ld.rho <= ld.rho0 ? 'K·[11 + 1,5·√f_{ck}·ρ_{0}/ρ + 3,2·√f_{ck}·(ρ_{0}/ρ − 1)^{3/2}]' : "K·[11 + 1,5·√f_{ck}·ρ_{0}/(ρ − ρ') + √f_{ck}/12·√(ρ'/ρ_{0})]", `K = ${f(ld.K, 1)}`, f(ld.base, 2), '', ld.rho <= ld.rho0 ? '(7.16a)' : '(7.16b)');
    o += eq('(L/d)_{lim}', '(L/d)_{bazowe}·min(500/(f_{yk}·A_{s,req}/A_{s,prov}); 1,5)' + (ld.fT < 1 ? '·0,8' : '') + (ld.fL < 1 ? '·7/L' : ''), `${f(ld.base, 2)}·${f(ld.fS, 3)}${ld.fT < 1 ? '·0,8' : ''}${ld.fL < 1 ? '·' + f(ld.fL, 3) : ''}`, f(ld.lim, 2), '', '(7.17)');
    o += line(`L/d = ${f(q.seg.L, 0)}/${f(ld.d, 0)} = <b>${f(ld.act, 2)}</b> ${ld.act <= ld.lim ? '≤' : '>'} ${f(ld.lim, 2)} <span class="${ld.act <= ld.lim ? 'ok' : 'warn'}">${ld.act <= ld.lim ? '✔' : '⚠ decyduje metoda dokładna'}</span>`);
  });

  /* ---------------- pożar */
  if (R.fire && has(['fb', 'fa', 'fasd', 'fbw'])) {
    const fr = R.fire;
    o += H2(`Odporność ogniowa ${fr.R} (PN-EN 1992-1-2, tab. ${fr.cont ? '5.6 – belki ciągłe' : '5.5 – belki swobodnie podparte'})`);
    o += line(`Kombinacje b<sub>min</sub> / a [mm]: ${fr.tab.c.map(c => `${c[0]} / ${c[1]}`).join(' · ')}; b<sub>w,min</sub> (WA) = ${fr.tab.bw} mm`);
    o += cmp(fr.bmin, '≤', fr.b, 'mm (b<sub>min</sub> ≤ b)', 0);
    if (fr.amin !== null) {
      o += eq('a_{min}', '', `interpolacja dla b = ${fr.b} mm`, f(fr.amin, 1), 'mm') + eq('a_{m}', 'ΣA_{si}·a_{i}/ΣA_{si}', '', f(fr.am, 1), 'mm') + cmp(fr.amin, '≤', fr.am, 'mm', 1);
      if (fr.needAsd) o += eq('a_{sd}', 'c_{nom} + ⌀_{w} + ⌀/2', '', f(fr.asd, 1), 'mm') + cmp(fr.asdReq, '≤', fr.asd, 'mm (a<sub>sd</sub> ≥ a + 10 mm)', 1);
    }
  }

  /* ---------------- zestawienie */
  const sc = E.steelSchedule(R);
  o += H2('Zbrojenie belki – widok podłużny i zestawienie stali') + `<p class="note">Rysunek poglądowy (skala pionowa powiększona); numery pozycji w kółkach odpowiadają zestawieniu stali. Długości osiowe z odgięciami i hakami; φm – średnica trzpienia gięcia.</p><div class="fig">${U.elevationSVG(940)}</div>`;
  o += `<h3>Zestawienie stali</h3>` + sc.rows.map(r => line(`Poz. ${r.pos} – ${esc(r.name)}: ${r.n} × ⌀${r.d}, l = ${f(r.len / 1000, 2)} m${r.rL || r.rR ? `, gięcie φ<sub>m</sub> = ${f(2 * Math.max(r.rL || 0, r.rR || 0), 0)} mm` : ''}${r.set ? `, φ<sub>m</sub> = ${f(r.set.phm, 0)} mm, haki 135° ${f(r.set.ext, 0)} mm` : ''} → L = ${f(r.tot, 2)} m, masa ${f(r.mass, 1)} kg`)).join('');
  o += line(`Razem: ${Object.keys(sc.byD).map(Number).sort((a, b) => a - b).map(dd => `⌀${dd} – ${f(sc.byD[dd], 1)} kg`).join('; ')}; <b>masa całkowita ${f(sc.total, 1)} kg</b>; objętość betonu ${f(sc.vol, 3)} m³; wskaźnik ${f(sc.total / sc.vol, 0)} kg/m³`);
  if (sc.laps && sc.laps.length) o += `<h3>Zakłady prętów (8.7)</h3>` + sc.laps.map(l => line(`${l.side === 'top' ? 'Pręty górne ciągłe' : l.mid ? 'Pręty boczne' : `Pręty dolne – ${esc(md.segs[l.seg].label)}`}: pręty dłuższe od ${f(sc.Lmax / 1000, 0)} m łączone na zakład w x = ${f(l.a / 1000, 2)} ÷ ${f(l.b / 1000, 2)} m, l<sub>0</sub> = <b>${l.l0} mm</b> – ${l.mid ? 'pręty konstrukcyjne' : `w miejscu najmniejszego momentu rozciągającego te pręty (max |M<sub>Ed</sub>| na długości zakładu = ${f(l.M / 1e6, 1)} kNm)`}`, '8.7.3')).join('');

  /* ---------------- podsumowanie – tylko sprawdzenia odhaczone */
  o += H2('Zestawienie sprawdzeń');
  if (!ticked.length) o += `<p class="note">Brak odhaczonych sprawdzeń – zaznacz sprawdzenia w zakładce Podsumowanie, aby pojawiły się w raporcie.</p>`;
  else {
    let grp = '';
    ticked.forEach(c => {
      if (c.grp !== grp) { grp = c.grp; o += `<h3>${esc(grp)}</h3>`; }
      const cond = U.ckCond(c);
      o += line(`${sym(c.name)}${cond ? `: ${cond}` : ''}${c.status === 'info' || !isFinite(c.ratio) ? '' : `, η = ${f(c.ratio * 100, 0)}%`} – <span class="${c.status}">${U.STL[c.status]}</span>`, c.ref);
    });
  }
  const failsT = ticked.filter(c => c.status === 'fail'), mx = Math.max(0, ...ticked.filter(c => c.status !== 'info' && isFinite(c.ratio) && /^SG[NU]/.test(c.grp)).map(c => c.ratio));
  if (ticked.length) o += `<p class="verdict"><span class="${failsT.length ? 'fail' : 'ok'}">${failsT.length ? `✖ Spośród przedstawionych sprawdzeń niespełnione: ${failsT.length}.` : `✔ Przedstawione warunki normowe są spełnione. Maksymalne wykorzystanie η = ${f(mx * 100, 0)}%.`}</span></p>`;
  return o;
};
})();

/* ------------------------------------------------- raport do edytowalnego pliku OpenDocument (.odt) */
// HTML raportu → content.xml (nagłówki, akapity, tabele, indeksy dolne/górne, pogrubienia) + rysunki SVG zamienione na PNG; ZIP bez kompresji
BZR.odt = async function (html, title) {
  const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const host = document.createElement('div'); host.style.cssText = 'position:fixed;left:-10000px;top:0;width:1000px;'; host.innerHTML = html; document.body.appendChild(host);
  const pics = [];
  const svgPng = async svg => {
    const vb = svg.viewBox && svg.viewBox.baseVal && svg.viewBox.baseVal.width ? svg.viewBox.baseVal : null;
    const w = vb ? vb.width : (+svg.getAttribute('width') || svg.getBoundingClientRect().width || 800), h = vb ? vb.height : (+svg.getAttribute('height') || svg.getBoundingClientRect().height || 400);
    const cl = svg.cloneNode(true); cl.setAttribute('xmlns', 'http://www.w3.org/2000/svg'); cl.setAttribute('width', w); cl.setAttribute('height', h);
    cl.querySelectorAll('[style*="var("]').forEach(el => el.removeAttribute('style'));
    const src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(new XMLSerializer().serializeToString(cl).replace(/var\(--[^,)]+,\s*([^)]+)\)/g, '$1').replace(/var\(--[^)]+\)/g, '#1b2230'));
    const img = new Image(); await new Promise(res => { img.onload = res; img.onerror = res; img.src = src; });
    const k = 2, cv = document.createElement('canvas'); cv.width = Math.round(w * k); cv.height = Math.round(h * k);
    const cx = cv.getContext('2d'); cx.fillStyle = '#ffffff'; cx.fillRect(0, 0, cv.width, cv.height); try { cx.drawImage(img, 0, 0, cv.width, cv.height); } catch (e) { /* */ }
    const b64 = cv.toDataURL('image/png').split(',')[1], bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    const name = `Pictures/r${pics.length + 1}.png`; pics.push({ name, data: u });
    const wcm = Math.min(17, w / 96 * 2.54 * 0.85), hcm = wcm * h / w;
    return `<draw:frame draw:name="r${pics.length}" text:anchor-type="as-char" svg:width="${wcm.toFixed(2)}cm" svg:height="${hcm.toFixed(2)}cm"><draw:image xlink:href="${name}" xlink:type="simple" xlink:show="embed" xlink:actuate="onLoad"/></draw:frame>`;
  };
  const inline = async el => {
    let o = '';
    for (const n of el.childNodes) {
      if (n.nodeType === 3) { o += esc(n.nodeValue.replace(/\s+/g, ' ')); continue; }
      if (n.nodeType !== 1) continue;
      const t = n.tagName.toLowerCase();
      if (t === 'svg') { o += await svgPng(n); continue; }
      if (t === 'br') { o += '<text:line-break/>'; continue; }
      if (t === 'sub') { o += `<text:span text:style-name="Tsub">${await inline(n)}</text:span>`; continue; }
      if (t === 'sup') { o += `<text:span text:style-name="Tsup">${await inline(n)}</text:span>`; continue; }
      if (t === 'b' || t === 'strong' || t === 'th') { o += `<text:span text:style-name="Tb">${await inline(n)}</text:span>`; continue; }
      if (n.classList && (n.classList.contains('ok') || n.classList.contains('fail') || n.classList.contains('warn'))) { o += `<text:span text:style-name="${n.classList.contains('ok') ? 'Tok' : n.classList.contains('fail') ? 'Tfail' : 'Twarn'}">${await inline(n)}</text:span>`; continue; }
      if (n.classList && n.classList.contains('r')) { o += `<text:tab/>${await inline(n)}`; continue; }
      o += await inline(n);
    }
    return o;
  };
  let body = `<text:p text:style-name="Title">${esc(title || 'Raport obliczeń')}</text:p>`;
  const block = async el => {
    for (const n of el.childNodes) {
      if (n.nodeType === 3) { if (n.nodeValue.trim()) body += `<text:p text:style-name="Body">${esc(n.nodeValue.trim())}</text:p>`; continue; }      // tekst wpisany wprost (raport własny)
      if (n.nodeType !== 1) continue;
      const t = n.tagName.toLowerCase();
      if (t === 'br') continue;
      if (/^h[1-4]$/.test(t)) { body += `<text:h text:style-name="H${t[1]}" text:outline-level="${+t[1] > 1 ? +t[1] - 1 : 1}">${await inline(n)}</text:h>`; continue; }
      if (t === 'table') {
        if (n.classList.contains('pwrap')) { const tb = n.querySelector('td.pbody'); if (tb) await block(tb); continue; }
        const rows = [...n.querySelectorAll('tr')]; if (!rows.length) continue; const nc = Math.max(...rows.map(r => [...r.children].reduce((a, c) => a + (+c.getAttribute('colspan') || 1), 0)));
        body += `<table:table table:style-name="Tab"><table:table-column table:number-columns-repeated="${nc}"/>`;
        for (const r of rows) { body += '<table:table-row>'; for (const c of r.children) { const cs = +c.getAttribute('colspan') || 1; body += `<table:table-cell table:style-name="Cell" office:value-type="string"${cs > 1 ? ` table:number-columns-spanned="${cs}"` : ''}><text:p text:style-name="${c.tagName === 'TH' ? 'Th' : 'Td'}">${await inline(c)}</text:p></table:table-cell>`; for (let k = 1; k < cs; k++) body += '<table:covered-table-cell/>'; } body += '</table:table-row>'; }
        body += '</table:table>'; continue;
      }
      if (t === 'div' && (n.classList.contains('fig') || n.classList.contains('tscroll'))) { if (n.querySelector('table') && !n.querySelector('svg')) { await block(n); continue; } body += `<text:p text:style-name="Fig">${await inline(n)}</text:p>`; continue; }
      if (t === 'ul' || t === 'ol') { for (const li of n.children) body += `<text:p text:style-name="Li">• ${await inline(li)}</text:p>`; continue; }
      if (t === 'div' && n.children.length && [...n.children].some(c => /^(h[1-4]|table|div|p|ul|ol)$/i.test(c.tagName)) && !n.classList.contains('eq')) { await block(n); continue; }
      const st = n.classList.contains('eq') ? 'Eq' : n.classList.contains('note') ? 'Note' : n.classList.contains('verdict') ? 'Verdict' : 'Body';
      const tx = await inline(n); if (tx.trim()) body += `<text:p text:style-name="${st}">${tx}</text:p>`;
    }
  };
  try { await block(host); } finally { host.remove(); }
  const NS = 'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" office:version="1.2"';
  const ps = (n, o) => `<style:style style:name="${n}" style:family="paragraph"${o.parent ? ` style:parent-style-name="${o.parent}"` : ''}><style:paragraph-properties fo:margin-top="${o.mt || '0cm'}" fo:margin-bottom="${o.mb || '0.1cm'}"${o.ml ? ` fo:margin-left="${o.ml}"` : ''}${o.tab ? '><style:tab-stops><style:tab-stop style:position="16.5cm" style:type="right"/></style:tab-stops></style:paragraph-properties>' : '/>'}<style:text-properties fo:font-size="${o.fs || '10pt'}"${o.b ? ' fo:font-weight="bold"' : ''}${o.c ? ` fo:color="${o.c}"` : ''}${o.it ? ' fo:font-style="italic"' : ''}/></style:style>`;
  const styles = `<?xml version="1.0" encoding="UTF-8"?><office:document-styles ${NS}><office:styles><style:default-style style:family="paragraph"><style:text-properties style:font-name="Calibri" fo:font-family="Calibri, Arial, sans-serif" fo:font-size="10pt" fo:language="pl" fo:country="PL"/></style:default-style></office:styles><office:automatic-styles><style:page-layout style:name="PL"><style:page-layout-properties fo:page-width="21cm" fo:page-height="29.7cm" fo:margin-top="1.8cm" fo:margin-bottom="1.8cm" fo:margin-left="2cm" fo:margin-right="1.8cm"/></style:page-layout></office:automatic-styles><office:master-styles><style:master-page style:name="Standard" style:page-layout-name="PL"/></office:master-styles></office:document-styles>`;
  const content = `<?xml version="1.0" encoding="UTF-8"?><office:document-content ${NS}><office:automatic-styles>` +
    ps('Title', { fs: '16pt', b: true, mb: '0.3cm' }) + ps('H1', { fs: '13pt', b: true, mt: '0.4cm', mb: '0.15cm', c: '#1d3f78' }) + ps('H2', { fs: '13pt', b: true, mt: '0.4cm', mb: '0.15cm', c: '#1d3f78' }) + ps('H3', { fs: '11pt', b: true, mt: '0.25cm', mb: '0.1cm' }) + ps('H4', { fs: '10pt', b: true, mt: '0.2cm' }) +
    ps('Body', {}) + ps('Eq', { ml: '0.4cm', tab: true }) + ps('Note', { fs: '9pt', it: true, c: '#4a5466' }) + ps('Verdict', { fs: '11pt', b: true, mt: '0.3cm' }) + ps('Li', { ml: '0.4cm' }) + ps('Fig', { mt: '0.2cm', mb: '0.2cm' }) + ps('Td', { fs: '9pt', mb: '0cm' }) + ps('Th', { fs: '9pt', b: true, mb: '0cm' }) +
    `<style:style style:name="Tsub" style:family="text"><style:text-properties style:text-position="sub 58%"/></style:style><style:style style:name="Tsup" style:family="text"><style:text-properties style:text-position="super 58%"/></style:style><style:style style:name="Tb" style:family="text"><style:text-properties fo:font-weight="bold"/></style:style>` +
    `<style:style style:name="Tok" style:family="text"><style:text-properties fo:color="#1d7f3c" fo:font-weight="bold"/></style:style><style:style style:name="Tfail" style:family="text"><style:text-properties fo:color="#c0262d" fo:font-weight="bold"/></style:style><style:style style:name="Twarn" style:family="text"><style:text-properties fo:color="#a35d00" fo:font-weight="bold"/></style:style>` +
    `<style:style style:name="Tab" style:family="table"><style:table-properties style:width="17cm" table:align="left" fo:margin-top="0.15cm" fo:margin-bottom="0.15cm"/></style:style><style:style style:name="Cell" style:family="table-cell"><style:table-cell-properties fo:padding="0.05cm" fo:border="0.5pt solid #9aa3b0"/></style:style>` +
    `</office:automatic-styles><office:body><office:text>${body}</office:text></office:body></office:document-content>`;
  const manifest = `<?xml version="1.0" encoding="UTF-8"?><manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2"><manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.text" manifest:version="1.2"/><manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/><manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/>${pics.map(p => `<manifest:file-entry manifest:full-path="${p.name}" manifest:media-type="image/png"/>`).join('')}</manifest:manifest>`;
  const enc = new TextEncoder();
  return BZR.zip([{ name: 'mimetype', data: enc.encode('application/vnd.oasis.opendocument.text') }, { name: 'META-INF/manifest.xml', data: enc.encode(manifest) }, { name: 'styles.xml', data: enc.encode(styles) }, { name: 'content.xml', data: enc.encode(content) }, ...pics]);
};
// ZIP (metoda „stored”, CRC-32) – wystarcza dla OpenDocument
// raport bez odwołań do punktów, tablic, rysunków i załączników normy oraz numerów wzorów – zostają numery wzorów kombinacji (PN-EN 1990: 6.10, 6.10a/b, 6.11, 6.14–6.16)
BZR.noRefs = function (html) {
  const COMBO = /^\(?6\.1[0-6][ab]?(?:\s*\/\s*6\.1[0-6][ab]?(?:,b)?)*\)?:?$/;
  const KW = '(?:tab\\.|tabl\\.|tablica|tablicy|rys\\.|zał\\.|załącznik|wz[óo]r)';
  const ATOM = `(?:${KW}\\s*(?:[A-Z]\\.?)?(?:\\d+(?:\\.\\d+)*)?[A-Za-z]?|(?:[A-Z]\\.)?[1-9]\\d?\\.\\d{1,2}(?:\\.\\d{1,2})*[a-zN]?(?:\\(\\d+\\))*)`;
  const PART = new RegExp(`^(?:wg\\s+|por\\.\\s+|patrz\\s+)?(?:(?:PN-)?EN\\s[\\d-]+,?\\s*)?${ATOM}(?:\\s*(?:,|i|oraz)\\s*${ATOM})*$`);
  const isRef = t => { t = t.trim(); if (!t || COMBO.test(t)) return false; return PART.test(t); };
  const clean = s => {
    if (!/\d\.\d|tab\.|tabl|rys\.|zał\.|wz[óo]r/.test(s)) return s;
    let o = s;
    // nawiasy (także z jednym poziomem zagnieżdżenia): części będące odwołaniami usuwane, nawias pusty – cały
    o = o.replace(/\s?\(((?:[^()]|\([^()]*\))*)\)/g, (m, inner) => {
      const parts = inner.split(/\s*(?:,|;| \/ | – )\s*/); const keep = parts.filter(q => !isRef(q));
      if (keep.length === parts.length) return m;
      if (!keep.length || keep.every(q => !q.trim())) return '';
      return `${m[0] === ' ' ? ' ' : ''}(${keep.join(', ')})`;
    });
    // odwołania poza nawiasami: „tab. 4.4N”, „zał. E”, punkty z podpunktem / numerem ustępu (np. 8.2(4), 9.2.1.1(1), 4.4.1)
    o = o.replace(new RegExp(`(,\\s*)?\\b${KW}\\s*(?:[A-Z]\\.?)?(?:\\d+(?:\\.\\d+)*)?[A-Za-z]?(?=[\\s,.;:)]|$)`, 'g'), '');
    o = o.replace(/(^|[^=\d.,\s]\s|[(\[,;]\s?)((?:wg\s+)?(?:[1-9]\d?\.\d{1,2}(?:\.\d{1,2})+|[1-9]\d?\.\d{1,2})(?:\(\d+\))+|[1-9]\d?\.\d{1,2}(?:\.\d{1,2}){2,})(?=[\s,.;:)\]]|$)/g, (m, pre, ref) => COMBO.test(ref) ? m : pre.replace(/[,;]\s?$/, ''));
    o = o.replace(/=\s*,\s*/g, '= ').replace(/\(\s*,\s*/g, '(').replace(/,\s*\)/g, ')').replace(/\(\s*\)/g, '').replace(/ {2,}/g, ' ').replace(/ ([,.;:])/g, '$1');
    return o;
  };
  const t = document.createElement('template'); t.innerHTML = html;
  t.content.querySelectorAll('span.r').forEach(sp => { const tx = sp.textContent.replace(/^\s*\[|\]\s*$/g, '').trim(); if (!COMBO.test(tx)) sp.remove(); });
  const w = document.createTreeWalker(t.content, NodeFilter.SHOW_TEXT, { acceptNode: n => (n.parentNode && /^(style|script)$/i.test(n.parentNode.nodeName) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) });
  const nodes = []; while (w.nextNode()) nodes.push(w.currentNode);
  nodes.forEach(n => { const v = clean(n.nodeValue); if (v !== n.nodeValue) n.nodeValue = v; });
  return t.innerHTML;
};
BZR.zip = function (files) {
  const T = BZR._crcT || (BZR._crcT = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })());
  const crc = u => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = T[(c ^ u[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  const enc = new TextEncoder(), parts = [], cen = []; let off = 0;
  const d = new Date(), dt = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate(), tm = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  files.forEach(f => {
    const nm = enc.encode(f.name), c = crc(f.data), sz = f.data.length;
    const lh = new DataView(new ArrayBuffer(30)); lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true); lh.setUint16(10, tm, true); lh.setUint16(12, dt, true); lh.setUint32(14, c, true); lh.setUint32(18, sz, true); lh.setUint32(22, sz, true); lh.setUint16(26, nm.length, true); lh.setUint16(28, 0, true);
    parts.push(new Uint8Array(lh.buffer), nm, f.data);
    const ch = new DataView(new ArrayBuffer(46)); ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, 0, true); ch.setUint16(12, tm, true); ch.setUint16(14, dt, true); ch.setUint32(16, c, true); ch.setUint32(20, sz, true); ch.setUint32(24, sz, true); ch.setUint16(28, nm.length, true); ch.setUint32(42, off, true);
    cen.push(new Uint8Array(ch.buffer), nm);
    off += 30 + nm.length + sz;
  });
  const cs = cen.reduce((a, u) => a + u.length, 0), ed = new DataView(new ArrayBuffer(22)); ed.setUint32(0, 0x06054b50, true); ed.setUint16(8, files.length, true); ed.setUint16(10, files.length, true); ed.setUint32(12, cs, true); ed.setUint32(16, off, true);
  const all = [...parts, ...cen, new Uint8Array(ed.buffer)], n = all.reduce((a, u) => a + u.length, 0), out = new Uint8Array(n); let p = 0; all.forEach(u => { out.set(u, p); p += u.length; });
  return out;
};
