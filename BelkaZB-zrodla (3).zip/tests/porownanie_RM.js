const E=require('/home/claude/belka/web/engine.js');
function mk(opts){
  const S=E.defaultState();
  S.geom.L=5; S.geom.b=250; S.geom.h=400; S.geom.t=250; S.supCfg=[{},{type:'fix'}];
  S.mat.concrete='C20/25'; S.mat.steel='B500SP'; S.mat.steelW='B500SP';
  S.env.cBot=23; S.env.cTop=23; S.env.cSide=23;
  S.reb.bot=E.zoneOf([{n:4,d:20}]); S.reb.top=E.zoneOf([{n:4,d:12}]);
  S.stir.d=8; S.stir.legs=2; S.stir.sAuto=false; S.stir.s1=269; S.stir.s2=269; S.stir.nz='1';
  S.sls.phiSel='man'; S.sls.phi=2.0;
  Object.assign(S, opts(S)||{});
  return S;
}
const f=(v,d=3)=>(+v).toFixed(d);
function run(name, opts){
  const S=E.normalize(mk(opts)); const R=E.calc(S); if(R.errors.length){console.log(name,R.errors);return;}
  const st=R.st, kB=st.kAt(5000), k25=st.kAt(2500);
  let kmax=0; st.MEdMax.forEach((v,i)=>{ if(v>st.MEdMax[kmax]) kmax=i; });
  let kq=0; (st.Mqp||st.MqpMax||[]).forEach((v,i)=>{ if(v>(st.Mqp||st.MqpMax)[kq]) kq=i; });
  const sup=R.secs.find(s=>s.kind==='supp'), sp=R.secs.find(s=>s.kind==='span');
  console.log('\n== '+name);
  console.log('ULS: M_B =',f(st.MEdMin[kB]/1e6),' M(2.5) =',f(st.MEdMax[k25]/1e6),' M+max =',f(st.MEdMax[kmax]/1e6),'@',f(st.x[kmax]/1000,3),' V_A =',f(st.Vat(0.5)/1e3),' V(2.5) =',f(st.Vat(2500)/1e3),' V_B =',f(st.Vat(4999.5)/1e3));
  const qpArr = st.Mqp || st.MqpMin; 
  console.log('keys st:', Object.keys(st).filter(k=>/qp|Mk|char/i.test(k)).join(','));
  return {S,R};
}
const A=run('RM-fit: G=5,75, Q=5,0 (ψ2=0,25), 6.10', S=>{ S.loads.sw=false; S.loads.comb='610'; S.loads.perm=[{name:'G',q:5.75,span:0,x1:'',x2:'',pts:[]}]; S.loads.var=[{kind:'other',name:'Q',dir:'y',span:0,q:5,qz:0,x1:'',x2:'',pts:[],p0:0.7,p1:0.5,p2:0.25}]; });
{
const {S,R}=A; const st=R.st, kB=st.kAt(5000);
let kq=0; st.MqpMax.forEach((v,i)=>{ if(v>st.MqpMax[kq]) kq=i; });
console.log('QP: M_B =',f(st.MqpMin[kB]/1e6),' M+max =',f(st.MqpMax[kq]/1e6),'  CHAR: M_B =',f(st.MkMin[kB]/1e6));
const sup=R.secs.find(s=>s.kind==='supp');
console.log('support sec: d=',f(sup.d,1),' As1,req=',f(sup.des.As1/100,2),'cm2  MRd=',f(sup.MRd/1e6,3),' x=', sup.r? f(sup.r.x,1):'');
R.sh.ends.forEach(e=>console.log('end',e.name,'V0',f(e.V0/1e3),'Vred',f(e.Vred/1e3),'VRdc',f(e.VRdc/1e3),'d',f(e.d,1),'red',e.red, 'xr', e.xr));
R.checks.filter(c=>['ssk','sck','scqp','wk','f','Vs1','Mspan','Msupp','acr','asmin','crk'].includes(c.id)||/rys|ugi|napręż/i.test(c.name)).forEach(c=>console.log(c.id, c.at, c.name.slice(0,70), '|', typeof c.Ed==='number'?f(c.Ed):c.Ed, c.rel, typeof c.Rd==='number'?f(c.Rd):c.Rd, c.unit, c.note? '| '+c.note.slice(0,120):''));
}
const sc=[
 ['B: te same G, Q, ale domyślne 6.10a/6.10b (ξ=0,85)', S=>{ S.loads.sw=false; S.loads.comb='610ab'; S.loads.perm=[{name:'G',q:5.75,span:0,x1:'',x2:'',pts:[]}]; S.loads.var=[{kind:'other',name:'Q',dir:'y',span:0,q:5,qz:0,x1:'',x2:'',pts:[],p0:0.7,p1:0.5,p2:0.25}]; }],
 ['C: G=5,75 wpisane razem z c.w. + automatyczny ciężar własny 2,5 (podwójnie), 6.10a/b', S=>{ S.loads.sw=true; S.loads.comb='610ab'; S.loads.perm=[{name:'G',q:5.75,span:0,x1:'',x2:'',pts:[]}]; S.loads.var=[{kind:'other',name:'Q',dir:'y',span:0,q:5,qz:0,x1:'',x2:'',pts:[],p0:0.7,p1:0.5,p2:0.25}]; }],
 ['D: kategoria B (ψ2=0,3) zamiast ψ2=0,25, 6.10', S=>{ S.loads.sw=false; S.loads.comb='610'; S.loads.perm=[{name:'G',q:5.75,span:0,x1:'',x2:'',pts:[]}]; S.loads.var=[{kind:'imp',cat:'B',name:'Q',dir:'y',span:0,q:5,qz:0,x1:'',x2:'',pts:[]}]; }],
 ['E: obie podpory przegubowe (domyślny schemat), 6.10', S=>{ S.supCfg=[]; S.loads.sw=false; S.loads.comb='610'; S.loads.perm=[{name:'G',q:5.75,span:0,x1:'',x2:'',pts:[]}]; S.loads.var=[{kind:'other',name:'Q',dir:'y',span:0,q:5,qz:0,x1:'',x2:'',pts:[],p0:0.7,p1:0.5,p2:0.25}]; }],
];
sc.forEach(([n,o])=>{ const r=run(n,o); const st=r.R.st, kB=st.kAt(5000); let kq=0; st.MqpMax.forEach((v,i)=>{ if(v>st.MqpMax[kq]) kq=i; }); console.log('QP: M_B =',f(st.MqpMin[kB]/1e6),' M+max =',f(st.MqpMax[kq]/1e6)); });
