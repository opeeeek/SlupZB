/* BelkaŻB – interfejs użytkownika */
(function () {
'use strict';
const E = window.EC2;
const U = window.BZ = {};               // współdzielone z report.js
let S = E.defaultState();
let R = null;
let filePath = '';
let dirty = false;

/* ------------------------------------------------------------ narzędzia */
const $ = (s, el) => (el || document).querySelector(s);
const $$ = (s, el) => Array.from((el || document).querySelectorAll(s));
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = (v, dp) => {
  if (dp === undefined) dp = 2;
  if (v === null || v === undefined || typeof v !== 'number' || !isFinite(v)) return '—';
  let s = (Math.abs(v) < 0.5 * Math.pow(10, -dp) ? 0 : v).toFixed(dp);
  const neg = s[0] === '-'; if (neg) s = s.slice(1);
  let [i, f] = s.split('.'); i = i.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  return (neg ? '−' : '') + i + (f !== undefined ? ',' + f : '');
};
const sym = s => esc(s).replace(/_\{([^}]*)\}/g, '<sub>$1</sub>').replace(/\^\{([^}]*)\}/g, '<sup>$1</sup>')
  .replace(/_([0-9A-Za-ząćęłńóśźżθ]+(?:,[0-9A-Za-ząćęłńóśźż]+)*)/g, '<sub>$1</sub>');
const getP = (o, p) => p.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
const setP = (o, p, v) => { const ks = p.split('.'); let a = o; for (let i = 0; i < ks.length - 1; i++) { if (a[ks[i]] === undefined || a[ks[i]] === null) a[ks[i]] = /^\d+$/.test(ks[i + 1]) ? [] : {}; a = a[ks[i]]; } a[ks[ks.length - 1]] = v; };
const parseNum = s => { if (typeof s === 'number') return s; const x = parseFloat(String(s).replace(',', '.').replace(/\s/g, '')); return isFinite(x) ? x : null; };
const showNum = v => (v === '' || v === null || v === undefined) ? '' : String(v).replace('.', ',');
Object.assign(U, { esc, fmt, sym, getP });

/* ---------------------------------------------------------- definicja pól */
const T = s => s.geom.type === 'T';
const MAN = s => s.scheme === 'manual';
const CONT = s => s.scheme === 'cont';
const rng = (a, b, st) => { const r = []; for (let v = a; v <= b + 1e-9; v += st) r.push(+v.toFixed(3)); return r; };
const DIA = E.BAR_DIAS.map(d => [d, '⌀' + d]);
const NBARS = rng(0, 12, 1).map(n => [n, String(n)]);
// pola edytowane w oknach zakładki Przekrój (strzemiona, siatka, pręty boczne)
// otulina poszczególnych krawędzi (puste – wartość ogólna / wymagana)
const covPh = k => () => { if (!R || !R.cov || R.cov.cb === undefined) return 'auto'; const c = R.cov, man = c.manual; return 'auto: ' + (man ? c.cnom : k === 'b' ? c.reqB : k === 't' ? c.reqT : c.reqS); };
const COV_FACES = [
  { k: 'env.cBot', t: 'num', l: 'Otulina krawędzi dolnej c_{nom,b}', u: 'mm', list: ['', ...rng(15, 80, 5)], opt: true, min: 0, ph: covPh('b') },
  { k: 'env.cTop', t: 'num', l: 'Otulina krawędzi górnej c_{nom,t}', u: 'mm', list: ['', ...rng(15, 80, 5)], opt: true, min: 0, ph: covPh('t') },
  { k: 'env.cSide', t: 'num', l: 'Otulina boków c_{nom,s}', u: 'mm', list: ['', ...rng(15, 80, 5)], opt: true, min: 0, ph: covPh('s') },
];
function covHint() {
  if (!R || !R.cov || R.cov.cb === undefined) return 'Otulina nominalna c<sub>nom</sub> = c<sub>min</sub> + Δc<sub>dev</sub>, mierzona do strzemion.';
  const c = R.cov, row = (n, v, rq) => `${n}: przyjęto <b>${v} mm</b>, wymagane ${rq} mm ${v >= rq ? '✔' : '<span style="color:var(--fail)">✖</span>'}`;
  return [[row('dół', c.cb, c.reqB), row('góra', c.ct, c.reqT), row('boki', c.cs, c.reqS)].join(' · ') + (c.ground ? ` · betonowanie dolnej powierzchni na podłożu: ≥ ${c.ground} mm.` : '.'),
    `c<sub>nom</sub> = c<sub>min</sub> + Δc<sub>dev</sub> (4.4.1), c<sub>min</sub> = max(c<sub>min,b</sub>; c<sub>min,dur</sub> + Δ…; 10 mm), mierzona do strzemion; pręty podłużne mają otulinę ≥ c<sub>min,b</sub> = ⌀. Puste pola krawędzi – przyjmowana jest wartość ogólna (wymagana lub podana ręcznie).`];
}
const POP = {
  cov: [
    { k: 'env.cnomSel', t: 'sel', l: 'Otulina c_{nom} (do strzemion)', o: [['auto', 'automatycznie – wymagana (zaokr. do 5 mm)'], ['manual', 'podana ręcznie']], wide: true, re: true },
    { k: 'env.cnomVal', t: 'num', l: 'Przyjęta otulina c_{nom}', u: 'mm', list: rng(15, 80, 5), min: 0, show: s => s.env.cnomSel === 'manual' },
    { t: 'sub', l: 'Otulina poszczególnych krawędzi' },
    ...COV_FACES,
    { k: 'env.cast', t: 'sel', l: 'Betonowanie dolnej powierzchni', o: [['form', 'w deskowaniu'], ['prep', 'na przygotowanym podłożu (≥ 40 mm)'], ['ground', 'bezpośrednio na gruncie (≥ 75 mm)']], wide: true },
    { t: 'hint', exT: 'Objaśnienie otuliny', h: () => covHint() },
  ],
  stir: [
    { k: 'stir.d', t: 'sel', l: 'Średnica strzemion ⌀_{w}', o: DIA.filter(d => d[0] <= 12), num: true, re: true },
    { k: 'stir.kind', t: 'sel', l: 'Rodzaj strzemion', o: Object.entries(E.STIR_KIND), wide: true, re: true },
    { k: 'stir.bent', t: 'sel', l: 'Pręty odgięte 45° na ścinanie', o: [['auto', 'tylko gdy same strzemiona nie wystarczają'], ['off', 'nie stosować – tylko strzemiona']], wide: true },
    { k: 'stir.legs', t: 'sel', l: 'Liczba ramion (cięć)', o: [[2, '2-cięte'], [3, '3-cięte'], [4, '4-cięte'], [5, '5-cięte'], [6, '6-cięte'], [8, '8-cięte']], num: true, re: true, dis: v => { const mx = holdMax(null); return mx && +v > mx ? 'brak prętów w narożach' : ''; } },
    { t: 'hint', exT: 'Kiedy jakie strzemiona?', h: () => hintStirKind() },
    { k: 'stir.sAuto', t: 'chk', l: 'Rozstaw strzemion dobierany automatycznie (z V_{Ed}, kąta krzyżulców θ, skręcania, ρ_{w,min} i s_{l,max})', re: true },
    { k: 'stir.nz', t: 'sel', l: 'Liczba stref rozstawu (od podpory)', o: [['auto', 'automatycznie (1–3)'], ['1', '1 – rozstaw stały'], ['2', '2 – s₁ przy podporze, s₂ w środku'], ['3', '3 – s₁, strefa pośrednia s_p, s₂']], wide: true, re: true },
    { t: 'hint', show: s => s.stir.sAuto, h: () => hintAutoS() },
    { k: 'stir.s1', t: 'num', l: 'Rozstaw s_{1} – strefa przypodporowa', u: 'mm', list: [75, 100, 120, 125, 150, 175, 200, 250], min: 30, show: s => !s.stir.sAuto },
    { k: 'stir.sp', t: 'num', l: 'Rozstaw s_{p} – strefa pośrednia (s₁ < s_p < s₂)', u: 'mm', list: ['', 100, 125, 150, 175, 200, 225, 250, 300], opt: true, min: 30, ph: 'brak', show: s => !s.stir.sAuto && s.stir.nz !== '1' && s.stir.nz !== '2' },
    { k: 'stir.s2', t: 'num', l: 'Rozstaw s_{2} – część środkowa', u: 'mm', list: [100, 150, 200, 250, 300, 350, 400], min: 30, show: s => !s.stir.sAuto && s.stir.nz !== '1' },
    { k: 'stir.hookA', t: 'sel', l: 'Kąt haków strzemion', o: [[135, '135° (zalecane, wymagane przy skręcaniu)'], [90, '90°']], num: true, wide: true, re: true },
    { k: 'stir.hook', t: 'num', l: 'Długość prostego zakończenia haka', u: 'mm', list: ['', 50, 60, 70, 80, 100, 120, 150], opt: true, min: 0, ph: s => 'auto ' + Math.max(10 * s.stir.d, 70) },
    { t: 'hint', h: s => `Minimum wg rys. 8.5: hak ${s.stir.hookA === 90 ? '90° – ≥ 10⌀ i ≥ 70 mm = ' + Math.max(10 * s.stir.d, 70) : '135° – ≥ 5⌀ i ≥ 50 mm = ' + Math.max(5 * s.stir.d, 50)} mm.` },
    { k: 'stir.l1', t: 'sel', l: 'Długość strefy s_{1} od lica podpory', o: [['auto', 'auto (wymagana)'], ...[0.3, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0].map(v => [String(v), String(v).replace('.', ',') + ' m'])], wide: true },
    { k: 'stir.lp', t: 'sel', l: 'Długość strefy pośredniej s_{p}', o: [['auto', 'auto (wymagana)'], ...[0.3, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0].map(v => [String(v), String(v).replace('.', ',') + ' m'])], wide: true, show: s => s.stir.nz !== '1' && s.stir.nz !== '2' && (s.stir.sAuto || +s.stir.sp > 0) },
    { k: 'stir.cot', t: 'sel', l: 'Kąt krzyżulców cot θ', o: [['auto', 'auto (maks. z 1,0÷2,5)'], ['1', '1,0 (θ = 45°)'], ['1.5', '1,5'], ['2', '2,0'], ['2.5', '2,5 (θ = 21,8°)']], wide: true },
    { k: 'stir.e0', t: 'num', l: 'Odstęp 1. strzemienia od lica podpory', u: 'mm', list: ['', 10, 15, 20, 25, 30, 35, 40, 45, 50], opt: true, ph: 'auto 10–50', min: 0, max: 50 },
    { t: 'html', show: s => CONT(s), h: () => stirSpansHTML() },
    { t: 'hint', exT: 'Rozmieszczenie strzemion – objaśnienie', h: () => hintStir() },
    { k: 'stir.ffd', t: 'sel', l: 'Zbrojenie poprzeczne półki ⌀_{f}', o: DIA.filter(d => d[0] <= 16), num: true, show: T },
    { k: 'stir.ffs', t: 'num', l: 'Rozstaw zbrojenia półki s_{f}', u: 'mm', list: [100, 125, 150, 200, 250, 300], show: T, min: 30 },
  ],
  surf: [
    { t: 'hint', h: () => hintSurf() },
    { k: 'surf.d', t: 'sel', l: 'Siatka – średnica prętów', o: DIA.filter(d => d[0] <= 16), num: true },
    { k: 'surf.s', t: 'num', l: 'Siatka – rozstaw (oczko)', u: 'mm', list: [75, 100, 125, 150, 200], min: 20 },
  ],
  mid: [
    { k: 'reb.mid.n', t: 'sel', l: 'Liczba rzędów przy każdym boku', o: [0, 1, 2, 3, 4, 5, 6].map(v => [v, v ? v + (v === 1 ? ' rząd (w połowie wysokości)' : ' rzędy') : 'brak prętów bocznych']), num: true, wide: true, re: true },
    { k: 'reb.mid.d', t: 'sel', l: 'Średnica prętów bocznych', o: DIA.filter(d => d[0] <= 25), num: true, show: s => s.reb.mid.n > 0 },
    { k: 'reb.mid.ys', t: 'txt', l: 'Wysokości rzędów od dolnej krawędzi [mm] (puste – równomiernie)', ph: 'np. 250; 400', show: s => s.reb.mid.n > 0, wide: true },
    { t: 'hint', ex: true, exT: 'Objaśnienie', h: () => 'Pręty przy obu bokach (wewnątrz strzemion), uwzględniane w nośności, rysach, skręcaniu i w zbrojeniu bocznym belek h ≥ 1 m (7.3.3(3)). Rzędy liczone od dołu.' },
  ],
};
// informacje o redukcjach dopuszczanych przez normę, których program nie stosuje sam (pole wyboru do ich uwzględnienia)
function alRedHint() {
  if (!R || !R.anch || !R.anch.rows) return '';
  const all = [...R.anch.rows, ...(R.anch.ends || []).map(q => Object.assign({ name: `Dolne – ${q.name}` }, q.r))].filter(q => q && q.lbdC !== undefined);
  if (S.anch.alRed) { const q = all.filter(r => r.lbdC < (r.lbd || 0) + 1 && (r.al2 < 1 || r.al5 < 1)); return q.length ? `Przyjęto α₂ / α₅ < 1 (tab. 8.2) – l<sub>bd</sub> zmniejszone, np. ${esc(q[0].name)}: α₂ = ${fmt(q[0].al2, 2)}, α₅ = ${fmt(q[0].al5, 2)}.` : ''; }
  const q = all.filter(r => r.lbdC < r.lbd - 1).sort((u, v) => (v.lbd - v.lbdC) - (u.lbd - u.lbdC));
  return q.length ? `ℹ Możliwe skrócenie zakotwień: ${q.slice(0, 2).map(r => `${esc(r.name)} – l<sub>bd</sub> ${fmt(r.lbd, 0)} → ${fmt(r.lbdC, 0)} mm (α₂ = ${fmt(r.al2c, 2)}${r.al5c < 1 ? `, α₅ = ${fmt(r.al5c, 2)}` : ''})`).join('; ')}. Program tego nie stosuje sam – zaznacz pole powyżej, aby uwzględnić w obliczeniach.` : '';
}
function pairHint() {
  if (!R || !R.md || !R.md.segs) return '';
  const lays = [...R.md.segs.map(sg => sg.Lb), R.LtM, ...R.md.sups.map(p => p.LtS)].filter(Boolean);
  const has = lays.some(L => (L.bars || []).some(b => b.nb === 2 && b.shape === 'v'));
  if (!has) return '';
  return S.anch.pairSep ? 'Pary prętów jeden nad drugim liczone jak pręty pojedyncze (8.9.1(4)) – w dobrych warunkach przyczepności.' : 'ℹ W przekroju są pary prętów jeden nad drugim – w dobrych warunkach przyczepności można je liczyć jak pręty pojedyncze (8.9.1(4): odstępy, otulina i zakotwienie z ⌀ zamiast ⌀<sub>n</sub>). Program tego nie stosuje sam – zaznacz pole powyżej, aby uwzględnić.';
}
const GROUPS = [
  { id: 'geo', title: 'Schemat statyczny i geometria', items: [
    { k: 'scheme', t: 'sel', l: 'Schemat statyczny', o: () => Object.entries(E.SCHEMES).filter(([k]) => k !== 'manual').map(([k, v]) => [k, v.name]), wide: true, re: true },
    { k: 'geom.L', t: 'num', l: 'Rozpiętość obliczeniowa L_{eff}', u: 'm', list: [2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 9, 10, 12], min: 0.3, show: s => !CONT(s) },
    { t: 'cont', show: CONT },
    { k: 'geom.t', t: 'num', l: 'Szerokość podpory t', u: 'mm', list: [150, 200, 250, 300, 350, 400, 450, 500, 600], min: 0 },
    { k: 'geom.type', t: 'sel', l: 'Kształt przekroju', o: [['rect', 'Prostokątny'], ['T', 'Teowy (półka górna)']], re: true },
    { k: 'geom.b', t: 'num', badge: 'b', l: 'Szerokość b (b_{w})', u: 'mm', list: [150, 180, 200, 220, 250, 300, 350, 400, 450, 500, 600], min: 60, show: s => !CONT(s), re: true },
    { k: 'geom.h', t: 'num', badge: 'h', l: 'Wysokość h', u: 'mm', list: [250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 900, 1000, 1200], min: 120, show: s => !CONT(s), re: true },
    { k: 'geom.hf', t: 'num', l: 'Grubość półki h_{f}', u: 'mm', list: [80, 100, 120, 140, 150, 160, 180, 200, 220, 250], show: T, min: 20 },
    { k: 'geom.beffMode', t: 'sel', l: 'Szerokość współpracująca', o: [['manual', 'podana ręcznie'], ['auto', 'wg 5.3.2.1']], show: T, re: true },
    { k: 'geom.beff', t: 'num', l: 'b_{eff}', u: 'mm', list: [600, 800, 1000, 1200, 1400, 1500, 1600, 1800, 2000, 2400], show: s => T(s) && s.geom.beffMode !== 'auto', min: 60 },
    { k: 'geom.b1', t: 'num', l: 'b_{1} – ½ rozstawu żeber w świetle (L)', u: 'mm', list: [500, 750, 1000, 1250, 1500, 2000, 2500, 3000], show: s => T(s) && s.geom.beffMode === 'auto', min: 0 },
    { k: 'geom.b2', t: 'num', l: 'b_{2} – ½ rozstawu żeber w świetle (P)', u: 'mm', list: [500, 750, 1000, 1250, 1500, 2000, 2500, 3000], show: s => T(s) && s.geom.beffMode === 'auto', min: 0 },
    { k: 'geom.l0t', t: 'num', l: 'Rozstaw stężeń bocznych l_{0t}', u: 'm', list: ['', 2, 3, 4, 5, 6, 8, 10], opt: true, ph: '= L' },
    { t: 'hint', ex: true, exT: 'Co to jest rozstaw stężeń bocznych?', h: () => 'Rozstaw stężeń bocznych l<sub>0t</sub> – odległość między punktami, w których ściskany pas belki jest zabezpieczony przed przesunięciem bocznym (np. połączenie z płytą stropu, belki poprzeczne, żebra, tężniki). Służy do sprawdzenia zwichrzenia (5.9(3)): l<sub>0t</sub>/b ≤ 50/(h/b)<sup>1/3</sup>. Belka z płytą zespoloną górą – ściskany pas stężony na całej długości (można przyjąć małe l<sub>0t</sub>); puste pole – przyjmuje się rozpiętość L.' },
    { t: 'hint', h: s => hintGeo(s) },
  ] },
  { id: 'mat', title: 'Materiały', items: [
    { k: 'mat.concrete', t: 'sel', l: 'Klasa betonu', o: () => E.CONC_NAMES.map(n => [n, n]) },
    { k: 'mat.autoC', t: 'chk', l: 'Klasa betonu dobierana automatycznie – najniższa spełniająca ekspozycję (zał. E), SGN, SGU i odporność ogniową (przy doborze zbrojenia)' },
    { k: 'mat.steel', t: 'sel', l: 'Stal zbrojenia podłużnego', o: () => E.STEEL_LIST.map(s => [s.id, s.name]), wide: true },
    { k: 'mat.steelW', t: 'sel', l: 'Stal strzemion', o: () => E.STEEL_LIST.map(s => [s.id, s.name]), wide: true },
    { k: 'mat.dg', t: 'sel', l: 'Maks. wymiar kruszywa d_{g}', o: [[8, '8 mm'], [16, '16 mm'], [22, '22 mm'], [32, '32 mm'], [63, '63 mm']], num: true },
    { k: 'reb.dB', t: 'sel', l: 'Średnica prętów dolnych (dobór zbrojenia)', o: () => [[0, 'automatycznie – najmniejsza spełniająca warunki'], ...[12, 16, 20, 25, 28].map(d => [d, '⌀' + d])], num: true, wide: true, re: true },
    { k: 'reb.dT', t: 'sel', l: 'Średnica prętów górnych (dobór zbrojenia)', o: () => [[0, 'automatycznie – najmniejsza spełniająca warunki'], ...[12, 16, 20, 25, 28].map(d => [d, '⌀' + d])], num: true, wide: true, re: true },
    { t: 'hint', keep: true, h: () => (S.reb.dB || S.reb.dT) ? `Dobór zbrojenia (wykres M w Danych, „Dobierz zbrojenie”, „Dobierz wszystko”) – pręty ${[S.reb.dB ? `dolne ⌀${S.reb.dB}` : '', S.reb.dT ? `górne ⌀${S.reb.dT}` : ''].filter(Boolean).join(', ')}; liczba prętów dobierana do średnicy. Średnicę pojedynczej strefy można zmienić klikając n⌀ na wykresie M.` : '' },
    { k: 'mat.diag', t: 'sel', l: 'Wykres σ–ε betonu (SGN)', o: [['rect', 'prostokątny (3.1.7(3))'], ['parab', 'parabola-prostokąt (3.1.7(1))']], wide: true },
    { t: 'hint', h: s => { const m = E.materials(E.normalize(s)); return `f<sub>cd</sub> = ${fmt(m.fcd)} MPa · f<sub>ctm</sub> = ${fmt(m.fctm)} MPa · E<sub>cm</sub> = ${fmt(m.Ecm / 1000, 0)} GPa · f<sub>yd</sub> = ${fmt(m.fyd)} MPa · f<sub>ywd</sub> = ${fmt(m.fywd)} MPa · ε<sub>ud</sub> = ${fmt(m.eud * 1000, 1)}‰`; } },
  ] },
  { id: 'env', title: 'Środowisko i otulina', items: [
    { k: 'env.exp', t: 'sel', l: 'Klasa ekspozycji (korozja)', o: () => E.EXPOSURES.map(x => [x, `${x} – ${E.EXP_DESC[x]}`]), wide: true },
    { k: 'env.expF', t: 'sel', l: 'Zamrażanie/rozmrażanie', o: [['-', 'brak'], ...['XF1', 'XF2', 'XF3', 'XF4'].map(x => [x, `${x} – ${E.EXP_DESC[x]}`])], wide: true },
    { k: 'env.expA', t: 'sel', l: 'Agresja chemiczna', o: [['-', 'brak'], ...['XA1', 'XA2', 'XA3'].map(x => [x, `${x} – ${E.EXP_DESC[x]}`])], wide: true },
    { t: 'hint', exT: 'Przykłady elementów w tej klasie', h: s => expHint(s) },
    { k: 'env.life', t: 'sel', l: 'Projektowy okres użytkowania', o: [[50, '50 lat'], [100, '100 lat']], num: true },
    { k: 'env.scSel', t: 'sel', l: 'Klasa konstrukcji', o: [['auto', 'automatycznie (tab. 4.3N)'], ...[1, 2, 3, 4, 5, 6].map(i => ['S' + i, 'S' + i])] },
    { k: 'env.qc', t: 'chk', l: 'Specjalna kontrola jakości produkcji betonu (−1 klasa)' },
    { k: 'env.scRed', t: 'chk', l: 'Obniżenie klasy konstrukcji o 1 za klasę wytrzymałości betonu (tab. 4.3N)', re: true },
    { t: 'hint', keep: true, h: () => R && R.cov && R.cov.redPossible && !R.cov.scRed && R.cov.cdurRed !== null ? `ℹ Możliwa redukcja otuliny: beton ${esc(S.mat.concrete)} ≥ ${esc(R.cov.thr)} (ekspozycja ${esc(R.cov.exp)}) pozwala obniżyć klasę konstrukcji S${R.cov.sc} → S${Math.max(1, R.cov.sc - 1)} (tab. 4.3N): c<sub>min,dur</sub> ${R.cov.cdur} → ${R.cov.cdurRed} mm. Program jej nie stosuje sam – zaznacz pole powyżej, aby uwzględnić ją w obliczeniach.` : (R && R.cov && R.cov.scRed && R.cov.redPossible ? `Przyjęto obniżenie klasy konstrukcji o 1 (beton ≥ ${esc(R.cov.thr)}, tab. 4.3N).` : '') },
    { k: 'env.dcdev', t: 'sel', l: 'Odchyłka wykonawcza Δc_{dev}', o: [[0, '0 mm'], [5, '5 mm'], [10, '10 mm'], [15, '15 mm']], num: true },
    { k: 'env.dcg', t: 'sel', l: 'Δc_{dur,γ} (dodatek bezp.)', o: [[0, '0 mm'], [5, '5 mm'], [10, '10 mm']], num: true },
    { k: 'env.dcst', t: 'sel', l: 'Δc_{dur,st} (stal nierdzewna)', o: [[0, '0 mm'], [5, '5 mm'], [10, '10 mm']], num: true },
    { k: 'env.dcadd', t: 'sel', l: 'Δc_{dur,add} (dodatk. ochrona)', o: [[0, '0 mm'], [5, '5 mm'], [10, '10 mm']], num: true },
    { k: 'env.cast', t: 'sel', l: 'Betonowanie dolnej powierzchni', o: [['form', 'w deskowaniu'], ['prep', 'na przygotowanym podłożu (≥ 40 mm)'], ['ground', 'bezpośrednio na gruncie (≥ 75 mm)']], wide: true },
    { k: 'env.cnomSel', t: 'sel', l: 'Otulina c_{nom} (do strzemion)', o: [['auto', 'automatycznie – wymagana (zaokr. do 5 mm)'], ['manual', 'podana ręcznie']], wide: true, re: true },
    { k: 'env.cnomVal', t: 'num', l: 'Przyjęta otulina c_{nom}', u: 'mm', list: rng(15, 80, 5), min: 0, show: s => s.env.cnomSel === 'manual' },
    ...COV_FACES,
    { t: 'hint', h: () => R && R.cov ? `Klasa konstrukcji <b>S${R.cov.sc}</b>, c<sub>min,dur</sub> = ${R.cov.cdur} mm, c<sub>nom</sub> wymagane = <b>${fmt(R.cov.req, 0)} mm</b> (→ ${R.cov.reqR} mm), przyjęto <b>${R.cov.cnom} mm</b>` + (R.cov.manual && R.cov.cnom < R.cov.reqR ? ' <span style="color:var(--fail)">– mniej niż wymagane</span>' : '') + `. Min. klasa betonu: ${R.cov.minCls}.` : '' },
  ] },
  { id: 'load', title: 'Obciążenia', show: s => !MAN(s), items: [
    { t: 'sub', l: 'Kombinacje i siły przekrojowe' },
    { k: 'loads.accPsi', t: 'sel', l: 'Wiodące zmienne w 6.11b', o: [['psi1', 'ψ₁ – wartość częsta'], ['psi2', 'ψ₂ – wartość quasi-stała']], wide: true, show: s => s.loads.acc.length },
    { k: 'loads.accN', t: 'num', l: 'N_{Ed,A} w sytuacji wyjątkowej', u: 'kN', list: [-100, 0, 100, 200, 500], show: s => s.loads.acc.length },
    { k: 'loads.accT', t: 'num', l: 'T_{Ed,A} w sytuacji wyjątkowej', u: 'kNm', list: [0, 5, 10, 20], show: s => s.loads.acc.length },
    { k: 'loads.comb', t: 'sel', l: 'Kombinacja SGN (PN-EN 1990)', o: [['610ab', 'wzory 6.10a i 6.10b'], ['610', 'wzór 6.10']], wide: true, re: true },
    { k: 'loads.gG', t: 'num', l: 'γ_{G,sup} (γ_{G,inf} = 1,0)', list: [1.0, 1.15, 1.35], min: 0 },
    { k: 'loads.gQ', t: 'num', l: 'γ_{Q}', list: [0, 1.0, 1.5], min: 0 },
    { k: 'loads.xi', t: 'num', l: 'ξ (redukcja obc. stałych w 6.10b)', list: [0.85, 0.9, 1.0], show: s => s.loads.comb === '610ab', min: 0 },
    { t: 'hint', h: () => `Siłę podłużną N<sub>Ed</sub>${S.loads.NEd ? ` (obecnie <b>${fmt(S.loads.NEd, 1)} kN</b>)` : ''}, siły pionowe i momenty skręcające w węzłach zadajesz na schemacie – kliknij kropkę węzła (podpora, węzeł w przęśle, koniec belki).` },
    { k: 'loads.TEd', t: 'num', l: 'Moment skręcający T_{Ed} (stały, podany wprost)', u: 'kNm', list: [0, 5, 10, 15, 20, 30, 50], show: s => +s.loads.TEd !== 0 },
    { t: 'hint', h: () => hintLoads() },
  ] },
  { id: 'man', title: 'Siły wewnętrzne (wprowadzane ręcznie)', show: MAN, items: [
    { t: 'hint', h: () => 'Momenty w kNm: dodatnie – rozciągane włókna dolne. Rozkład M(x) przyjmowany jako parabola przez 3 punkty, V(x) liniowo.' },
    { t: 'mtab' },
    { k: 'man.VL', t: 'num', l: 'V_{Ed} przy lewej podporze', u: 'kN', list: [50, 100, 150, 200, 300] },
    { k: 'man.VR', t: 'num', l: 'V_{Ed} przy prawej podporze (wartość)', u: 'kN', list: [50, 100, 150, 200, 300] },
    { k: 'man.NEd', t: 'num', l: 'Siła osiowa N_{Ed} (+ ściskanie)', u: 'kN', list: [-100, 0, 100, 200, 500] },
    { k: 'man.TEd', t: 'num', l: 'Moment skręcający T_{Ed}', u: 'kNm', list: [0, 5, 10, 20, 30] },
    { k: 'man.K', t: 'sel', l: 'Współczynnik K (tab. 7.4N)', o: [['1.0', '1,0 – swobodnie podparta'], ['1.3', '1,3 – przęsło skrajne'], ['1.5', '1,5 – przęsło wewnętrzne'], ['0.4', '0,4 – wspornik']], wide: true },
  ] },
  { id: 'anch', title: 'Zakotwienia i zakłady', items: [
    { k: 'anch.shape', t: 'sel', l: 'Zakończenie prętów', o: [['auto', 'automatycznie (proste, a gdy się nie mieszczą – odgięcia)'], ['line', 'wyłącznie pręty proste'], ['hook', 'haki / odgięcia / pętle (α₁ = 0,7)']], wide: true },
    { t: 'hint', show: s => s.anch.shape === 'auto', ex: true, exT: 'Dobrane zakończenia prętów', h: () => anchAutoHint() },
    { k: 'anch.innerB', t: 'sel', l: 'Pręty dolne nad podporami pośrednimi', o: [['anch', 'zakotwione ≥ 10⌀ za licem podpory, bez zakładu (9.2.1.5(1))'], ['lap', 'łączone na zakład l₀ nad podporą (ciągłość, 9.2.1.5(3))'], ['cont', 'ciągłe przez podporę – bez podziału (gdy przęsła mają to samo zbrojenie dolne; podział tylko przy L > L_max)']], wide: true, show: s => CONT(s) || (s.supCfg || []).length > 2 },
    { k: 'anch.lap', t: 'sel', l: 'Udział prętów łączonych w przekroju', o: [['25', '≤ 25% (α₆ = 1,0)'], ['33', '33% (α₆ = 1,15)'], ['50', '50% (α₆ = 1,4)'], ['100', '> 50% (α₆ = 1,5)']], wide: true },
    { k: 'anch.toEnd', t: 'sel', l: 'Pręty dolne doprowadzone do podpór', o: [['all', 'wszystkie pręty przęsła'], ['50', '≥ 50% prętów przęsła'], ['25', '≥ 25% prętów, nie mniej niż 2 szt. (9.2.1.4(1))']], wide: true },
    { k: 'anch.sigma', t: 'sel', l: 'Naprężenie σ_{sd} w pręcie', o: [['fyd', 'σ_sd = f_yd (bezpiecznie)'], ['actual', 'σ_sd = f_yd·A_s,req/A_s,prov']], wide: true },
    { k: 'anch.bond', t: 'sel', l: 'Warunki przyczepności', o: [['auto', 'automatycznie (rys. 8.2)'], ['good', 'dobre (η₁ = 1,0)'], ['poor', 'średnie (η₁ = 0,7)']], wide: true },
    { k: 'anch.alRed', t: 'chk', l: 'Współczynniki α₂ (otulina) i α₅ (docisk poprzeczny) < 1 w długości zakotwienia (tab. 8.2)', re: true },
    { t: 'hint', keep: true, h: () => alRedHint() },
    { k: 'anch.pairSep', t: 'chk', l: 'Pary prętów jeden nad drugim jak pręty pojedyncze (8.9.1(4), dobre warunki przyczepności)', re: true },
    { t: 'hint', keep: true, h: () => pairHint() },
    { k: 'anch.Lmax', t: 'sel', l: 'Maks. długość pręta (zakłady prętów dłuższych)', o: [[6, '6 m'], [8, '8 m'], [10, '10 m'], [12, '12 m'], [14, '14 m'], [0, 'bez ograniczeń']], num: true, wide: true },
  ] },
  { id: 'sls', title: 'SGU – parametry', items: [
    { k: 'sls.RH', t: 'sel', l: 'Wilgotność względna RH', o: [[40, '40% (ogrzewane wnętrza)'], [50, '50% (wnętrza)'], [60, '60%'], [70, '70%'], [80, '80% (na zewnątrz)'], [90, '90%']], num: true, wide: true },
    { k: 'sls.t0', t: 'sel', l: 'Wiek betonu przy obciążeniu t_{0}', o: [3, 7, 10, 14, 21, 28, 60, 90].map(v => [v, v + ' dni']), num: true },
    { k: 'sls.cem', t: 'sel', l: 'Klasa cementu', o: [['S', 'S – CEM 32,5N'], ['N', 'N – CEM 32,5R, 42,5N'], ['R', 'R – CEM 42,5R, 52,5N/R']], wide: true },
    { k: 'sls.t', t: 'sel', l: 'Chwila obliczeniowa t', o: [['inf', 't = ∞'], ['25550', '70 lat'], ['18250', '50 lat'], ['3650', '10 lat'], ['365', '1 rok']] },
    { k: 'sls.ts', t: 'sel', l: 'Koniec pielęgnacji t_{s}', o: [1, 3, 7, 14, 28].map(v => [v, v + ' dni']), num: true },
    { k: 'sls.phiSel', t: 'sel', l: 'Pełzanie betonu – współczynnik φ(t,t_{0})', o: [['auto', 'obliczony (zał. B)'], ['manual', 'podany ręcznie'], ['off', 'nie uwzględniaj pełzania (φ = 0)']], re: true },
    { k: 'sls.phi', t: 'num', l: 'φ(t,t_{0})', list: [1.5, 2.0, 2.5, 3.0, 3.5], show: s => s.sls.phiSel === 'manual', min: 0 },
    { k: 'sls.lim', t: 'sel', l: 'Ugięcie graniczne', o: [200, 250, 300, 350, 400, 500].map(v => [v, 'L/' + v]), num: true },
    { k: 'sls.camber', t: 'num', l: 'Odwrotna strzałka ugięcia (podniesienie deskowania) w_{0}', u: 'mm', list: ['', 'auto', 5, 10, 15, 20, 25, 30, 40, 50], opt: true, auto: true, ph: 'brak', min: 0 },
    { t: 'hint', exT: 'Odwrotna strzałka – jak liczona?', h: () => R && R.sls && R.sls.defl && R.sls.defl.spans.some(q => q.camber > 0) ? [`Przyjęto: ${R.sls.defl.spans.filter(q => q.camber > 0).map(q => `${R.md.cont ? esc(q.label) + ': ' : ''}w<sub>0</sub> = ${fmt(q.camber, 0)} mm (f = ${fmt(q.tot.f, 1)} → f − w<sub>0</sub> = ${fmt(q.tot.f - (q.camberUse ? q.camber : 0), 1)} mm)`).join('; ') || 'brak (ugięcie ≤ 0)'}.`, hintCamber()] : ['', hintCamber()] },
    { t: 'hint', ex: true, exT: 'Kiedy L/250, L/300, L/500…?', h: () => 'Kiedy jakie ugięcie graniczne: <b>L/250</b> – wartość podstawowa PN-EN 1992-1-1, 7.4.1(4): ugięcie od obciążeń quasi-stałych, gdy chodzi o wygląd i ogólną użytkowalność (stropy, belki bez elementów wrażliwych); <b>L/500</b> – 7.4.1(5): przyrost ugięcia po wykonaniu elementów wrażliwych (ścianki działowe murowane, okładziny, przeszklenia), które mogą ulec uszkodzeniu; <b>L/300 – L/400</b> – często stosowane dla belek podpierających ściany działowe, belek podsuwnicowych, dachów z pokryciem wrażliwym lub gdy wymaga tego inwestor/specyfikacja; <b>L/200</b> – elementy drugorzędne, w których większe ugięcie nie wpływa na wygląd i użytkowanie. Dla wsporników jako L przyjmuje się 2·l (podwójny wysięg).' },
    { k: 'sls.wSel', t: 'sel', l: 'Graniczna szerokość rys w_{max}', o: [['auto', 'auto (tab. 7.1N)'], ['0.4', '0,4 mm'], ['0.3', '0,3 mm'], ['0.2', '0,2 mm'], ['0.1', '0,1 mm']] },
    { k: 'sls.sens', t: 'chk', l: 'Belka podpiera elementy wrażliwe na ugięcia (7/L dla L > 7 m)' },
  ] },
  { id: 'coef', title: 'Współczynniki (Załącznik krajowy PL)', closed: true, items: [
    { k: 'coef.gc', t: 'num', l: 'γ_{c} – sytuacja trwała/przejściowa', list: [1.4, 1.5], min: 1 },
    { k: 'coef.gs', t: 'num', l: 'γ_{s} – sytuacja trwała/przejściowa', list: [1.15], min: 1 },
    { k: 'coef.gcA', t: 'num', l: 'γ_{c,A} – sytuacja wyjątkowa', list: [1.2], min: 1 },
    { k: 'coef.gsA', t: 'num', l: 'γ_{s,A} – sytuacja wyjątkowa', list: [1.0], min: 1 },
    { k: 'coef.acc', t: 'num', l: 'α_{cc}', list: [0.85, 1.0], min: 0.5 },
    { k: 'coef.act', t: 'num', l: 'α_{ct}', list: [0.8, 1.0], min: 0.5 },
    { k: 'coef.k1', t: 'num', l: 'k_{1} (σ_c, kombinacja char.)', list: [0.6], min: 0.1 },
    { k: 'coef.k2', t: 'num', l: 'k_{2} (σ_c, kombinacja quasi-stała)', list: [0.45], min: 0.1 },
    { k: 'coef.k3', t: 'num', l: 'k_{3} (σ_s, kombinacja char.)', list: [0.8, 1.0], min: 0.1 },
  ] },
];

const LIST_TITLE = { perm: 'Dodatkowe obciążenia stałe (na odcinku / siły skupione)', imp: 'Obciążenia użytkowe (PN-EN 1991-1-1)', snow: 'Obciążenie śniegiem (PN-EN 1991-1-3)', wind: 'Oddziaływanie wiatru (PN-EN 1991-1-4)', other: 'Inne obciążenia zmienne (ψ podane ręcznie)', acc: 'Obciążenia wyjątkowe A_d' };
const LIST_DEF = {
  perm: n => ({ name: `Stałe ${n}`, q: 0, pts: [{ P: 10, a: '', ref: 'L' }] }),
  imp: n => ec1Auto({ kind: 'imp', name: `Użytkowe ${n}`, cat: 'B', sub: 'B', bw: impBwDef(), qAuto: true, q: 0 }),
  snow: () => ({ kind: 'snow', name: 'Śnieg', alt: 'low', q: 2 }),
  wind: n => ({ kind: 'wind', name: n > 1 ? `Wiatr ${n}` : 'Wiatr', q: 1 }),
  other: n => ({ kind: 'other', name: `Inne ${n}`, q: 1, p0: 0.7, p1: 0.5, p2: 0.3 }),
  acc: n => ({ name: `Wyjątkowe ${n}`, q: 0, pts: [{ P: 50, a: '', ref: 'L' }] }),
};
const KIND_COLOR = { G: '#4a5466', perm: '#4a5466', imp: '#1d5bb8', snow: '#0e8fa8', wind: '#1d7f3c', other: '#6a3fb5', acc: '#c0262d' };
const listArr = kind => kind === 'acc' ? S.loads.acc : kind === 'perm' ? S.loads.perm : S.loads.var;
const arrKey = kind => kind === 'acc' ? 'acc' : kind === 'perm' ? 'perm' : 'var';
const arrByKey = k => k === 'acc' ? S.loads.acc : k === 'perm' ? S.loads.perm : S.loads.var;
const REFS = [['L', 'od lewej [m]'], ['R', 'od prawej [m]'], ['rel', 'względnie x/L']];
const DIRS = [['y', 'Y – pionowo'], ['z', 'Z – poziomo (⊥ do układu)'], ['yz', 'Y i Z jednocześnie'], ['t', 'tylko moment skręcający']];
function model() { try { return E.beamModel(S); } catch (e) { return { segs: [], sups: [], Ltot: S.geom.L * 1000 }; } }
function itemRange(it, md) {
  md = md || model();
  const sg = it && it.span > 0 ? md.segs[it.span - 1] : null;
  if (sg && it.el !== '' && it.el !== undefined && sg.els && sg.els.length > 1) { const e = sg.els[Math.min(+it.el, sg.els.length - 1)]; return { x0: e.x0, L: e.L, sg, e }; }
  return { x0: sg ? sg.x0 : 0, L: sg ? sg.L : md.Ltot, sg, e: null };
}
function segLen(it) { return itemRange(it).L / 1000; }
function absText(p, it) {
  if (p.ref === 'L' && p.a !== '') return '';
  const Lr = segLen(it) * 1000, x = E.absX(Lr, p.a, p.ref);
  return `= ${fmt(x / 1000, 3)} m`;
}
function idOf(kind, i) {
  if (!R || !R.st || !R.st.vars) return '—';
  if (kind === 'perm') return E.hasLoad(S.loads.perm[i] || {}) ? 'G' : '—';
  const v = (kind === 'acc' ? R.st.accs : R.st.vars).find(o => o.si === i);
  return v ? v.id : '—';
}
function renderList(kind, filt, ctx) {
  const arr = listArr(kind), ak = arrKey(kind);
  const idx = arr.map((it, i) => [it, i]).filter(([it]) => (kind === 'acc' || kind === 'perm' || it.kind === kind) && (!filt || filt(it)));
  const ctxA = ctx ? ` data-span="${ctx.span}" data-el="${ctx.el}"` : '';
  let h = `<div class="lhead"><span>${sym(LIST_TITLE[kind])}</span>${ctx && ctx.noAdd ? '' : `<button class="addb" data-add="${kind}"${ctxA}>+ dodaj</button>`}</div>`;
  if (!idx.length) h += `<div class="lnone">brak</div>`;
  const sub = kind === 'acc' ? 'd' : 'k';
  const segs = model().segs;
  idx.forEach(([it, i]) => {
    const key = ak + '.' + i, dir = it.dir || 'y';
    const inp = (fld, ph, cls) => `<input class="txt ${cls || ''}" data-li="${key}.${fld}" value="${esc(showNum(it[fld]))}" ${ph ? `placeholder="${ph}"` : ''} spellcheck="false" autocomplete="off">`;
    let sel = '';
    if (kind === 'imp') { const L = E.IMP_EC1[it.cat] || E.IMP_EC1.B, sb = (L.find(z => z.id === it.sub) || L[0]).id;
      sel = `<select data-li="${key}.cat">${['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map(c => `<option value="${c}" ${it.cat === c ? 'selected' : ''}>${esc(E.PSI[c].name)}</option>`).join('')}</select>`
        + (L.length > 1 ? `<select data-li="${key}.sub" title="Podkategoria wg PN-EN 1991-1-1">${L.map(z => `<option value="${z.id}" ${sb === z.id ? 'selected' : ''} title="${esc(z.d)}">${esc(z.n)}</option>`).join('')}</select>` : '')
        + `<span title="Szerokość pasma zbierania obciążenia z płyty (rozstaw belek) – do przeliczenia q_k [kN/m²] na obciążenie belki [kN/m]">pasmo b</span>${inp('bw', '–', 'sm')}<span class="u">m</span></div><div class="lrow ec1" data-ec1="${key}">${ec1Row(it, key)}`; }
    else if (kind === 'snow') sel = `<select data-li="${key}.alt"><option value="low" ${it.alt !== 'high' ? 'selected' : ''}>H ≤ 1000 m n.p.m.</option><option value="high" ${it.alt === 'high' ? 'selected' : ''}>H > 1000 m n.p.m.</option></select>`;
    const dirSel = `<select data-li="${key}.dir" title="Kierunek działania">${DIRS.map(([v, l]) => `<option value="${v}" ${dir === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
    const spanSel = ctx ? '' : (segs.length > 1 ? `<select data-li="${key}.span" title="Odcinek belki">${[[0, 'cała belka'], ...segs.map((sg, j) => [j + 1, sg.label])].map(([v, l]) => `<option value="${v}" ${(it.span || 0) === v ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>` : '');
    let psiTxt = '';
    if (kind === 'other') psiTxt = `<div class="lrow"><span>ψ₀</span>${inp('p0', '', 'sm')}<span>ψ₁</span>${inp('p1', '', 'sm')}<span>ψ₂</span>${inp('p2', '', 'sm')}</div>`;
    else if (kind !== 'acc' && kind !== 'perm') { const ps = E.psiOf(it); psiTxt = `<div class="lpsi">ψ₀ = ${psiF(ps.p0)} · ψ₁ = ${psiF(ps.p1)} · ψ₂ = ${psiF(ps.p2)}</div>`; }
    const multiS = it.spans && it.spans.length > 1, tor = dir === 't' || !!it.tor;
    const pts = multiS ? '' : (it.pts || []).map((p, j) => {
      const pk = `${key}.${j}`;
      const pin = (fld, lab, u) => `<span>${lab}</span><input class="txt" data-lp="${pk}.${fld}" value="${esc(showNum(p[fld]))}" placeholder="0" spellcheck="false" autocomplete="off"><span class="u">${u || 'kN'}</span>`;
      return `<div class="lrow pt">${dir !== 'z' && dir !== 't' ? pin('P', `P<sub>${sub}</sub>${dir === 'yz' ? '<sup>Y</sup>' : ''}`) : ''}${dir !== 'y' && dir !== 't' ? pin('Pz', `P<sub>${sub}</sub><sup>Z</sup>`) : ''}${tor ? pin('T', `T<sub>${sub}</sub>`, 'kNm') : ''}` +
        `<span>x</span><input class="txt sm" data-lp="${pk}.a" value="${esc(showNum(p.a))}" placeholder="${p.ref === 'rel' ? '0,5' : 'L/2'}" spellcheck="false" autocomplete="off">` +
        `<select class="ref" data-lp="${pk}.ref">${REFS.map(([v, l]) => `<option value="${v}" ${p.ref === v ? 'selected' : ''}>${l}</option>`).join('')}</select>` +
        `<span class="lx">${absText(p, it)}</span><button class="del sm" data-dp="${pk}" title="Usuń siłę">×</button></div>`;
    }).join('');
    const shp = it.shape === 't' || it.shape === 'p' ? it.shape : 'u';
    const qy = dir !== 'z' && dir !== 't' ? (shp === 'p' ? '' : `<span>q<sub>${sub}</sub>${dir === 'yz' ? '<sup>Y</sup>' : ''}${shp === 't' ? '<sub>,1</sub>' : ''}</span>${inp('q', '0')}<span class="u">kN/m</span>` + (shp === 't' ? `<span>→ q<sub>${sub},2</sub></span>${inp('q2', '0')}<span class="u">kN/m</span>` : '')) : '';
    const shapeRow = dir !== 'z' && dir !== 't' && !multiS ? `<div class="lrow"><select data-li="${key}.shape" title="Rozkład obciążenia ciągłego">${[['u', 'równomierne'], ['t', 'liniowo zmienne – trapezowe / trójkątne'], ['p', 'o zadanej geometrii (punkty x : q)']].map(([v, l]) => `<option value="${v}" ${shp === v ? 'selected' : ''}>${l}</option>`).join('')}</select>${shp === 't' ? `<button class="lnk" data-tri="${key}.0" title="q₁ = 0 – trójkąt rosnący">◺ 0→q</button><button class="lnk" data-tri="${key}.1" title="q₂ = 0 – trójkąt malejący">◹ q→0</button>` : ''}${dir === 'y' ? `<span>kąt od pionu α</span>${inp('ang', '0', 'sm')}<span class="u">°</span>` : ''}</div>` + (shp === 'p' ? `<div class="lrow"><span>q(x)</span><input class="txt lprof" data-li="${key}.prof" value="${esc(it.prof || '')}" placeholder="np. 0:5; 2:12; 4,5:12; 6:0" spellcheck="false" autocomplete="off"><span class="u">m : kN/m</span></div>` : '') : '';
    const qz = dir !== 'y' && dir !== 't' ? `<span>q<sub>${sub}</sub><sup>Z</sup></span>${inp('qz', '0')}<span class="u">kN/m</span>` : '';
    const mt = tor ? `<span>m<sub>t,${sub}</sub></span>${inp('mt', '0')}<span class="u">kNm/m</span>` : '';
    const segsTxt = multiS ? `<span class="lx">na przęsłach: ${it.spans.map(j => segs[j - 1] ? segs[j - 1].label.replace('przęsło ', '') : j).join(', ')} (całe)</span>` : '';
    const flags = `<div class="lrow flags">${dir !== 't' ? `<label class="chk sm"><input type="checkbox" data-lf="${key}.tor" ${it.tor ? 'checked' : ''}><span>+ moment skręcający (mimośród)</span></label>` : ''}<label class="chk sm" title="Redukcja V_Ed w odległości d od lica (6.2.1(8)) – tylko przy obciążeniu górnej powierzchni"><input type="checkbox" data-lf="${key}.top" ${it.top !== false ? 'checked' : ''}><span>przyłożone do górnej powierzchni</span></label></div>`;
    h += `<div class="litem" style="border-left-color:var(--sv-${KIND_COLOR[kind].slice(1)}, ${KIND_COLOR[kind]})"><div class="lrow top"><span class="lid">${idOf(kind, i)}</span><input class="txt lname" data-li="${key}.name" value="${esc(it.name)}" placeholder="nazwa" spellcheck="false"><button class="del" data-del="${key}" title="Usuń obciążenie">×</button></div>
      ${sel ? `<div class="lrow">${sel}</div>` : ''}
      <div class="lrow">${dirSel}${spanSel}${ctx && ctx.where ? `<span class="lx">${esc(ctx.where(it))}</span>` : ''}${segsTxt}</div>
      ${shapeRow}<div class="lrow">${qy}${qz}${mt}${multiS || shp === 'p' ? '' : `<span>od</span>${inp('x1', '0', 'sm')}<span>do</span>${inp('x2', 'L', 'sm')}<span class="u">m</span>`}</div>
      ${pts}${multiS ? '' : `<div class="lrow"><button class="addp" data-ap="${key}">+ ${tor && dir === 't' ? 'moment skupiony' : 'siła skupiona'}</button></div>`}
      ${flags}${psiTxt}</div>`;
  });
  return h;
}
// pasmo zbierania obciążenia nowego obciążenia użytkowego [m]: jak w ostatnim obciążeniu użytkowym; belka teowa z b_eff z b₁, b₂ – b₁ + b_w + b₂; inaczej 1,0 m
function impBwDef() {
  const last = S.loads.var.filter(it => it.kind === 'imp' && +it.bw > 0).pop(); if (last) return +last.bw;
  if (S.geom.type === 'T' && S.geom.beffMode === 'auto' && S.geom.b1 > 0) return Math.round((+S.geom.b1 + +S.geom.b2 + +S.geom.b) / 10) / 100;
  return 1;
}
// q_k obciążenia użytkowego wpisywane automatycznie (qAuto): górna granica zakresu EC1 × pasmo b – do pierwszej ręcznej zmiany q_k
function ec1Auto(it) {
  if (!it || it.kind !== 'imp' || !it.qAuto) return it;
  const L = E.IMP_EC1[it.cat] || E.IMP_EC1.B, q = L.find(z => z.id === it.sub) || L[0], bw = +it.bw > 0 ? +it.bw : 1;
  it.q = Math.round(q.q[1] * bw * 100) / 100; if (it.shape === 't') it.q2 = it.q;
  return it;
}
// podpowiedź obciążenia użytkowego wg PN-EN 1991-1-1 (tabl. 6.2, 6.4, 6.8, 6.10): zakres q_k, Q_k i górna granica przeliczona przez pasmo b na kN/m
function ec1Row(it, key) {
  const L = E.IMP_EC1[it.cat] || E.IMP_EC1.B, q = L.find(z => z.id === it.sub) || L[0];
  const rng = a => a[0] === a[1] ? fmt(a[0], 1) : `${fmt(a[0], 1)}–${fmt(a[1], 1)}`;
  const up = q.q[1], bw = +it.bw > 0 ? +it.bw : (it.qAuto ? 1 : null), cur = bw && +it.q > 0 ? +it.q / bw : null;
  let t = `<span class="ec1t" title="${esc(q.d)}">EC1, tabl. ${q.t} – ${esc(q.n)}: q<sub>k</sub> = ${rng(q.q)} kN/m², Q<sub>k</sub> = ${rng(q.Q)} kN.</span> `;
  if (it.qAuto) return t + `<b>q<sub>k</sub> = ${fmt(up, 1)} kN/m² × ${fmt(bw, 2)} m = ${fmt(up * bw, 2)} kN/m</b> – wpisane automatycznie (górna granica × pasmo b${+it.bw > 0 ? '' : '; pasmo b = 1,0 m – wpisz rozstaw belek'}); zmiana kategorii lub pasma przelicza q<sub>k</sub>, wpisanie q<sub>k</sub> ręcznie wyłącza przeliczanie.`;
  t += bw ? `Górna granica: ${fmt(up, 1)} kN/m² × ${fmt(bw, 2)} m = <b>${fmt(up * bw, 2)} kN/m</b> <button class="lnk" data-ec1q="${key}" title="Przyjmij q_k = górna granica × pasmo b i przeliczaj automatycznie">przyjmij (automatycznie)</button>`
    : `Górna granica: <b>${fmt(up, 1)} kN/m²</b> – podaj pasmo b (rozstaw belek), aby przeliczyć na kN/m.`;
  if (cur !== null) t += ` Obecnie q<sub>k</sub>/b = ${fmt(cur, 2)} kN/m²${cur < q.q[0] - 1e-6 ? ' – <b class="ec1bad">poniżej zakresu normy</b>' : cur > up + 1e-6 ? ' (powyżej górnej granicy)' : Math.abs(cur - up) < 1e-6 ? ' (górna granica)' : ''}.`;
  return t;
}
function hintLoads() {
  if (!R || !R.st || R.st.manual || !R.st.tabU) return '';
  const st = R.st, gov = st.tabU.find(r => r.govMpos) || st.tabU.find(r => r.govMneg);
  let t = `g<sub>k</sub> całk. = ${fmt(st.gk, 2)} kN/m (w tym c.w. ${fmt(st.gSelf, 2)}); kombinacji SGN: <b>${st.tabU.length}</b>, charakterystycznych: ${st.tabK.length}` + (st.tabA ? `, wyjątkowych: ${st.tabA.length}` : '');
  if (gov) t += `<br>Decyduje: <b>${esc(gov.name)}</b> (${esc(gov.desc)})`;
  return t;
}
function hintGeo(s) {
  if (!R || !R.g || !R.g.Ac) return '';
  const g = R.g;
  let t = `A<sub>c</sub> = ${fmt(g.Ac / 1e4, 1)} cm², I<sub>c</sub> = ${fmt(g.Ic / 1e8, 1)}·10<sup>4</sup> cm⁴, c.w. = ${fmt(g.selfW, 2)} kN/m`;
  if (g.T && g.beffAuto) t += `<br>b<sub>eff</sub> wg 5.3.2.1 = <b>${fmt(g.beff, 0)} mm</b> (l<sub>0</sub> = ${fmt(g.l0 / 1000, 2)} m)`;
  return t;
}
const cap = t => t ? t[0].toUpperCase() + t.slice(1) : t;
const clampI = (v, a, b) => Math.max(a, Math.min(b, v));
function hintSurf() {
  if (!R || !R.surf) return '';
  const f = R.surf;
  if (!f.req) return `Nie jest wymagane: ⌀<sub>max</sub> (lub ⌀<sub>n</sub> wiązki) = ${fmt(f.dmax, 0)} mm ≤ 32 mm i c<sub>nom</sub> = ${f.cnom} mm ≤ 70 mm.`;
  return `<b>Wymagane</b> – ${[f.byBar ? `⌀ = ${fmt(f.dmax, 1)} mm > 32 mm` : '', f.byCover ? `c<sub>nom</sub> = ${f.cnom} mm > 70 mm` : ''].filter(Boolean).join(', ')}: siatka o oczku ≤ 150 mm, A<sub>s,surf</sub> ≥ ${f.rho === 0.01 ? '0,01' : '0,005'}·A<sub>ct,ext</sub> w obu kierunkach` + (f.gov ? ` → ${fmt(f.AsReq, 0)} mm² (przyjęto ${fmt(f.AsProv, 0)} mm²).` : '.');
}
// belka ciągła: rozpiętości, podpory skrajne, wsporniki
function contHTML() {
  const C = S.cont, n = C.spans.length;
  let h = `<div class="row"><label>Liczba przęseł</label><select data-cn="1">${rng(1, 8, 1).map(v => `<option value="${v}" ${v === n ? 'selected' : ''}>${v}</option>`).join('')}</select><span></span></div>`;
  const list = JSON.stringify([2, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 9, 10, 12]);
  C.spans.forEach((v, i) => { h += `<div class="row"><label>Rozpiętość przęsła ${i + 1} L<sub>${i + 1}</sub></label><div class="combo"><input data-k="cont.spans.${i}" value="${esc(showNum(v))}" data-min="0.3" autocomplete="off" spellcheck="false"><button tabindex="-1" data-list='${list}' aria-label="lista">▾</button></div><span class="unit">m</span></div>`; });
  // przekroje przęseł b × h (każde przęsło osobno; wsporniki – jak przęsło sąsiednie)
  const gs = C.geoSpans || [], bl = JSON.stringify([150, 200, 250, 300, 350, 400, 450, 500, 600]), hl = JSON.stringify([300, 400, 450, 500, 550, 600, 650, 700, 800, 900, 1000]);
  h += `<div class="lsub">Przekroje przęseł b × h</div>`;
  C.spans.forEach((v, i) => { const q = gs[i] || {}; const bv = q.b > 0 ? q.b : S.geom.b, hv = q.h > 0 ? q.h : S.geom.h; h += `<div class="row geo2"><label>Przęsło ${i + 1}: b × h</label><div class="combo sm2"><input data-k="cont.geoSpans.${i}.b" value="${esc(showNum(bv))}" data-min="60" autocomplete="off" spellcheck="false"><button tabindex="-1" data-list='${bl}' aria-label="lista">▾</button></div>${dimBadge(i, 'b')}<div class="combo sm2"><input data-k="cont.geoSpans.${i}.h" value="${esc(showNum(hv))}" data-min="120" autocomplete="off" spellcheck="false"><button tabindex="-1" data-list='${hl}' aria-label="lista">▾</button></div>${dimBadge(i, 'h')}<span class="unit">mm</span></div>`; });
  const cl = JSON.stringify([0, 0.5, 1, 1.5, 2, 2.5, 3]);
  [['cantL', 'Wspornik lewy (0 – brak)'], ['cantR', 'Wspornik prawy (0 – brak)']].forEach(([k, lab]) => { h += `<div class="row"><label>${lab}</label><div class="combo"><input data-k="cont.${k}" value="${esc(showNum(C[k]))}" data-min="0" data-re="1" autocomplete="off" spellcheck="false"><button tabindex="-1" data-list='${cl}' aria-label="lista">▾</button></div><span class="unit">m</span></div>`; });
  return h;
}
// automatyczna długość prętów dodatkowych (z ostatnich obliczeń) – podpowiedź w polu
// długość prętów górnych dodatkowych nad podporą pośrednią (od osi podpory, w lewo / w prawo; puste – długość wymagana) – z widoku podłużnego
function setSupLen(i, sd, txt) {
  const t = String(txt || '').trim(), v = t === '' ? '' : parseNum(t);
  if (v !== '' && !(v > 0 && v <= 30)) return false;
  const C = S.cont; C.rebSupps[i] = C.rebSupps[i] || Object.assign(E.zoneOf([]), { lenL: '', lenR: '' });
  C.rebSupps[i][sd === 'L' ? 'lenL' : 'lenR'] = v === '' ? '' : String(v); return true;
}
function supLenPopup(i, focus) {
  const m = $('#modal'), z = S.cont.rebSupps[i] || {}, nm = String.fromCharCode(65 + i);
  m.innerHTML = `<div class="dlg barpop"><h3>Pręty górne nad podporą ${nm} – długość</h3>
    <div class="zl"><h5>Długość prętów dodatkowych od osi podpory</h5><div class="zg"><span>w lewo</span><input class="txt" id="slL" value="${esc(showNum(z.lenL))}" placeholder="${esc(autoLenTxt(i, 'L'))}" inputmode="decimal"><span>m</span><span>w prawo</span><input class="txt" id="slR" value="${esc(showNum(z.lenR))}" placeholder="${esc(autoLenTxt(i, 'R'))}" inputmode="decimal"><span>m</span></div></div>
    <div class="hint">Puste pole – długość wymagana: zasięg |M<sub>Ed</sub>| > M<sub>Rd</sub> prętów ciągłych + a<sub>l</sub> + l<sub>bd</sub> (9.2.1.3). Wpisana dłuższa – pręty przedłużone do tej długości (pozycje w zestawieniu, widok podłużny, DXF); krótsza od wymaganej jest zgłaszana w sprawdzeniach.</div>
    <div class="iss" id="slErr" style="display:none">Długość od 0 do 30 m.</div>
    ${focus ? `<p><button class="lnk" id="slBend">Zakończenie pręta (odgięcie)…</button></p>` : ''}
    <div class="dbtn"><button class="btn" id="slAuto">Automatycznie</button><span class="sp"></span><button class="btn" id="slCancel">Anuluj</button><button class="btn pri" id="slOk">Zastosuj</button></div></div>`;
  m.style.display = 'flex';
  $('#slCancel', m).onclick = () => { m.style.display = 'none'; };
  $('#slAuto', m).onclick = () => { setSupLen(i, 'L', ''); setSupLen(i, 'R', ''); m.style.display = 'none'; changed(true); };
  $('#slOk', m).onclick = () => { const a = $('#slL', m).value, b = $('#slR', m).value; const z0 = JSON.parse(JSON.stringify(S.cont.rebSupps[i] || {}));
    if (!setSupLen(i, 'L', a) || !setSupLen(i, 'R', b)) { S.cont.rebSupps[i] = z0; $('#slErr', m).style.display = ''; return; } m.style.display = 'none'; changed(true); };
  m.querySelectorAll('input.txt').forEach(q => q.addEventListener('keydown', ev => { if (ev.key === 'Enter') $('#slOk', m).click(); }));
  const bb = $('#slBend', m); if (bb) bb.onclick = () => { m.style.display = 'none'; barPopup('x' + i, focus); };
  const fi = $(focus === 'R' ? '#slR' : '#slL', m); fi.focus(); fi.select();
}
function hintCamber() { return 'Odwrotna strzałka w<sub>0</sub> (PN-EN 1992-1-1, 7.4.1(4)): ugięcie od obciążeń quasi-stałych można skompensować podniesieniem deskowania (strzałką odwrotną); sprawdzane jest wtedy f − w<sub>0</sub> ≤ L/lim, a strzałka nie powinna przekraczać L/250. <b>auto</b> – w<sub>0</sub> równe ugięciu (zaokrąglone w dół do 5 mm), nie więcej niż L/250. Przy ugięciu granicznym L/500 (ugięcie po wykonaniu elementów wrażliwych, 7.4.1(5)) strzałka odwrotna nie zmniejsza ugięcia. Strzałka jest pokazywana na wykresie ugięć (zakładka Wykresy) i w raporcie.'; }
function autoLenTxt(i, side) {
  if (!R || !R.anch || !R.anch.topCut) return 'auto';
  const tc = R.anch.topCut.find(q => q.sup.idx === i) || (!R.md.cont ? R.anch.topCut[0] : null);
  if (!tc) return 'auto';
  const sd = tc.sides.find(q => q.side === side && !q.none && !q.cant) || (!R.md.cont ? tc.sides.find(q => !q.none && !q.cant) : null);
  return sd ? `auto ${fmt(sd.lenReq / 1000, 2)}` : 'auto';
}
// największa liczba ramion strzemion, przy której każde ramię obejmuje pręt podłużny (warstwa 1, dół i góra)
function hintAutoS() {
  if (!R || !R.md || (R.errors && R.errors.length) || !R.sh) return '';
  const seen = new Set(), parts = [];
  R.md.segs.forEach(sg => { const q = sg.stir; if (seen.has(q) || !q.sAutoInfo) return; seen.add(q); const a = q.sAutoInfo;
    const es = R.sh.ends.filter(e => e.stir === q), lz = es.map(e => `${esc(e.sup.label)}: s₁ na ${fmt(e.l1 / 1000, 2)} m${e.sp ? `, s_p na ${fmt(e.lp / 1000, 2)} m` : ''}`).join(', ');
    parts.push(`${R.md.segs.length > 1 ? esc(sg.label) + ': ' : ''}<b>s₁ = ${q.s1} mm${q.sp ? `, s_p = ${q.sp} mm` : ''}, s₂ = ${q.s2} mm</b> (z V<sub>Ed</sub> i cot θ = ${fmt(a.cot, 2)}: s ≤ ${isFinite(a.need) ? fmt(a.need, 0) : '∞'}; ρ<sub>w,min</sub>: ${fmt(a.sRho, 0)}; s<sub>l,max</sub>: ${fmt(a.sMax, 0)} mm)${lz ? ` – od lica: ${lz}` : ''}`); });
  return parts.join('; ') + (parts.length ? '. Strefy od podpory: s₁ – gdzie V<sub>Ed</sub> > V<sub>Rd,s</sub>(s<sub>p</sub>) lub V<sub>Rd,s</sub>(s₂), strefa pośrednia s<sub>p</sub> (gdy zmniejsza liczbę strzemion o ≥ 3 szt. i ≥ 4%) – gdzie V<sub>Ed</sub> > V<sub>Rd,s</sub>(s₂), dalej s₂. Rozstawy zaokrąglone w dół do 25 mm (poniżej 100 mm – do 5 mm), min. 50 mm. Odznacz, aby wpisać rozstawy ręcznie (w belce ciągłej możesz też wpisać rozstaw tylko dla wybranego przęsła).' : '');
}
function holdMax(si) {
  if (!R || !R.md || (R.errors && R.errors.length)) return 0;
  const segs = R.md.segs.filter(sg => sg.hold && sg.kind === 'span' && (si === null ? !(CONT(S) && S.cont.stirSpans[sg.si] && S.cont.stirSpans[sg.si].legs > 0) : sg.si === si));
  return segs.length ? Math.min(...segs.map(sg => sg.hold.maxLegs || 2)) : 0;
}
// strzemiona w poszczególnych przęsłach belki ciągłej (puste – jak ogólne)
function stirSpansHTML() {
  const C = S.cont, ov = C.stirSpans || [];
  const opt = (arr, v) => arr.map(([a, l]) => `<option value="${a}" ${String(a) === String(v) ? 'selected' : ''}>${esc(l)}</option>`).join('');
  const kinds = [['', '– jak ogólne –'], ...Object.entries(E.STIR_KIND).map(([k, l]) => [k, l.replace(/ \(.*\)$/, '')])];
  const dias = [['', '–'], ...[6, 8, 10, 12].map(d => [d, '⌀' + d])], legs = [['', '–'], ...[2, 3, 4, 5, 6, 8].map(n => [n, n + '-cięte'])];
  const sl = JSON.stringify(['', 75, 100, 125, 150, 175, 200, 250, 300, 350]);
  let h = `<div class="lsub">Strzemiona w poszczególnych przęsłach<small> – puste pola: jak wyżej (${S.stir.legs}-cięte ⌀${S.stir.d}${S.stir.sAuto ? ', rozstaw automatyczny' : `, s₁ = ${S.stir.s1}${+S.stir.sp > 0 ? `, s_p = ${S.stir.sp}` : ''}, s₂ = ${S.stir.s2}`})</small></div><div class="tscroll"><table class="sttab"><tr><th>Przęsło</th><th>Rodzaj</th><th>⌀</th><th>Ramiona</th><th>s₁ [mm]</th><th>s_p [mm]</th><th>s₂ [mm]</th></tr>`;
  C.spans.forEach((L, i) => {
    const q = ov[i] || {};
    h += `<tr><td>${i + 1} <small>(${fmt(L, 2)} m)</small></td><td><select data-k="cont.stirSpans.${i}.kind" data-re="1">${opt(kinds, q.kind || '')}</select></td><td><select data-k="cont.stirSpans.${i}.d" data-re="1">${opt(dias, q.d)}</select></td><td><select data-k="cont.stirSpans.${i}.legs" data-re="1">${legs.map(([a, l]) => { const mx = holdMax(i), bad = a !== '' && mx && a > mx; return `<option value="${a}" ${String(a) === String(q.legs) ? 'selected' : ''} ${bad && String(a) !== String(q.legs) ? 'disabled' : ''}>${esc(l)}${bad ? ' – brak prętów' : ''}</option>`; }).join('')}</select></td>` +
      ['s1', 'sp', 's2'].map(k => { const sg = R && R.md ? R.md.segs.find(z => z.si === i) : null, auto = S.stir.sAuto && sg ? (k === 'sp' && !sg.stir.sp ? 'auto –' : `auto ${sg.stir[k]}`) : (k === 'sp' && !(+S.stir.sp > 0) ? '–' : String(S.stir[k])); return `<td><div class="combo sm3"><input data-k="cont.stirSpans.${i}.${k}" value="${esc(showNum(q[k]))}" placeholder="${auto}" data-opt="1" data-min="30" autocomplete="off" spellcheck="false"><button tabindex="-1" data-list='${sl}' aria-label="lista">▾</button></div></td>`; }).join('') + `</tr>`;
  });
  return h + `</table></div>`;
}
function hintStirKind() {
  let t = '<b>Kiedy jakie strzemiona:</b> <b>2-cięte</b> – belki do ok. b<sub>w</sub> = 400 mm, gdy rozstaw poprzeczny ramion s<sub>t</sub> ≤ s<sub>t,max</sub> = min(0,75·d; 600 mm) (9.2.2(8)); <b>4-cięte</b> – szersze belki (gdy przy 2 ramionach s<sub>t</sub> > s<sub>t,max</sub>), duża siła poprzeczna przy ograniczonym rozstawie, 5 i więcej prętów w warstwie; <b>6–8-cięte</b> – belki bardzo szerokie (b<sub>w</sub> ≥ ok. 800–1200 mm), podciągi z dużą siłą poprzeczną; <b>zamknięte + szpilki</b> – ramiona wewnętrzne jako szpilki z hakami 135° (łatwiejszy montaż przy wielu prętach); <b>otwarte (U)</b> – tylko bez skręcania, w belkach zespolonych z płytą (kotwione w strefie ściskanej, z prętem montażowym u góry); <b>na skręcanie</b> – zawsze zamknięte, zakotwione zakładem lub hakami 135° (9.2.3(1), rys. 9.6), rozstaw ≤ u/8 (9.2.3(3)); do skręcania liczy się tylko obwód zewnętrzny.';
  let n = '';
  const hd = R && R.md && R.md.segs[0] && R.md.segs[0].hold ? R.md.segs : null;
  if (hd) n += 'Ramiona strzemion muszą obejmować pręty podłużne w narożach: ' + R.md.segs.filter(sg => sg.kind === 'span' && sg.hold).map(sg => `${R.md.segs.length > 1 ? esc(sg.label) + ': ' : ''}warstwa 1 – dół ${sg.hold.nB}, góra ${sg.hold.nT} prętów → maks. <b>${sg.hold.maxLegs || 0}</b> ramion`).join('; ') + '. ';
  if (R && R.sh && R.sh.segs) n += '<b>Wymagana liczba:</b> ' + R.sh.segs.map(q => `${R.sh.segs.length > 1 ? esc(q.seg.label) + ': ' : ''}b<sub>w</sub> = ${q.seg.g.bw} mm, s<sub>t</sub> = ${fmt(q.st, 0)} mm ≤ s<sub>t,max</sub> = ${fmt(q.stMax, 0)} mm → min. <b>${q.legsMin}</b> ramiona`).join('; ') + (R.tor && R.tor.on ? ` · <b>T<sub>Ed</sub> = ${fmt(R.st.TEd / 1e6, 1)} kNm – wymagane strzemiona zamknięte</b>` : '');
  return [n, t];
}
function hintStir() {
  const z = R && R.stirZones;
  const t = 'Strzemiona od lica podpory: odstęp pierwszego strzemienia 10–50 mm dobierany tak, by rozstaw był równomierny (część środkowa – równy rozstaw ≤ s₂, najlepiej okrągły); strefa s₁ mierzona od lica.';
  let n = '';
  if (z && z.length) {
    const parts = z.filter(q => q.eL !== null || q.eR !== null).map(q => `${R.md.segs.length > 1 ? esc(q.seg.label) + ': ' : ''}e = ${q.eL !== null ? q.eL : q.eR} mm, ${q.n} szt., środek co <b>${fmt(q.sm, Math.abs(q.sm - Math.round(q.sm)) < 1e-6 ? 0 : 1)} mm</b>`);
    if (parts.length) n = parts.join('; ');
  }
  return [n, t];
}
function expHint(s) {
  const X = window.BZN && window.BZN.EXP;
  if (!X) return '';
  const cls = [s.env.exp, s.env.expF, s.env.expA].filter(c => c && c !== '-');
  return ['', cls.map(c => `<b>${c}</b> – np. ${esc(X[c] || '')}`).join('<br>') + ` <button class="lnk" data-expall="1">przykłady wszystkich klas…</button>`];
}

/* ------------------------------------------------------- render formularza */
function optionsOf(f) { return typeof f.o === 'function' ? f.o(S) : f.o; }
// podpowiedź: liczby i wzory widoczne, objaśnienia słowne – rozwijane na życzenie
const exDetails = (ex, t) => ex ? `<details class="exh"><summary>${t || 'Objaśnienie'}</summary><div>${ex}</div></details>` : '';
function hintHTML(f) {
  const h = f.h(S); if (!h) return '';
  if (Array.isArray(h)) return (h[0] || '') + exDetails(h[1], f.exT);
  return f.ex ? exDetails(h, f.exT) : h;
}
// pola formularza (wspólne dla zakładki Dane i okien w zakładce Przekrój)
function fieldsHTML(items, gid) {
  let html = '';
  items.forEach((f, i) => {
    if (f.show && !f.show(S)) return;
    const id = `f_${gid}_${i}`;
    if (f.t === 'hint') { const h = hintHTML(f); if (h || f.keep) html += `<div class="hint${f.keep ? ' keep info' : ''}" data-hint="${gid}_${i}"${h ? '' : ' style="display:none"'}>${h}</div>`; return; }
    if (f.t === 'sub') { html += `<div class="lsub">${sym(f.l)}</div>`; return; }
    if (f.t === 'html') { html += f.h(S); return; }
    if (f.t === 'sel') {
      const v = getP(S, f.k); const opts = optionsOf(f);
      const sel = opts.map(([val, lab]) => { const why = f.dis ? f.dis(val) : ''; return `<option value="${esc(val)}" ${String(val) === String(v) ? 'selected' : ''} ${why && String(val) !== String(v) ? 'disabled' : ''}>${esc(lab)}${why ? ' – ' + esc(why) : ''}</option>`; }).join('');
      html += `<div class="row ${f.wide ? 'wide' : ''}"><label for="${id}">${sym(f.l)}</label><select id="${id}" data-k="${f.k}" data-num="${f.num ? 1 : ''}" data-re="${f.re ? 1 : ''}">${sel}</select>${f.wide ? '' : '<span></span>'}</div>`;
    } else if (f.t === 'num') {
      const v = getP(S, f.k);
      const ph = typeof f.ph === 'function' ? f.ph(S) : f.ph;
      html += `<div class="row${f.badge ? ' hasdim' : ''}"><label for="${id}">${sym(f.l)}</label><div class="combo"><input id="${id}" data-k="${f.k}" value="${esc(showNum(v))}" ${ph ? `placeholder="${esc(ph)}"` : ''} data-opt="${f.opt ? 1 : ''}" ${f.auto ? 'data-auto="1"' : ''} data-min="${f.min !== undefined ? f.min : ''}" data-max="${f.max !== undefined ? f.max : ''}" data-ph="${typeof f.ph === 'function' ? gid + '_' + i : ''}" autocomplete="off" spellcheck="false"><button tabindex="-1" data-list="${esc(JSON.stringify(f.list || []))}" aria-label="lista">▾</button></div><span class="unit">${esc(f.u || '')}</span>${f.badge ? dimBadge(0, f.badge) : ''}</div>`;
    } else if (f.t === 'txt') {
      html += `<div class="row wide"><label for="${id}">${sym(f.l)}</label><input class="txt" id="${id}" data-kt="${f.k}" value="${esc(getP(S, f.k) || '')}" placeholder="${esc(f.ph || '')}" spellcheck="false" autocomplete="off"></div>`;
    } else if (f.t === 'chk') {
      html += `<label class="chk"><input type="checkbox" data-k="${f.k}" ${getP(S, f.k) ? 'checked' : ''}><span>${sym(f.l)}</span></label>`;
    } else if (f.t === 'cont') {
      html += contHTML();
    } else if (f.t === 'list') {
      html += renderList(f.kind);
    } else if (f.t === 'mtab') {
      const row = (k, lab) => `<tr><td>${lab}</td>${[0, 1, 2].map(j => `<td><input data-mk="${k}" data-j="${j}" value="${esc(showNum(S.man[k][j]))}"></td>`).join('')}</tr>`;
      html += `<table class="mtab"><tr><th></th><th>lewa podpora</th><th>przęsło (L/2)</th><th>prawa podpora</th></tr>${row('MEd', 'M<sub>Ed</sub> (SGN)')}${row('MEk', 'M<sub>Ek</sub> (char.)')}${row('MEqp', 'M<sub>Eqp</sub> (q-st.)')}</table>`;
    }
  });
  return html;
}
// automatyczny dobór: przekroje (b × h, klasa betonu) oraz przekroje i zbrojenie z wytężeniem docelowym – przyciski nad danymi
function renderAutoBar() {
  const el = $('#autobar'); if (!el) return;
  const eta = (S.design && S.design.eta) || 100;
  el.innerHTML = `<div class="autobar"><button class="btn sm" id="adDims" title="Najmniejsze przekroje (b × h każdego przęsła, h/b ≤ 2,5) dla zadanych obciążeń i zadanej klasy betonu (klasa bez zmian) – każdy wariant sprawdzony pełnym doborem zbrojenia i kompletem warunków (SGN, SGU, konstrukcyjne). Zbrojenie podłużne zostaje wyczyszczone (widać zbrojenie wymagane).">⚙ Dobierz przekroje</button>
    <button class="btn sm" id="adReb" title="Zbrojenie podłużne (i w razie potrzeby średnica / liczba ramion strzemion) dla obecnych przekrojów – to samo, które pokazuje wykres M (n⌀): wszystkie warunki z Podsumowania, wytężenie ≤ η, średnice zadane w Materiałach lub wybrane na wykresie M">⚙ Dobierz zbrojenie</button>
    <button class="btn sm pri" id="adAll" title="Wszystkie parametry: wymiary przekrojów, zbrojenie (średnice i liczby prętów), strzemiona, klasa betonu (≥ minimalnej dla ekspozycji, wyższa tylko gdy potrzeba) i otulina – tak, aby wszystkie sprawdzenia z Podsumowania były spełnione, a wytężenie ≤ η">⚙ Dobierz wszystko</button>
    <label class="adeta" title="Wymagane wytężenie elementu: E_d / R_d ≤ η we wszystkich warunkach nośności (zginanie, ścinanie, skręcanie, siła osiowa) i SGU (naprężenia, rysy, ugięcia) – w doborze zbrojenia (także na wykresie M) i w „Dobierz wszystko”">wytężenie ≤ <input class="txt sm" id="adEta" value="${eta}" inputmode="numeric" autocomplete="off" spellcheck="false"> %</label></div>`;
  const inp = $('#adEta', el);
  const etaOk = () => { const v = parseNum(inp.value); if (v === null || v < 50 || v > 100) { inp.classList.add('bad'); toast('Wytężenie docelowe: od 50 do 100%.'); return false; } S.design = Object.assign({}, S.design, { eta: Math.round(v) }); return true; };
  inp.addEventListener('change', () => { const v = parseNum(inp.value); const ok = v !== null && v >= 50 && v <= 100; inp.classList.toggle('bad', !ok); if (ok && Math.round(v) !== ((S.design && S.design.eta) || 100)) { S.design = Object.assign({}, S.design, { eta: Math.round(v) }); inp.value = Math.round(v); changed(false); } });
  inp.addEventListener('input', () => { const v = parseNum(inp.value); inp.classList.toggle('bad', !(v !== null && v >= 50 && v <= 100)); });
  $('#adDims', el).onclick = () => runDesign();
  $('#adReb', el).onclick = () => { if (etaOk()) doAutoReb(); };
  $('#adAll', el).onclick = () => { if (etaOk()) runDesignAll(); };
}
// dobór zbrojenia – te same opcje wszędzie (wykres M w Danych, „Dobierz zbrojenie”, „Dobierz wszystko”): wytężenie η, wszystkie warunki z Podsumowania
const rebOpts = () => ({ eta: ((S.design && S.design.eta) || 100) / 100, strict: true });
// dobór przekrojów (bez zbrojenia) – klasa betonu bez zmian, zbrojenie wyczyszczone (widać zbrojenie wymagane i propozycję na wykresie M)
function runDesign() {
  if (MAN(S)) { toast('Automatyczny dobór wymaga obliczenia sił wewnętrznych ze schematu i obciążeń (nie dla sił podanych ręcznie).'); return; }
  if (!E.hasLoad || !(R && R.st)) { toast('Najpierw zadaj schemat i obciążenia.'); return; }
  const eta = ((S.design && S.design.eta) || 100) / 100;
  const m = $('#modal');
  m.innerHTML = `<div class="dlg"><h3>Dobór przekrojów</h3><p><i class="dpend"></i> Trwa dobór – każdy wariant przekroju sprawdzany jest pełnym doborem zbrojenia i kompletem warunków${eta < 1 ? ` (wytężenie ≤ ${Math.round(eta * 100)}%)` : ''}. To może potrwać kilka–kilkanaście sekund…</p></div>`;
  m.style.display = 'flex';
  setTimeout(() => {
    let res = null; try { res = E.designDims(S, { eta, all: true }); } catch (e) { console.error(e); }
    m.style.display = 'none';
    if (!res || !res.S) { toast((res && res.msg) || 'Nie udało się dobrać przekrojów – sprawdź dane i obciążenia.', 6000); return; }
    const T = res.S, cont = CONT(S);
    S.geom.b = T.geom.b; S.geom.h = T.geom.h; if (cont) S.cont.geoSpans = T.cont.geoSpans;
    S.mat.autoC = false; E.clearReb(S);
    changed(true);
    const dd = res.dims.map(q => `${res.dims.length > 1 ? q.label + ': ' : ''}${q.b}×${q.h} mm`).join(', ');
    toast(res.ok ? `Dobrano przekrój ${dd} dla betonu ${S.mat.concrete} (klasa bez zmian) – najmniejszy, przy którym dobrane zbrojenie spełnia wszystkie warunki. Zbrojenie: „Dobierz zbrojenie” (to samo co na wykresie M) albo „Dobierz wszystko”.`
      : `Dobrano przekrój ${dd}, ale nie wszystkie warunki są spełnione: ${res.fails.slice(0, 3).join('; ')}.`, 9000);
  }, 60);
}
// „Dobierz wszystko”: wymiary przekrojów, zbrojenie (średnice, liczby prętów), strzemiona, klasa betonu i otulina – aż do spełnienia wszystkich
// sprawdzeń z Podsumowania (status ok / info) i wytężenia ≤ η; warianty: klasa zadana (≥ minimalnej) ze średnicami zadanymi, bez nich, wyższe klasy
let designCancel = false;
function runDesignAll() {
  if (MAN(S)) { toast('Automatyczny dobór wymaga obliczenia sił wewnętrznych ze schematu i obciążeń (nie dla sił podanych ręcznie).'); return; }
  if (!E.hasLoad || !(R && R.st)) { toast('Najpierw zadaj schemat i obciążenia.'); return; }
  const eta = ((S.design && S.design.eta) || 100) / 100, m = $('#modal'), t0 = Date.now();
  let prep; try { prep = E.designAllPrep(S); } catch (e) { console.error(e); toast('Błąd przygotowania danych: ' + e.message); return; }
  const P = prep.S, hasPref = Object.keys(P.reb.dSel || {}).length > 0 || P.reb.dB > 0 || P.reb.dT > 0;
  const i0 = E.classIdx(P.mat.concrete), iMax = Math.min(E.CONC_NAMES.length - 1, E.classIdx('C50/60'));
  const att = [{ cls: P.mat.concrete, pref: true }]; if (hasPref) att.push({ cls: P.mat.concrete, pref: false });
  for (let i = i0 + 1; i <= iMax && att.length < 7; i++) att.push({ cls: E.CONC_NAMES[i], pref: !hasPref });
  let best = null; designCancel = false;
  const show = k => { m.innerHTML = `<div class="dlg"><h3>Dobierz wszystko</h3><p><i class="dpend"></i> Wariant ${k + 1} z najwyżej ${att.length}: beton ${esc(att[k].cls)}${hasPref ? (att[k].pref ? ', średnice zadane' : ', średnice automatycznie') : ''}. Każdy wariant przekroju jest sprawdzany pełnym doborem zbrojenia i kompletem warunków z Podsumowania${eta < 1 ? ` (wytężenie ≤ ${Math.round(eta * 100)}%)` : ''} – to może potrwać do kilkudziesięciu sekund…</p>${best ? `<p class="hint keep">Najlepszy dotąd: ${esc(best.cls)}, ${esc(best.dd)} – niespełnione: ${best.bad.length}.</p>` : ''}<div class="dbtn"><span class="sp"></span><button class="btn" id="daStop">Przerwij</button></div></div>`; m.style.display = 'flex'; const b = $('#daStop', m); if (b) b.onclick = () => { designCancel = true; b.disabled = true; b.textContent = 'Przerywanie…'; }; };
  const finish = () => {
    m.style.display = 'none';
    if (designCancel && !(best && !best.bad.length)) { toast('Przerwano – dane bez zmian.'); return; }
    if (!best) { toast('Nie udało się dobrać przekrojów – sprawdź schemat, obciążenia i dane.', 7000); return; }
    const C = best.C, r = best.r;
    Object.keys(C).forEach(k => { if (k !== 'meta') S[k] = C[k]; });
    applyReb(r, true);
    const notes = prep.notes.slice(); if (best.cls !== P.mat.concrete) notes.push(`klasa betonu ${P.mat.concrete} → ${best.cls} (przy niższej nie da się spełnić wszystkich warunków)`); if (hasPref && !best.pref) notes.push('średnice zadane zastąpione automatycznymi (z zadanymi nie da się spełnić warunków)');
    changed(true);
    const t = ((Date.now() - t0) / 1000).toFixed(0);
    if (!best.bad.length) toast(`Dobrano wszystko (${t} s): ${best.dd}, beton ${best.cls}, zbrojenie wg wykresu M – wszystkie sprawdzenia z Podsumowania spełnione, największe wytężenie ${fmt(best.mx * 100, 0)}% (≤ ${Math.round(eta * 100)}%).${notes.length ? ' Zmieniono też: ' + notes.join('; ') + '.' : ''}`, 12000);
    else toast(`Nie udało się spełnić wszystkich warunków (${t} s) – przyjęto najlepszy wariant: ${best.dd}, beton ${best.cls}. Niespełnione: ${[...new Set(best.bad.map(c => c.name.replace(/\s*\(.*$/, '').replace(/ [≤≥].*$/, '')))].slice(0, 4).join('; ')}. Sprawdź schemat, obciążenia, szerokości podpór i ograniczenia (h/b ≤ 2,5, b ≤ 1200 mm).`, 15000);
  };
  const step = k => {
    if (k >= att.length || designCancel || (best && !best.bad.length)) { finish(); return; }
    show(k);
    setTimeout(() => {
      try {
        const a = att[k], T = JSON.parse(JSON.stringify(P)); T.mat.concrete = a.cls; if (!a.pref) { T.reb.dSel = {}; T.reb.dB = 0; T.reb.dT = 0; }
        const res = E.designDims(T, { eta, all: true, tMax: k ? 25000 : 40000 });
        if (res && res.S) {
          const C = E.normalize(JSON.parse(JSON.stringify(T))), Q = res.S;
          C.geom.b = Q.geom.b; C.geom.h = Q.geom.h; if (C.scheme === 'cont') { C.cont.geoSpans = Q.cont.geoSpans; C.cont.stirSpans = Q.cont.stirSpans; }
          ['d', 'legs', 'sAuto', 's1', 's2', 'sp', 'zl'].forEach(q => { C.stir[q] = Q.stir[q]; });
          const r = E.autoReb(C, { eta, strict: true });
          if (r && r.R && !r.R.errors.length) {
            const bad = E.allBad(r.R, eta); let mx = 0; r.R.checks.forEach(c => { if (E.ETA_IDS.has(c.id) && c.status !== 'info' && c.status !== 'warn' && isFinite(c.ratio)) mx = Math.max(mx, c.ratio); });
            const dd = res.dims.map(q => `${res.dims.length > 1 ? q.label + ': ' : ''}${q.b}×${q.h} mm`).join(', ');
            if (!best || bad.length < best.bad.length) best = { C, r, bad, mx, dd, cls: a.cls, pref: a.pref };
          }
        }
      } catch (e) { console.error(e); }
      step(k + 1);
    }, 40);
  };
  step(0);
}
function renderInputs() {
  renderAutoBar();
  const host = $('#inputs'), pane = $('#p-data'), st = pane ? pane.scrollTop : 0;
  const openState = {}; $$('details.grp', host).forEach(d => openState[d.dataset.id] = d.open);
  let html = '';
  GROUPS.forEach(G => {
    if (G.show && !G.show(S)) return;
    const open = openState[G.id] !== undefined ? openState[G.id] : !G.closed;
    html += `<details class="grp" data-id="${G.id}" ${open ? 'open' : ''}><summary>${esc(G.title)}</summary><div class="fields">${fieldsHTML(G.items, G.id)}</div></details>`;
  });
  host.innerHTML = html;
  if (pane) pane.scrollTop = st;
  bindInputs(host);
}
function refreshHints() {
  const all = GROUPS.map(G => [G.id, G.items]).concat(Object.entries(POP).map(([k, v]) => ['pop_' + k, v]));
  all.forEach(([gid, items]) => items.forEach((f, i) => {
    if (f.t !== 'hint') return;
    const el = $(`[data-hint="${gid}_${i}"]`); if (!el) return;
    const open = !!el.querySelector('details.exh[open]'), h = hintHTML(f); el.innerHTML = h; el.style.display = h ? '' : 'none'; if (open) { const d = el.querySelector('details.exh'); if (d) d.open = true; }
  }));
}
function bindInputs(host) {
  host = host || $('#inputs');
  $$('select[data-k]', host).forEach(el => el.addEventListener('change', () => {
    const k = el.dataset.k; let v = el.value;
    if (el.dataset.num) v = parseNum(v);
    setP(S, k, v);
    if (k === 'mat.concrete') { S.mat.autoC = false; const cb = $('#inputs input[data-k="mat.autoC"]'); if (cb) cb.checked = false; }   // klasa wybrana ręcznie
    if (k === 'scheme') S.supCfg = [];                    // nowy schemat – domyślne podpory
    if (k === 'reb.dB' || k === 'reb.dT') { const top = k === 'reb.dT', d0 = S.reb.dSel || {}; S.reb.dSel = {}; Object.keys(d0).forEach(z => { if ((z[0] === 'b') === top) S.reb.dSel[z] = d0[z]; }); }   // średnica w Materiałach zastępuje wybrane na wykresie M
    changed(el.dataset.re);
  }));
  $$('select[data-cn]', host).forEach(el => el.addEventListener('change', () => {
    const n = +el.value, C = S.cont;
    C.geoSpans = C.geoSpans || []; C.stirSpans = C.stirSpans || [];
    while (C.spans.length < n) { C.spans.push(C.spans[C.spans.length - 1] || 6); C.rebSpans.push(JSON.parse(JSON.stringify(C.rebSpans[C.rebSpans.length - 1]))); C.geoSpans[C.spans.length - 1] = JSON.parse(JSON.stringify(C.geoSpans[C.spans.length - 2] || {})); C.stirSpans[C.spans.length - 1] = JSON.parse(JSON.stringify(C.stirSpans[C.spans.length - 2] || {})); }
    C.spans.length = n; C.rebSpans.length = n; C.geoSpans.length = Math.min(C.geoSpans.length, n); C.stirSpans.length = Math.min(C.stirSpans.length, n);
    while (C.rebSupps.length < n + 1) C.rebSupps.splice(C.rebSupps.length - 1, 0, JSON.parse(JSON.stringify(C.rebSupps[Math.max(0, C.rebSupps.length - 2)] || Object.assign(E.zoneOf([]), { lenL: '', lenR: '' }))));
    if (C.rebSupps.length > n + 1) C.rebSupps.splice(n, C.rebSupps.length - n - 1);
    if (S.supCfg.length > n + 1) S.supCfg.length = n + 1;
    S.nodes = S.nodes.filter(q => q.seg < model().segs.length);
    [S.loads.perm, S.loads.var, S.loads.acc].forEach(a => a.forEach(it => { if (it.span > model().segs.length) it.span = 0; }));
    changed(true);
  }));
  $$('[data-kt]', host).forEach(el => el.addEventListener('input', () => { setP(S, el.dataset.kt, el.value); changed(false); }));
  $$('input[type=checkbox]', host).forEach(el => el.addEventListener('change', () => { setP(S, el.dataset.k, el.checked); changed(false); }));
  $$('.combo input', host).forEach(el => {
    el.addEventListener('input', () => numInput(el, false));
    el.addEventListener('change', () => numInput(el, true));
    el.addEventListener('keydown', e => { if (e.key === 'ArrowDown' && e.altKey) { openList(el.nextElementSibling); e.preventDefault(); } });
  });
  $$('.combo button', host).forEach(b => b.addEventListener('mousedown', e => { e.preventDefault(); openList(b); }));
  $$('[data-li]', host).forEach(el => {
    const [arr, i, fld] = el.dataset.li.split('.');
    const item = arrByKey(arr)[+i];
    if (el.tagName === 'SELECT') { el.addEventListener('change', () => { item[fld] = fld === 'span' ? +el.value : el.value; if (fld === 'cat') item.sub = ''; if (fld === 'cat' || fld === 'sub') { if (fld === 'cat') { const L = E.IMP_EC1[item.cat]; if (L) item.sub = L[0].id; } ec1Auto(item); } changed(true); }); return; }
    el.addEventListener('input', () => {
      if (fld === 'name') { item.name = el.value; changed(false); return; }
      if (fld === 'prof') { item.prof = el.value; changed(false); return; }
      const raw = el.value.trim();
      const ec1 = () => { if (fld !== 'q' && fld !== 'bw' && fld !== 'q2') return; if (item.kind !== 'imp') return;
        if (fld === 'q' || fld === 'q2') item.qAuto = false;
        else if (item.qAuto) { ec1Auto(item); const qi = host.querySelector(`[data-li="${arr}.${i}.q"]`); if (qi) { qi.value = showNum(item.q); qi.classList.remove('bad'); } const q2 = host.querySelector(`[data-li="${arr}.${i}.q2"]`); if (q2 && item.shape === 't') q2.value = showNum(item.q2); }
        const r = host.querySelector(`[data-ec1="${arr}.${i}"]`); if (r) r.innerHTML = ec1Row(item, `${arr}.${i}`); };
      if (raw === '' && ['x1', 'x2', 'bw'].includes(fld)) { el.classList.remove('bad'); item[fld] = ''; changed(false); ec1(); return; }
      let v = parseNum(raw); if (raw === '' && (fld === 'q' || fld === 'qz' || fld === 'mt' || fld === 'q2' || fld === 'ang')) v = 0;
      if (fld === 'ang' && v !== null && Math.abs(v) > 90) v = null;
      const bad = v === null || (/^p[012]$/.test(fld) && (v < 0 || v > 1)) || (['x1', 'x2'].includes(fld) && (v < 0 || v > segLen(item) + 1e-9));
      el.classList.toggle('bad', bad || (fld === 'bw' && !(v > 0))); if (bad || (fld === 'bw' && !(v > 0))) return;
      item[fld] = v; changed(false); ec1();
    });
  });
  // „przyjmij” górną granicę obciążenia użytkowego (EC1) – delegacja, bo wiersz podpowiedzi jest odświeżany przy wpisywaniu
  if (!host._ec1) { host._ec1 = true; host.addEventListener('click', ev => { const b = ev.target.closest && ev.target.closest('[data-ec1q]'); if (!b) return; ev.preventDefault();
    const [a2, i2] = b.dataset.ec1q.split('.'), it2 = arrByKey(a2)[+i2]; if (!it2) return; const L = E.IMP_EC1[it2.cat] || E.IMP_EC1.B, q = L.find(z => z.id === it2.sub) || L[0];
    if (!(+it2.bw > 0)) return; it2.qAuto = true; ec1Auto(it2); changed(true); toast(`Przyjęto q_k = ${fmt(it2.q, 2)} kN/m (${fmt(q.q[1], 1)} kN/m² × ${fmt(+it2.bw, 2)} m – górna granica, PN-EN 1991-1-1 tabl. ${q.t}).`, 4000); }); }
  $$('[data-tri]', host).forEach(el => el.addEventListener('click', ev => { ev.preventDefault(); const [arr, i, w] = el.dataset.tri.split('.'); const item = arrByKey(arr)[+i]; item.qAuto = false; const qm = Math.max(Math.abs(+item.q || 0), Math.abs(+item.q2 || 0)) || 10; if (w === '0') { item.q = 0; item.q2 = qm; } else { item.q = qm; item.q2 = 0; } changed(true); }));
  $$('[data-lf]', host).forEach(el => el.addEventListener('change', () => {
    const [arr, i, fld] = el.dataset.lf.split('.'); const item = arrByKey(arr)[+i];
    item[fld] = el.checked; changed(fld === 'tor');
  }));
  $$('[data-lp]', host).forEach(el => {
    const [arr, i, j, fld] = el.dataset.lp.split('.');
    const item = arrByKey(arr)[+i], pt = item.pts[+j];
    const row = el.closest('.pt');
    if (el.tagName === 'SELECT') {
      el.addEventListener('change', () => {
        const L = segLen(item), old = pt.ref, nw = el.value;
        if (pt.a !== '' && old !== nw) {   // zachowaj to samo położenie bezwzględne
          const x = E.absX(L * 1000, pt.a, old) / 1000;
          pt.a = +(nw === 'rel' ? x / L : nw === 'R' ? L - x : x).toFixed(4);
        }
        pt.ref = nw; changed(true);
      });
      return;
    }
    el.addEventListener('input', () => {
      const raw = el.value.trim();
      if (fld === 'a' && raw === '') { el.classList.remove('bad'); pt.a = ''; $('.lx', row).textContent = absText(pt, item); changed(false); return; }
      let v = parseNum(raw); if (raw === '' && (fld === 'P' || fld === 'Pz' || fld === 'T')) v = 0;
      const lim = pt.ref === 'rel' ? 1 : segLen(item);
      const bad = v === null || (fld === 'a' && (v < 0 || v > lim + 1e-9));
      el.classList.toggle('bad', bad); if (bad) return;
      pt[fld] = v; if (fld === 'a') $('.lx', row).textContent = absText(pt, item);
      changed(false);
    });
  });
  $$('[data-add]', host).forEach(b => b.addEventListener('click', () => {
    const kind = b.dataset.add, arr = listArr(kind);
    const n = arr.filter(it => kind === 'acc' || kind === 'perm' || it.kind === kind).length + 1;
    const it = LIST_DEF[kind](n);
    if (b.dataset.span !== undefined) { it.span = +b.dataset.span; it.el = b.dataset.el === '' ? '' : +b.dataset.el; if (kind === 'perm') { it.q = 5; it.pts = []; } }
    if (b.dataset.spans) { it.spans = b.dataset.spans.split(',').map(Number); it.el = ''; it.pts = []; if (!it.q) it.q = 5; }
    arr.push(E.normItem(it, ['acc', 'perm'].includes(kind) ? kind : kind));
    changed(true);
  }));
  $$('[data-del]', host).forEach(b => b.addEventListener('click', () => {
    const [arr, i] = b.dataset.del.split('.');
    arrByKey(arr).splice(+i, 1); changed(true);
  }));
  $$('[data-ap]', host).forEach(b => b.addEventListener('click', () => {
    const [arr, i] = b.dataset.ap.split('.');
    const it = arrByKey(arr)[+i]; it.pts = it.pts || [];
    it.pts.push(E.normPt(it.dir === 't' ? { P: 0, T: 5, a: '', ref: 'L' } : { P: 10, a: '', ref: 'L' })); changed(true);
  }));
  $$('[data-dp]', host).forEach(b => b.addEventListener('click', () => {
    const [arr, i, j] = b.dataset.dp.split('.');
    arrByKey(arr)[+i].pts.splice(+j, 1); changed(true);
  }));
  $$('[data-num2]', host).forEach(el => el.addEventListener('input', () => {
    const raw = el.value.trim();
    if (raw === '') { el.classList.remove('bad'); setP(S, el.dataset.k, ''); changed(false); return; }
    const v = parseNum(raw), bad = v === null || v < 0;
    el.classList.toggle('bad', bad); if (bad) return;
    setP(S, el.dataset.k, v); changed(false);
  }));
  $$('.mtab input', host).forEach(el => el.addEventListener('input', () => {
    const v = parseNum(el.value); el.classList.toggle('bad', v === null);
    if (v !== null) { S.man[el.dataset.mk][+el.dataset.j] = v; changed(false); }
  }));
}
function numInput(el, final) {
  const raw = el.value.trim();
  const opt = !!el.dataset.opt;
  const min = el.dataset.min !== '' ? parseFloat(el.dataset.min) : null, max = el.dataset.max ? parseFloat(el.dataset.max) : null;
  if (raw === '' && opt) { el.classList.remove('bad'); setP(S, el.dataset.k, ''); changed(false); return; }
  if (el.dataset.auto && /^auto/i.test(raw)) { el.classList.remove('bad'); setP(S, el.dataset.k, 'auto'); if (final) el.value = 'auto'; changed(false); return; }
  const v = parseNum(raw);
  const bad = v === null || (min !== null && v < min) || (max !== null && v > max);
  el.classList.toggle('bad', bad);
  if (bad) return;
  if (CONT(S) && /^cont\.geoSpans\./.test(el.dataset.k)) S.cont.spans.forEach((_, i) => { const q = (S.cont.geoSpans || [])[i] || {}; if (!(q.b > 0)) setP(S, `cont.geoSpans.${i}.b`, S.geom.b); if (!(q.h > 0)) setP(S, `cont.geoSpans.${i}.h`, S.geom.h); });
  if (CONT(S) && (el.dataset.k === 'cont.cantL' || el.dataset.k === 'cont.cantR')) {
    if ((S.cont[el.dataset.k.slice(5)] > 0) !== (v > 0)) { if (!final) return; cantToggle(el.dataset.k === 'cont.cantL' ? 'L' : 'R', v); }
  }
  setP(S, el.dataset.k, v);
  if (final) el.value = showNum(v);
  changed(final && !!el.dataset.re);
}
// dodanie / usunięcie wspornika belki ciągłej: przenumerowanie odcinków w obciążeniach i węzłach
function cantToggle(side, v) {
  const was = S.cont['cant' + side] > 0, now = v > 0; if (was === now) return;
  const md = model(), nSeg = md.segs.length;
  const gone = it => side === 'L' ? it.span === 1 : it.span === nSeg;
  if (was) {   // usunięcie wspornika
    let lost = 0;
    ['perm', 'var', 'acc'].forEach(k => { const a = arrByKey(k); for (let i = a.length - 1; i >= 0; i--) if (gone(a[i])) { a.splice(i, 1); lost++; } });
    S.nodes = S.nodes.filter(q => side === 'L' ? q.seg !== 0 : q.seg !== nSeg - 1);
    if (side === 'L') { allItems().forEach(it => { if (it.span > 0) it.span--; }); S.nodes.forEach(q => q.seg--); }
    if (lost) toast(`Usunięto obciążenia wspornika (${lost}).`);
  } else if (side === 'L') { allItems().forEach(it => { if (it.span > 0) it.span++; }); S.nodes.forEach(q => q.seg++); }
}
// lista rozwijana wartości typowych
let popFor = null;
function openList(btn) {
  const pop = $('#pop'); const inp = btn.previousElementSibling;
  if (popFor === inp && pop.style.display === 'block') { closeList(); return; }
  const list = JSON.parse(btn.dataset.list || '[]');
  pop.innerHTML = list.map(v => `<div data-v="${esc(String(v))}" class="${String(v) === String(parseNum(inp.value) ?? '') ? 'cur' : ''}">${v === '' ? (inp.placeholder || '—') : esc(showNum(v))}</div>`).join('');
  const r = inp.parentElement.getBoundingClientRect();
  pop.style.display = 'block'; pop.style.minWidth = r.width + 'px';
  const ph = Math.min(260, pop.scrollHeight);
  const below = window.innerHeight - r.bottom > ph + 6;
  pop.style.left = r.left + 'px'; pop.style.top = (below ? r.bottom + 2 : r.top - ph - 2) + 'px';
  popFor = inp;
  const cur = $('.cur', pop); if (cur) cur.scrollIntoView({ block: 'center' });
  $$('div', pop).forEach(d => d.addEventListener('mousedown', e => {
    e.preventDefault(); inp.value = showNum(d.dataset.v); numInput(inp, true); closeList(); inp.focus();
  }));
}
function closeList() { $('#pop').style.display = 'none'; popFor = null; }
document.addEventListener('mousedown', e => { if (!e.target.closest('#pop') && !e.target.closest('.combo button')) closeList(); });
document.addEventListener('click', e => { if (e.target.closest('[data-expall]')) expAll(); });
window.addEventListener('resize', closeList);

/* ----------------------------------------------------------- obliczenia */
let tmr = null;
function changed(rerender) {
  dirty = true; updateTitle();
  if (rerender) { renderInputs(); if (popRedraw && $('#modal').style.display === 'flex' && $('#modal .fpop')) popRedraw(); }
  clearTimeout(tmr); tmr = setTimeout(recalc, 60);
  autosave();
}
function recalc() {
  try { R = E.calc(S); } catch (e) { R = { errors: ['Błąd obliczeń: ' + e.message], checks: [], S }; console.error(e); }
  U.R = R; U.S = S;
  refreshHints();
  $$('#inputs .litem, #modal .litem').forEach(el => {
    const d = el.querySelector('[data-del]'); if (!d || !R || !R.st || !R.st.vars) return;
    const [arr, i] = d.dataset.del.split('.');
    el.querySelector('.lid').textContent = idOf(arr === 'var' ? 'imp' : arr, +i);
  });
  $$('#inputs [data-ph], #modal [data-ph]').forEach(el => { if (!el.dataset.ph) return; const ps = el.dataset.ph.split('_'), ii = +ps.pop(), gid = ps.join('_'); const items = gid.startsWith('pop_') ? POP[gid.slice(4)] : (GROUPS.find(q => q.id === gid) || {}).items; const f = items && items[ii]; if (f && typeof f.ph === 'function') el.placeholder = f.ph(S); });
  syncTicks();
  renderStatus();
  renderDsum();
  rendered = {};
  renderActive();
  dimQueue();
}
// ocena wymiarów przekroju (✔ / ✖ obok b × h): dobór zbrojenia na bieżących wymiarach i komplet sprawdzeń; propozycja – przekrój spełniający wszystkie warunki
// (obliczenia w tle, po przerwie w edycji; kliknięcie ✖ przyjmuje proponowane wymiary)
let dimSt = { key: '', spans: {}, done: false }, dimT = 0, dimSeed = null;     // dimSeed – wynik doboru właśnie przyjętego w belce (opisy wykresu M = przyjęte zbrojenie)
const dimKey = () => JSON.stringify([S.scheme, S.geom, S.cont.spans, S.cont.cantL, S.cont.cantR, S.cont.geoSpans, S.loads, S.mat, S.env, S.fire, S.supCfg, S.nodes, S.stir.d, S.stir.legs, S.stir.kind, S.sls, S.anch, S.reb.vib, S.reb.vibOn, S.reb.sameD, S.reb.useComp, S.reb.dSel, S.reb.dB, S.reb.dT, S.design, S.coef]);
function dimQueue() {
  // błąd „nie mieści się w wysokości” oznacza za mały przekrój – wtedy też sprawdzać (✖ przy h)
  if (MAN(S) || !R || (R.errors && R.errors.some(t => !/nie mieści się w wysokości/.test(t)))) { if (dimSt.key) { dimSt = { key: '', spans: {}, done: true }; dimPaint(); } return; }
  const key = dimKey(); if (dimSt.key === key) return;
  dimSt = { key, spans: {}, done: false }; clearTimeout(dimT); dimPaint();
  dimT = setTimeout(() => dimRun(key), 450);
}
function dimRun(key) {
  if (dimSt.key !== key) return;
  let r0 = null, D = null;
  try { r0 = dimSeed && dimSeed.key === key ? dimSeed.r : E.autoReb(S, rebOpts()); } catch (e) { console.error(e); }
  // wynik doboru zbrojenia – opisy prętów na wykresie M w Danych (to samo zbrojenie zada „Dobierz zbrojenie”)
  dimSt.auto = r0 && r0.R && r0.R.sched && r0.R.md && !(r0.R.errors && r0.R.errors.length) ? r0 : false; autoRepaint();
  try { D = r0 ? E.suggestDims(S) : null; } catch (e) { console.error(e); }
  if (!r0 || !r0.R || !D) { dimSt.done = true; dimPaint(); return; }
  const list = D.spans.map(q => ({ q, si: q.si !== undefined ? q.si : 0 }));
  // błędy doboru (np. zbrojenie nie mieści się w wysokości) – przekrój za mały: ✖ przy h przęsła, którego dotyczą (gdy nie wiadomo którego – wszystkich)
  const errs = r0.R.errors || [], segs = (r0.R.md && r0.R.md.segs) || [], labs = segs.map(sg => sg && sg.label ? `(${sg.label})` : '\u0000');
  const errOf = seg => errs.filter(t => t.includes(labs[seg] || '\u0000') || !labs.some(l => t.includes(l)));
  list.forEach(({ q, si }) => {
    const fe = errOf(q.seg); let fl = []; try { fl = errs.length ? [] : E.dimFails(r0.R, q.seg, 1, r0.S || S); } catch (e) { fl = []; }
    dimSt.spans[si] = { seg: q.seg, cur: q.cur, ok: !fl.length && !fe.length, ids: fe.length ? ['fit'] : fl.map(c => c.id), names: fe.length ? fe.map(t => t.replace(/\s*\(.*$/, '').replace(/:.*$/, '')) : [...new Set(fl.map(c => c.name.replace(/\s*\(.*$/, '').replace(/ [≤≥].*$/, '')))], prop: null, pend: true };
  });
  dimPaint();
  let k = 0;
  const step = () => {
    if (dimSt.key !== key) return;
    if (k >= list.length) { dimSt.done = true; dimPaint(); return; }
    const { q, si } = list[k++], d = dimSt.spans[si];
    try {
      // przekrój za mały: szerokość bez zmian (o ile nie decyduje ona o niespełnieniu), wysokość co 50 mm; przekrój wystarczający: najmniejszy spełniający warunki
      const st = d.ok ? (q.best || q.cur) : q.atB ? { b: q.cur.b, h: Math.max(q.cur.h, q.atB.h) } : q.best ? { b: Math.max(q.cur.b, q.best.b), h: Math.max(q.cur.h, q.best.h) } : q.cur;
      const v = E.verifyDims(S, q.seg, st.b, st.h);
      if (v && v.ok) d.prop = { b: v.b, h: v.h };
      // przekrój wystarczający – czy nie za duży: najmniejsza wysokość przy obecnej szerokości i najmniejsza szerokość przy obecnej wysokości
      // (każda sprawdzona pełnym doborem zbrojenia i kompletem warunków); ✖ przy wymiarze, który można zmniejszyć co najmniej o 50 mm
      if (d.ok) {
        const cur = q.cur, hLow = Math.max(250, Math.ceil(0.8 * cur.b / 50) * 50), small = { h: null, b: null };
        const okAt = (bb, hh) => { const w = E.verifyDims(S, q.seg, bb, hh); return w && w.ok && w.h === hh && w.b === bb; };
        let hT = q.atB && q.atB.h < cur.h ? Math.max(hLow, q.atB.h) : cur.h - 50;
        if (hT >= hLow && hT < cur.h) { const w = E.verifyDims(S, q.seg, cur.b, hT); if (w && w.ok && w.b === cur.b && w.h < cur.h) { small.h = w.h; if (w.h === hT) for (let k = 0; k < 3 && small.h - 50 >= hLow && okAt(cur.b, small.h - 50); k++) small.h -= 50; } }
        const bLow = q.bMin || 200, bs = [...new Set((q.cands || []).filter(c => c.b < cur.b && c.b >= bLow && c.h <= cur.h).map(c => c.b).concat(cur.b - 50 >= bLow && cur.h >= 0.8 * (cur.b - 50) ? [cur.b - 50] : []))].sort((a, b) => a - b);
        for (const bb of bs.filter(x => cur.h <= 2.5 * x + 1e-6).slice(0, 3)) { if (bb > cur.h / 0.8 + 1e-6) continue; const w = E.verifyDims(S, q.seg, bb, cur.h); if (w && w.ok && w.h <= cur.h && w.b < cur.b) { small.b = w.b; break; } }
        d.small = small;
      }
    } catch (e) { console.error(e); }
    d.pend = false; dimPaint(); setTimeout(step, 0);
  };
  setTimeout(step, 0);
}
// opisy prętów na wykresie M (Dane): po zakończeniu doboru w tle – ponowne narysowanie schematu
function autoRepaint() {
  if (diagMode !== 'M') return;
  const on = $('.tabs button.on'); if (on && on.dataset.tab === 'data') renderDataSide(); else rendered.data = false;
}
function autoPending() {
  if (MAN(S) || !R || (R.errors && R.errors.some(t => !/nie mieści się w wysokości/.test(t)))) return false;
  return !(dimSt.key === dimKey() && dimSt.auto !== undefined);
}
// zbrojenie z automatycznego doboru (dimSt.auto): pręty w każdym miejscu belki (dół / góra) wg zestawienia prętów,
// ze strefą wyboru średnicy (S.reb.dSel: b<i> – dół przęsła, t – góra ciągła, x<i> / x – nad podporą)
let autoMemo = null;
function autoBars() {
  const a = dimSt.auto; if (!a || dimSt.key !== dimKey()) return null;
  if (autoMemo && autoMemo.a === a) return autoMemo.v;
  const md = a.R.md, cont = md.cont, rows = a.R.sched.rows.filter(r => (r.side === 'bot' || r.side === 'top') && r.n > 0 && r.x1 > r.x0);
  const supOf = r => (r.sup !== undefined && r.sup !== null ? r.sup : null);
  const dzOf = r => { if (r.side === 'top') return supOf(r) !== null ? (cont ? 'x' + r.sup : 'x') : 't';
    if (!cont) return 'b0'; const sg = md.segs[r.seg], z = sg ? (sg.reb ? sg : md.segs[sg.adj]) : null; return z && z.si !== undefined ? 'b' + z.si : null; };
  const R2 = rows.map(r => ({ r, dz: dzOf(r), g: [r.side, r.key || 'c' + r.seg, supOf(r), r.layer, r.d, r.cut ? 1 : 0].join('|') }));
  // pręty w przekroju x: odcinki tego samego pręta (zakład) liczone raz; grupowanie wg strefy i średnicy
  const at = x => { const g = new Map(); R2.forEach(q => { if (x < q.r.x0 - 1 || x > q.r.x1 + 1) return; const o = g.get(q.g); if (!o || q.r.n > o.r.n) g.set(q.g, q); });
    const sum = side => { const m = new Map(); g.forEach(q => { if (q.r.side !== side) return; const k = q.dz + '|' + q.r.d, o = m.get(k) || { n: 0, d: q.r.d, dz: q.dz }; o.n += q.r.n; m.set(k, o); });
      return Array.from(m.values()).sort((p, q) => (side === 'top' ? (p.dz === 't' ? 0 : 1) - (q.dz === 't' ? 0 : 1) : 0) || String(p.dz).localeCompare(String(q.dz)) || q.d - p.d); };
    return { bot: sum('bot'), top: sum('top') }; };
  // zasięg prętów dodatkowych nad podporami i prętów dolnych skróconych (wymiary pod wykresem)
  const gx = new Map();
  R2.forEach(q => { const r = q.r, k = r.side === 'top' ? (supOf(r) !== null ? 'x' + r.sup : null) : r.cut ? 'c' + r.seg : null; if (!k) return;
    const o = gx.get(k) || { x0: r.x0, x1: r.x1, top: r.side === 'top', dz: q.dz, gs: new Map() }; o.x0 = Math.min(o.x0, r.x0); o.x1 = Math.max(o.x1, r.x1);
    const e = o.gs.get(q.g); if (!e || r.n > e.n) o.gs.set(q.g, { n: r.n, d: r.d }); gx.set(k, o); });
  gx.forEach(o => { const m = new Map(); o.gs.forEach(e => m.set(e.d, (m.get(e.d) || 0) + e.n)); o.parts = Array.from(m.entries()).sort((u, v) => v[0] - u[0]).map(([d, n]) => ({ n, d, dz: o.dz })); });
  // pręty strefy (największa liczba w przekroju strefy) – do okna wyboru średnicy
  const zone = dz => { const bySup = new Map(); const g = new Map(); R2.filter(q => q.dz === dz).forEach(q => { const o = g.get(q.g); if (!o || q.r.n > o.r.n) g.set(q.g, q); });
    g.forEach(q => { const k = supOf(q.r) === null ? -1 : q.r.sup, m = bySup.get(k) || new Map(); m.set(q.r.d, (m.get(q.r.d) || 0) + q.r.n); bySup.set(k, m); });
    let best = null; bySup.forEach(m => { const tot = Array.from(m.values()).reduce((a, b) => a + b, 0); if (!best || tot > best.tot) best = { tot, m }; });
    return best ? Array.from(best.m.entries()).sort((u, v) => v[0] - u[0]).map(([d, n]) => ({ n, d })) : []; };
  const v = { at, ext: Array.from(gx.values()), zone };
  autoMemo = { a, v }; return v;
}
function dzName(dz) {
  const md = R && R.md; if (!md) return dz;
  if (dz === 't') return 'góra – pręty ciągłe';
  if (dz[0] === 'x') { const i = dz.slice(1); if (i === '') return 'góra – pręty dodatkowe nad podporami'; const p = md.sups[+i]; return `góra – pręty dodatkowe nad podporą${p ? ' ' + p.label : ''}`; }
  if (dz[0] === 'b') { if (!md.cont) return 'dół – pręty przęsła'; const sg = md.segs.find(q => q.reb && q.si === +dz.slice(1)); return `dół – ${sg ? sg.label : 'przęsło'}`; }
  return dz;
}
// wybór średnicy prętów strefy (kliknięcie n⌀ na wykresie M w Danych) – liczba prętów dobierana do wybranej średnicy (pełny dobór, wszystkie warunki)
function dselPopup(dz) {
  const A = autoBars(), cur = (S.reb.dSel || {})[dz], m = $('#modal'), same = S.reb.sameD !== false;
  const now = A ? A.zone(dz).map(p => `${p.n}⌀${p.d}`).join(' + ') : '';
  let ap = false; try { ap = localStorage.getItem('bz.dsApply') === '1'; } catch (e) { /* */ }
  const DS = [12, 16, 20, 25, 28];
  const sameNote = !same ? '' : dz === 't' ? ' Włączona opcja „Jedna średnica”: pręty dodatkowe nad podporami (bez wybranej średnicy) przyjmą tę samą średnicę.' : dz[0] === 'x' ? ' Włączona opcja „Jedna średnica”: średnica inna niż prętów ciągłych górnych wyłącza ją w tej strefie.' : '';
  m.innerHTML = `<div class="dlg barpop dselpop"><h3>Średnica prętów – ${esc(dzName(dz))}</h3>
    ${now ? `<p class="hint keep">Obecnie (${cur ? 'średnica wybrana ręcznie' : 'dobór automatyczny'}): <b>${now}</b></p>` : ''}
    <div class="zl"><div class="dchips"><button class="btn sm ${cur ? '' : 'pri'}" data-dsd="">automatycznie</button>${DS.map(d => `<button class="btn sm ${cur === d ? 'pri' : ''}" data-dsd="${d}">⌀${d}</button>`).join('')}</div></div>
    <p class="hint keep">Liczba prętów zostanie dobrana do wybranej średnicy tak, aby spełnić wszystkie warunki (SGN, A<sub>s,min</sub>, rysy, naprężenia, ugięcie, rozstaw prętów 8.2, zakotwienie). „Automatycznie” – najmniejsza średnica spełniająca warunki. Wybór obowiązuje też w „Dobierz zbrojenie” i w automatycznym doborze przekrojów.${sameNote}</p>
    <label class="chk sm"><input type="checkbox" id="dsApply" ${ap ? 'checked' : ''}><span>Od razu zastosuj w zbrojeniu belki (jak „Dobierz zbrojenie” – zastępuje obecne zbrojenie podłużne)</span></label>
    <div class="dbtn"><span class="sp"></span><button class="btn" id="dsCancel">Anuluj</button></div></div>`;
  m.style.display = 'flex';
  $('#dsCancel', m).onclick = () => { m.style.display = 'none'; };
  $$('[data-dsd]', m).forEach(b => b.addEventListener('click', () => {
    const d = +b.dataset.dsd || 0, apply = $('#dsApply', m).checked;
    try { localStorage.setItem('bz.dsApply', apply ? '1' : '0'); } catch (e) { /* */ }
    S.reb.dSel = Object.assign({}, S.reb.dSel || {}); if (d) S.reb.dSel[dz] = d; else delete S.reb.dSel[dz];
    m.style.display = 'none';
    if (apply) doAutoReb(); else changed(true);
  }));
}
// ✔ / ✖ osobno dla szerokości (b) i wysokości (h): wymiar do zmiany – gdy proponowany przekrój ma większą wartość
// (przed wyznaczeniem propozycji: wg rodzaju niespełnionych warunków – rozstaw prętów, V_Rd,max, zwichrzenie → b; pozostałe → h)
const DIM_B_IDS = new Set(['sp', 'Vmax', 'hold', 'lat', 'Tmax', 'Tl', 'vib', 'slab', 'VzMax']);
function dimBadge(si, which) {
  which = which || 'h';
  const d = dimSt.spans[si], nm = which === 'b' ? 'szerokość b' : 'wysokość h';
  if (!d) return `<span class="dimst" data-dimst="${si}" data-dw="${which}">${dimSt.key && !dimSt.done ? '<i class="dpend" title="Sprawdzanie wymiarów przekroju…"></i>' : ''}</span>`;
  let bad = false;
  // przekrój większy niż potrzeba – ✖ przy wymiarze do zmniejszenia (kliknięcie przyjmuje najmniejszy wystarczający)
  const sm = d.ok && d.small ? (which === 'b' ? d.small.b : d.small.h) : null;
  if (sm !== null && sm !== undefined && sm < (which === 'b' ? d.cur.b : d.cur.h)) {
    const nb = which === 'b' ? sm : d.cur.b, nh = which === 'b' ? d.cur.h : sm;
    const tip = `<span class="dimtip"><b>${cap(nm)} ${which === 'b' ? d.cur.b : d.cur.h} mm – przekrój spełnia wszystkie warunki, ale jest większy niż potrzeba: wystarczy ${sm} mm.</b> Przekrój ${nb}×${nh} mm spełnia wszystkie warunki (SGN, SGU, konstrukcyjne, rozstaw prętów 8.2) z dobranym zbrojeniem – kliknij ?, aby go przyjąć (razem z tym zbrojeniem); możesz też zostawić obecny wymiar.${d.prop && d.prop.b * d.prop.h < nb * nh - 1 ? `<br>Najmniejszy przekrój (najmniejsze pole): <b>${d.prop.b}×${d.prop.h} mm</b> <button class="lnk" data-dsug="${d.seg}|${d.prop.b}|${d.prop.h}">przyjmij</button>` : ''}</span>`;
    return `<span class="dimst big" data-dimst="${si}" data-dw="${which}" data-dsug="${d.seg}|${nb}|${nh}" role="button" tabindex="0" aria-label="Przekrój większy niż potrzeba – przyjmij mniejszy ${nb}×${nh} mm">?${tip}</span>`;
  }
  if (!d.ok) {
    if (d.prop) { const bB = d.prop.b > d.cur.b, bH = d.prop.h > d.cur.h; bad = which === 'b' ? bB : (bH || !bB); }
    else { const wB = (d.ids || []).some(id => DIM_B_IDS.has(id)), wH = (d.ids || []).some(id => !DIM_B_IDS.has(id)); bad = which === 'b' ? wB : (wH || !wB); }
  }
  if (!bad) {
    const mn = d.ok && d.prop && d.prop.b * d.prop.h < d.cur.b * d.cur.h - 1 ? ` Najmniejszy przekrój spełniający wszystkie warunki: ${d.prop.b}×${d.prop.h} mm.` : '';
    const t = d.ok ? `${cap(nm)} ${which === 'b' ? d.cur.b : d.cur.h} mm – wystarczająca${d.small ? ' i najmniejsza możliwa przy drugim wymiarze' : d.pend ? ' (sprawdzanie, czy nie za duża…)' : ''}: zbrojenie dobrane dla tych wymiarów spełnia wszystkie warunki (SGN, SGU, konstrukcyjne).${mn}` : `${cap(nm)} ${which === 'b' ? d.cur.b : d.cur.h} mm – bez zmian; do poprawy ${which === 'b' ? 'wysokość h' : 'szerokość b'}${d.prop ? ` (proponowany przekrój ${d.prop.b}×${d.prop.h} mm)` : ''}.`;
    return `<span class="dimst ok" data-dimst="${si}" data-dw="${which}" title="${esc(t)}">✔</span>`;
  }
  const pv = d.prop ? (which === 'b' ? d.prop.b : d.prop.h) : null;
  const tip = `<span class="dimtip"><b>${cap(nm)} ${which === 'b' ? d.cur.b : d.cur.h} mm – do poprawy${pv ? ` → ${pv} mm` : ''}.</b> Po doborze zbrojenia nie są spełnione: ${esc(d.names.slice(0, 5).join('; '))}${d.names.length > 5 ? '…' : ''}.<br>${d.prop ? `Proponowany przekrój: <b>${d.prop.b}×${d.prop.h} mm</b> (sprawdzony z dobranym zbrojeniem) – kliknij ✖, aby przyjąć.` : d.pend ? 'Wyznaczanie proponowanych wymiarów…' : 'Nie znaleziono wymiarów spełniających wszystkie warunki – zmień schemat, obciążenia lub materiały.'}</span>`;
  return `<span class="dimst bad" data-dimst="${si}" data-dw="${which}" ${d.prop ? `data-dsug="${d.seg}|${d.prop.b}|${d.prop.h}" role="button" tabindex="0" aria-label="Przyjmij proponowany przekrój ${d.prop.b}×${d.prop.h} mm"` : ''}>✖${tip}</span>`;
}
function dimPaint() { $$('[data-dimst]').forEach(el => { const t = document.createElement('span'); t.innerHTML = dimBadge(+el.dataset.dimst, el.dataset.dw); el.replaceWith(t.firstElementChild); }); }
let rendered = {};
function renderActive() {
  const tab = $('.tabs button.on').dataset.tab;
  if (rendered[tab]) return; rendered[tab] = true;
  const el = $('#p-' + tab);
  try {
    if (tab === 'data') { renderDataSide(); return; }
    setTimeout(() => $$('.dsumx', el).forEach(x => { x.innerHTML = dsumHTML(); bindDsum(x); }), 0);
    if (tab === 'sec') { renderSection(el); return; }
    if (tab === 'report' && repView() === 'own' && S.meta.ownOn) { renderReport(el); return; }      // raport własny – także przy błędach danych
    if (!R || (R.errors && R.errors.length)) { el.innerHTML = errBox(); return; }
    ({ sum: renderSummary, chart: renderCharts, elev: renderElevation, report: renderReport })[tab](el);
  } catch (e) { console.error(e); el.innerHTML = `<div class="msg err">Błąd wyświetlania: ${esc(e.message)}</div>`; }
}
function errBox() { return `<div class="msgs">${((R && R.errors) || []).map(e => `<div class="msg err">${esc(e)}</div>`).join('')}</div>`; }
// znaczniki sprawdzeń: warunek, który przestał być spełniony – odznaczany; który zaczął być spełniony (lub nowy spełniony) – zaznaczany
const SAT = c => c.status === 'ok' || c.status === 'info';
let prevStat = null;
function syncTicks() {
  if (!R || !R.checks || !R.checks.length || (R.errors && R.errors.length)) return;
  const T = S.meta.ticks = S.meta.ticks || {};
  let ch = false;
  if (!S.meta.ticksInit) {
    if (!Object.keys(T).length) R.checks.forEach(c => { if (SAT(c)) T[c.key] = true; });
    S.meta.ticksInit = true; ch = true;
  } else if (prevStat) {
    R.checks.forEach(c => {
      const p = prevStat[c.key], now = SAT(c);
      if ((p === undefined || p === false) && now && !T[c.key]) { T[c.key] = true; ch = true; }
      else if (p === true && !now && T[c.key]) { delete T[c.key]; ch = true; }
    });
  }
  prevStat = {}; R.checks.forEach(c => { prevStat[c.key] = SAT(c); });
  if (ch) autosave();
}
function expAll() {
  const X = window.BZN.EXP, m = $('#modal');
  const rows = [...E.EXPOSURES, 'XF1', 'XF2', 'XF3', 'XF4', 'XA1', 'XA2', 'XA3'].map(c => `<tr><td><b>${c}</b></td><td>${esc(E.EXP_DESC[c] || '')}</td><td>${esc(X[c] || '')}</td></tr>`).join('');
  m.innerHTML = `<div class="dlg norm"><h3>Klasy ekspozycji – przykłady elementów</h3><p>Przykłady orientacyjne (por. PN-EN 1992-1-1, tab. 4.1 i PN-EN 206); o klasie decydują rzeczywiste warunki środowiska elementu.</p><div class="tscroll"><table class="sched exptab"><tr><th>Klasa</th><th>Środowisko</th><th>Przykłady elementów i obiektów</th></tr>${rows}</table></div><div class="dbtn"><button class="btn pri" id="nClose">Zamknij</button></div></div>`;
  m.style.display = 'flex';
  $('#nClose', m).onclick = () => { m.style.display = 'none'; };
}
// odporność ogniowa – wynik na bieżąco i podpowiedź, co zmienić (otulina, wymiary przekroju)
function fireStatusHTML() {
  if (!(S.fire.R && S.fire.R !== '-')) return '';
  if (!R || !R.fire || (R.errors && R.errors.length)) return `<div class="firest">Odporność ogniowa ${esc(S.fire.R)}: wynik po usunięciu błędów danych.</div>`;
  const f = R.fire, cs = R.checks.filter(c => /^f(b|a|asd|bw)$/.test(c.id)), bad = f.assumed ? [f.b < f.bmin, f.amin !== null && f.am < f.amin - 1e-6, f.needAsd && f.amin !== null && f.asd < f.asdReq - 1e-6].filter(Boolean) : cs.filter(c => c.status === 'fail');
  const tips = [];
  if (f.b < f.bmin) tips.push(`zwiększ szerokość belki do b ≥ ${f.bmin} mm`);
  if (f.amin !== null && f.am < f.amin - 1e-6) {
    const dA = Math.ceil((f.amin - f.am) / 5) * 5, alt = f.tab.c.find(([bb, aa]) => aa <= f.am + 1e-6);
    tips.push(`zwiększ otulinę dolną c<sub>nom,b</sub> z ${R.cov.cb} do ≥ ${R.cov.cb + dA} mm (odległość osiowa a = ${fmt(f.am, 0)} → ≥ ${fmt(f.amin, 0)} mm)` + (alt ? ` albo poszerz belkę do b ≥ ${alt[0]} mm (wtedy wystarcza a = ${alt[1]} mm)` : ''));
  }
  if (f.needAsd && f.amin !== null && f.asd < f.asdReq - 1e-6) tips.push(`zwiększ otulinę boczną c<sub>nom,s</sub> z ${R.cov.cs} do ≥ ${R.cov.cs + Math.ceil((f.asdReq - f.asd) / 5) * 5} mm (a<sub>sd</sub> ≥ a + 10 mm dla prętów narożnych)`);
  if (R.g.T && R.g.bw < f.bwMin) tips.push(`zwiększ grubość środnika b<sub>w</sub> do ≥ ${f.bwMin} mm`);
  return `<div class="firest ${bad.length ? 'fail' : 'ok'}">${bad.length ? '✖' : '✔'} ${esc(f.R)} (PN-EN 1992-1-2, tab. ${f.cont ? '5.6' : '5.5'}): b = ${f.b} mm ${f.b >= f.bmin ? '≥' : '<'} b<sub>min</sub> = ${f.bmin} mm${f.amin !== null ? `; a = ${fmt(f.am, 0)} mm ${f.am >= f.amin - 1e-6 ? '≥' : '<'} a<sub>min</sub> = ${fmt(f.amin, 0)} mm` : ''}${f.needAsd && f.amin !== null ? `; a<sub>sd</sub> = ${fmt(f.asd, 0)} mm ${f.asd >= f.asdReq - 1e-6 ? '≥' : '<'} ${fmt(f.asdReq, 0)} mm` : ''}${tips.length ? `<br><b>Co zmienić:</b> ${tips.join('; ')}.` : ''}</div>`;
}
// podgląd wyników w zakładce Dane (nad polami danych): SGN zginanie, ścinanie; SGU rysy, ugięcie, naprężenia
const DSUM = [['SGN', 'zginanie', x => /^SGN – zginanie/.test(x.grp)], ['SGN', 'ścinanie', x => /^SGN – ścinanie/.test(x.grp)], ['SGU', 'rysy', x => /zarysowanie/.test(x.grp)], ['SGU', 'ugięcie', x => /ugięcia/.test(x.grp)], ['SGU', 'naprężenia', x => /naprężenia/.test(x.grp)], ['', 'konstrukcja', x => /^Otulina|^Zakotwienia|ogniow|EN 1992-1-2/i.test(x.grp)]];
const DSUM_CAP = { 1: c => ['Vmax', 'Vs1', 'VzMax', 'VzS', 'T631', 'Tst', 'Tl'].includes(c.id) };      // ścinanie: wykorzystanie nośności (nie konstrukcyjne)
function dsumHTML() {
  if (!R || !R.checks) return '';
  if (R.errors && R.errors.length) return `<div class="dsum"><span class="dsb fail">✖ błąd danych – wyniki niedostępne</span></div>`;
  let h = '<div class="dsum">';
  if (R.bare) h += `<button class="dsb fail" data-auto="1" title="Przekroje bez zbrojenia podłużnego – dobierz zbrojenie wymagane">✖ <b>brak zbrojenia</b> – dobierz</button>`;
  DSUM.forEach(([a, l, pr], gi) => {
    const cs = R.checks.filter(pr).filter(x => x.status !== 'info'); if (!cs.length) return;
    const st = cs.some(x => x.status === 'fail') ? 'fail' : cs.some(x => x.status === 'warn') ? 'warn' : 'ok';
    const rv = x => isFinite(x.ratio) ? x.ratio : 9.99, csW = DSUM_CAP[gi] && cs.some(DSUM_CAP[gi]) && st !== 'fail' ? cs.filter(DSUM_CAP[gi]) : cs, w = csW.reduce((p, q) => (rv(q) > rv(p) ? q : p));
    const bad = cs.filter(x => x.status === 'fail').length;
    h += `<button class="dsb ${st}" data-dg="${gi}" title="${esc(w.name.replace(/_\{?([^}]*)\}?/g, '$1'))}${isFinite(w.ratio) ? ' – ' + fmt(w.ratio * 100, 0) + '%' : ''} · kliknij, aby przejść do Podsumowania"><span class="ic">${st === 'fail' ? '✖' : st === 'warn' ? '!' : '✔'}</span>${a ? `<b>${a}</b> ` : ''}${l}<span class="pc">${isFinite(w.ratio) ? fmt(w.ratio * 100, 0) + '%' : '∞'}</span>${bad ? `<span class="nb">${bad}</span>` : ''}</button>`;
  });
  return h + '</div>';
}
function bindDsum(el) {
  $$('[data-auto]', el).forEach(b => b.addEventListener('click', ev => { ev.stopPropagation(); doAutoReb(); }));
  $$('[data-dg]', el).forEach(b => b.addEventListener('click', () => {
    const pr = DSUM[+b.dataset.dg][2], c = R.checks, i0 = c.findIndex(x => pr(x) && x.status === 'fail'), i1 = i0 >= 0 ? i0 : c.findIndex(x => pr(x) && x.status === 'warn'), i = i1 >= 0 ? i1 : c.findIndex(pr);
    const x = c[i]; if (x && (x.status === 'fail' || x.status === 'warn')) { gotoCheck(x); return; }
    const gov = c.filter(pr).reduce((a, q) => (!a || (isFinite(q.ratio) && q.ratio > a.ratio) ? q : a), null); if (gov) { explainPopup(gov); return; }
    U.selectTab('sum'); setTimeout(() => { const tr = $(`#p-sum tr[data-ci="${i}"]`); if (tr) { tr.scrollIntoView({ block: 'center' }); flash(tr); } }, 60);
  }));
}
function renderDsum() {
  const el = $('#dsum'); if (!el) return;
  el.innerHTML = dsumHTML(); bindDsum(el);
  $$('.dsumx').forEach(x => { x.innerHTML = dsumHTML(); bindDsum(x); });
  requestAnimationFrame(() => { const x = $$('.pane.on > .dsumx')[0]; if (x && x.offsetHeight) document.documentElement.style.setProperty('--dsh', x.offsetHeight + 'px'); });
}
function flash(el) { if (!el) return; el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 2200); }
// przejście z Podsumowania do miejsca niespełnienia warunku
// czerwone podświetlenie elementu, który trzeba zmienić (do kliknięcia)
function hlg(t) {
  const els = (Array.isArray(t) ? t : [t]).flatMap(x => typeof x === 'string' ? $$(x) : x ? [x] : []);
  els.forEach((el, i) => {
    const box = el.closest ? (el.closest('.row, .zg, tr, label.chk, .zl') || el) : el;
    if (i === 0 && box.scrollIntoView) box.scrollIntoView({ block: 'center' });
    box.classList.remove('hlg'); void box.offsetWidth; box.classList.add('hlg');
  });
  if (els.length) hlgT = Date.now();
  return els.length;
}
// podział zakładki Dane: dane | schemat (przeciąganie; zapamiętywany)
(function () {
  const wrap = () => $('#p-data .datawrap'), set = v => { const w = wrap(); if (w) w.style.setProperty('--dsl', v); };
  try { const v = localStorage.getItem('bz.dsl'); if (v) set(v); } catch (e) { /* */ }
  document.addEventListener('pointerdown', e => {
    const h = e.target.closest && e.target.closest('#dsplit'); if (!h) return;
    e.preventDefault(); const w = wrap(), r = w.getBoundingClientRect(); h.classList.add('drag'); document.body.classList.add('dsdrag');
    const mv = ev => { const pc = Math.max(25, Math.min(75, (ev.clientX - r.left) / r.width * 100)); set(pc.toFixed(1) + '%'); };
    const up = () => { h.classList.remove('drag'); document.body.classList.remove('dsdrag'); window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
      try { localStorage.setItem('bz.dsl', w.style.getPropertyValue('--dsl')); } catch (e2) { /* */ } rendered.data = false; renderDataSide(); };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  });
  document.addEventListener('dblclick', e => { if (e.target.closest && e.target.closest('#dsplit')) { set('50%'); try { localStorage.setItem('bz.dsl', '50%'); } catch (e2) { /* */ } renderDataSide(); } });
})();
// powiększanie i przesuwanie schematu (Dane) i widoku podłużnego: Ctrl + kółko – zoom względem kursora, przeciąganie – przesuw, dwuklik na „100%” – reset
const ZOOM = { scheme: { k: 1, x: 0, y: 0 }, elev: { k: 1, x: 0, y: 0 } };
const zKey = el => el.classList.contains('elevwrap') ? 'elev' : 'scheme';
function zoomApply(root) {
  $$('.schemewrap, .elevwrap', root || document).forEach(w => {
    const z = ZOOM[zKey(w)], svg = w.querySelector('svg'); if (!svg) return;
    w.classList.toggle('zoomed', z.k > 1.001);
    svg.style.transformOrigin = '0 0'; svg.style.transform = z.k > 1.001 ? `translate(${z.x}px, ${z.y}px) scale(${z.k})` : '';
    let b = w.querySelector('.zoomrst'); if (z.k > 1.001) { if (!b) { b = document.createElement('button'); b.className = 'zoomrst'; b.type = 'button'; b.title = 'Przywróć widok (100%)'; w.appendChild(b); } b.textContent = Math.round(z.k * 100) + '% ✕'; } else if (b) b.remove();
  });
}
// powiększanie pozostałych rysunków (przekroje, wykresy, raport, okna): Ctrl + kółko – zoom względem kursora (viewBox), przeciąganie – przesuw,
// dwuklik lub „✕” w rogu rysunku – 100%
const ZSVG = new WeakMap();
function zsvgOf(t) {
  let svg = t && t.closest ? t.closest('svg') : null; if (!svg) return null;
  for (let p = svg.parentElement && svg.parentElement.closest('svg'); p; p = p.parentElement && p.parentElement.closest('svg')) svg = p;
  if (svg.closest('.schemewrap, .elevwrap, button, .nozoom')) return null;
  const r = svg.getBoundingClientRect(); return r.width >= 120 && r.height >= 80 ? svg : null;
}
function zsvgGet(svg) {
  let z = ZSVG.get(svg);
  if (!z) { const vb = svg.viewBox && svg.viewBox.baseVal, r = svg.getBoundingClientRect(); const b = vb && vb.width > 0 ? { x: vb.x, y: vb.y, w: vb.width, h: vb.height } : { x: 0, y: 0, w: +svg.getAttribute('width') || r.width, h: +svg.getAttribute('height') || r.height };
    z = { b, v: Object.assign({}, b), had: svg.hasAttribute('viewBox') }; ZSVG.set(svg, z); }
  return z;
}
function zsvgApply(svg, z) {
  const b = z.b, v = z.v, k = b.w / v.w;
  let ov = svg.querySelector(':scope > g.zsvgov');
  if (k <= 1.001) { z.v = Object.assign({}, b); if (z.had) svg.setAttribute('viewBox', `${b.x} ${b.y} ${b.w} ${b.h}`); else svg.removeAttribute('viewBox'); if (ov) ov.remove(); return; }
  v.x = Math.min(b.x + b.w - v.w, Math.max(b.x, v.x)); v.y = Math.min(b.y + b.h - v.h, Math.max(b.y, v.y));
  svg.setAttribute('viewBox', `${v.x} ${v.y} ${v.w} ${v.h}`);
  if (!ov) { ov = document.createElementNS('http://www.w3.org/2000/svg', 'g'); ov.setAttribute('class', 'zsvgov'); svg.appendChild(ov); }
  const r = svg.getBoundingClientRect(), u = v.w / Math.max(1, r.width), txt = `${Math.round(k * 100)}% ✕`, tw = (txt.length * 6.4 + 10) * u, th = 18 * u;
  ov.innerHTML = `<title>Przywróć widok 100% (albo dwuklik na rysunku)</title><rect x="${v.x + v.w - tw - 4 * u}" y="${v.y + 4 * u}" width="${tw}" height="${th}" rx="${4 * u}" fill="#1d5bb8" fill-opacity="0.88"/><text x="${v.x + v.w - tw / 2 - 4 * u}" y="${v.y + 4 * u + th * 0.68}" font-size="${11 * u}" text-anchor="middle" fill="#fff" font-weight="600">${txt}</text>`;
}
const zsvgReset = svg => { const z = ZSVG.get(svg); if (!z) return; z.v = Object.assign({}, z.b); zsvgApply(svg, z); };
function zsvgWheel(e) {
  const svg = zsvgOf(e.target); if (!svg) return false;
  e.preventDefault(); const z = zsvgGet(svg), v = z.v, k0 = z.b.w / v.w, k = Math.max(1, Math.min(10, k0 * Math.exp(-e.deltaY * 0.0022)));
  let pt = null; try { const m = svg.getScreenCTM().inverse(), p0 = svg.createSVGPoint(); p0.x = e.clientX; p0.y = e.clientY; pt = p0.matrixTransform(m); } catch (er) { pt = { x: v.x + v.w / 2, y: v.y + v.h / 2 }; }
  const w2 = z.b.w / k, h2 = z.b.h / k; z.v = { x: pt.x - (pt.x - v.x) * w2 / v.w, y: pt.y - (pt.y - v.y) * h2 / v.h, w: w2, h: h2 };
  zsvgApply(svg, z); return true;
}
let zsDrag = null;
document.addEventListener('pointerdown', e => { if (e.button !== 0) return; const svg = zsvgOf(e.target); if (!svg) return; const z = ZSVG.get(svg); if (!z || z.b.w / z.v.w <= 1.001) return;
  if (e.target.closest('g.zsvgov')) { zsvgReset(svg); e.preventDefault(); return; }
  zsDrag = { svg, z, x0: e.clientX, y0: e.clientY, v0: Object.assign({}, z.v), moved: false }; });
document.addEventListener('pointermove', e => { if (!zsDrag) return; const dx = e.clientX - zsDrag.x0, dy = e.clientY - zsDrag.y0; if (!zsDrag.moved && Math.hypot(dx, dy) < 5) return; zsDrag.moved = true;
  const r = zsDrag.svg.getBoundingClientRect(), u = zsDrag.v0.w / Math.max(1, r.width); zsDrag.z.v = Object.assign({}, zsDrag.v0, { x: zsDrag.v0.x - dx * u, y: zsDrag.v0.y - dy * u }); zsvgApply(zsDrag.svg, zsDrag.z); });
document.addEventListener('pointerup', () => { if (zsDrag && zsDrag.moved) { const stop = ev => { ev.stopPropagation(); ev.preventDefault(); window.removeEventListener('click', stop, true); }; window.addEventListener('click', stop, true); setTimeout(() => window.removeEventListener('click', stop, true), 50); } zsDrag = null; });
document.addEventListener('dblclick', e => { const svg = zsvgOf(e.target); if (!svg) return; const z = ZSVG.get(svg); if (z && z.b.w / z.v.w > 1.001) { e.preventDefault(); e.stopPropagation(); zsvgReset(svg); } }, true);
document.addEventListener('wheel', e => {
  if (!e.ctrlKey) return; const w = e.target.closest && e.target.closest('.schemewrap, .elevwrap'); if (!w) { zsvgWheel(e); return; }
  e.preventDefault(); const z = ZOOM[zKey(w)], r = w.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
  const k2 = Math.max(1, Math.min(8, z.k * Math.exp(-e.deltaY * 0.0022)));
  z.x = px - (px - z.x) * k2 / z.k; z.y = py - (py - z.y) * k2 / z.k; z.k = k2;
  if (k2 <= 1.001) { z.k = 1; z.x = 0; z.y = 0; }
  const svg = w.querySelector('svg'); if (svg) { const W2 = r.width, H2 = svg.getBoundingClientRect().height / (z.k || 1); z.x = Math.min(0, Math.max(W2 - W2 * z.k, z.x)); z.y = Math.min(0, Math.max(H2 - H2 * z.k, z.y)); }
  zoomApply(w.parentElement);
}, { passive: false });
let zDrag = null, zMoved = false;
document.addEventListener('pointerdown', e => { const w = e.target.closest && e.target.closest('.schemewrap.zoomed, .elevwrap.zoomed'); if (!w || e.button !== 0) return; if (e.target.closest('.zoomrst')) return; zDrag = { w, x0: e.clientX, y0: e.clientY, z: Object.assign({}, ZOOM[zKey(w)]) }; zMoved = false; });
document.addEventListener('pointermove', e => { if (!zDrag) return; const dx = e.clientX - zDrag.x0, dy = e.clientY - zDrag.y0; if (!zMoved && Math.hypot(dx, dy) < 5) return; zMoved = true;
  const z = ZOOM[zKey(zDrag.w)], r = zDrag.w.getBoundingClientRect(), svg = zDrag.w.querySelector('svg'), H2 = svg ? svg.getBoundingClientRect().height / z.k : r.height;
  z.x = Math.min(0, Math.max(r.width - r.width * z.k, zDrag.z.x + dx)); z.y = Math.min(0, Math.max(H2 - H2 * z.k, zDrag.z.y + dy)); zoomApply(zDrag.w.parentElement); });
document.addEventListener('pointerup', () => { if (zDrag && zMoved) { const stop = ev => { ev.stopPropagation(); ev.preventDefault(); window.removeEventListener('click', stop, true); }; window.addEventListener('click', stop, true); setTimeout(() => window.removeEventListener('click', stop, true), 50); } zDrag = null; });
document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('.zoomrst'); if (!b) return; const w = b.closest('.schemewrap, .elevwrap'); const z = ZOOM[zKey(w)]; z.k = 1; z.x = 0; z.y = 0; zoomApply(w.parentElement); });
// czerwone podświetlenie trwa do kliknięcia poza oknem objaśnienia (lub Esc)
let hlgT = 0;
const hlgOff = () => $$('.hlg').forEach(x => x.classList.remove('hlg'));
document.addEventListener('pointerdown', e => { if (Date.now() - hlgT < 400) return; if (e.target.closest && e.target.closest('#nmodal .dlg, #modal .dlg')) return; hlgOff(); }, true);
document.addEventListener('keydown', e => { if (e.key === 'Escape') hlgOff(); });
// przejście z Podsumowania (lub podglądu wyników) bezpośrednio do miejsca niespełnienia warunku – z podświetleniem, co zmienić
function gotoCheck(c) {
  const at = String(c.at || ''), id = c.id, grp = c.grp || '', md = R.md;
  const closeM = () => { if ($('#modal').style.display === 'flex') $('#modal').style.display = 'none'; };
  const go = (tab, fn) => { closeM(); U.selectTab(tab); setTimeout(() => { try { fn && fn(); } catch (e) { console.error(e); } }, 90); };
  const inPop = (open, sels) => { open(); setTimeout(() => { if (!hlg(sels.map(q => '#modal ' + q))) hlg('#modal .dlg'); }, 60); };
  const secOf = k => (R.secs || []).find(q => q.key === k);
  const stirF = ids => go('sec', () => inPop(() => fieldPopup('stir'), ids));
  const segOfE = k => { const m2 = /^e(\d+)/.exec(k); return m2 ? md.segs[+m2[1]] : null; };
  if (R.bare && (id === 'Mspan' || id === 'Msupp')) return go('sec', () => hlg('#rbAuto'));
  // otulina
  if (id === 'cnom' || at === 'cov') { const f = /dolnej/.test(c.name) ? 'cBot' : /górnej/.test(c.name) ? 'cTop' : /bocznych/.test(c.name) ? 'cSide' : 'cnomSel'; return go('sec', () => inPop(() => fieldPopup('cov'), [`[data-k="env.${f}"]`, '[data-k="env.cnomSel"]'])); }
  // rozstaw prętów, buława
  if (/^L\d+$/.test(at)) return go('sec', () => inPop(() => zonePopup('b' + at.slice(1)), ['[data-zn]', '[data-zp]']));
  if (at === 'LtM') return go('sec', () => inPop(() => zonePopup('t'), ['[data-zn]', '[data-zp]']));
  if (/^T\d+$/.test(at)) return go('sec', () => inPop(() => zonePopup('x' + at.slice(1)), ['[data-zn]', '[data-zp]']));
  // strzemiona
  if (id === 'hold') return stirF(['[data-k="stir.legs"]', '[data-k^="cont.stirSpans"][data-k$=".legs"]']);
  if (id === 'Thook') return stirF(['[data-k="stir.hookA"]']);
  if (id === 'Tclosed') return stirF(['[data-k="stir.kind"]']);
  if (id === 'hook') return stirF(['[data-k="stir.hook"]']);
  if (id === 'st') return stirF(['[data-k="stir.legs"]']);
  if (['rho1', 'rho2', 'smax', 'scomp', 'Tst'].includes(id)) return stirF(S.stir.sAuto ? ['[data-k="stir.sAuto"]', '[data-k="stir.d"]'] : ['[data-k="stir.s1"]', '[data-k="stir.s2"]', '[data-k="stir.d"]']);
  if (id === 'Vs1' || id === 'l1' || id === 'VzS') return stirF(S.stir.sAuto ? ['[data-k="stir.d"]', '[data-k="stir.legs"]', '[data-k="stir.cot"]'] : ['[data-k="stir.s1"]', '[data-k="stir.d"]', '[data-k="stir.legs"]', '[data-k="stir.l1"]']);
  if (id === 'Vmax' || id === 'VzMax' || id === 'T631' || id === 'Tl') { const sg = segOfE(at) || md.segs[0]; return go('sec', () => inPop(() => geoPopup(sg.idx), ['[data-gw="b"]', '[data-gw="h"]'])); }
  // ugięcia – wysokość przęsła (Dane)
  if (id === 'w0') return go('data', () => hlg('#inputs [data-k="sls.camber"]'));
  if (id === 'f' && (S.sls.camber === 'auto' || +S.sls.camber > 0)) return go('data', () => hlg(['#inputs [data-k="sls.camber"]', '#inputs [data-k="geom.h"]']));
  if (/^d\d+$/.test(at) || id === 'ld' || id === 'fz') { const sg = md.segs[+at.slice(1)] || md.segs[0], si = sg.si !== undefined ? sg.si : (md.segs[sg.adj] || {}).si; return go('data', () => { if (!hlg(CONT(S) ? `#inputs [data-k="cont.geoSpans.${si || 0}.h"]` : '#inputs [data-k="geom.h"]')) hlg('#inputs [data-k="geom.h"]'); }); }
  // zakotwienia, zakłady, długości prętów – widok podłużny
  if (id === 'Lmax' || id === 'lenMan') return go('elev', () => hlg(`.xbar[data-key="${at.replace(/^bar/, '')}"]`) || hlg('#p-elev .elevbox'));
  if (['FE', 'lbd', 'legMan', 'phm'].includes(id) && /^e\d+[LR]$/.test(at)) { const sd = at.slice(-1); return go('elev', () => hlg([`svg.elev .bend[data-key="b${at.slice(1, -1)}"][data-end="${sd}"]`]) || hlg('#p-elev .elevbox')); }
  if (['lbdT', 'phm', 'topLen'].includes(id) && /^p\d+$/.test(at)) { const pi = +at.slice(1); if (id === 'topLen') return go('sec', () => inPop(() => zonePopup('x' + pi), ['[data-zlen]'])); return go('elev', () => hlg(`svg.elev .bend[data-key="t"], svg.elev .bend[data-key="x${pi}"]`) || hlg('#p-elev .elevbox')); }
  if (['lapB', 'stepB', 'stepL', 'inner'].includes(id) && /^p\d+$/.test(at)) { const p0 = md.sups[+at.slice(1)]; return go('elev', () => hlg([`svg.elev .bend[data-key="b${p0.segL}"][data-end="R"]`, `svg.elev .bend[data-key="b${p0.segR}"][data-end="L"]`]) || hlg('#p-elev .elevbox')); }
  if (/^Zakotwienia/.test(grp)) return go('elev', () => hlg('#p-elev .elevbox'));
  // przekroje: zbrojenie strefy rozciąganej
  if (/^[sp]\d+$/.test(at)) {
    const q = secOf(at);
    return go('sec', () => { const box = $(`[data-sk="${at}"]`); if (box) box.scrollIntoView({ block: 'center' });
      if (q) { const z = sectionZones(q), zid = q.kind === 'span' ? z.bot : z.top; hlg([`.rebbar [data-z="${zid}"]`, ...(box ? $$(`.zhit[data-z="${zid}"]`, box) : [])]); if (['sck', 'scqp', 'duct'].includes(id)) hlg(box ? $$('.geohit', box) : []); } });
  }
  if (/^z\d+$/.test(at)) return go('chart', () => hlg('[data-chart="MZ"]'));
  if (id === 'minclass') return go('data', () => hlg(['#inputs [data-k="mat.concrete"]', '#inputs [data-k="env.exp"]']));
  if (/^f(b|a|asd|bw)$/.test(id) || /1992-1-2|ogniow/i.test(grp)) return go('data', () => hlg('#fireRow') && hlg('.firest'));
  if (/^surf/.test(id)) return go('sec', () => inPop(() => fieldPopup('surf'), ['[data-k="surf.d"]', '[data-k="surf.s"]']));
  if (id === 'lat') return go('data', () => hlg('#inputs [data-k="geom.l0t"]'));
  if (id === 'skin') return go('sec', () => inPop(() => fieldPopup('mid'), ['[data-k="reb.mid.n"]']));
  if (id === 'N') return go('data', () => hlg('#inputs [data-k="loads.NEd"]'));
  if (id === 'asmax' || id === 'bots' || id === 'tops') return go('sec', () => hlg([...$$('#p-sec .zhit'), '#rbAuto']));
  return go('sec', () => hlg($$('#p-sec .zhit').length ? [...$$('#p-sec .zhit')] : '.rebbar'));
}
function goData(gid) {
  U.selectTab('data');
  setTimeout(() => { const g = $(`#inputs details[data-id="${gid}"]`); if (!g) return; g.open = true; g.scrollIntoView({ block: 'start' }); flash(g); }, 60);
}
function renderStatus() {
  const el = $('#status'), dot = $('#mDot');
  const set = (cls, txt) => { el.className = cls; el.textContent = txt; if (dot) dot.className = 'dot ' + cls; };
  if (!R || (R.errors && R.errors.length)) { set('fail', '✖ Błąd danych'); return; }
  const fails = R.checks.filter(c => c.status === 'fail').length, warns = R.checks.filter(c => c.status === 'warn').length;
  if (fails) set('fail', `✖ Niespełnione warunki: ${fails}`);
  else if (warns) set('warn', `✔ Nośność OK · uwagi: ${warns} · η = ${fmt(R.maxUtil * 100, 0)}%`);
  else set('ok', `✔ Wszystkie warunki spełnione · η = ${fmt(R.maxUtil * 100, 0)}%`);
}

/* ------------------------------------------------------------ podsumowanie */
const CHECK_DP = { kNm: 1, kN: 1, mm: 1, MPa: 2, 'mm²': 0, '‰': 3, '': 3, m: 2, 'mm²/mm': 3, 'mm²/m': 0 };
function ckVal(c, v) { if (c.fmt === 'text') return ''; const dp = typeof c.fmt === 'number' ? c.fmt : (CHECK_DP[c.unit] ?? 2); return fmt(v, dp); }
function ckCond(c) {
  if (c.status === 'info' && c.Ed === 0 && c.Rd === 0) return '';
  if (c.fmt === 'text') return `${esc(c.RdTxt)} ≥ ${esc(c.EdTxt)}`;
  const u = c.unit ? ' ' + c.unit : '';
  return c.rel === '≥' ? `${ckVal(c, c.Rd)} ≥ ${ckVal(c, c.Ed)}${u}` : `${ckVal(c, c.Ed)} ≤ ${ckVal(c, c.Rd)}${u}`;
}
const STL = { ok: 'OK', fail: 'NIE', warn: 'UWAGA', info: 'INFO' };
U.ckCond = ckCond; U.STL = STL;
function utilBar(c) {
  if (c.status === 'info' || !isFinite(c.ratio) && c.status !== 'fail') return '';
  const r = isFinite(c.ratio) ? c.ratio : 9.99;
  const w = Math.min(100, r * 100);
  const cls = c.status === 'fail' ? 'fail' : (c.status === 'warn' || r > 0.9) ? 'warn' : '';
  return `<span class="ub ${cls}"><i style="width:${w}%"></i></span><span class="pct">${isFinite(c.ratio) ? fmt(r * 100, 0) + '%' : '∞'}</span>`;
}
function renderSummary(el) {
  const c = R.checks;
  const worst = (pred) => { const a = c.filter(pred).filter(x => x.status !== 'info'); if (!a.length) return null; return a.reduce((p, q) => (q.ratio > p.ratio ? q : p)); };
  const card = (t, v, s, ck) => `<div class="card ${ck ? (ck.status === 'fail' ? 'fail' : ck.status === 'warn' ? 'warn' : 'ok') : ''}"><div class="t">${t}</div><div class="v">${v}</div><div class="s">${s}</div></div>`;
  const secs = R.secs || [];
  const gov = secs.reduce((a, q) => (!a || (q.MRd > 0 ? q.MEd / q.MRd : 9) > (a.MRd > 0 ? a.MEd / a.MRd : 9) ? q : a), null);
  const wb = worst(x => /^SGN – zginanie/.test(x.grp));
  const ws = worst(x => /^SGN – ścinanie/.test(x.grp));
  const ww = worst(x => x.id === 'wk');
  const wf = worst(x => x.id === 'f');
  const wc = c.find(x => x.id === 'cnom');
  const wr = worst(x => /^SGU – naprężenia/.test(x.grp));
  const ends = R.sh.ends;
  const Vmax = ends.length ? Math.max(...ends.map(s => s.V0)) : 0;
  let cards = '';
  if (gov) cards += card('Zginanie' + (secs.length > 1 ? ' – ' + esc(gov.loc) : ''), `${fmt(gov.MEd / 1e6, 1)} / ${fmt(gov.MRd / 1e6, 1)}`, `|M<sub>Ed</sub>| / M<sub>Rd</sub> [kNm]` + (secs.length > 1 ? ` · przekrojów: ${secs.length}` : ''), wb);
  const Vr = ends.length ? Math.max(...ends.map(s => s.Vred)) : 0, anyRed = ends.some(s => s.red);
  cards += card('Ścinanie', `${fmt(Vmax / 1e3, 1)} kN`, `V<sub>Ed,max</sub>${anyRed ? ` · V<sub>Ed,red</sub> = ${fmt(Vr / 1e3, 1)} kN (6.2.1(8))` : S.stir.redV ? ' · bez redukcji' : ''} · cot θ = ${fmt(R.sh.cot, 2)}`, ws);
  if (ww) cards += card('Rysy', `${fmt(ww.Ed, 3)} mm`, `w<sub>k</sub> ≤ w<sub>max</sub> = ${fmt(R.sls.wmax, 1)} mm`, ww);
  if (wf) cards += card('Ugięcie', `${fmt(wf.Ed, 1)} mm`, `f ≤ f<sub>lim</sub> = ${fmt(wf.Rd, 1)} mm` + (R.md.segs.length > 1 ? ' (odcinek decydujący)' : ` (L/${S.sls.lim})`), wf);
  if (wr) cards += card('Naprężenia SGU', `${fmt(wr.ratio * 100, 0)}%`, sym(wr.name.replace(/ ≤.*$/, '')), wr);
  cards += card('Otulina', R.cov.faces ? `${R.cov.cb} / ${R.cov.ct} / ${R.cov.cs} mm` : `${R.cov.cnom} mm`, (R.cov.faces ? 'dół / góra / boki · ' : '') + `c<sub>nom</sub> do strzemion · S${R.cov.sc} · ${R.cov.exp}` + (R.cov.manual ? ' · ręcznie' : ''), wc);
  let html = `<div class="cards">${cards}</div>`;
  const msgs = [...(R.errors || []).map(e => `<div class="msg err">${esc(e)}</div>`), ...(R.warnings || []).map(e => `<div class="msg wrn">${esc(e)}</div>`)];
  if (Math.abs(R.st.NEd) > 0 && R.st.NEd < 0) msgs.push(`<div class="msg wrn">Siła rozciągająca N<sub>Ed</sub> jest uwzględniona w SGN; w SGU (rysy, ugięcia) przyjęto zginanie bez siły osiowej – wynik SGU może być niedoszacowany.</div>`);
  if (msgs.length) html += `<div class="msgs">${msgs.join('')}</div>`;
  const ticks = S.meta.ticks || {};
  const nT = c.filter(x => ticks[x.key]).length;
  html += `<div class="tickbar"><span id="tickCnt">Odhaczono: <b>${nT}</b> z ${c.length}</span><button class="btn sm" id="tickOk">Odhacz spełnione</button><button class="btn sm" id="tickClr">Wyczyść znaczniki</button><span class="hint">Kliknij numer punktu normy, aby zobaczyć objaśnienie.</span></div>`;
  html += `<div class="tscroll"><table class="ctab"><thead><tr><th class="tk" title="Sprawdzone">✓</th><th>Sprawdzenie</th><th>PN-EN 1992-1-1</th><th style="text-align:right">Warunek</th><th>Wykorzystanie</th><th>Status</th><th class="nt">Uwagi</th></tr></thead><tbody>`;
  let grp = '';
  c.forEach((x, i) => {
    if (x.grp !== grp) { grp = x.grp; html += `<tr class="g"><td colspan="7">${esc(grp)}</td></tr>`; }
    const on = !!ticks[x.key];
    html += `<tr class="${on ? 'done' : ''}" data-ci="${i}"><td class="tk"><input type="checkbox" data-tick="${i}" ${on ? 'checked' : ''} aria-label="sprawdzone"></td><td>${sym(x.name)}</td><td class="ref"><button class="nref" data-ref="${i}" title="Objaśnienie punktu normy">${esc(x.ref)}</button></td><td class="val">${ckCond(x)}</td><td class="bar" style="white-space:nowrap">${utilBar(x)}</td><td class="stc"><span class="st ${x.status}">${STL[x.status]}</span>${x.status === 'fail' || x.status === 'warn' ? `<button class="goto" data-goto="${i}" title="Przejdź do miejsca, którego dotyczy warunek">pokaż →</button>` : ''}</td><td class="nt">${x.note ? exDetails(esc(x.note)) : ''}</td></tr>`;
  });
  html += `</tbody></table></div>`;
  el.innerHTML = html;
  const upd = () => { const n = c.filter(x => (S.meta.ticks || {})[x.key]).length; $('#tickCnt', el).innerHTML = `Odhaczono: <b>${n}</b> z ${c.length}`; };
  const setTick = (x, v) => { S.meta.ticks = S.meta.ticks || {}; if (v) S.meta.ticks[x.key] = true; else delete S.meta.ticks[x.key]; };
  $$('[data-tick]', el).forEach(cb => cb.addEventListener('change', () => {
    const x = c[+cb.dataset.tick]; setTick(x, cb.checked); cb.closest('tr').classList.toggle('done', cb.checked);
    upd(); dirty = true; updateTitle(); autosave(); rendered.report = false;
  }));
  $('#tickOk', el).onclick = () => { c.forEach(x => { if (x.status === 'ok' || x.status === 'info') setTick(x, true); }); dirty = true; updateTitle(); autosave(); rendered.report = false; renderSummary(el); };
  $('#tickClr', el).onclick = () => { S.meta.ticks = {}; dirty = true; updateTitle(); autosave(); rendered.report = false; renderSummary(el); };
  $$('[data-ref]', el).forEach(b => b.addEventListener('click', () => normPopup(c[+b.dataset.ref])));
  $$('tr[data-ci] td.val, tr[data-ci] td.bar', el).forEach(td => { td.classList.add('xclick'); td.title = 'Kliknij – jak obliczono (wzór, podstawienie, punkt normy)'; td.addEventListener('click', () => explainPopup(c[+td.closest('tr').dataset.ci])); });
  $$('[data-goto]', el).forEach(b => b.addEventListener('click', () => gotoCheck(c[+b.dataset.goto])));
  const nF = c.filter(x => x.status === 'fail').length;
  if (nF) { const bar = $('.tickbar', el); if (bar) bar.insertAdjacentHTML('beforebegin', `<div class="failnav">Niespełnione warunki: ${c.map((x, i) => x.status === 'fail' ? `<button class="goto" data-goto2="${i}">${sym(x.name)}</button>` : '').join('')}</div>`); $$('[data-goto2]', el).forEach(b => b.addEventListener('click', () => gotoCheck(c[+b.dataset.goto2]))); }
}
// okno z objaśnieniem punktu normy
const normLab = k => k === 'fire' ? 'PN-EN 1992-1-2, rozdz. 5' : k === 'acc' ? 'PN-EN 1990, 6.4.3.3' : k === '1990' ? 'PN-EN 1990, rozdz. 6.4–6.5' : k === 'Z' ? 'PN-EN 1992-1-1, 6.1 – zginanie ukośne' : (/^[A-Z]$/.test(k) ? `PN-EN 1992-1-1, załącznik ${k}` : `PN-EN 1992-1-1, pkt ${k}`);
const normBody = keys => keys.filter(k => window.BZN && window.BZN.N[k]).map(k => {
  const e = window.BZN.N[k];
  return `<div class="nsec"><div class="nlab">${esc(normLab(k))}</div><h4>${e.t}</h4><p>${e.s}</p>${e.f ? `<div class="nf">${e.f}</div>` : ''}${e.h ? `<div class="nh"><b>Podpowiedź:</b> ${e.h}</div>` : ''}</div>`;
}).join('');
function normPopup(x) {
  const keys = window.BZN ? window.BZN.find(x.ref, x.grp) : [];
  const m = $('#modal');
  let body = normBody(keys);
  if (!body) body = `<p>Brak objaśnienia dla odnośnika „${esc(x.ref)}”.</p>`;
  const cond = ckCond(x);
  const cur = `<div class="ncur"><b>W tym projekcie:</b> ${sym(x.name)}${cond ? ` – ${cond}` : ''}${x.status !== 'info' && isFinite(x.ratio) ? `, wykorzystanie ${fmt(x.ratio * 100, 0)}%` : ''} · <span class="st ${x.status}">${STL[x.status]}</span>${x.note ? `<br><small>${esc(x.note)}</small>` : ''}</div>`;
  m.innerHTML = `<div class="dlg norm"><h3>[${esc(x.ref)}]</h3>${cur}${body}<p class="ndisc">Streszczenie i podpowiedź opracowane na potrzeby programu – nie zastępują treści normy PN-EN 1992-1-1 (z Załącznikiem Krajowym).</p><div class="dbtn"><button class="btn pri" id="nClose">Zamknij</button></div></div>`;
  m.style.display = 'flex';
  $('#nClose', m).onclick = () => { m.style.display = 'none'; };
  $('#nClose', m).focus();
}

// „jak obliczono”: wynik sprawdzenia – wzory, podstawienia i wyniki z pełnego raportu (właściwy punkt i miejsce belki) oraz objaśnienie punktu normy
let repCache = { R: null, el: null };
function repDom() { if (repCache.R !== R) { const d = document.createElement('div'); try { d.innerHTML = window.BZR.build(R, S); } catch (e) { d.innerHTML = ''; } repCache = { R, el: d }; } return repCache.el; }
function explainHTML(c) {
  const id = c.id || '';
  const rx = /^(Mspan|Msupp|duct|asmin|asmax|biax|N|redist|xi)$/.test(id) ? /zginanie/i : /^(Vs1|Vb|b3|Vmax|Vsp|rho1|rho2|smax|st|Tst|T631|Tl|Thook|Tclosed|hook|l1|lp|hold|VzS|VzMax|Vrdc)$/.test(id) ? /ścinanie|skręc/i
    : /^(wk|ascr)$/.test(id) ? /zarysowanie/i : /^(ssk|sck|scqp)$/.test(id) ? /naprężenia/i : /^(f|ld|fz|w0)$/.test(id) ? /ugięci/i
    : /^(lbd|lbdT|FE|lap|inner|inner10|lapB|lapMan|Lmax|lenMan|legMan|phm|stepB|stepL)$/.test(id) ? /zakotwien|zakład/i : id === 'cnom' ? /otulina/i : /^(fb|fa|fasd|fbw)$/.test(id) ? /ogni|pożar/i : /konstrukcyjne/i;
  const loc = ((/\(([^()]*)\)\s*(?:[^()]*)$/.exec(c.name) || [])[1] || '').replace(/^z T_Ed$/, '').trim().toLowerCase();
  const d = repDom(), nodes = [...d.querySelectorAll('h2, h3, h4, .eq, p, table, .fig')];
  let i0 = nodes.findIndex(n => n.tagName === 'H2' && rx.test(n.textContent)); if (i0 < 0) return '';
  let i1 = nodes.findIndex((n, i) => i > i0 && n.tagName === 'H2'); if (i1 < 0) i1 = nodes.length;
  let a = i0 + 1, b = i1;
  if (loc) { const k = nodes.findIndex((n, i) => i > i0 && i < i1 && /^H[34]$/.test(n.tagName) && n.textContent.toLowerCase().includes(loc)); if (k > 0) { a = k; b = nodes.findIndex((n, i) => i > k && (/^H[23]$/.test(n.tagName))); if (b < 0 || b > i1) b = i1; } }
  const pick = nodes.slice(a, Math.min(b, a + 70)).filter(n => !n.closest('.fig') || n.classList.contains('fig')).filter(n => !(n.tagName === 'TABLE' && n.closest('table') !== n));
  return pick.map(n => n.classList.contains('fig') ? '' : n.outerHTML).join('');
}
// dowolny wynik (wiersz tabeli w zakładkach Przekrój, Wykresy, Zbrojenie belki, okno przekroju, kombinacje w Danych):
// właściwy rozdział raportu (wg wielkości) i miejsce belki; wiersze z daną wielkością wyróżnione
const XRX = [
  [/zestawienie stali|masa \[?kg|\bkg\b|razem stal/i, /Zbrojenie belki – widok/i],
  [/zakotw|zakład|l_?bd|l₀|lb,rqd|f_?bd|α₁|α₂|c_?d\b|odgię|haki|zagię|φ_?m|L_?max/i, /Zakotwienie i zakłady/i],
  [/c_?nom|otulin|c_?min|Δc_?dev|klasa konstrukcji/i, /Otulina/i],
  [/w_?k|rys|s_?r,?max|ε_?sm|ρ_?p,?eff/i, /zarysowanie/i],
  [/σ_?s|σ_?c|naprężen/i, /naprężenia/i],
  [/ugię|strzałk|L\/d|krzywizn|w₀/i, /ugięcia/i],
  [/φ\(|pełzan|skurcz|ε_?cs|E_?c,?eff/i, /reologiczne/i],
  [/V_?Ed|V_?Rd|ścin|strzem|A_?sw|s₁|s₂|s_?p\b|cot|θ|ρ_?w|V_?Rd,?c|T_?Ed|T_?Rd|skręc|A_?sl|s_?l,?max|s_?t,?max/i, /ścinanie/i],
  [/M_?Ed|M_?Rd|zgin|ξ|x_?eff|x_?u|A_?s1|A_?s2|ε_?s\b|ε_?c\b|ściskan|rozciągan|N_?Ed|zbrojenie (rozciągane|ściskane)|M_?z|ukośn/i, /zginanie/i],
  [/q_?Ed|q_?k|q_?qp|kombin|ψ|6\.10|R_?Ed|R_?k|reakc|H_?Ed/i, /Obciążenia i siły wewnętrzne/i],
  [/A_?s,?min|A_?s,?max|przypowierzchn|boczn|prześwit|rozstaw prętów/i, /Wymagania konstrukcyjne|zginanie/i],
  [/masa|kg|zestawien|długość|szt\./i, /Zbrojenie belki – widok/i],
  [/f_?ck|f_?cd|f_?ctm|E_?cm|f_?yd|f_?yk|E_?s|ε_?cu|ε_?c2|beton|stal/i, /Parametry materiałowe/i],
];
function explainRow(label, loc, rowText, ctx) {
  const t = label + ' ' + rowText, fx = q => (XRX.find(([a]) => a.test(q)) || [])[1];
  const rx = fx(label) || (ctx && fx(ctx)) || fx(t) || (loc ? /zginanie/i : null);
  const d = repDom(), nodes = [...d.querySelectorAll('h2, h3, h4, .eq, p, table, .fig')];
  if (!rx) return { html: '', sec: '' };
  const i0 = nodes.findIndex(n => n.tagName === 'H2' && rx.test(n.textContent)); if (i0 < 0) return { html: '', sec: '' };
  let i1 = nodes.findIndex((n, i) => i > i0 && n.tagName === 'H2'); if (i1 < 0) i1 = nodes.length;
  let a = i0 + 1, b = i1, sub = false; const lc = (loc || '').toLowerCase();
  if (lc) { const k = nodes.findIndex((n, i) => i > i0 && i < i1 && /^H[34]$/.test(n.tagName) && n.textContent.toLowerCase().includes(lc)); if (k > 0) { a = k; sub = true; b = nodes.findIndex((n, i) => i > k && /^H[23]$/.test(n.tagName)); if (b < 0 || b > i1) b = i1; } }
  const pick = nodes.slice(a, Math.min(b, a + 80)).filter(n => !n.closest('.fig') && !n.classList.contains('fig')).filter(n => !(n.tagName === 'TABLE' && n.parentElement && n.parentElement.closest('table')));
  const html = pick.map(n => n.outerHTML).join('');
  return { html, sec: nodes[i0].textContent + (sub ? ' → ' + nodes[a].textContent : '') };
}
// wyróżnienie (na zielono) wzoru, w którym obliczono klikniętą wielkość, i samej wartości:
// kandydaci – wiersze wzorów (.eq) i wiersze tabel raportu; ocena: wartości z klikniętej komórki (najważniejsze), z całego wiersza,
// symbol wielkości zdefiniowany we wzorze („M_Rd = …”) lub w nim obecny; wybierany jeden najlepszy wiersz
const XNUM = /\d+⌀\d+|⌀\d+|(?<![\d.,])\d+(?:,\d+)?(?![\d.]|,\d)/g;
const XNUMT = /\d+⌀\d+|⌀\d+|(?<![\d.,])\d{1,3}(?:[   ]\d{3})+(?:,\d+)?(?![\d.]|,\d)|(?<![\d.,])\d+(?:,\d+)?(?![\d.]|,\d)/g;   // liczby w tekście (także z odstępem tysięcy)
const xnorm = t => String(t || '').replace(/(\d)[   ](?=\d{3}(?!\d))/g, '$1').replace(/[   ]/g, ' ').replace(/−/g, '-');   // odstęp tysięcy (fmt – U+2009) usuwany, zwykła spacja rozdziela liczby
function xnums(t) {
  const q = xnorm(t).replace(/x = [\d,]+ m/g, ' ').replace(/(przęsło|przęsła|podpora|podpory|warstw[a-z]*|wzór|pkt|tab\.?|poz\.?)\s*\d+/gi, ' ');
  return [...new Set((q.match(XNUM) || []).filter(v => /⌀|,/.test(v) || v.length >= 2))].slice(0, 8);
}
// liczba z tekstu → { v, dp } albo pręty „n⌀d”; zgodność wartości z dokładnością do zaokrąglenia (np. 107,2 ↔ 107,23)
const xparse = t => { const q = t.replace(/[\s   ]/g, ''); if (q.includes('⌀')) return { bar: q }; const [i, f] = q.split(','); return { v: parseFloat(i + '.' + (f || '0')), dp: f ? f.length : 0 }; };
function xsame(a, b) {
  if (a.bar || b.bar) { if (!a.bar || !b.bar) return false; const [s1, l1] = a.bar.length <= b.bar.length ? [a.bar, b.bar] : [b.bar, a.bar]; return s1 === l1 || (s1[0] === '⌀' && l1.endsWith(s1)); }   // „⌀20” ↔ „2⌀20”
  const dp = Math.min(a.dp, b.dp); if (Math.abs(a.dp - b.dp) > 2) return false;
  if (dp === 0 && Math.max(a.v, b.v) < 10 && a.dp !== b.dp) return false;
  return Math.abs(a.v - b.v) <= 0.5 * Math.pow(10, -dp) + 1e-9;
}
function xtoks(label) {
  return [...new Set((String(label || '').match(/\p{L}[\p{L}\p{N},₀-₉′]*/gu) || []).map(t => t.replace(/,+$/, '')).filter(t => t.length >= 2 && (/[A-ZĄĆĘŁŃÓŚŹŻΑ-Ωα-ωσεξθρφ]/u.test(t) || /^[a-z]{1,2},[a-z]+$/.test(t)) && !/^(Jak|Wynik|Siła|Moment|Przekrój|TAK|NIE|OK|UWAGA|Zbrojenie|Podpora|Przęsło)$/.test(t)))].slice(0, 4);
}
const md0 = sg => sg && sg.label && R && R.md && R.md.cont ? sg.label : '';
// ocena wiersza raportu (wzór / wiersz tabeli) jako miejsca obliczenia klikniętej wielkości
function xprep(label, primTxt, secTxt) {
  const P = xnums(primTxt).map(xparse), S2 = xnums(secTxt).map(xparse).filter(q => !P.some(p => xsame(p, q) && p.dp === q.dp));
  return { P, S2, T: xtoks(label), ph: String(label || '').split(' – ')[0].replace(/\s*\(.*$/, '').trim().toLowerCase() };
}
const xnumsIn = el => (xnorm(el.textContent).match(XNUMT) || []).map(xparse);
function xscore(n, q) {
  const ns = xnorm(n.textContent).replace(/[\s_]/g, ''), nn = xnumsIn(n); let sc = 0, val = 0, def = 0;
  q.P.forEach(v => { if (nn.some(r => xsame(v, r))) { const w = v.bar || v.v >= 10 || v.dp >= 1 ? 5 : 2; sc += w; val += w; } });   // małe liczby całkowite – słabsza wskazówka
  q.S2.forEach(v => { if (nn.some(r => xsame(v, r))) sc += 2; });
  q.T.forEach(t => { const tn = t.replace(/[\s_]/g, ''), te = tn.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); if (new RegExp('(^|[^\\p{L}])' + te + '(=|≤|≥|<|>|:)', 'u').test(ns)) { sc += 3; def++; } else if (ns.includes(tn)) sc += 1; });
  if (sc > 0 && q.P.some(v => v.bar) && /przyjęto|prov/i.test(ns)) sc += 1;              // pręty – wiersz „przyjęto …”
  if (q.ph.length >= 6 && xnorm(n.textContent).toLowerCase().includes(q.ph)) sc += 1;     // nazwa wielkości (np. „zbrojenie ściskane”)
  return { sc, val, def };
}
const xcands = root => [...root.querySelectorAll('.eq, tr')].filter(n => !n.querySelector('th') && !n.closest('.fig'));
function hiliteFrag(root, label, primTxt, secTxt) {
  if (!root) return null;
  const q = xprep(label, primTxt, secTxt), { P, S2 } = q, cands = xcands(root);
  let best = null, bs = 0;
  cands.forEach(n => { const { sc } = xscore(n, q); if (sc > bs) { bs = sc; best = n; } });
  if (!best || bs < 3) return null;
  // dodatkowo – wzory, w których obliczono wartości z klikniętego wyniku („… = 107,23 kNm”), najwyżej 2
  const sel = [best];
  if (P.length <= 2) P.forEach(v => { if (sel.length >= 3 || v.bar || (v.v < 10 && v.dp < 2)) return;   // tylko dla wartości z jednej klikniętej komórki
    const f = cands.find(n => !sel.includes(n) && (xnorm(n.textContent).match(/=\s*-?[\d ]+(?:,\d+)?/g) || []).some(z => { const r = xparse(z.replace(/^=\s*-?/, '')); return r.dp >= v.dp && xsame(v, r); }));
    if (f) sel.push(f); });
  sel.forEach(el => { el.classList.add('xhit'); const nn = xnumsIn(el), pm = P.filter(v => nn.some(r => xsame(v, r))); markVals(el, pm.length ? pm : S2); });   // znacznik – wartość z klikniętej komórki (gdy jej brak w wierszu – pozostałe z wiersza)
  const first = cands.find(n => sel.includes(n));
  setTimeout(() => first.scrollIntoView({ block: 'center' }), 30);
  return best;
}
// gdy w przypisanym rozdziale nie ma wzoru z klikniętą wartością – szukanie w całym raporcie (rozdział i podrozdział znalezionego wiersza)
function xlocate(label, primTxt, secTxt) {
  const q = xprep(label, primTxt, secTxt); if (!q.P.length && !q.T.length) return null;
  const d = repDom(), cs = xcands(d).map(n => ({ n, r: xscore(n, q) }));
  // najpierw wiersz z klikniętą wartością, a gdy jej nie ma w raporcie (np. inna postać – ‰ zamiast mm²/m) – wiersz z definicją symbolu
  let pick0 = cs.filter(c => c.r.val >= 5).sort((a, b) => b.r.sc - a.r.sc)[0] || cs.filter(c => c.r.def && c.r.sc >= 3).sort((a, b) => b.r.sc - a.r.sc)[0];
  const best = pick0 && pick0.n; if (!best) return null;
  const nodes = [...d.querySelectorAll('h2, h3, h4, .eq, p, table, .fig')], k = nodes.findIndex(n => n === best || n.contains(best)); if (k < 0) return null;
  let i0 = k; while (i0 > 0 && nodes[i0].tagName !== 'H2') i0--;
  let a = k; while (a > i0 && !/^H[34]$/.test(nodes[a].tagName)) a--;
  let b = nodes.findIndex((n, i) => i > a && (n.tagName === 'H2' || (a > i0 && /^H[34]$/.test(n.tagName)))); if (b < 0) b = nodes.length;
  if (a === i0) a = i0 + 1;
  if (b - a > 80) { a = Math.max(a, k - 30); b = Math.min(b, k + 30); }
  const pick = nodes.slice(a, b).filter(n => !n.closest('.fig') && !n.classList.contains('fig')).filter(n => !(n.tagName === 'TABLE' && n.parentElement && n.parentElement.closest('table')));
  return { html: pick.map(n => n.outerHTML).join(''), sec: nodes[i0].textContent + (a > i0 + 1 || /^H[34]$/.test(nodes[a].tagName) ? ' → ' + nodes[a].textContent : '') };
}
// wartości w wyróżnionym wierszu – znacznik <mark>
function markVals(el, tgt) {
  const walk = document.createTreeWalker(el, NodeFilter.SHOW_TEXT), tn = [];
  while (walk.nextNode()) tn.push(walk.currentNode);
  tn.forEach(t => {
    const src = t.nodeValue; let last = 0, m, hit = false; const frag = document.createDocumentFragment(); XNUMT.lastIndex = 0;
    while ((m = XNUMT.exec(src))) {
      if (!tgt.some(v => xsame(v, xparse(m[0])))) continue;
      hit = true; frag.appendChild(document.createTextNode(src.slice(last, m.index)));
      const mk = document.createElement('mark'); mk.className = 'xval'; mk.textContent = m[0]; frag.appendChild(mk); last = m.index + m[0].length;
    }
    if (!hit) return; frag.appendChild(document.createTextNode(src.slice(last))); t.parentNode.replaceChild(frag, t);
  });
}
function explainRowPopup(label, loc, rowText, ctx, valTxt, fullRow) {
  const r = explainRow(label, loc, rowText, ctx), m = $('#modal'), back = m.style.display === 'flex' ? m.innerHTML : null;
  m.innerHTML = `<div class="dlg norm expl"><h3>Jak obliczono: ${esc(label.slice(0, 90))}${loc ? ` <small>(${esc(loc)})</small>` : ''}</h3>
    <div class="ncur"><b>Wynik:</b> ${esc(rowText.replace(/\s+/g, ' ').trim().slice(0, 240))}</div>
    ${r.html ? `<h4 class="lsec">Wzory, podstawienia i wyniki – raport: ${esc(r.sec)}</h4><div class="rexp">${r.html}</div>` : `<p class="hint keep">Dla tej wielkości raport nie zawiera osobnego wyprowadzenia – to dana wejściowa albo wynik pomocniczy; pełny tok obliczeń – zakładka Raport obliczeń.</p>`}
    <p class="ndisc">Wzór, w którym obliczono klikniętą wielkość, i jej wartość – wyróżnione na zielono. Odnośniki do punktów normy w tekście można kliknąć.</p><div class="dbtn">${back ? '<button class="btn" id="nBack">← Wróć</button><span class="sp"></span>' : ''}<button class="btn pri" id="nClose">Zamknij</button></div></div>`;
  m.style.display = 'flex'; $('#nClose', m).onclick = () => { m.style.display = 'none'; };
  const bk = $('#nBack', m); if (bk) bk.onclick = () => { m.style.display = 'none'; };
  const pv = valTxt !== undefined && valTxt !== '' ? valTxt : rowText, sv = rowText + ' ' + (fullRow || '');
  if (!hiliteFrag($('.rexp', m), label, pv, sv)) {
    const g = xlocate(label, pv, sv);
    if (g) {
      const box = $('.rexp', m), hint = $('p.hint', m);
      if (box) { box.innerHTML = g.html; $('h4.lsec', m).textContent = 'Wzory, podstawienia i wyniki – raport: ' + g.sec; }
      else if (hint) hint.outerHTML = `<h4 class="lsec">Wzory, podstawienia i wyniki – raport: ${esc(g.sec)}</h4><div class="rexp">${g.html}</div>`;
      hiliteFrag($('.rexp', m), label, pv, sv);
    } else if ($('.rexp', m)) $('.rexp', m).insertAdjacentHTML('beforebegin', '<p class="hint keep">Ta wartość nie występuje w raporcie w postaci wzoru – poniżej rozdział, z którego wynika.</p>');
  }
}
document.addEventListener('click', e => {
  if (!R || R.bare === undefined && !R.secs) return;
  const tr = e.target.closest && e.target.closest('.xres tr'); if (!tr || tr.classList.contains('xclick')) return;
  if (e.target.closest('input, select, button, a, .nref, .nlink, textarea, [data-dsug], .zhit, svg')) return;
  if (tr.querySelector('input, select, textarea') || !tr.querySelector('td')) return;
  if (tr.closest('#p-sum') || tr.closest('.dlg.expl')) return;
  const box = tr.closest('[data-sk]'), sec = box && (R.secs || []).find(q => q.key === box.dataset.sk);
  const cells = [...tr.cells].map(c => c.textContent.trim()), row = cells.join(' ').replace(/\s+/g, ' ').trim();
  const head = tr.closest('table') && tr.closest('table').querySelector('tr th') ? [...tr.closest('table').querySelectorAll('tr:first-child th')].map(th => th.textContent.trim()) : [];
  const ci = Math.max(0, [...tr.cells].indexOf(e.target.closest('td')));
  const label = ci > 0 && head[ci] ? `${head[ci]} – ${cells[0]}` : (cells[0] || row);
  const bx2 = tr.closest('.box, .dlg'), lm = /(przęsło \d+|podpora [A-Z]\w*|wspornik \w+)/i.exec(row + ' ' + (box ? box.textContent.slice(0, 80) : '') + ' ' + (bx2 ? bx2.textContent.slice(0, 160) : '')), loc = sec ? sec.loc : lm ? lm[1].toLowerCase() : '';
  // kontekst: nagłówek tabeli (rozdział) – np. „Długości zakotwienia”, „Zestawienie stali”, „Strzemiona – wymagane”
  const tb = tr.closest('table'), wrap = tb && (tb.closest('.tscroll') || tb), prev = wrap && wrap.previousElementSibling, ctx = [prev && (/^H\d$/.test(prev.tagName) || prev.matches('.h2, .h3, .lsec, .sub')) && !prev.querySelector('svg') && prev.textContent.length < 160 ? prev.textContent : '', tb && tb.caption ? tb.caption.textContent : ''].join(' ').slice(0, 200);
  explainRowPopup(label, loc, head.length && ci > 0 ? `${head[ci]}: ${cells[ci]} (${cells[0]})` : row, ctx, ci > 0 && xnums(cells[ci]).length ? cells[ci] : cells.slice(1).join(' ') || row, cells.join(' '));
});
function explainPopup(c) {
  if (!c) return;
  const m = $('#modal'), cond = ckCond(c), calc = explainHTML(c);
  const keys = window.BZN ? window.BZN.find(c.ref, c.grp) : [], nb = normBody(keys);
  m.innerHTML = `<div class="dlg norm expl"><h3>Jak obliczono: ${sym(c.name)}</h3>
    <div class="ncur"><b>Wynik:</b> ${cond || '—'}${c.status !== 'info' && isFinite(c.ratio) ? ` · wykorzystanie <b>${fmt(c.ratio * 100, 0)}%</b>` : ''} · <span class="st ${c.status}">${STL[c.status]}</span>${c.note ? `<br><small>${esc(c.note)}</small>` : ''}</div>
    ${calc ? `<h4 class="lsec">Wzory, podstawienia i wyniki (z raportu obliczeń)</h4><div class="rexp">${calc}</div>` : ''}
    <h4 class="lsec">Punkt normy [${esc(c.ref)}]</h4>${nb || `<p>Brak objaśnienia dla odnośnika „${esc(c.ref)}”.</p>`}
    <p class="ndisc">Objaśnienia opracowane na potrzeby programu – nie zastępują treści normy.</p><div class="dbtn"><button class="btn pri" id="nClose">Zamknij</button></div></div>`;
  m.style.display = 'flex'; $('#nClose', m).onclick = () => { m.style.display = 'none'; }; $('#nClose', m).focus();
  { const tmp = document.createElement('div'); tmp.innerHTML = cond || ''; const lb = c.name.replace(/\s*\(.*$/, ''), pv = xnums(tmp.textContent).length ? tmp.textContent : c.name, sv = c.name + ' ' + (c.note || '');
    if (!hiliteFrag($('.rexp', m), lb, pv, sv)) { const g = xlocate(lb, pv, sv), box = $('.rexp', m);
      if (g && box) { box.innerHTML = g.html; const h4 = box.previousElementSibling; if (h4 && h4.matches('h4.lsec')) h4.textContent = 'Wzory, podstawienia i wyniki – raport: ' + g.sec; hiliteFrag(box, lb, pv, sv); }
      else if (g && !box) { const h = $('h4.lsec', m); if (h) h.insertAdjacentHTML('beforebegin', `<h4 class="lsec">Wzory, podstawienia i wyniki – raport: ${esc(g.sec)}</h4><div class="rexp">${g.html}</div>`); hiliteFrag($('.rexp', m), lb, pv, sv); } } }
}
// okno objaśnienia odnośnika klikniętego w tekście – osobna warstwa nad oknami dialogowymi
function normRefPopup(ref, keys) {
  let m = $('#nmodal');
  if (!m) { m = document.createElement('div'); m.id = 'nmodal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true'); document.body.appendChild(m); }
  const body = normBody(keys) || `<p>Brak objaśnienia dla odnośnika „${esc(ref)}”.</p>`;
  m.innerHTML = `<div class="dlg norm"><h3>[${esc(ref)}]</h3>${body}<p class="ndisc">Streszczenie i podpowiedź opracowane na potrzeby programu – nie zastępują treści normy (PN-EN 1992-1-1 z Załącznikiem Krajowym, PN-EN 1992-1-2, PN-EN 1990).</p><div class="dbtn"><button class="btn pri" id="nmClose">Zamknij</button></div></div>`;
  m.style.display = 'flex';
  const close = () => { m.style.display = 'none'; window.removeEventListener('keydown', kd, true); };
  const kd = e => { if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); close(); } };
  window.addEventListener('keydown', kd, true);
  m.onmousedown = e => { if (e.target === m) close(); };
  $('#nmClose', m).onclick = close;
  $('#nmClose', m).focus();
}
// numery punktów, tablic, rysunków i wzorów normy w tekście → przyciski z objaśnieniem
const NREF_RX = /(PN-EN\s*1990|PN-EN\s*1992-1-2|EN\s*1992-1-2)?([,\s]*)(?:([Tt]abl?\.|[Rr]ys\.|[Ww]zór|[Ww]zory|[Ww]zoru|[Ww]z\.|[Zz]ał\.)\s*)?(\()?(?<![\p{L}\d.,])(\d{1,2}\.\d{1,2}(?:\.\d{1,2}){0,3}[a-zA-Z]{0,3}|[A-E]\.\d{1,2}[A-Z]?|[A-J](?![\p{L}\d]))(\(\d{1,2}\))?(\))?(?!\d|,\d)/gu;
const NL_SKIP = 'svg,button,select,option,textarea,input,script,style,.nlink,.dlg.norm,#top,.tabs,.nf,[contenteditable]';
function linkRefs(root) {
  const B = window.BZN; if (!root || !B || !B.resolve) return 0;
  const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => /\d\.\d|ał\.\s*[A-J]/.test(n.nodeValue) && n.parentElement && !n.parentElement.closest(NL_SKIP) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT });
  const list = []; let n; while ((n = tw.nextNode())) list.push(n);
  let cnt = 0;
  list.forEach(tn => {
    const t = tn.nodeValue; let last = 0, made = false; const frag = document.createDocumentFragment();
    NREF_RX.lastIndex = 0; let m, prevEnd = 0;
    while ((m = NREF_RX.exec(t))) {
      const [all, g1, g2, pre, po, tok, tail, pc] = m;
      const pe = prevEnd; prevEnd = m.index + all.length;
      if (!all.length) { NREF_RX.lastIndex++; continue; }
      if (!tok) continue;
      const preL = (pre || '').toLowerCase();
      let kind = /^tab/.test(preL) ? 'tab' : /^rys/.test(preL) ? 'rys' : /^wz/.test(preL) ? 'eq' : /^zał/.test(preL) ? 'zal' : '';
      if (/^[A-J]$/.test(tok) && kind !== 'zal') continue;
      if (!pre && !po && !/\S/.test(t.slice(0, m.index + (g1 || '').length + (g2 || '').length)) && /^\.\s/.test(t.slice(m.index + all.length))) continue;   // numeracja nagłówka „5.4. Podpora C”
      if (!kind) { const parts = tok.replace(/[a-zA-Z]+$/, '').split('.').length; kind = parts === 2 && !tail && (po && pc || /[a-zA-Z]$/.test(tok)) ? 'eq' : 'cl'; }
      const ctx = (g1 || '') + ' ' + t.slice(Math.max(pe, m.index - 40), m.index);
      const keys = B.resolve(kind, tok, ctx);
      if (!keys.length) continue;
      const both = !!(po && pc);
      let s0 = m.index + (g1 || '').length + (g2 || '').length, s1 = m.index + all.length;
      if (po && !both) { if (!pre) s0 += 1; }
      if (pc && !both) s1 -= 1;
      const lt = t.slice(s0, s1);
      if (s0 > last) frag.appendChild(document.createTextNode(t.slice(last, s0)));
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'nlink'; b.dataset.nk = keys.join(','); b.dataset.nref = lt.replace(/^\(|\)$/g, '').trim();
      b.title = keys.map(normLab).join('; ') + ' – kliknij, aby zobaczyć objaśnienie';
      b.textContent = t.slice(s0, s1);
      frag.appendChild(b); last = s1; made = true; cnt++;
    }
    if (!made) return;
    if (last < t.length) frag.appendChild(document.createTextNode(t.slice(last)));
    tn.parentNode.replaceChild(frag, tn);
  });
  return cnt;
}
U.linkRefs = linkRefs;
// objaśnienia tekstowe (.hint) – zwinięte pod klikalnym „Objaśnienie”; widoczne pozostają komunikaty (.keep), elementy aktualizowane
// w miejscu (z id) i raport; stan rozwinięcia pamiętany (także po odświeżeniu treści)
const HX_OPEN = new Set();
function hxOne(el) {
  if (el.id || el.classList.contains('keep') || el.closest('.rexp, #p-report, svg')) return;
  const kids = [...el.childNodes].filter(n => !(n.nodeType === 3 && !n.textContent.trim()));
  if (!kids.length || (kids.length === 1 && kids[0].nodeName === 'DETAILS' && kids[0].classList.contains('hx'))) return;
  const key = el.dataset.hint || el.dataset.xt || (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 50);
  const inner = kids.find(n => n.nodeName === 'DETAILS' && n.classList.contains('exh'));
  const sm0 = inner && inner.querySelector('summary');
  const d = document.createElement('details'), sm = document.createElement('summary'), body = document.createElement('div');
  d.className = 'exh hx'; sm.textContent = el.dataset.xt || (sm0 ? sm0.textContent : '') || 'Objaśnienie';
  kids.forEach(n => { if (n === inner) { const b2 = inner.querySelector(':scope > div'); [...(b2 || inner).childNodes].forEach(c => { if (c !== sm0) body.appendChild(c); }); } else body.appendChild(n); });
  el.textContent = ''; d.appendChild(sm); d.appendChild(body); el.appendChild(d);
  if (HX_OPEN.has(key) || (inner && inner.open)) d.open = true;
  d.addEventListener('toggle', () => { if (d.open) HX_OPEN.add(key); else HX_OPEN.delete(key); });
}
function hxWrap(root) {
  if (!root || root.nodeType !== 1) return;
  if (root.matches('div.hint, p.hint')) hxOne(root);
  root.querySelectorAll('div.hint, p.hint').forEach(hxOne);
}
U.hxWrap = hxWrap;
let nlT = 0;
function nlRun() { ['#out', '#modal', '#pop'].forEach(sel => { const el = $(sel); if (el) linkRefs(el); }); nlObs.takeRecords(); }
const nlObs = new MutationObserver(recs => {
  recs.forEach(r => { if (!r.addedNodes.length || r.target.nodeType !== 1) return; const h = r.target.closest && r.target.closest('div.hint, p.hint'); if (h) hxOne(h); else r.addedNodes.forEach(hxWrap); });
  if (!recs.some(r => r.addedNodes.length && r.target.nodeType === 1 && !r.target.closest('svg'))) return;
  clearTimeout(nlT); nlT = setTimeout(nlRun, 120);
});
document.addEventListener('click', e => {
  const ds = e.target && e.target.closest && e.target.closest('[data-dsug]');
  if (ds) { e.preventDefault(); const [sg, b, h] = ds.dataset.dsug.split('|').map(Number); applyDimSug(sg, b, h); return; }
  const b = e.target && e.target.closest && e.target.closest('.nlink'); if (!b) return;
  e.preventDefault(); e.stopPropagation();
  normRefPopup(b.dataset.nref, (b.dataset.nk || '').split(',').filter(Boolean));
}, true);

/* --------------------------------------------------------------- SVG */
const svgOpen = (w, h, extra) => `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" ${extra || ''}>`;
const tx = (x, y, s, o) => { o = o || {}; return `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" font-size="${o.fs || 11}" fill="${o.c || '#1b2230'}" text-anchor="${o.a || 'middle'}" ${o.w ? `font-weight="${o.w}"` : ''} ${o.rot ? `transform="rotate(${o.rot} ${x.toFixed(1)} ${y.toFixed(1)})"` : ''}>${s}</text>`; };
function dimH(x1, x2, y, label, o) { o = o || {};
  return `<g stroke="#5d6778" stroke-width="0.8"><line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}"/><line x1="${x1}" y1="${y - 4}" x2="${x1}" y2="${y + 4}"/><line x1="${x2}" y1="${y - 4}" x2="${x2}" y2="${y + 4}"/>` +
    `<line x1="${x1 - 3}" y1="${y + 3}" x2="${x1 + 3}" y2="${y - 3}"/><line x1="${x2 - 3}" y1="${y + 3}" x2="${x2 + 3}" y2="${y - 3}"/></g>` + tx((x1 + x2) / 2, y + (o.below ? 13 : -4), label, { fs: o.fs || 10.5, c: '#3d4656' }); }
function dimV(x, y1, y2, label, o) { o = o || {};
  return `<g stroke="#5d6778" stroke-width="0.8"><line x1="${x}" y1="${y1}" x2="${x}" y2="${y2}"/><line x1="${x - 4}" y1="${y1}" x2="${x + 4}" y2="${y1}"/><line x1="${x - 4}" y1="${y2}" x2="${x + 4}" y2="${y2}"/>` +
    `<line x1="${x - 3}" y1="${y1 + 3}" x2="${x + 3}" y2="${y1 - 3}"/><line x1="${x - 3}" y1="${y2 + 3}" x2="${x + 3}" y2="${y2 - 3}"/></g>` + tx(x + (o.right ? 6 : -5), (y1 + y2) / 2, label, { fs: o.fs || 10.5, c: '#3d4656', a: o.right ? 'start' : 'middle', rot: o.right ? 0 : -90 }); }

let secSeq = 0; const SECREG = {};
function sectionSVG(sec, opts) {
  opts = opts || {};
  const kind = sec.kind, uid = kind + sec.key;
  const g = sec.g || R.g, h = g.h, B = g.beff;
  const W = opts.W || 330, H = opts.H || 380, m = 46;
  // rzędy prętów do wymiarowania prześwitów (łańcuchy wymiarowe poza przekrojem: dolne – pod, górne – nad, odstępy warstw – z lewej)
  const GAPS = opts.gaps !== false && W >= 280, wOfB = b => (b.nb > 1 ? (b.shape === 'h' ? b.nb * b.dBar : b.shape === 't' ? 2 * b.dBar : b.dBar) : (b.dBar || b.d));
  let gRows = [];
  if (GAPS) { const mp = new Map(); sec.bars.filter(b => b.side === 'bot' || b.side === 'top').forEach(b => { const k = b.side + ':' + Math.round(b.y); if (!mp.has(k)) mp.set(k, []); mp.get(k).push(b); }); gRows = [...mp.values()].map(rw => rw.sort((a, b) => a.x - b.x)); }
  const chOf = sd => gRows.filter(rw => rw[0].side === sd && rw.length > 1).sort((a, b) => (sd === 'bot' ? b[0].y - a[0].y : a[0].y - b[0].y));
  const chB = chOf('bot'), chT = chOf('top'), hasV = ['bot', 'top'].some(sd => gRows.filter(rw => rw[0].side === sd).length > 1), DS = 14;
  const mt = m + chT.length * DS, mb = m + chB.length * DS, ml = m + (hasV ? 22 : 0);
  const sc = Math.min((W - ml - m) / B, (H - mt - mb) / h);
  const ox = ml + (W - ml - m - B * sc) / 2, oy = mt + (H - mt - mb - h * sc) / 2;
  const X = x => ox + x * sc, Y = y => oy + y * sc;
  const xw0 = (B - g.bw) / 2, xw1 = xw0 + g.bw;
  let p;
  if (g.T) p = [[0, 0], [B, 0], [B, g.hf], [xw1, g.hf], [xw1, h], [xw0, h], [xw0, g.hf], [0, g.hf]];
  else p = [[0, 0], [B, 0], [B, h], [0, h]];
  let s = svgOpen(W, H);
  s += `<defs><pattern id="hc${uid}" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#cfd3d9" stroke-width="1"/></pattern></defs>`;
  s += `<polygon points="${p.map(q => X(q[0]).toFixed(1) + ',' + Y(q[1]).toFixed(1)).join(' ')}" fill="#eceef1" stroke="#39414f" stroke-width="1.4"/>`;
  // strefa ściskana (SGN)
  const st0 = sec.r;
  if (st0 && isFinite(st0.x) && opts.na !== false) {
    const x = Math.min(st0.x, h);
    const y0 = kind === 'span' ? 0 : h - x, y1 = kind === 'span' ? x : h;
    s += `<clipPath id="cp${uid}"><polygon points="${p.map(q => X(q[0]).toFixed(1) + ',' + Y(q[1]).toFixed(1)).join(' ')}"/></clipPath>`;
    s += `<rect x="${X(0)}" y="${Y(y0)}" width="${B * sc}" height="${(y1 - y0) * sc}" fill="url(#hc${uid})" clip-path="url(#cp${uid})"/>`;
    const yna = kind === 'span' ? x : h - x;
    s += `<line x1="${X(0) - 8}" y1="${Y(yna)}" x2="${X(B) + 8}" y2="${Y(yna)}" stroke="#c0262d" stroke-width="1" stroke-dasharray="5 3"/>`;
    s += tx(X(B) + 10, Y(yna) + 3.5, `x=${fmt(st0.x, 0)}`, { fs: 9.5, c: '#c0262d', a: 'start' });
  }
  // strzemiona (rodzaj, liczba ramion, promień gięcia) i otulina krawędzi
  const cov = R.cov, cs = cov.cs, cb = cov.cb, ct = cov.ct;
  const hold = opts.hold || holdOfSec(sec);
  s += stirDraw(opts.stir || stirOfSec(sec), g, cov, X, Y, sc, hold && hold.xs, sec.bars);
  // pręty
  sec.bars.forEach(b => {
    const col = opts.hl && !opts.hl(b) ? '#b4bac4' : b.side === 'bot' ? '#1d2a3f' : b.side === 'mid' ? '#5d7a2e' : b.tag === 'z' && opts.hl ? '#6a3fb5' : '#3b5b8f';
    if (b.cut && b.nb <= 1) { s += `<circle cx="${X(b.x)}" cy="${Y(b.y)}" r="${Math.max(2, (b.dBar || b.d) / 2 * sc) - 0.6}" fill="#ffffff" stroke="${col}" stroke-width="1.3"/>`; return; }
    if (b.nb > 1) {   // wiązka – pręty składowe (dy dodatnie – w stronę lica)
      const rr = b.dBar / 2, k = b.nb;
      const off = b.shape === 'h' ? Array.from({ length: k }, (_, i) => [(2 * i - (k - 1)) * rr, 0])
        : b.shape === 't' ? [[-rr, rr * 0.58], [rr, rr * 0.58], [0, -rr * 1.15]]
        : Array.from({ length: k }, (_, i) => [0, (2 * i - (k - 1)) * rr]);
      off.forEach(([dx, dy]) => { s += `<circle cx="${X(b.x + dx)}" cy="${Y(b.y + (b.side === 'bot' ? dy : -dy))}" r="${Math.max(1.6, rr * sc)}" fill="${col}"/>`; });
    } else s += `<circle cx="${X(b.x)}" cy="${Y(b.y)}" r="${Math.max(2, (b.dBar || b.d) / 2 * sc)}" fill="${col}"/>`;
  });
  // prześwity w świetle między prętami – łańcuchy wymiarowe poza przekrojem (rzędy dolne pod przekrojem, górne nad nim; najbliżej – rząd
  // skrajny) z liniami pomocniczymi od krawędzi prętów; odstępy pionowe warstw – z lewej strony przekroju. Wymagane wg 8.2(2):
  // max(⌀; d_g + 5; 20 mm), pręty w styku – ⌀_n = ⌀·√2; za małe – na czerwono
  if (GAPS) {
    const dg = S.mat.dg || 16, wOf = wOfB;
    const touchY = new Set(); gRows.forEach(rw => gRows.forEach(r2 => { if (r2 === rw || r2[0].side !== rw[0].side) return; const dy = Math.abs(r2[0].y - rw[0].y), dd = (wOf(rw[0]) + wOf(r2[0])) / 2; if (dy <= dd + 0.5) touchY.add(rw); }));
    const tick = (x, y, c) => `<line x1="${(x - 2.2).toFixed(1)}" y1="${(y + 2.2).toFixed(1)}" x2="${(x + 2.2).toFixed(1)}" y2="${(y - 2.2).toFixed(1)}" stroke="${c}" stroke-width="0.9"/>`;
    [['bot', chB], ['top', chT]].forEach(([sd, list]) => list.forEach((rw, k) => {
      const isBot = sd === 'bot', yc = isBot ? Y(h) + 12 + k * DS : Y(0) - 10 - k * DS, ry = Math.max(...rw.map(wOf)) / 2;
      const yb = isBot ? Y(rw[0].y + ry) : Y(rw[0].y - ry);           // krawędź prętów od strony łańcucha
      let alt = 0;
      for (let i = 0; i < rw.length - 1; i++) {
        const a = rw[i], b = rw[i + 1], gap = (b.x - wOf(b) / 2) - (a.x + wOf(a) / 2), dmx = Math.max(a.d, b.d), smin = touchY.has(rw) ? Math.max(1.5 * dmx, dg + 5, 30) : Math.max(dmx, dg + 5, 20);
        const x1 = X(a.x + wOf(a) / 2), x2 = X(b.x - wOf(b) / 2), lab = fmt(gap, 0), bad = gap < smin - 0.5, c = bad ? '#c0262d' : '#6b7584';
        const lw = lab.length * 4.3 + 2, narrow = x2 - x1 < lw;
        const yl = narrow ? (alt++ % 2 ? yc + 8.5 : yc - 2.5) : yc - 2.5;
        s += `<g class="gapdim"><title>Prześwit ${fmt(gap, 0)} mm ${bad ? '<' : '≥'} wymagany ${fmt(smin, 0)} mm (${touchY.has(rw) ? 'pręty w styku z warstwą sąsiednią – max(1,5⌀; d_g + 5; 30 mm)' : '8.2(2) – max(⌀; d_g + 5; 20 mm)'})</title>`
          + `<path d="M${x1.toFixed(1)},${yb.toFixed(1)} V${(yc + (isBot ? 2 : -2)).toFixed(1)} M${x2.toFixed(1)},${yb.toFixed(1)} V${(yc + (isBot ? 2 : -2)).toFixed(1)}" stroke="#aab2bf" stroke-width="0.45" stroke-dasharray="1.5 1.5" fill="none"/>`
          + `<line x1="${x1.toFixed(1)}" y1="${yc.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${yc.toFixed(1)}" stroke="${c}" stroke-width="0.7"/>` + tick(x1, yc, c) + tick(x2, yc, c)
          + tx((x1 + x2) / 2, yl, lab, { fs: 7.5, c: bad ? '#c0262d' : '#4f5868', w: bad ? 700 : 500 }) + '</g>';
      }
    }));
    // odstęp pionowy w świetle między warstwami – z lewej strony przekroju
    ['bot', 'top'].forEach(sd => {
      const rs = gRows.filter(rw => rw[0].side === sd).sort((a, b) => (sd === 'bot' ? b[0].y - a[0].y : a[0].y - b[0].y));
      for (let i = 0; i < rs.length - 1; i++) {
        const A = rs[i], Bq = rs[i + 1], ra = Math.max(...A.map(wOf)) / 2, rb = Math.max(...Bq.map(wOf)) / 2, gapV = Math.abs(A[0].y - Bq[0].y) - ra - rb;
        const xl = X(0) - 9, y1 = Y(sd === 'bot' ? A[0].y - ra : A[0].y + ra), y2 = Y(sd === 'bot' ? Bq[0].y + rb : Bq[0].y - rb), xs = X(Math.min(A[0].x, Bq[0].x) - Math.max(ra, rb));
        const svMin = gapV < 0.5 ? 0 : Math.max(Math.max(...A.map(b => b.d), ...Bq.map(b => b.d)), dg + 5, 20), bad = gapV > 0.5 && gapV < svMin - 0.5, c = bad ? '#c0262d' : '#6b7584';
        s += `<g class="gapdim"><title>${gapV < 0.5 ? 'Warstwy w styku (pręty jeden na drugim)' : `Odstęp pionowy w świetle ${fmt(gapV, 0)} mm ${bad ? '<' : '≥'} ${fmt(svMin, 0)} mm (8.2(2))`}</title>`
          + `<path d="M${xs.toFixed(1)},${y1.toFixed(1)} H${(xl - 2).toFixed(1)} M${xs.toFixed(1)},${y2.toFixed(1)} H${(xl - 2).toFixed(1)}" stroke="#aab2bf" stroke-width="0.45" stroke-dasharray="1.5 1.5" fill="none"/>`
          + `<line x1="${xl.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${xl.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${c}" stroke-width="0.7"/>` + tick(xl, y1, c) + tick(xl, y2, c)
          + tx(xl - 3, (y1 + y2) / 2 + 3, gapV < 0.5 ? '0' : fmt(gapV, 0), { fs: 7.5, a: 'end', c: bad ? '#c0262d' : '#4f5868', w: bad ? 700 : 500 }) + '</g>';
      }
    });
  }
  // wymiary (klikalne – okno wymiarów przekroju)
  const gi = opts.edit && R && R.md ? segOfSec(sec).idx : null;
  const gh = (inner, x, y, w, hh) => gi === null ? inner : `<g class="geohit" data-geo="${gi}"><rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${w.toFixed(1)}" height="${hh.toFixed(1)}" fill="transparent"><title>Wymiary przekroju – kliknij, aby zmienić</title></rect>${inner}</g>`;
  const yB = Y(0) - 16 - chT.length * DS, yBot = Y(h) + chB.length * DS;
  s += gh(dimH(X(0), X(B), yB, g.T ? `b<tspan font-size="8" dy="2">eff</tspan><tspan dy="-2"> = ${fmt(B, 0)}</tspan>` : `b = ${fmt(B, 0)}`), X(B / 2) - 40, yB - 16, 80, 22);
  if (g.T) s += gh(dimH(X(xw0), X(xw1), yBot + 18, `b<tspan font-size="8" dy="2">w</tspan><tspan dy="-2"> = ${fmt(g.bw, 0)}</tspan>`, { below: true }), X(xw0), yBot + 10, X(xw1) - X(xw0), 22);
  const xH = X(0) - 18 - (hasV ? 22 : 0);
  s += gh(dimV(xH, Y(0), Y(h), `h = ${fmt(h, 0)}`), xH - 16, Y(h / 2) - 40, 22, 80);
  if (g.T) s += dimV(X(B) + 14, Y(0), Y(g.hf), `${fmt(g.hf, 0)}`, { right: true, fs: 9.5 });
  const dd = sec.d;
  if (dd) {
    const xd = g.T ? X(xw1) + 16 : X(B) + 16;
    if (kind === 'span') s += dimV(xd, Y(0), Y(dd), `d=${fmt(dd, 0)}`, { right: true, fs: 9.5 });
    else s += dimV(xd, Y(h - dd), Y(h), `d=${fmt(dd, 0)}`, { right: true, fs: 9.5 });
  }
  // otulina (do strzemion): dół / góra / boki
  s += `<g stroke="#1d5bb8" stroke-width="1"><line x1="${X(xw0)}" y1="${Y(h) + 6}" x2="${X(xw0 + cs)}" y2="${Y(h) + 6}"/><line x1="${X(xw1) + 4}" y1="${Y(h)}" x2="${X(xw1) + 4}" y2="${Y(h - cb)}"/><line x1="${X(B) + 4}" y1="${Y(0)}" x2="${X(B) + 4}" y2="${Y(ct)}"/></g>`;
  const cTxt = cov.faces ? `c<tspan font-size="7.5" dy="2">b</tspan><tspan dy="-2"> = ${cb} · c</tspan><tspan font-size="7.5" dy="2">t</tspan><tspan dy="-2"> = ${ct} · c</tspan><tspan font-size="7.5" dy="2">s</tspan><tspan dy="-2"> = ${cs} mm</tspan>` : `c<tspan font-size="7.5" dy="2">nom</tspan><tspan dy="-2"> = ${cs} mm</tspan>`;
  const cy = yBot + (g.T ? 32 : 19);
  s += `<g class="${opts.edit ? 'covhit' : ''}" ${opts.edit ? 'data-z="cov"' : ''}>${opts.edit ? `<rect x="${(X(B / 2) - 80).toFixed(1)}" y="${cy - 11}" width="160" height="15" fill="transparent"><title>Otulina – kliknij, aby zmienić</title></rect>` : ''}${tx(X(B / 2), cy, cTxt, { fs: 9.5, c: '#1d5bb8' })}</g>`;
  // strefy kliknięcia (edycja zbrojenia): góra, dół, boki, wnętrze
  if (opts.edit) {
    const tb = 0.27 * h, sw = 0.2 * g.bw;
    const hit = (x0, y0, x1, y1, z, t) => `<rect class="zhit" data-z="${z}" x="${x0.toFixed(1)}" y="${y0.toFixed(1)}" width="${(x1 - x0).toFixed(1)}" height="${(y1 - y0).toFixed(1)}" fill="transparent" stroke="transparent" rx="3"><title>${t} – kliknij, aby edytować</title></rect>`;
    s += hit(X(0) - 10, Y(0) - 10, X(B) + 10, Y(tb), opts.edit.top, 'Zbrojenie górne');
    s += hit(X(xw0) - 10, Y(h - tb), X(xw1) + 10, Y(h) + 10, opts.edit.bot, 'Zbrojenie dolne');
    s += hit(X(xw0) - 10, Y(tb), X(xw0 + sw), Y(h - tb), 'mid', 'Pręty boczne');
    s += hit(X(xw1 - sw), Y(tb), X(xw1) + 10, Y(h - tb), 'mid', 'Pręty boczne');
    s += hit(X(xw0 + sw), Y(tb), X(xw1 - sw), Y(h - tb), 'stir', 'Strzemiona');
    // pręty – zaznaczanie (klik, Ctrl + klik – kilka) i usuwanie klawiszem Delete
    const sid = 'q' + (++secSeq); SECREG[sid] = { sec, edit: opts.edit };
    s += `<g class="bhits" data-sid="${sid}">` + sec.bars.map((b, i) => b.cut ? '' : `<circle class="barhit" data-bi="${i}" cx="${X(b.x).toFixed(1)}" cy="${Y(b.y).toFixed(1)}" r="${Math.max(6, (b.nb > 1 ? b.nb * b.dBar : b.dBar || b.d) / 2 * sc + 3).toFixed(1)}" fill="transparent"><title>Pręt ⌀${b.dBar || b.d}${b.side === 'mid' ? ' (boczny)' : ''} – kliknij, aby zaznaczyć (Ctrl + klik – kilka); Delete – usuń</title></circle>`).join('') + '</g>';
  }
  s += '</svg>';
  return s;
}
// strzemiona przekroju – na podstawie zestawu E.stirSet (rodzaj, ramiona, promień gięcia φm/2, haki 135° ≥ max(10⌀; 70 mm))
function stirOfSec(sec) {
  if (sec.stir) return sec.stir;
  if (sec.seg && sec.seg.stir) return sec.seg.stir;
  if (sec.sup && sec.sup.gSeg && sec.sup.gSeg.stir) return sec.sup.gSeg.stir;
  if (sec.sup && R.md) { const adj = [sec.sup.segR, sec.sup.segL].filter(i => i !== null && i !== undefined).map(i => R.md.segs[i]); const sg = adj.find(q => q && q.stir); if (sg) return sg.stir; }
  return S.stir;
}
function holdOfSec(sec) { return sec.hold || (sec.seg && sec.seg.hold) || (sec.sup && sec.sup.gSeg && sec.sup.gSeg.hold) || null; }
function segOfSec(sec) { const md = R.md; if (sec.seg) return sec.seg.reb ? sec.seg : (md.segs[sec.seg.adj] || sec.seg); if (sec.sup && sec.sup.gSeg) return sec.sup.gSeg; return md.segs.find(q => q.kind === 'span') || md.segs[0]; }
function stirDraw(q, g, cov, X, Y, sc, xsLegs, bars) {
  let set; try { set = E.stirSet(q, g, cov, xsLegs && xsLegs.length === Math.max(2, Math.round(q.legs)) ? xsLegs : null); } catch (e) { return ''; }
  const d = set.d, rc = set.r + d / 2, xw0 = (g.beff - g.bw) / 2, h = g.h;
  const x0 = xw0 + cov.cs + d / 2, x1 = xw0 + g.bw - cov.cs - d / 2, y0 = cov.ct + d / 2, y1 = h - cov.cb - d / 2;   // osie prętów strzemion
  const col = '#8a2f2f', sw = Math.max(1.1, d * sc).toFixed(2), Rr = Math.max(1.2, rc * sc).toFixed(1), ex = Math.min(set.ext, (y1 - y0) * 0.35) * sc * 0.7071;
  // pręt w narożu strzemienia (styczny do obu ramion) – strzemię owinięte wokół pręta: promień osi gięcia ⌀/2 + ⌀w/2 (pręt mieści się w narożu)
  const cornerBar = (xa, ya, sx, sy) => { if (!bars) return null; for (const b of bars) { if (b.nb > 1 || b.cut) continue; const rho = (b.dBar || b.d) / 2;
    if (Math.abs(b.x - (xa + sx * (d / 2 + rho))) < 2 && Math.abs(b.y - (ya + sy * (d / 2 + rho))) < 2) return { x: b.x, y: b.y, R: rho + d / 2 }; } return null; };
  const corner = (xa, ya, sx, sy) => cornerBar(xa, ya, sx, sy) || { x: xa + sx * rc, y: ya + sy * rc, R: rc };
  const P = (x, y) => `${X(x).toFixed(1)},${Y(y).toFixed(1)}`, A = r => `A${(r * sc).toFixed(2)},${(r * sc).toFixed(2)} 0 0 1 `;
  const rect = (a, b) => { const tl = corner(a, y0, 1, 1).R, tr = corner(b, y0, -1, 1).R, br = corner(b, y1, -1, -1).R, bl = corner(a, y1, 1, -1).R;
    return `<path d="M${P(a + tl, y0)} H${X(b - tr).toFixed(1)} ${A(tr)}${P(b, y0 + tr)} V${Y(y1 - br).toFixed(1)} ${A(br)}${P(b - br, y1)} H${X(a + bl).toFixed(1)} ${A(bl)}${P(a, y1 - bl)} V${Y(y0 + tl).toFixed(1)} ${A(tl)}${P(a + tl, y0)} Z" fill="none" stroke="${col}" stroke-width="${sw}"/>`; };
  // haki w narożu (lewe górne): oba końce owinięte wokół pręta narożnego – 135°: zakończenia proste styczne do pręta, skierowane do wnętrza
  // przekroju (pod i obok pręta, nie na nim); 90°: zakończenia równoległe do ramion, za prętem
  const hooks = a => { const c = corner(a, y0, 1, 1), Rk = c.R, L = Math.min(set.ext, (y1 - y0) * 0.35), k = Math.SQRT1_2;
    if (set.hookA === 90) {      // zakończenia wzdłuż ramion (w rzucie pokrywają się z ramionami) – cieńsza linia z kreską końcową, poza prętem
      const t = Math.max(3, d * sc * 1.2), w2 = Math.max(0.8, d * sc * 0.45).toFixed(2), yv = c.y + L, xh = c.x + L;
      return `<path d="M${P(a, c.y)} V${Y(yv).toFixed(1)} m${(-t / 2).toFixed(1)},0 h${t.toFixed(1)} M${P(c.x, y0)} H${X(xh).toFixed(1)} m0,${(-t / 2).toFixed(1)} v${t.toFixed(1)}" stroke="#e6b3b3" stroke-width="${w2}" stroke-linecap="round" fill="none"><title>hak 90° – zakończenie ${fmt(set.ext, 0)} mm wzdłuż ramienia</title></path>`; }
    const p1 = [c.x - Rk * k, c.y + Rk * k], p2 = [c.x + Rk * k, c.y - Rk * k], r = (Rk * sc).toFixed(2), Lk = L * k;
    return `<path d="M${P(c.x - Rk, c.y)} A${r},${r} 0 0 0 ${P(p1[0], p1[1])} L${P(p1[0] + Lk, p1[1] + Lk)} M${P(c.x, c.y - Rk)} A${r},${r} 0 0 1 ${P(p2[0], p2[1])} L${P(p2[0] + Lk, p2[1] + Lk)}" stroke="${col}" stroke-width="${sw}" stroke-linecap="round" fill="none"/>`; };
  const legX = i => set.xs ? set.xs[i] : x0 + (x1 - x0) * i / (set.legs - 1);
  let s = '';
  set.pieces.forEach(pc => {
    if (pc.type === 'closed') s += rect(x0, x1) + hooks(x0);
    else if (pc.type === 'tors') {
      const lap = Math.min(pc.lap || 0, (x1 - x0) * 0.8);
      s += rect(x0, x1) + `<line x1="${X(x0 + rc).toFixed(1)}" y1="${(Y(y0) + d * sc).toFixed(1)}" x2="${X(x0 + rc + lap).toFixed(1)}" y2="${(Y(y0) + d * sc).toFixed(1)}" stroke="${col}" stroke-width="${sw}" stroke-linecap="round"/>`;
    } else if (pc.type === 'open') {
      s += `<path d="M${X(x0).toFixed(1)},${Y(y0).toFixed(1)} V${(Y(y1) - rc * sc).toFixed(1)} A${Rr},${Rr} 0 0 0 ${(X(x0) + rc * sc).toFixed(1)},${Y(y1).toFixed(1)} H${(X(x1) - rc * sc).toFixed(1)} A${Rr},${Rr} 0 0 0 ${X(x1).toFixed(1)},${(Y(y1) - rc * sc).toFixed(1)} V${Y(y0).toFixed(1)}" fill="none" stroke="${col}" stroke-width="${sw}"/>`;
      s += `<path d="M${X(x0).toFixed(1)},${Y(y0).toFixed(1)} l${(ex * 0.9).toFixed(1)},${(-ex * 0.2).toFixed(1)} M${X(x1).toFixed(1)},${Y(y0).toFixed(1)} l${(-ex * 0.9).toFixed(1)},${(-ex * 0.2).toFixed(1)}" stroke="${col}" stroke-width="${sw}" stroke-linecap="round"/>`;
      s += `<line x1="${X(x0 + d * 1.2).toFixed(1)}" y1="${Y(y0 + d * 0.6).toFixed(1)}" x2="${X(x1 - d * 1.2).toFixed(1)}" y2="${Y(y0 + d * 0.6).toFixed(1)}" stroke="${col}" stroke-width="0.8" stroke-dasharray="3 2"/>`;
    } else if (pc.type === 'inner') {
      const k = pc.k, a = legX(k), b = legX(set.legs - 1 - k);
      s += rect(a, b) + hooks(a);
    } else if (pc.type === 'pin') {
      const list = [];
      if (set.kind === 'pins') for (let i = 1; i < set.legs - 1; i++) list.push(legX(i)); else list.push((x0 + x1) / 2);
      list.forEach(xx => { const k90 = set.hookA === 90; s += `<path d="M${(X(xx) + ex * (k90 ? 1.1 : 0.8)).toFixed(1)},${(Y(y0) + (k90 ? 0 : ex * 0.8)).toFixed(1)} L${X(xx).toFixed(1)},${Y(y0).toFixed(1)} V${Y(y1).toFixed(1)} l${(-ex * (k90 ? 1.1 : 0.8)).toFixed(1)},${(k90 ? 0 : -ex * 0.8).toFixed(1)}" fill="none" stroke="${col}" stroke-width="${Math.max(1, d * sc * 0.85).toFixed(2)}" stroke-linecap="round"/>`; });
    }
  });
  return s;
}
// wykres odkształceń i naprężeń SGN
function strainSVG(sec) {
  const kind = sec.kind;
  if (!sec.r) return '';
  const g = sec.g || R.g, h = g.h, W = 280, H = 380, m = 46, st = sec.r;
  const sc = (H - 2 * m) / h, oy = m;
  const Y = y => oy + y * sc;
  let s = svgOpen(W, H);
  const eT = kind === 'span' ? st.eT : st.eB, eB = kind === 'span' ? st.eB : st.eT; // fizycznie góra/dół
  const emax = Math.max(Math.abs(eT), Math.abs(eB)) || 1;
  const ax = 100, ws = 56;
  const Xe = e => ax + e / emax * ws;
  s += tx(ax, 18, 'ε [‰]', { fs: 11, w: 600 });
  s += `<line x1="${ax}" y1="${Y(0) - 6}" x2="${ax}" y2="${Y(h) + 6}" stroke="#39414f" stroke-width="1"/>`;
  s += `<polygon points="${ax},${Y(0)} ${Xe(eT)},${Y(0)} ${Xe(eB)},${Y(h)} ${ax},${Y(h)}" fill="rgba(29,91,184,.12)" stroke="#1d5bb8" stroke-width="1.2"/>`;
  s += tx(Xe(eT) + (eT >= 0 ? 4 : -4), Y(0) - 4, fmt(eT * 1000, 2), { fs: 10, a: eT >= 0 ? 'start' : 'end', c: '#1d5bb8' });
  s += tx(Xe(eB) + (eB >= 0 ? 4 : -4), Y(h) + 13, fmt(eB * 1000, 2), { fs: 10, a: eB >= 0 ? 'start' : 'end', c: '#1d5bb8' });
  // naprężenia w betonie (blok prostokątny / parabola)
  const bx = 205, bw = 40;
  s += tx(bx, 18, 'σ<tspan font-size="8" dy="2">c</tspan>', { fs: 11, w: 600 });
  s += `<line x1="${bx}" y1="${Y(0) - 6}" x2="${bx}" y2="${Y(h) + 6}" stroke="#39414f" stroke-width="1"/>`;
  if (R.m.diag === 'rect' && st.block) {
    const y0 = kind === 'span' ? st.block[0] : h - st.block[1], y1 = kind === 'span' ? st.block[1] : h - st.block[0];
    s += `<rect x="${bx}" y="${Y(y0)}" width="${bw}" height="${(y1 - y0) * sc}" fill="rgba(192,38,45,.15)" stroke="#c0262d"/>`;
    s += tx(bx + bw + 3, Y((y0 + y1) / 2) + 3, `η·f<tspan font-size="8" dy="2">cd</tspan>`, { fs: 9.5, a: 'start', c: '#c0262d' });
    s += tx(bx + bw / 2, Y(y1) + 12, `λx = ${fmt(y1 - y0, 0)}`, { fs: 9.5, c: '#c0262d' });
  } else if (isFinite(st.x)) {
    const pts = [];
    for (let i = 0; i <= 40; i++) {
      const y = h * i / 40; const ys = kind === 'span' ? y : h - y;
      const e = st.eT + (st.eB - st.eT) * ys / h;
      const sg = e <= 0 ? 0 : e >= R.m.ec2 ? 1 : 1 - Math.pow(1 - e / R.m.ec2, R.m.npar);
      pts.push([bx + sg * bw, Y(y)]);
    }
    s += `<polygon points="${bx},${Y(0)} ${pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ')} ${bx},${Y(h)}" fill="rgba(192,38,45,.15)" stroke="#c0262d"/>`;
  }
  // siła w stali rozciąganej
  const ss = st.bs.length ? Math.min(...st.bs.map(b => b.s)) : 0;
  s += tx(bx, Y(h) + 26, `σ<tspan font-size="8" dy="2">s1</tspan><tspan dy="-2"> = ${fmt(Math.abs(ss), 0)} MPa</tspan>`, { fs: 10, c: '#1d2a3f' });
  s += tx(ax, Y(h) + 26, `x = ${fmt(st.x, 1)} mm`, { fs: 10, c: '#c0262d' });
  s += '</svg>';
  return s;
}
// poglądowe porównanie zbrojenia: wymagane (SGN), minimalne (9.1N, rysy 7.3.2), przyjęte, maksymalne
function asNeed(sec) {
  const r = sec.sls, req = sec.des ? sec.des.As1 : 0, req2 = sec.des ? sec.des.As2 : 0;
  const amin = r ? r.AsMin : 0, acr = r && r.asmin && r.Mk > 0 ? r.asmin.As : 0;
  return { req, req2, amin, acr, need: Math.max(req, amin, acr) };
}
// tabela: warunek | wymagane | przyjęte | spełniony (TAK/NIE)
function reqTable(rows) {
  return `<table class="reqt"><tr><th>Warunek</th><th>wymagane</th><th>przyjęte</th><th>spełniony</th></tr>${rows.map(([l, rq, pv, rel, u, dp]) => {
    const tol = dp ? 1e-9 : 0.5, ok = rel === '≤' ? pv <= rq + tol : pv >= rq - tol, uu = u ? ' ' + u : '';
    return `<tr><td>${l}</td><td>${rel} ${fmt(rq, dp || 0)}${uu}</td><td>${fmt(pv, dp || 0)}${uu}</td><td class="${ok ? 'yes' : 'no'}">${ok ? 'TAK' : 'NIE'}</td></tr>`;
  }).join('')}</table>`;
}
function asReqHTML(sec, Aprov, desc) {
  const n = asNeed(sec), A = Aprov === undefined ? sec.tens.A : Aprov, g = sec.g || R.g;
  const A2 = sec.comp ? sec.comp.A : 0;
  const rows = [['A<sub>s1</sub> – zginanie SGN (A<sub>s1,req</sub>)', n.req, A, '≥', 'mm²'], ['A<sub>s,min</sub> – 9.2.1.1(1), wzór 9.1N', n.amin, A, '≥', 'mm²']];
  if (n.acr > 0) rows.push(['A<sub>s,min</sub> – ograniczenie rys, 7.3.2', n.acr, A, '≥', 'mm²']);
  if (n.req2 > 0) rows.push(['A<sub>s2</sub> – zbrojenie ściskane (A<sub>s2,req</sub>)', n.req2, A2, '≥', 'mm²']);
  rows.push(['A<sub>s1</sub> + A<sub>s2</sub> ≤ A<sub>s,max</sub> = 0,04·A<sub>c</sub> – 9.2.1.1(3)', 0.04 * g.Ac, A + A2, '≤', 'mm²']);
  let h = `<div class="asreq"><h5>Zbrojenie ${sec.kind === 'span' ? 'dolne' : 'górne'} (rozciągane)${desc ? ` – ${esc(desc)}` : ''}</h5>${reqTable(rows)}`;
  const dB = sec.tens.dBarMax || sec.tens.dmax || 16, aB = Math.PI * dB * dB / 4;
  if (A < n.need - 0.5) h += `<p class="hint keep">Brakuje ${fmt(n.need - A, 0)} mm² – ok. ${Math.ceil((n.need - A) / aB)} × ⌀${dB} więcej.</p>`;
  return h + `</div>`;
}
// strzemiona: wymagane A_sw/s przy podporach (poglądowo, bez skręcania)
function aswReqHTML() {
  if (!R.sh || !R.sh.ends || !R.sh.ends.length) return '';
  const m = R.m, cot = R.sh.cot || 2.5, multi = R.md.segs.length > 1;
  const aOf = q => Math.max(2, q.legs) * Math.PI * q.d ** 2 / 4;
  const rows = [];
  R.sh.ends.forEach(e => {
    const q = e.stir || S.stir, req = Math.max(0, e.Vred) / (e.z * m.fywd * cot) * 1000;
    rows.push([`${esc(cap(e.sup.name))}${multi ? ' – ' + esc(e.seg.label) : ''}: A<sub>sw</sub>/s dla V<sub>Ed${e.red ? ',red' : ''}</sub> = ${fmt(e.Vred / 1e3, 1)} kN (s₁ = ${q.s1})`, req, aOf(q) / q.s1 * 1000, '≥', 'mm²/m']);
  });
  const segs = (R.sh.segs && R.sh.segs.length ? R.sh.segs : [{ seg: R.md.segs[0], stir: S.stir }]);
  segs.forEach(z => {
    const q = z.stir || S.stir, bw = (z.seg && z.seg.g ? z.seg.g : R.g).bw, lab = multi && z.seg ? esc(z.seg.label) + ': ' : '';
    rows.push([`${lab}ρ<sub>w,min</sub> = 0,08√f<sub>ck</sub>/f<sub>yk</sub> (9.5N) przy s₂ = ${q.s2}`, 0.08 * Math.sqrt(m.fck) / m.fywk * bw * 1000, aOf(q) / q.s2 * 1000, '≥', 'mm²/m']);
    if (z.sMax) rows.push([`${lab}rozstaw podłużny s₂ ≤ s<sub>l,max</sub> = 0,75·d (9.6N)`, z.sMax, q.s2, '≤', 'mm']);
    if (z.legsMin) rows.push([`${lab}liczba ramion (s<sub>t,max</sub> = min(0,75d; 600) – 9.2.2(8))`, z.legsMin, q.legs, '≥', '']);
  });
  let h = `<div class="box asbox"><h4>Strzemiona – wymagane i przyjęte<small> · cot θ = ${fmt(cot, 2)}</small></h4><div class="asreq" style="border:0;padding-top:0">${reqTable(rows)}`;
  h += `<p style="margin:6px 0"><button class="btn sm" data-areas="1" title="Pola przekroju A_s [cm²] dla n prętów ⌀ oraz masa 1 m pręta">Tablica pól przekroju prętów</button></p>`;
  return h + `<p class="hint">Wymagane A<sub>sw</sub>/s = V<sub>Ed</sub>/(z·f<sub>ywd</sub>·cot θ) przy licu każdej podpory (bez skręcania, z redukcją 6.2.1(8) gdy dopuszczalna); szczegóły w Podsumowaniu.</p></div></div>`;
}
function renderSection(el) {
  const hdr = `<div class="dsumx"></div><div class="h2">Przekrój i zbrojenie<small>kliknij krawędź przekroju (górę, dół, bok) lub jego wnętrze (strzemiona), aby dodać lub zmienić zbrojenie; „Dobierz zbrojenie wymagane” – dobór wg schematu z zakładki Dane</small></div>${rebBar()}${R && R.bare ? bareNote() : ''}`;
  if (!R || !R.secs || (R.errors && R.errors.length)) { el.innerHTML = hdr + errBox(); bindRebBar(el); return; }
  let html = hdr + `<div class="h2">Przekroje obliczeniowe<small>stan graniczny nośności dla M<sub>Rd</sub> przy N<sub>Ed</sub> = ${fmt(R.st.NEd / 1e3, 1)} kN</small></div><div class="flex">`;
  R.secs.forEach(sec => {
    const isS = sec.kind === 'span';
    html += `<div class="box" data-sk="${sec.key}"><h4>${esc(cap(sec.loc))} – ${isS ? 'M > 0 (rozciągane włókna dolne)' : 'M < 0 (rozciągane włókna górne)'}<small> · x = ${fmt(sec.x / 1000, 2)} m${sec.g && (R.gVar || (sec.g.bw !== R.g.bw || sec.g.h !== R.g.h)) ? ` · ${sec.g.bw}×${sec.g.h}` : ''}</small></h4><div class="flex secedit" style="gap:0">${sectionSVG(sec, { edit: sectionZones(sec) })}${strainSVG(sec)}</div>`;
    const tens = sec.tens, comp = sec.comp;
    html += `<table class="kv">
      <tr><td>Zbrojenie rozciągane</td><td>${tens.desc}</td><td>A<sub>s1</sub> = ${fmt(tens.A, 0)} mm²</td></tr>
      <tr><td>Zbrojenie ściskane</td><td>${comp && comp.n ? comp.desc : '—'}</td><td>A<sub>s2</sub> = ${fmt(comp ? comp.A : 0, 0)} mm²</td></tr>
      <tr><td>Wysokość użyteczna d</td><td>${fmt(sec.d, 1)}</td><td>mm</td></tr>
      <tr><td>A<sub>s1,req</sub> (metoda uproszczona)</td><td>${fmt(sec.des.As1, 0)}</td><td>mm² ${sec.des.As2 > 0 ? `+ A<sub>s2,req</sub> = ${fmt(sec.des.As2, 0)} mm²` : ''}</td></tr>
      <tr><td>Stopień zbrojenia ρ<sub>l</sub></td><td>${fmt(tens.A / ((sec.g || R.g).bw * sec.d) * 100, 2)}</td><td>%</td></tr>
${sec.red ? `<tr><td>Redukcja nad podporą <span class="nrefx">5.3.2.2</span></td><td>${fmt(sec.red.M0 / 1e6, 1)} → ${fmt(sec.MEd / 1e6, 1)}</td><td>kNm (${sec.red.kind === 'free' ? `ΔM = F·t/8 = ${fmt(sec.red.F / 1e3, 1)}·${fmt(sec.red.t / 1000, 2)}/8 = ${fmt(sec.red.dM / 1e6, 1)}` : `moment w licu ${fmt(sec.red.Mf / 1e6, 1)}, ≥ 0,65·M`})</td></tr>` : ''}
      <tr><td>|M<sub>Ed</sub>| / M<sub>Rd</sub></td><td>${fmt(sec.MEd / 1e6, 1)} / ${fmt(sec.MRd / 1e6, 1)}</td><td>kNm (${fmt(sec.MRd > 0 ? sec.MEd / sec.MRd * 100 : 0, 0)}%)</td></tr>
      <tr><td>ε<sub>s1</sub> / ε<sub>yd</sub></td><td>${sec.r ? fmt(Math.abs(Math.min(...sec.r.bs.map(b => b.e))) * 1000, 2) : '—'} / ${fmt(R.m.eyd * 1000, 2)}</td><td>‰</td></tr>
      ${sec.biax && sec.biax.Mz > 1e3 ? `<tr><td>Zginanie ukośne M<sub>y</sub>; M<sub>z</sub></td><td>${fmt(sec.biax.My / 1e6, 1)}; ${fmt(sec.biax.Mz / 1e6, 1)}</td><td>kNm (η = ${fmt(sec.biax.u * 100, 0)}%)</td></tr>` : ''}
    </table>${asReqHTML(sec)}</div>`;
  });
  html += aswReqHTML() + `</div>`;
  const ss = R.secs.filter(x => x.sls);
  if (ss.length) {
    html += `<div class="h2" style="margin-top:18px">Charakterystyki SGU<small>α<sub>e</sub> = E<sub>s</sub>/E<sub>cm</sub> = ${fmt(R.sls.aeS, 2)}, α<sub>e,t</sub> = E<sub>s</sub>/E<sub>c,eff</sub> = ${fmt(R.sls.aeL, 2)}</small></div><div class="flex">`;
    ss.forEach(x => {
      const r = x.sls;
      html += `<div class="box"><h4>${esc(cap(x.loc))}</h4><table class="kv">
        <tr><td>I<sub>I</sub> (faza I, krótkotrwale)</td><td>${fmt(r.unS.I / 1e8, 1)}</td><td>·10⁴ cm⁴</td></tr>
        <tr><td>I<sub>II</sub> (faza II, długotrwale)</td><td>${fmt(r.crL.I / 1e8, 1)}</td><td>·10⁴ cm⁴</td></tr>
        <tr><td>x<sub>II</sub> krótko / długotrwale</td><td>${fmt(r.crS.x, 1)} / ${fmt(r.crL.x, 1)}</td><td>mm</td></tr>
        <tr><td>M<sub>cr</sub></td><td>${fmt(r.Mcr / 1e6, 1)}</td><td>kNm</td></tr>
        <tr><td>M<sub>Ek</sub> / M<sub>Eqp</sub></td><td>${fmt(r.Mk / 1e6, 1)} / ${fmt(r.Mqp / 1e6, 1)}</td><td>kNm</td></tr>
        <tr><td>σ<sub>c</sub> / σ<sub>s</sub> (char.)${r.biax ? ' – ukośne' : ''}</td><td>${fmt(r.sc_k, 1)} / ${fmt(r.ss_k, 0)}</td><td>MPa</td></tr>
        <tr><td>w<sub>k</sub></td><td>${fmt(r.w.wk, 3)}</td><td>mm</td></tr></table></div>`;
    });
    html += `</div>`;
  }
  el.innerHTML = html;
  bindRebBar(el);
  applyFailMarks(el);
  $$('.box[data-sk] table.kv tr', el).forEach(tr => { const box = tr.closest('[data-sk]'), k = box.dataset.sk, txt = tr.textContent;
    const id = /M<sub>Ed|MEd|M_Ed|\|MEd\||ε/.test(tr.innerHTML) ? (k[0] === 's' ? 'Mspan' : 'Msupp') : /A<sub>s1,req|Stopień|Zbrojenie rozciągane/.test(tr.innerHTML) ? 'asmin' : null; if (!id) return;
    const ck = R.checks.find(q => q.at === k && q.id === id) || R.checks.find(q => q.at === k && /^M(span|supp)$/.test(q.id)); if (!ck) return;
    tr.classList.add('xclick'); tr.title = 'Kliknij – jak obliczono (wzór, podstawienie, punkt normy)'; tr.addEventListener('click', () => explainPopup(ck)); void txt; });
  $$('.zhit, .covhit', el).forEach(r => r.addEventListener('click', () => zoneClick(r.dataset.z)));
  $$('.geohit', el).forEach(r => r.addEventListener('click', ev => { ev.stopPropagation(); geoPopup(+r.dataset.geo); }));
}

/* --------------------------------------- strefy zbrojenia (zakładka Przekrój) */
// identyfikatory: 'b<odcinek>' – dół odcinka, 't' – góra ciągła, 'x<podpora>' – góra dodatkowa nad podporą
const PLACE = [['even', 'równomiernie na szerokości'], ['min', 'w odstępach normowych od naroży'], ['pair', 'sparowane – zlicowane z prętami warstwy 1'], ['manual', 'współrzędne podane ręcznie']];
const VIB = [25, 30, 35, 38, 40, 45, 50, 55, 60, 65, 75];
function zoneSeg(zid) { const md = R && R.md ? R.md : model(); const sg = md.segs[+zid.slice(1)]; if (!sg) return null; return sg.reb ? sg : md.segs[sg.adj]; }
function zonePath(zid) {
  if (zid === 't') return 'reb.top';
  if (zid[0] === 'b') { const sg = zoneSeg(zid); if (!sg) return null; return CONT(S) ? `cont.rebSpans.${sg.si}` : 'reb.bot'; }
  if (zid[0] === 'x') return CONT(S) ? `cont.rebSupps.${+zid.slice(1)}` : 'reb.topX';
  return null;
}
const zoneGet = zid => { const p = zonePath(zid); return p ? getP(S, p) : null; };
function zoneTitle(zid) {
  const md = R && R.md ? R.md : model();
  if (zid === 't') return 'Zbrojenie górne – pręty ciągłe (na całej długości belki)';
  if (zid[0] === 'b') { const sg = zoneSeg(zid); return 'Zbrojenie dolne' + (md.segs.length > 1 && sg ? ` – ${sg.label}` : '') + (S.scheme === 'cant' ? ' (wspornik)' : ''); }
  const sp = md.sups[+zid.slice(1)];
  if (CONT(S)) return `Zbrojenie górne dodatkowe – ${sp ? sp.name : ''}`;
  return S.scheme === 'cant' ? 'Zbrojenie górne dodatkowe przy utwierdzeniu' : 'Zbrojenie górne dodatkowe nad podporami';
}
function zoneDesc(z) {
  if (!z || !z.layers || !z.layers.length) return 'brak';
  const nb = z.nb > 1 ? '×' + z.nb : '';
  return z.layers.map(l => l.bars.map(q => `${q.n}${nb}⌀${q.d}`).join(' + ')).join(' / ');
}
// informacja o przekrojach bez zbrojenia: zbrojenie wymagane w strefach (dobór optymalny)
function bareNote() {
  if (!R || !R.req) return '';
  const zs = R.req.zones.filter(z => z.ch || z.kind === 'top');
  const t = zs.map(z => `${esc(cap(z.label))}: <b>${z.kind === 'supp' ? `${R.req.top.ch.n}⌀${R.req.top.ch.d} ciągłe + ${z.ch ? z.ch.n + '⌀' + z.ch.d : '—'}` : `${z.ch.n}⌀${z.ch.d}`}</b> <small>(${z.kind === 'top' && !(z.AsReq > 1) ? 'montażowe – narożniki strzemion' : `A<sub>s,req</sub> = ${fmt(z.AsReq, 0)} mm²`})</small>`).join(' · ');
  return `<div class="barenote"><b>Przekroje bez zbrojenia podłużnego</b> – pokazano siły wewnętrzne i zbrojenie wymagane. Dobór optymalny (SGN, A<sub>s,min</sub>${R.req.mid ? ', skręcanie' : ''}): ${t}${R.req.mid ? ` · pręty boczne 2×${R.req.mid.n}⌀${R.req.mid.d}` : ''}. Rysy, naprężenia i ugięcia sprawdzane są po zadaniu zbrojenia.</div>`;
}
// zakończenie prętów dobrane automatycznie – na podporach skrajnych (8.4.4, 9.2.1.4(3), tab. 8.2)
function anchAutoHint() {
  if (!R || !R.anch || R.bare) return 'Pręty proste, gdy l<sub>bd</sub> ≤ t − c<sub>nom</sub>; w przeciwnym razie odgięcie 90° na wymaganą długość (α₁ = 0,7 przy c<sub>d</sub> > 3⌀, tab. 8.2), z trzpieniem wg tab. 8.1N i warunku (8.1).';
  const a = [...(R.anch.ends || []).map(q => `${esc(q.name)} (dół): ${q.bent ? `odgięcie ${fmt(q.leg, 0)} mm, l<sub>bd</sub> = ${fmt(q.lbdHook, 0)} mm` : `pręty proste, l<sub>bd</sub> = ${fmt(q.lbd, 0)} ≤ ${fmt(q.avail, 0)} mm`}`), ...(R.anch.endsTop || []).map(q => `${esc(q.name)} (góra): ${q.bent ? `odgięcie ${fmt(q.leg, 0)} mm` : 'pręty proste'}`)];
  return `Dobrano: ${a.join('; ') || 'brak podpór skrajnych swobodnych'}. Pręty proste, gdy l<sub>bd</sub> ≤ t − c<sub>nom</sub>; w przeciwnym razie odgięcie 90° (α₁ = 0,7 przy c<sub>d</sub> > 3⌀, tab. 8.2) z trzpieniem wg tab. 8.1N.`;
}
// przyjęcie proponowanego przekroju (✖ przy b / h) – propozycje są zawsze sprawdzone pełnym doborem zbrojenia i kompletem warunków
function applyDimSug(seg, b, h) {
  let v = null; try { v = E.verifyDims(S, seg, b, h); } catch (e) { console.error(e); }
  if (v && v.ok) { b = v.b; h = v.h; } else if (v && v.h > h) h = v.h;
  // przekrój przyjmowany razem ze zbrojeniem, z którym został sprawdzony (rozstaw prętów 8.2(2), buława, wszystkie warunki) – gdy belka ma
  // zadane zbrojenie podłużne (dotychczasowe mogłoby się nie mieścić w mniejszym przekroju)
  const zHas = z => !!(z && z.layers && z.layers.some(l => (l.bars || []).some(q => q.n > 0)));
  const hadReb = [S.reb.bot, S.reb.top, S.reb.topX].some(zHas) || (CONT(S) && [...(S.cont.rebSpans || []), ...(S.cont.rebSupps || [])].some(zHas));
  if (CONT(S)) { const md = R && R.md ? R.md : model(), sg = md.segs[seg]; if (!sg || sg.si === undefined) return; S.cont.geoSpans = S.cont.geoSpans || []; const n = S.cont.spans.length; for (let i = 0; i < n; i++) S.cont.geoSpans[i] = Object.assign({ b: S.geom.b, h: S.geom.h }, S.cont.geoSpans[i] || {}); S.cont.geoSpans[sg.si] = Object.assign({}, S.cont.geoSpans[sg.si], { b, h }); }
  else { S.geom.b = b; S.geom.h = h; }
  let rn = '';
  if (v && v.ok && v.reb && v.reb.S && hadReb) {
    const T = v.reb.S; S.reb.bot = T.reb.bot; S.reb.top = T.reb.top; S.reb.topX = T.reb.topX; S.reb.mid = T.reb.mid;
    if (CONT(S) && T.cont) { S.cont.rebSpans = T.cont.rebSpans; S.cont.rebSupps = T.cont.rebSupps; }
    S.stir.d = T.stir.d; S.stir.legs = T.stir.legs; S.barEdit = {}; rn = ' i zbrojenie dobrane dla tego przekroju';
  }
  const note = v ? (v.ok ? ` – sprawdzony z dobranym zbrojeniem (rozstaw prętów 8.2(2), wszystkie warunki)${v.dh > 0 ? `; h zwiększono o ${v.dh} mm` : ''}` : ` – nadal niespełnione: ${v.fails.join(', ')}`) : '';
  changed(true); toast(`Przyjęto przekrój ${b}×${h} mm${rn}${note}.`, 6000);
}
// lista stref do paska narzędzi
function zoneList() {
  const md = R && R.md ? R.md : model(), out = [];
  if (CONT(S)) md.segs.filter(sg => sg.reb).forEach(sg => out.push(['b' + sg.idx, `Dół – ${sg.label}`]));
  else out.push(['b0', S.scheme === 'cant' ? 'Dół (wspornik)' : 'Dół']);
  out.push(['t', 'Góra – pręty ciągłe']);
  if (CONT(S)) md.sups.forEach(p => out.push(['x' + p.idx, `Góra nad podporą ${p.label}`]));
  else out.push(['x0', S.scheme === 'cant' ? 'Góra przy utwierdzeniu' : 'Góra nad podporami']);
  return out;
}
// układ strefy z ostatnich obliczeń (do przekształcenia układu automatycznego w warstwy)
function zoneLayR(zid) {
  if (!R || !R.md) return null;
  if (zid === 't') return R.LtM || null;
  if (zid[0] === 'b') { const sg = zoneSeg(zid); return sg && sg.Lb ? sg.Lb : null; }
  const p = R.md.sups[+zid.slice(1)] || R.md.sups[0];
  return p && p.LtS ? p.LtS : null;
}
function materialize(zid, z) {
  const W = JSON.parse(JSON.stringify(z || E.zoneOf([])));
  if (!W.auto) return W;
  W.auto = false;
  const lay = zoneLayR(zid);
  if (!lay || !lay.bars || !lay.bars.length) {               // bez wyników – wszystkie grupy w jednej warstwie
    const all = []; W.layers.forEach(l => l.bars.forEach(q => all.push(q)));
    W.layers = all.length ? [{ bars: all, place: 'even', xs: '', gap: '', toSupp: (z.layers[0] || {}).toSupp || 'all' }] : [];
    return W;
  }
  const own = zid[0] === 'x' ? lay.bars.filter(b => b.tag === 'z') : lay.bars;
  const ks = Array.from(new Set(own.map(b => b.layer))).sort((a, b) => a - b);
  W.layers = ks.map(k => {
    const bk = own.filter(b => b.layer === k), mp = new Map();
    bk.forEach(b => mp.set(b.dBar, (mp.get(b.dBar) || 0) + 1));
    const nS = bk.filter(b => b.supp !== false).length;
    return { bars: Array.from(mp.entries()).sort((a, b) => b[0] - a[0]).map(([d, n]) => ({ n, d })), place: k > ks[0] ? 'pair' : 'even', xs: '', gap: '', toSupp: nS === bk.length ? 'all' : nS };
  });
  return W;
}
function zoneGeo(zid) {
  const md = R.md;
  if (zid && zid[0] === 'b') { const sg = zoneSeg(zid); if (sg && sg.g) return sg.g; }
  if (zid && zid[0] === 'x') { const p = md.sups[+zid.slice(1)] || md.sups[0]; if (p && p.g) return p.g; }
  return md.segs.reduce((a, sg) => (sg.g && sg.g.bw < a.bw ? sg.g : a), R.g);     // pręty ciągłe – najwęższy przekrój
}
function zoneCtx(zid) {
  if (!R || !R.g || !R.cov || !R.cov.cnom || !R.LtM) return null;
  const g = zoneGeo(zid), cv = R.cov, dsw = Math.max(...R.md.segs.map(sg => (sg.stir || S.stir).d));
  return { g, c: cv.cnom, cvB: { e: cv.cb, s: cv.cs }, cvT: { e: cv.ct, s: cv.cs }, dsw, dg: S.mat.dg, sepB: S.anch.bond !== 'poor', sepT: S.anch.bond === 'good' || g.h <= 250 };
}
function zoneLayout(zid, z) {
  const k = zoneCtx(zid); if (!k) return null;
  const zz = E.normZone(JSON.parse(JSON.stringify(z)), E.zoneOf([]));
  if (zid[0] === 'b') return E.layoutZone(zz, k.g, k.cvB, k.dsw, k.dg, { sep: k.sepB });
  if (zid === 't') return E.layoutZone(zz, k.g, k.cvT, k.dsw, k.dg, { sep: k.sepT });
  const p = R.md.sups[+zid.slice(1)] || R.md.sups[0];
  return E.layoutZone(zz, k.g, k.cvT, k.dsw, k.dg, { sep: k.sepT, base: S.reb.top, baseSep: k.sepT, baseLay: p && p.gSeg && p.gSeg.Lt ? p.gSeg.Lt : R.LtM });
}
// pręty, które nie mieszczą się w warstwie (prześwit < s_min), są przenoszone do kolejnej warstwy (zlicowanej z warstwą 1)
// rozmieszczenie prętów w warstwach: w każdej warstwie największa liczba prętów, jaka się mieści (odstępy 8.2(2), warstwy w styku –
// max(1,5⌀; d_g + 5; 30 mm), prześwit na buławę, gdy był), nadmiar – do warstwy wyższej; gdy w warstwie niższej jest miejsce – pręty
// z warstwy wyższej przenoszone w dół; warstwa sparowana / w styku nie ma więcej prętów niż warstwa pod nią
function autoFit(zid, W) {
  const moved = [], nOf = L => L.bars.reduce((a, b) => a + b.n, 0), layOf = () => { try { return zoneLayout(zid, W); } catch (e) { return null; } };
  const vibOn = S.reb.vibOn !== false, vibReq = (S.reb.vib || 40) + 10, isTop = zid[0] !== 'b';
  const okLay = (lay, k) => { const ly = lay && lay.layers[k]; if (!ly) return true; if (ly.n > 1 && ly.gap < ly.smin - 1e-6) return false;
    const L = W.layers[k]; if (k > 0 && (L.touch || L.place === 'pair') && L.place !== 'manual' && nOf(L) > nOf(W.layers[k - 1])) return false; return true; };
  const mv = (from, to, q) => { q.n -= 1; const L = W.layers[from]; if (q.n <= 0) L.bars.splice(L.bars.indexOf(q), 1);
    let N = W.layers[to]; if (!N) { N = { bars: [], place: 'pair', xs: '', gap: '', toSupp: 'all' }; W.layers.splice(to, 0, N); }
    const t = N.bars.find(b => b.d === q.d); if (t) t.n += 1; else N.bars.push({ n: 1, d: q.d });
    if (L.toSupp !== 'all' && L.toSupp >= nOf(L)) L.toSupp = 'all';
    const m0 = moved.find(v => v.k === from && v.to === to && v.d === q.d); if (m0) m0.n++; else moved.push({ k: from, to, d: q.d, n: 1 }); };
  // 1. nadmiar w górę (od warstwy 1)
  for (let it = 0; it < 120; it++) {
    const lay = layOf(); if (!lay) return moved;
    const k = W.layers.findIndex((L, i) => L.place !== 'manual' && nOf(L) > 1 && !okLay(lay, i));
    if (k < 0 || (W.layers.length >= 6 && k === W.layers.length - 1)) break;
    const L = W.layers[k]; if (nOf(L) <= 2 && k === 0) break;
    mv(k, k + 1, L.bars.reduce((bq, q) => (q.d <= bq.d ? q : bq), L.bars[0]));
  }
  // 2. wolne miejsce w warstwie niższej – pręty z warstwy wyższej w dół (warstwa 1 możliwie pełna)
  for (let k = 0; k < W.layers.length - 1; k++) {
    const L = W.layers[k], N = W.layers[k + 1]; if (L.place === 'manual' || N.place === 'manual') continue;
    for (let it = 0; it < 40 && nOf(N) > 0; it++) {
      const lay0 = layOf(), open0 = lay0 ? lay0.open : 0, snap = JSON.stringify(W.layers), q = N.bars.reduce((bq, x) => (x.d >= bq.d ? x : bq), N.bars[0]);
      const mvd = moved.length; const qq = { n: q.n, d: q.d }; q.n -= 1; if (q.n <= 0) N.bars.splice(N.bars.indexOf(q), 1);
      const t = L.bars.find(b => b.d === qq.d); if (t) t.n += 1; else L.bars.push({ n: 1, d: qq.d });
      const lay = layOf(), ok = lay && W.layers.every((_, i) => okLay(lay, i)) && !(vibOn && (isTop || lay.stacked) && open0 >= vibReq && lay.open < vibReq);
      if (!ok) { W.layers = JSON.parse(snap); moved.length = mvd; break; }
      const m0 = moved.find(v => v.k === k + 1 && v.to === k && v.d === qq.d); if (m0) m0.n++; else moved.push({ k: k + 1, to: k, d: qq.d, n: 1 });
    }
  }
  // puste warstwy wyższe – usunięte
  for (let k = W.layers.length - 1; k > 0; k--) if (!nOf(W.layers[k])) W.layers.splice(k, 1);
  return moved;
}
// pręty do rysunku przekroju z układu strefy
const layBars = (L, side, h) => L ? L.bars.map(b => Object.assign({}, b, { y: side === 'bot' ? h - b.e : b.e, side, cut: side === 'bot' && b.supp === false })) : [];
function hintBundle(z) {
  let t = 'Wiązki (8.9): średnica zastępcza ⌀<sub>n</sub> = ⌀·√n<sub>b</sub> ≤ 55 mm – do otuliny, odstępów i zakotwienia; prześwit mierzony od obrysu wiązki.';
  if (z && z.shape === 'v') t += ' Pręty <b>jeden nad drugim, bez odstępu</b>: para prętów w dobrych warunkach przyczepności może być liczona jak pręty pojedyncze (8.9.1(4)). Między kolumnami pozostaw prześwit na buławę wibratora (8.2(4)).';
  return t;
}
// okno edycji strefy zbrojenia: warstwy, grupy prętów n×⌀, rozmieszczenie, odstęp warstw, pręty doprowadzone do podpór
function zonePopup(zid) {
  const z0 = zoneGet(zid); if (!z0) return;
  const W = materialize(zid, z0);
  const isB = zid[0] === 'b', isX = zid[0] === 'x', cont = CONT(S);
  const supI = isX ? +zid.slice(1) : -1;
  const lens = isX ? (cont ? { L: z0.lenL, R: z0.lenR } : { T: S.reb.taLen }) : null;
  const m = $('#modal');
  let lay = null, fitMsg = '';
  const dOpts = (v, mx) => E.BAR_DIAS.filter(d => d <= (mx || 40)).map(d => `<option value="${d}" ${d === v ? 'selected' : ''}>⌀${d}</option>`).join('');
  const nOpts = v => rng(1, 20, 1).map(n => `<option value="${n}" ${n === v ? 'selected' : ''}>${n}</option>`).join('');
  const xWeb = () => { const gz = R && R.md ? zoneGeo(zid) : null; return gz ? (gz.beff - gz.bw) / 2 : 0; };
  const ownOf = k => lay ? lay.bars.filter(b => b.layer === k && (!isX || b.tag === 'z')) : [];
  // aktualne położenia prętów warstwy w kolejności grup (do pola współrzędnych)
  const posOf = k => {
    const L = W.layers[k]; if (!L || !lay) return '';
    const bk = ownOf(k).slice().sort((a, b) => a.x - b.x), used = new Set(), out = [];
    L.bars.forEach(q => { for (let i = 0; i < q.n; i++) { const b = bk.find(u => !used.has(u) && u.dBar === q.d); if (b) { used.add(b); out.push(Math.round(b.x - xWeb())); } } });
    return out.join('; ');
  };
  const layInfo = k => {
    if (!lay) return '';
    const bk = ownOf(k).slice().sort((a, b) => a.x - b.x); if (!bk.length) return '';
    const L = lay.layers[bk[0].layer]; if (!L) return '';
    const parts = [`x [mm] od lewej krawędzi środnika: ${bk.map(b => Math.round(b.x - xWeb())).join('; ')}`];
    if (L.n > 1) parts.push(`prześwit min. ${fmt(L.gap, 0)} mm ${L.gap >= L.smin - 1e-6 ? '≥' : '<'} ${fmt(L.smin, 0)} mm`);
    if (L.sv !== null && L.sv !== undefined) parts.push(`odstęp od warstwy niższej ${fmt(L.sv, 0)} mm${L.svMin ? ` (min. ${fmt(L.svMin, 0)})` : ''}`);
    return `<span class="${L.ok ? 'okm' : 'iss'}">${parts.join(' · ')}</span>`;
  };
  const supOpts = (L, k) => {
    const n = L.bars.reduce((a, q) => a + q.n, 0), cur = L.toSupp;
    let o = `<option value="all" ${cur === 'all' ? 'selected' : ''}>wszystkie pręty warstwy</option>`;
    for (let i = (k === 0 ? Math.min(2, n) : 0); i < n; i++) o += `<option value="${i}" ${cur === i ? 'selected' : ''}>${i ? i + ' skrajne (pozostałe skrócone)' : 'żaden (wszystkie skrócone)'}</option>`;
    return o;
  };
  const edHTML = () => {
    let h = W.nb > 1 ? `<div class="zl"><p class="hint">Strefa zapisana w starszej wersji jako wiązki po ${W.nb} pręty (${hintBundle(W)}). <button class="lnk" id="zToSingle">Zamień na pręty pojedyncze w warstwach</button></p></div>` : '';
    if (!W.layers.length) h += `<p class="hint keep">${isX ? 'Brak prętów dodatkowych – nad podporą działają tylko pręty ciągłe górne.' : 'Brak prętów w tej strefie.'}</p>`;
    W.layers.forEach((L, k) => {
      h += `<div class="zl" data-l="${k}"><h5>Warstwa ${k + 1}${k === 0 ? (isB ? ' (najniższa)' : ' (najwyższa)') : ''}<span class="sp"></span><button class="del sm" data-zdl="${k}" title="Usuń warstwę">×</button></h5>`;
      L.bars.forEach((q, j) => {
        h += `<div class="zg"><select data-zn="${k}.${j}" aria-label="liczba prętów">${nOpts(q.n)}</select><span>×</span><select data-zd="${k}.${j}" aria-label="średnica">${dOpts(q.d)}</select>${W.nb > 1 ? `<span>(${q.n} wiąz${q.n === 1 ? 'ka' : q.n < 5 ? 'ki' : 'ek'} po ${W.nb})</span>` : ''}${L.bars.length > 1 ? `<button class="del sm" data-zdg="${k}.${j}" title="Usuń grupę">×</button>` : ''}</div>`;
      });
      if (L.bars.length < 4) h += `<div class="zg"><button class="addp" data-zag="${k}">+ pręty innej średnicy w tej warstwie</button></div>`;
      if (k > 0) h += `<div class="zg"><span>Położenie względem warstwy ${k}</span><select data-ztouch="${k}"><option value="0" ${L.touch ? '' : 'selected'}>odstęp normowy między rzędami – max(⌀; dg + 5; 20 mm)</option><option value="1" ${L.touch ? 'selected' : ''}>bezpośrednio na warstwie niższej – pręty w styku, prześwit ≥ max(1,5⌀; dg + 5; 30 mm)</option></select></div>`;
      if (!(k > 0 && L.touch)) h += `<div class="zg"><span>Rozmieszczenie</span><select data-zp="${k}">${PLACE.filter(([v]) => k > 0 || v !== 'pair').map(([v, l]) => `<option value="${v}" ${L.place === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>`;
      else h += `<p class="hint">Pręty ułożone na prętach warstwy niższej (pary jeden nad drugim, zlicowane). Prześwit poziomy w obu warstwach ≥ max(1,5·⌀; d<sub>g</sub> + 5 mm; 30 mm) (⌀ – większa średnica pary); wymaganie ostrzejsze od 8.2(2) z ⌀<sub>n</sub> = ⌀·√2 dla par w styku (8.9.1), więc spełnia też Eurokod; liczba prętów ≤ liczbie prętów warstwy niższej.</p>`;
      if (L.place === 'manual' && !(k > 0 && L.touch)) h += `<div class="zg"><span>x [mm] od lewej krawędzi środnika</span><input class="txt wide" data-zx="${k}" value="${esc(L.xs)}" placeholder="${esc(posOf(k))}" spellcheck="false" autocomplete="off"></div>`;
      if (k > 0 && !L.touch) h += `<div class="zg"><span>Odstęp w świetle od warstwy ${k}</span><input class="txt" data-zgap="${k}" value="${esc(showNum(L.gap))}" placeholder="normowy" spellcheck="false" autocomplete="off"><span>mm</span></div>`;
      if (isB) h += `<div class="zg"><span>Do podpór doprowadzone</span><select data-zs="${k}">${supOpts(L, k)}</select></div>`;
      h += `<div class="zg" data-zi="${k}">${layInfo(k)}</div></div>`;
    });
    if (W.layers.length < 6) h += `<div><button class="addb" id="zAddL">+ dodaj warstwę</button></div>`;
    if (isX) {
      h += `<div class="zl"><h5>Długość prętów dodatkowych (od osi podpory)</h5>`;
      if (cont) h += `<div class="zg"><span>w lewo</span><input class="txt" data-zlen="L" value="${esc(showNum(lens.L))}" placeholder="${esc(autoLenTxt(supI, 'L'))}"><span>m</span><span>w prawo</span><input class="txt" data-zlen="R" value="${esc(showNum(lens.R))}" placeholder="${esc(autoLenTxt(supI, 'R'))}"><span>m</span></div>`;
      else h += `<div class="zg"><span>w głąb przęsła</span><input class="txt" data-zlen="T" value="${esc(showNum(lens.T))}" placeholder="${esc(autoLenTxt(0, 'R'))}"><span>m</span></div>`;
      h += `<p class="hint">Puste – długość wymagana: zasięg |M<sub>Ed</sub>| > M<sub>Rd</sub> prętów ciągłych + a<sub>l</sub> + l<sub>bd</sub> (9.2.1.3), przy podporach skrajnych ≥ 0,2·L (9.2.1.2(1)). Można podać dłuższą; krótsza od wymaganej jest zgłaszana w sprawdzeniach.</p></div>`;
    }
    h += `<div class="hint">${exDetails(`Rozmieszczenie: <b>równomiernie</b> – pręty na całej szerokości między strzemionami; <b>normowo od naroży</b> – w minimalnym prześwicie s<sub>min</sub> = max(⌀; d<sub>g</sub> + 5; 20 mm) (8.2(2)) od obu naroży, z wolnym środkiem na buławę wibratora; <b>sparowane</b> (warstwy 2 i dalsze) – pręty zlicowane z prętami warstwy 1, w tych samych pionach (od naroży), z prześwitem pionowym między warstwami; <b>ręcznie</b> – położenia osi prętów (kolejno dla grup z listy).`, 'Sposoby rozmieszczenia prętów')}</div>`;
    return h;
  };
  const preview = () => {
    let err = '';
    try { lay = zoneLayout(zid, W); } catch (e) { lay = null; err = e.message; }
    const box = $('#zPrev', m); if (!box) return;
    if (!lay) { box.innerHTML = `<p class="hint keep">${err ? 'Błąd układu: ' + esc(err) : 'Podgląd przekroju będzie dostępny po usunięciu błędów danych.'}</p>`; return; }
    const g = zoneGeo(zid), h = g.h, md = R.md;
    let bot, top, kind = 'span', stirQ = null;
    if (isB) { const sg = zoneSeg(zid); bot = lay; top = sg && sg.Lt ? sg.Lt : R.LtM; stirQ = sg ? sg.stir : null; }
    else if (zid === 't') { const sg = md.segs.find(q => q.Lb && q.Lb.n && q.g === g) || md.segs.find(q => q.Lb && q.Lb.n); bot = sg ? sg.Lb : null; top = lay; kind = 'supp'; stirQ = sg ? sg.stir : null; }
    else { const p = md.sups[supI] || md.sups[0]; bot = p && p.LbS ? p.LbS : null; top = lay; kind = 'supp'; stirQ = p && p.gSeg ? p.gSeg.stir : null; }
    const mid = E.midBars(g, R.cv || R.cov.cnom, zoneCtx(zid).dsw, S.reb.mid, bot, top);
    const bars = [...layBars(bot, 'bot', h), ...layBars(top, 'top', h), ...mid];
    const d = kind === 'span' ? (bot && bot.n ? h - bot.eC : 0) : (top && top.n ? h - top.eC : 0);
    const hl = isB ? (b => b.side === 'bot') : zid === 't' ? (b => b.side === 'top') : (b => b.side === 'top' && b.tag === 'z');
    const own = lay.bars.filter(b => !isX || b.tag === 'z'), A = own.reduce((a, b) => a + b.A, 0);
    const nW = window.innerWidth < 700;
    const stQ = stirQ || S.stir; let hold = null; try { hold = E.stirLegs(bot, top, g, R.cov, stQ); } catch (e) { hold = null; }
    let s = (fitMsg ? `<div class="fitmsg">ℹ ${fitMsg}</div>` : '') + sectionSVG({ kind, key: 'zp', bars, d, g, stir: stirQ, hold }, { W: nW ? 290 : 330, H: nW ? 310 : 350, hl });
    if (hold && !hold.ok) s += `<div class="iss">⚠ Strzemiona ${stQ.legs}-cięte nie obejmą prętów w narożach: w warstwie 1 dół ${hold.nB}, góra ${hold.nT} prętów (maks. ${hold.maxLegs || 0} ramion). Dodaj pręty lub zmniejsz liczbę ramion strzemion.</div>`;
    s += `<table class="kv"><tr><td>A<sub>s</sub> strefy</td><td>${fmt(A, 0)}</td><td>mm² (${own.length ? esc(lay.desc && !isX ? lay.desc : zoneDesc(W)) : 'brak'})</td></tr>`;
    if (isX) s += `<tr><td>Razem nad podporą</td><td>${fmt(lay.A, 0)}</td><td>mm² (${esc(lay.desc)})</td></tr>`;
    if (isB && own.some(b => b.supp === false)) { const As = own.filter(b => b.supp !== false).reduce((a, b) => a + b.A, 0); s += `<tr><td>Doprowadzone do podpór</td><td>${fmt(As, 0)}</td><td>mm² (${fmt(A > 0 ? As / A * 100 : 0, 0)}%; ○ – pręty skrócone)</td></tr>`; }
    s += S.reb.vibOn !== false ? `<tr><td>Prześwit na buławę ⌀${S.reb.vib}</td><td>${fmt(lay.open, 0)}</td><td>mm ${lay.open >= S.reb.vib + 10 ? '≥' : '<'} ${S.reb.vib + 10} mm</td></tr></table>` : `<tr><td>Prześwit na buławę</td><td>${fmt(lay.open, 0)}</td><td>mm (nie uwzględniany)</td></tr></table>`;
    // porównanie z wymaganym (przekroje obliczeniowe tej strefy)
    const secsZ = (R.secs || []).filter(q => isB ? (q.kind === 'span' && q.seg && (q.seg.reb ? q.seg.idx : q.seg.adj) === zoneSeg(zid).idx) : isX ? (q.kind === 'supp' && (!cont || q.sup.idx === supI)) : (q.kind === 'supp' && !q.sup.hasX));
    secsZ.forEach(q => { s += asReqHTML(q, lay.A, q.loc); });
    if (zid === 't' && !secsZ.length) s += `<p class="hint">Pręty ciągłe górne: w przęsłach ściskane (montażowe); nad podporami z prętami dodatkowymi liczone razem z nimi.</p>`;
    const iss = lay.issues.slice();
    if (isB && own.length && !own.some(b => b.supp !== false)) iss.push('co najmniej jeden pręt musi być doprowadzony do podpór');
    const extOf = Lz => Lz && Lz.bars.length ? Math.max(...Lz.bars.map(b => b.edge + (b.nb > 1 && b.shape === 'v' ? b.nb * b.dBar : b.nb === 3 && b.shape === 't' ? 1.87 * b.dBar : b.dBar))) : 0;
    if (extOf(bot) + extOf(top) > h - 20) iss.push(`pręty dolne (${Math.round(extOf(bot))} mm od spodu) i górne (${Math.round(extOf(top))} mm od góry) nie mieszczą się w wysokości h = ${h} mm`);
    const dn = Math.max(0, ...own.map(b => b.dn || b.d));
    if (dn > 55) iss.push(`średnica zastępcza wiązki ⌀n = ${fmt(dn, 1)} mm > 55 mm (8.9.1(2))`);
    s += iss.length ? `<div class="iss">✖ ${iss.map(esc).join('<br>✖ ')}</div>` : (own.length ? `<div class="okm">✔ Odstępy prętów wg 8.2(2)${S.reb.vibOn !== false && lay.open >= S.reb.vib + 10 ? ' i prześwit na buławę wibratora (8.2(4))' : ''} spełnione.</div>` : '');
    if (own.length && S.reb.vibOn !== false && lay.open < S.reb.vib + 10) s += `<div class="iss">⚠ Za mały prześwit na buławę wibratora (8.2(4)) – rozważ rozmieszczenie normowe od naroży (wolny środek) lub mniej prętów w warstwie.</div>`;
    box.innerHTML = s;
    themeSvgIn(box);
    W.layers.forEach((L, k) => { const el = $(`[data-zi="${k}"]`, m); if (el) el.innerHTML = layInfo(k); const xi = $(`[data-zx="${k}"]`, m); if (xi) xi.placeholder = posOf(k); });
  };
  const draw = () => {
    const keep = $('.dlg.zpop', m) ? $('.dlg.zpop', m).scrollTop : 0;
    const allBtn = isB && cont && R && R.md && R.md.segs.filter(q => q.reb).length > 1 ? `<button class="btn" id="zAll">Zastosuj do wszystkich przęseł</button>` : '';
    m.innerHTML = `<div class="dlg zpop"><h3>${esc(zoneTitle(zid))}</h3>${z0.auto ? '<p class="hint">Zbrojenie z wcześniejszej wersji programu (układ automatyczny) – pokazano je jako warstwy; po zastosowaniu układ będzie zapisany warstwami.</p>' : ''}<div class="zcols"><div class="zed">${edHTML()}</div><div class="zprev" id="zPrev"></div></div><div class="dbtn">${allBtn}<button class="btn" id="zCancel">Anuluj</button><button class="btn pri" id="zOk">Zastosuj</button></div></div>`;
    m.style.display = 'flex';
    if ($('.dlg.zpop', m)) $('.dlg.zpop', m).scrollTop = keep;
    preview(); bind();
  };
  const L = k => W.layers[+k];
  const bind = () => {
    const fit = () => {
      const mv = autoFit(zid, W);
      fitMsg = mv.length ? 'Rozmieszczenie w warstwach: w każdej warstwie największa liczba prętów, jaka się mieści (odstępy 8.2(2); warstwy w styku – max(1,5⌀; d<sub>g</sub> + 5; 30 mm)), nadmiar – w warstwie wyższej. Przeniesiono automatycznie: ' + mv.map(v => `${v.n}⌀${v.d} z warstwy ${v.k + 1} do warstwy ${v.to + 1}`).join(', ') + '.' : '';
    };
    const sel = (a, fn) => $$(`[${a}]`, m).forEach(el => el.addEventListener('change', () => { fn(el.getAttribute(a), el.value); if (['data-zn', 'data-zd', 'data-zf', 'data-zp', 'data-ztouch'].includes(a)) fit(); draw(); }));
    sel('data-ztouch', (k, v) => { const ly = L(k); ly.touch = v === '1'; if (ly.touch) { ly.place = 'pair'; ly.gap = ''; } });   // nadmiar prętów – do warstwy wyższej (autoFit), bez usuwania
    { const ts = $('#zToSingle', m); if (ts) ts.onclick = () => { const nb = W.nb, sh = W.shape; W.nb = 1; W.shape = 'v';
      if (sh === 'v') { const nl = []; W.layers.forEach(L0 => { nl.push(Object.assign({}, L0, { bars: L0.bars.map(q => ({ n: q.n, d: q.d })) })); for (let i = 1; i < nb; i++) nl.push({ bars: L0.bars.map(q => ({ n: q.n, d: q.d })), place: 'pair', xs: '', gap: '', toSupp: L0.toSupp, touch: true }); }); W.layers = nl.slice(0, 6); }
      else W.layers.forEach(L0 => L0.bars.forEach(q => { q.n *= nb; }));
      fit(); draw(); }; }
    sel('data-zn', (kj, v) => { const [k, j] = kj.split('.'); L(k).bars[+j].n = +v; const ts = L(k).toSupp; if (ts !== 'all' && ts >= L(k).bars.reduce((a, q) => a + q.n, 0)) L(k).toSupp = 'all'; });
    sel('data-zd', (kj, v) => { const [k, j] = kj.split('.'); L(k).bars[+j].d = +v; });
    sel('data-zp', (k, v) => { const ly = L(k); if (v === 'manual' && !ly.xs) ly.xs = posOf(+k); ly.place = v; });
    sel('data-zs', (k, v) => { L(k).toSupp = v === 'all' ? 'all' : +v; });
    $$('[data-zx]', m).forEach(el => el.addEventListener('input', () => { L(el.dataset.zx).xs = el.value; preview(); }));
    $$('[data-zgap]', m).forEach(el => el.addEventListener('input', () => {
      const raw = el.value.trim(), v = parseNum(raw), bad = raw !== '' && (v === null || v < 0);
      el.classList.toggle('bad', bad); if (bad) return;
      L(el.dataset.zgap).gap = raw === '' ? '' : v; preview();
    }));
    $$('[data-zlen]', m).forEach(el => el.addEventListener('input', () => {
      const raw = el.value.trim(), v = parseNum(raw), bad = raw !== '' && (v === null || v < 0);
      el.classList.toggle('bad', bad); if (!bad) lens[el.dataset.zlen] = raw === '' ? '' : v;
    }));
    $$('[data-zdl]', m).forEach(b => b.addEventListener('click', () => { W.layers.splice(+b.dataset.zdl, 1); draw(); }));
    $$('[data-zdg]', m).forEach(b => b.addEventListener('click', () => { const [k, j] = b.dataset.zdg.split('.'); L(k).bars.splice(+j, 1); L(k).toSupp = 'all'; draw(); }));
    $$('[data-zag]', m).forEach(b => b.addEventListener('click', () => { const ly = L(b.dataset.zag), d0 = ly.bars[ly.bars.length - 1].d; const ds = E.BAR_DIAS; ly.bars.push({ n: 1, d: ds[Math.max(0, ds.indexOf(d0) - 1)] }); if (ly.place === 'manual') ly.xs = ''; fit(); draw(); }));
    const add = $('#zAddL', m);
    if (add) add.onclick = () => {
      const last = W.layers[W.layers.length - 1];
      W.layers.push(last ? { bars: [{ n: Math.min(2, last.bars[0].n), d: last.bars[0].d }], place: 'pair', xs: '', gap: '', toSupp: 'all', touch: false } : { bars: [{ n: isB ? 4 : 2, d: isB ? 12 : 12 }], place: 'even', xs: '', gap: '', toSupp: 'all' });
      draw();
    };
    const close = () => { m.style.display = 'none'; };
    $('#zCancel', m).onclick = close;
    const apply = all => {
      const out = E.normZone(JSON.parse(JSON.stringify(W)), E.zoneOf([]));
      const p = zonePath(zid);
      if (isX && cont) { out.lenL = lens.L === undefined ? '' : lens.L; out.lenR = lens.R === undefined ? '' : lens.R; out.extL = z0.extL === undefined ? '' : z0.extL; out.extR = z0.extR === undefined ? '' : z0.extR; }
      if (isX && !cont) S.reb.taLen = lens.T === undefined ? '' : lens.T;
      if (all) S.cont.rebSpans = S.cont.rebSpans.map(() => JSON.parse(JSON.stringify(out)));
      else setP(S, p, out);
      close(); changed(false);
    };
    $('#zOk', m).onclick = () => apply(false);
    const za = $('#zAll', m); if (za) za.onclick = () => apply(true);
  };
  draw();
}
// okno wymiarów przekroju przęsła (belka ciągła – każde przęsło osobno; kształt teowy – wspólny)
function geoPopup(segIdx) {
  const md = R && R.md ? R.md : model();
  let sg = md.segs[segIdx] || md.segs[0];
  if (sg.si === undefined && sg.adj !== undefined) sg = md.segs[sg.adj] || sg;
  const cont = CONT(S), si = sg.si || 0, cur = cont ? ((S.cont.geoSpans || [])[si] || {}) : {};
  const W = { b: cont && cur.b > 0 ? cur.b : S.geom.b, h: cont && cur.h > 0 ? cur.h : S.geom.h, type: S.geom.type, hf: S.geom.hf, beffMode: S.geom.beffMode, beff: S.geom.beff };
  const m = $('#modal');
  const inp = (k, lab, u, mn) => `<div class="zg"><span style="min-width:150px">${lab}</span><input class="txt" data-gw="${k}" value="${esc(showNum(W[k]))}" data-min="${mn}" spellcheck="false" autocomplete="off"><span>${u}</span></div>`;
  const draw = () => {
    m.innerHTML = `<div class="dlg geopop"><h3>Wymiary przekroju${cont ? ` – ${esc(sg.label)}` : ''}</h3>
      ${inp('b', W.type === 'T' ? 'Szerokość środnika b<sub>w</sub>' : 'Szerokość b', 'mm', 60)}${inp('h', 'Wysokość h', 'mm', 120)}
      <div class="zg"><span style="min-width:150px">Kształt</span><select data-gw="type"><option value="rect" ${W.type !== 'T' ? 'selected' : ''}>prostokątny</option><option value="T" ${W.type === 'T' ? 'selected' : ''}>teowy (półka górna)</option></select>${cont ? '<span class="hint">(wspólny dla belki)</span>' : ''}</div>
      ${W.type === 'T' ? inp('hf', 'Grubość półki h<sub>f</sub>', 'mm', 20) + (W.beffMode !== 'auto' ? inp('beff', 'Szerokość półki b<sub>eff</sub>', 'mm', 60) : '<p class="hint">b<sub>eff</sub> wyznaczane wg 5.3.2.1 (ustawienie w Danych).</p>') : ''}
      <div class="iss" id="gErr" style="display:none"></div>
      <p class="hint">Ciężar własny, nośność, ugięcia i rozmieszczenie prętów zostaną przeliczone po zastosowaniu.</p>
      <div class="dbtn">${cont && S.cont.spans.length > 1 ? '<button class="btn" id="gAll">Zastosuj do wszystkich przęseł</button>' : ''}<button class="btn" id="gCancel">Anuluj</button><button class="btn pri" id="gOk">Zastosuj</button></div></div>`;
    m.style.display = 'flex';
    $$('input[data-gw]', m).forEach(el => el.addEventListener('input', () => { const v = parseNum(el.value), bad = v === null || v < +el.dataset.min; el.classList.toggle('bad', bad); if (!bad) W[el.dataset.gw] = v; }));
    const ty = $('select[data-gw="type"]', m); ty.onchange = () => { W.type = ty.value; draw(); };
    const err = () => { const e = []; if (!(W.b >= 60)) e.push('b ≥ 60 mm'); if (!(W.h >= 120)) e.push('h ≥ 120 mm'); if (W.type === 'T' && !(W.hf > 0 && W.hf < W.h)) e.push('0 < h_f < h'); if (W.type === 'T' && W.beffMode !== 'auto' && !(W.beff >= W.b)) e.push('b_eff ≥ b_w'); return e; };
    const apply = all => {
      const e = err(); if (e.length) { const g = $('#gErr', m); g.style.display = ''; g.textContent = 'Popraw: ' + e.join(', '); return; }
      if (cont) {
        S.cont.spans.forEach((_, i) => { const q = (S.cont.geoSpans || [])[i] || {}; if (!(q.b > 0)) setP(S, `cont.geoSpans.${i}.b`, S.geom.b); if (!(q.h > 0)) setP(S, `cont.geoSpans.${i}.h`, S.geom.h); });
        (all ? S.cont.spans.map((_, i) => i) : [si]).forEach(i => { setP(S, `cont.geoSpans.${i}.b`, W.b); setP(S, `cont.geoSpans.${i}.h`, W.h); });
      }
      else { S.geom.b = W.b; S.geom.h = W.h; }
      S.geom.type = W.type; if (W.type === 'T') { S.geom.hf = W.hf; if (W.beffMode !== 'auto') S.geom.beff = W.beff; }
      m.style.display = 'none'; changed(true);
    };
    $('#gOk', m).onclick = () => apply(false); const ga = $('#gAll', m); if (ga) ga.onclick = () => apply(true);
    $('#gCancel', m).onclick = () => { m.style.display = 'none'; };
  };
  draw();
}
// okna pól (strzemiona, siatka przypowierzchniowa, pręty boczne) – pola jak w zakładce Dane
let popRedraw = null;
const POP_TITLE = { stir: 'Strzemiona i zbrojenie poprzeczne', surf: 'Zbrojenie przypowierzchniowe (9.2.4, załącznik J)', mid: 'Pręty boczne (przy bokach przekroju)', cov: 'Otulina zbrojenia (4.4.1)' };
function fieldPopup(key) {
  const m = $('#modal');
  const draw = () => {
    m.innerHTML = `<div class="dlg fpop"><h3>${esc(POP_TITLE[key])}</h3><div class="fields">${fieldsHTML(POP[key], 'pop_' + key)}</div><div class="dbtn"><button class="btn pri" id="nClose">Zamknij</button></div></div>`;
    m.style.display = 'flex';
    bindInputs(m);
    $('#nClose', m).onclick = () => { m.style.display = 'none'; popRedraw = null; };
  };
  popRedraw = draw;
  draw();
}
function zoneClick(z) {
  if (z === 'mid' || z === 'stir' || z === 'surf' || z === 'cov') fieldPopup(z);
  else zonePopup(z);
}
// pasek narzędzi zbrojenia
function rebBar() {
  let h = `<div class="rebbar"><button class="btn sm pri" id="rbAuto" title="Dobór zbrojenia wymaganego wg schematu i obciążeń z zakładki Dane: pręty dolne przęseł, górne ciągłe i nad podporami, pręty boczne (skręcanie); najtańszy układ prętów spełniający SGN, A_s,min, rysy, naprężenia i ugięcia (o ile wystarcza zbrojenie)">Dobierz zbrojenie wymagane</button>`;
  h += `<button class="btn sm" id="rbClr" title="Usuń zbrojenie podłużne we wszystkich przekrojach (strzemiona pozostają)">Wyczyść zbrojenie</button><span class="sp"></span>`;
  h += `<button class="btn sm" data-z="surf">Siatka przypowierzchniowa${R && R.surf && R.surf.req ? ': <b>wymagana</b>' : ''}</button>`;
  h += `<label class="vib vibon" title="Dobór zbrojenia: na każdej krawędzi przekroju pręty jednej średnicy – w przęśle dołem (obie warstwy, narożne i środkowe), u góry pręty ciągłe i dodatkowe nad podporami tej samej średnicy"><input type="checkbox" id="sameD" ${S.reb.sameD !== false ? 'checked' : ''}>Jedna średnica na krawędzi</label>`;
  const vOn = S.reb.vibOn !== false;
  h += `<label class="vib vibon" title="Uwzględniaj prześwit na buławę wibratora (8.2(4)) w doborze i sprawdzeniu zbrojenia; wyłącz, gdy mieszanka jest zagęszczana inaczej (np. SCC, wibratory przyczepne)"><input type="checkbox" id="vibOn" ${vOn ? 'checked' : ''}>Buława wibratora</label>`;
  h += `<label class="vib${vOn ? '' : ' off'}">⌀ <span class="combo sm2"><input data-vib="1" data-k="reb.vib" data-min="20" data-max="90" value="${esc(showNum(S.reb.vib))}" inputmode="decimal" autocomplete="off" spellcheck="false" ${vOn ? '' : 'disabled'} title="Średnica buławy wibratora [mm] (20–90 mm) – prześwit między prętami górnymi ≥ ⌀ + 10 mm"><button tabindex="-1" data-list='${JSON.stringify(VIB)}' aria-label="lista">▾</button></span> mm</label>`;
  return h + `</div>`;
}
// dobór zbrojenia wymaganego (silnik: E.autoReb) – zastępuje zbrojenie podłużne stref; strzemiona i otulina bez zmian
function doAutoReb() {
  // to samo zbrojenie, które pokazuje wykres M w Danych (wynik doboru w tle), a gdy jeszcze nie gotowe – dobór z tymi samymi opcjami
  let r = dimSt.key === dimKey() && dimSt.auto ? dimSt.auto : null;
  if (!r) { try { r = E.autoReb(S, rebOpts()); } catch (e) { console.error(e); toast('Błąd doboru zbrojenia: ' + e.message); return; } }
  if (!r || !r.S || (r.R && r.R.errors && r.R.errors.length && !r.R.req)) { toast('Nie można dobrać zbrojenia: ' + ((r && r.R && r.R.errors[0]) || 'błąd danych')); return; }
  const extra = applyReb(r);
  const RR = r.R, fails = RR && RR.checks ? E.allBad(RR, rebOpts().eta) : [];
  const defl = fails.some(c => c.id === 'f' || c.id === 'ld');
  changed(true);
  if (extra.length) toast(`Dobrano zbrojenie; zmieniono: ${extra.join(', ')}.`, 4000);
  if (!extra.length || fails.length) toast(fails.length ? `Dobrano zbrojenie (jak na wykresie M). Nie spełnione (${fails.length}): ${[...new Set(fails.map(c => c.name.replace(/\s*\(.*$/, '').replace(/ ≤.*| ≥.*/, '')))].slice(0, 3).join('; ')} – przy tych wymiarach nie da się ich spełnić samym zbrojeniem${defl ? ' (ugięcie)' : ''}: zwiększ przekrój (✖ przy wymiarach) albo użyj „Dobierz wszystko”.` : 'Dobrano zbrojenie (jak na wykresie M) – wszystkie sprawdzenia spełnione.', fails.length ? 9000 : 3000);
}
// zastosowanie wyniku doboru (E.autoReb) w belce: zbrojenie podłużne, strzemiona (średnica, ramiona); wynik zapamiętany dla wykresu M
function applyReb(r) {
  S.reb.bot = r.S.reb.bot; S.reb.top = r.S.reb.top; S.reb.topX = r.S.reb.topX; S.reb.mid = r.S.reb.mid;
  if (S.cont && r.S.cont) { S.cont.rebSpans = r.S.cont.rebSpans; S.cont.rebSupps = r.S.cont.rebSupps; }
  const extra = [];
  if (S.mat.autoC && r.cls && r.cls !== S.mat.concrete) { S.mat.concrete = r.cls; extra.push(`klasa betonu ${r.cls}`); }
  if (r.S.stir.legs !== S.stir.legs) { S.stir.legs = r.S.stir.legs; extra.push(`strzemiona ${r.S.stir.legs}-cięte`); }
  if (r.S.stir.d !== S.stir.d) { S.stir.d = r.S.stir.d; extra.push(`strzemiona ⌀${r.S.stir.d}`); }
  S.barEdit = {};
  dimSeed = { key: dimKey(), r };
  return extra;
}
function doClearReb() {
  E.clearReb(S); changed(true); toast('Usunięto zbrojenie podłużne – widoczne są zbrojenie wymagane i statyka.');
}
function bindRebBar(el) {
  $$('[data-z]', el).forEach(b => b.addEventListener('click', () => zoneClick(b.dataset.z)));
  const ba = $('#rbAuto', el), bc = $('#rbClr', el);
  if (ba) ba.onclick = () => doAutoReb();
  if (bc) bc.onclick = () => doClearReb();
  const sd = $('#sameD', el);
  if (sd) sd.addEventListener('change', () => { S.reb.sameD = sd.checked; changed(false); toast(sd.checked ? 'Dobór zbrojenia: jedna średnica prętów na każdej krawędzi przekroju – kliknij „Dobierz zbrojenie wymagane”.' : 'Dobór zbrojenia: dopuszczone różne średnice (narożne i środkowe, ciągłe i dodatkowe).', 3500); });
  const vo = $('#vibOn', el);
  if (vo) vo.addEventListener('change', () => { S.reb.vibOn = vo.checked; changed(false); });
  const v = $('input[data-vib]', el);
  if (v) { const ap = fin => { const x = parseNum(v.value); const bad = x === null || x < 20 || x > 90; v.classList.toggle('bad', bad); if (bad) return; if (x !== S.reb.vib) { S.reb.vib = x; changed(false); } if (fin) v.value = showNum(x); };
    v.addEventListener('input', () => ap(false)); v.addEventListener('change', () => ap(true)); v.addEventListener('keydown', e => { if (e.key === 'Enter') ap(true); }); }
}
// strefy kliknięcia na przekroju: góra, dół, boki (pręty boczne), wnętrze (strzemiona)
// niespełnione warunki → części przekroju (strefa zbrojenia, strzemiona, pręty boczne, wymiary, otulina) podświetlone na czerwono do kliknięcia
const zfOff = new Set();
function failMarks() {
  if (!R || !R.checks || R.bare || !R.md) return [];
  const md = R.md, out = new Map();
  const add = (sel, c) => { if (!out.has(sel)) out.set(sel, []); out.get(sel).push(c.key || c.id + c.at); };
  const secOf = k => (R.secs || []).find(q => q.key === k);
  const STIR = new Set(['Vs1', 'rho1', 'rho2', 'smax', 'scomp', 'st', 'Tst', 'l1', 'hook', 'Thook', 'Tclosed', 'hold', 'VzS', 'Vsp', 'lp']);
  const GEO = new Set(['Vmax', 'VzMax', 'T631', 'sck', 'scqp', 'duct', 'f', 'ld', 'deep', 'slab', 'lat']);
  const TENS = new Set(['Mspan', 'Msupp', 'asmin', 'ascr', 'wk', 'ssk', 'asmax', 'biax', 'N', 'FE']);
  R.checks.filter(c => c.status === 'fail').forEach(c => {
    const at = String(c.at || ''), id = c.id;
    if (id === 'cnom' || at === 'cov') return add('.covhit', c);
    if (id === 'skin' || id === 'Tside') return add('.zhit[data-z="mid"]', c);
    if (STIR.has(id)) return add('.zhit[data-z="stir"]', c);
    if (/^L\d+$/.test(at)) return add(`.zhit[data-z="b${at.slice(1)}"]`, c);
    if (at === 'LtM') return add('.zhit[data-z="t"]', c);
    if (/^T\d+$/.test(at)) return add(`.zhit[data-z="x${at.slice(1)}"]`, c);
    const q = /^[sp]\d+$/.test(at) ? secOf(at) : null;
    if (GEO.has(id)) { const sg = q ? segOfSec(q) : /^[de]\d+/.test(at) ? md.segs[parseInt(at.slice(1), 10)] : null; return add(sg ? `.geohit[data-geo="${sg.idx}"]` : '.geohit', c); }
    if (q && TENS.has(id)) { const z = sectionZones(q); add(`.zhit[data-z="${q.kind === 'span' ? z.bot : z.top}"]`, c); if (id === 'asmax') add(`.zhit[data-z="${q.kind === 'span' ? z.top : z.bot}"]`, c); }
  });
  return [...out.entries()].map(([sel, ks]) => ({ sel, key: sel + '|' + ks.sort().join(',') }));
}
function applyFailMarks(root) {
  if (!root) return;
  failMarks().forEach(m => { if (zfOff.has(m.key)) return; $$(m.sel, root).forEach(el => { el.classList.add('zfail'); el.dataset.zf = m.key; }); });
}
document.addEventListener('pointerdown', e => { const z = e.target.closest && e.target.closest('.zfail'); if (!z) return; zfOff.add(z.dataset.zf); $$('.zfail').forEach(x => { if (x.dataset.zf === z.dataset.zf) x.classList.remove('zfail'); }); }, true);
// zaznaczanie i usuwanie pojedynczych prętów w przekroju (klik – zaznacz, Ctrl/Shift + klik – kilka, Delete – usuń, Esc – anuluj)
let barSel = [];
function barZoneOf(sec, b, ez) {
  if (b.side === 'mid') return 'mid';
  if (b.side === 'bot') return ez.bot;
  return ez.top[0] === 'x' && b.tag === 'b' ? 't' : ez.top;
}
function barSelPaint() {
  $$('.barhit.on').forEach(c => c.classList.remove('on')); $$('.barbar').forEach(e => e.remove());
  barSel = barSel.filter(q => SECREG[q.sid] && document.querySelector(`.bhits[data-sid="${q.sid}"]`));
  if (!barSel.length) return;
  barSel.forEach(q => { const c = document.querySelector(`.bhits[data-sid="${q.sid}"] .barhit[data-bi="${q.bi}"]`); if (c) c.classList.add('on'); });
  const q0 = barSel[0], svg = document.querySelector(`.bhits[data-sid="${q0.sid}"]`).closest('svg'), host = svg.closest('.secedit') || svg.parentElement;
  const ds = barSel.map(q => { const b = SECREG[q.sid].sec.bars[q.bi]; return `⌀${b.dBar || b.d}${b.side === 'mid' ? ' boczny' : ''}`; });
  const bar = document.createElement('div'); bar.className = 'barbar';
  bar.innerHTML = `<span>Zaznaczono ${barSel.length === 1 ? 'pręt' : barSel.length + ' pręty'}: <b>${esc(ds.join(', '))}</b></span><button class="btn sm danger" data-bdel="1" title="Usuń zaznaczone pręty (klawisz Delete)">Usuń (Delete)</button><button class="btn sm" data-besc="1" title="Anuluj zaznaczenie (Esc)">Anuluj</button>`;
  host.insertAdjacentElement('afterend', bar);
}
function deleteSelBars() {
  if (!barSel.length) return;
  const groups = new Map();
  barSel.forEach(({ sid, bi }) => { const reg = SECREG[sid]; if (!reg) return; const b = reg.sec.bars[bi]; if (!b) return; const zid = barZoneOf(reg.sec, b, reg.edit); if (!zid) return; if (!groups.has(zid)) groups.set(zid, []); groups.get(zid).push({ sec: reg.sec, b }); });
  let n = 0, warn = '';
  groups.forEach((list, zid) => {
    if (zid === 'mid') { const rows = new Set(list.map(q => Math.round(q.b.y))).size; const n0 = S.reb.mid.n || 0; S.reb.mid.n = Math.max(0, n0 - rows); n += 2 * Math.min(rows, n0); if (S.reb.mid.ys) S.reb.mid.ys = ''; warn = ' Pręty boczne usuwane są parami (rząd przy obu bokach).'; return; }
    const z0 = zoneGet(zid); if (!z0) return;
    const W = materialize(zid, z0), sec = list[0].sec, side = list[0].b.side, gz = zoneGeo(zid), xWeb = (gz.beff - gz.bw) / 2;
    // położenia pozostałych prętów zachowane (rozmieszczenie „współrzędne”), gdy przekrój pokazuje całą strefę w tej samej geometrii
    const exact = sec.g && Math.abs(gz.bw - sec.g.bw) < 0.5 && Math.abs(gz.beff - sec.g.beff) < 0.5 && (zid[0] === 'x' || sec.kind === 'span');
    const byL = new Map(); list.forEach(q => { const k = q.b.layer; if (!byL.has(k)) byL.set(k, []); byL.get(k).push(q.b); });
    byL.forEach((del, k) => {
      const L = W.layers[k]; if (!L) return;
      const own = sec.bars.filter(b => b.side === side && b.layer === k && !b.cut && barZoneOf(sec, b, SECREG[barSel[0].sid].edit) === zid);
      del.forEach(b => { const gq = L.bars.find(q => q.d === (b.dBar || b.d) && q.n > 0); if (gq) { gq.n--; n += b.nb || 1; } });
      L.bars = L.bars.filter(q => q.n > 0);
      const nL = L.bars.reduce((a, q) => a + q.n, 0);
      if (exact && nL) { const rest = own.filter(b => !del.includes(b)), xs = [];
        L.bars.forEach(q => rest.filter(b => (b.dBar || b.d) === q.d).sort((a, b) => a.x - b.x).slice(0, q.n).forEach(b => xs.push(Math.round(b.x - xWeb))));
        if (xs.length === nL) { L.place = 'manual'; L.xs = xs.join('; '); } }
      if (typeof L.toSupp === 'number') L.toSupp = Math.min(L.toSupp, nL);
    });
    W.layers = W.layers.filter(L => L.bars.length);
    setP(S, zonePath(zid), W);
  });
  barSel = []; $$('.barbar').forEach(e => e.remove());
  if (!n) return;
  changed(true); toast(`Usunięto ${n} ${n === 1 ? 'pręt' : n < 5 ? 'pręty' : 'prętów'}. Pozostałe pręty zostały na swoich miejscach (rozmieszczenie: współrzędne – można je zmienić w oknie strefy).${warn}`, 5000);
}
document.addEventListener('click', e => {
  const c = e.target.closest && e.target.closest('.barhit');
  if (c) { e.preventDefault(); e.stopPropagation(); const sid = c.closest('.bhits').dataset.sid, bi = +c.dataset.bi, i = barSel.findIndex(q => q.sid === sid && q.bi === bi);
    if (e.ctrlKey || e.metaKey || e.shiftKey) { if (i >= 0) barSel.splice(i, 1); else barSel = barSel.filter(q => q.sid === sid).concat([{ sid, bi }]); }
    else barSel = i >= 0 && barSel.length === 1 ? [] : [{ sid, bi }];
    barSelPaint(); return; }
  if (e.target.closest && e.target.closest('[data-bdel]')) { e.preventDefault(); deleteSelBars(); return; }
  if (e.target.closest && e.target.closest('[data-besc]')) { e.preventDefault(); barSel = []; barSelPaint(); return; }
}, true);
document.addEventListener('keydown', e => {
  if (!barSel.length) return;
  if (e.target && e.target.closest && e.target.closest('input, textarea, select')) return;
  if (e.key === 'Delete') { e.preventDefault(); deleteSelBars(); }
  else if (e.key === 'Escape') { barSel = []; barSelPaint(); e.stopPropagation(); }
}, true);
function sectionZones(sec) {
  const md = R.md;
  if (sec.kind === 'span') { const sg = sec.seg; return { top: 't', bot: 'b' + (sg.reb ? sg.idx : sg.adj) }; }
  const p = sec.sup, adj = [p.segR, p.segL].filter(i => i !== null).map(i => md.segs[i]);
  const sg = adj.find(q => q.reb) || adj[0];
  return { top: 'x' + p.idx, bot: 'b' + (sg ? (sg.reb ? sg.idx : sg.adj) : 0) };
}

/* ------------------------------------------- zakładka Dane – panel boczny */
function supRowTxt(p) {
  const dofs = [['x', p.fx], ['y', p.fy], ['z', p.fz], ['φ', p.type === 'fix']].filter(q => q[1]).map(q => q[0]).join(', ');
  const parts = [E.SUP_NAME[p.type] + (p.fy ? '' : ' bez podparcia pionowego'), `blokady: ${dofs || 'brak'}`, `t = ${fmt(p.t, 0)} mm`];
  if (p.kv > 0) parts.push(`k<sub>v</sub> = ${fmt(p.kv, 0)} kN/m`);
  if (p.kr > 0) parts.push(`k<sub>φ</sub> = ${fmt(p.kr, 0)} kNm/rad`);
  if (p.hinge) parts.push('przegub w belce');
  if (p.direct === false) parts.push('podparcie pośrednie');
  return parts.join(' · ');
}
// opis położenia obciążenia
function locTxt(it, md) {
  md = md || model();
  if (!(it.span > 0) || !md.segs[it.span - 1]) return 'cała belka';
  const sg = md.segs[it.span - 1], r = itemRange(it, md);
  return sg.label + (r.e ? `, element ${r.e.k + 1}` : '');
}
const psiF = v => fmt(v, Math.abs(v * 10 - Math.round(v * 10)) > 1e-6 ? 2 : 1);
const KIND_NAME = { perm: 'stałe', imp: 'użytkowe', snow: 'śnieg', wind: 'wiatr', other: 'inne zmienne', acc: 'wyjątkowe' };
function hintLoadList() {
  return 'Obciążenia (stałe, zmienne, wyjątkowe, momenty skręcające) zadajesz <b>tylko na schemacie</b> obok: kliknij element belki, aby dodać obciążenie; kliknij obciążenie, aby je zmienić. Z klawiszem Ctrl (lub w trybie „zaznacz kilka przęseł”) zaznaczysz kilka przęseł i obciążysz je jednym obciążeniem. Zestawienie obciążeń – pod schematem.';
}
document.addEventListener('click', e => {
  const a = e.target.closest('[data-openload]'); if (a) { const [k, i] = a.dataset.openload.split('.'); openLoad(k, +i); return; }
  if (e.target.closest('[data-openall]')) loadPopup({ all: true });
});
// okno jednego, klikniętego obciążenia
function openLoad(k, i) {
  const it0 = arrByKey(k)[i]; if (!it0) return;
  const kind = k === 'acc' ? 'acc' : k === 'perm' ? 'perm' : it0.kind;
  const m = $('#modal');
  const draw = () => {
    const it = arrByKey(k).includes(it0) ? it0 : null;
    if (!it) { m.style.display = 'none'; popRedraw = null; return; }
    const md = model(), multi = it.spans && it.spans.length > 1, r = itemRange(it, md);
    const where = multi ? `przęsła ${it.spans.map(j => md.segs[j - 1] ? md.segs[j - 1].label.replace('przęsło ', '') : j).join(', ')}` : locTxt(it, md);
    const sub = multi ? 'Obciążenie działa na całych zaznaczonych przęsłach (jedno oddziaływanie).' : `Położenia (od / do, x siły) mierzone od początku: ${r.e ? 'elementu' : r.sg ? 'przęsła' : 'belki'} (x = ${fmt(r.x0 / 1000, 2)} m od lewego końca, długość ${fmt(r.L / 1000, 2)} m).`;
    m.innerHTML = `<div class="dlg fpop lpop"><h3>${esc(it.name || KIND_NAME[kind])} – ${esc(where)}</h3><p class="hint">${sub} Wartości charakterystyczne (wyjątkowe – obliczeniowe A<sub>d</sub>).</p>
      <div class="fields">${renderList(kind, q => q === it, { noAdd: true, span: it.span, el: it.el })}</div>
      <div class="dbtn"><button class="btn" id="lMove">Przenieś na inny element…</button><span style="flex:1"></span><button class="btn pri" id="nClose">Zamknij</button></div></div>`;
    m.style.display = 'flex';
    bindInputs(m);
    $('#nClose', m).onclick = () => { m.style.display = 'none'; popRedraw = null; };
    $('#lMove', m).onclick = () => { toast('Kliknij element belki na schemacie, aby przenieść tam obciążenie.'); moveLoad = { k, it }; m.style.display = 'none'; popRedraw = null; };
  };
  popRedraw = draw;
  draw();
}
let moveLoad = null, selSpans = new Set(), selMode = false;
// przeliczenie obciążenia zadanego na elemencie na obciążenie odcinka (przy zmianie podziału na elementy)
function itemToSeg(it, md) {
  const r = itemRange(it, md); if (!r.e) { it.el = ''; return; }
  const off = (r.e.x0 - r.sg.x0) / 1000, L = r.e.L / 1000;
  if (it.q || it.qz || it.mt) { it.x1 = +((it.x1 === '' ? 0 : +it.x1) + off).toFixed(4); it.x2 = +((it.x2 === '' ? L : +it.x2) + off).toFixed(4); }
  it.pts = (it.pts || []).map(p => Object.assign({}, p, { a: +(off + E.absX(r.e.L, p.a, p.ref) / 1000).toFixed(4), ref: 'L' }));
  it.el = '';
}
const allItems = () => [...S.loads.perm, ...S.loads.var, ...S.loads.acc];
function insertNode(seg, k, aEl) {
  const md = model(), sg = md.segs[seg]; if (!sg) return false;
  const e = sg.els[k], a = (e.x0 - sg.x0) / 1000 + aEl;
  if (!(aEl > 0.05 && aEl < e.L / 1000 - 0.05)) { toast('Węzeł musi leżeć wewnątrz elementu (≥ 0,05 m od jego końców).'); return false; }
  allItems().forEach(it => { if (it.span === seg + 1 && it.el !== '' && !(it.spans && it.spans.length > 1)) { if (+it.el === k) itemToSeg(it, md); else if (+it.el > k) it.el = +it.el + 1; } });
  S.nodes.push({ seg, a: +a.toFixed(4), hinge: false });
  return true;
}
function segToSegLevel(seg) { const md = model(); allItems().forEach(it => { if (it.span === seg + 1 && it.el !== '') itemToSeg(it, md); }); }
// okno obciążeń elementu (lub całej belki, lub kilku zaznaczonych przęseł): dodawanie obciążeń; podział elementu węzłami
const KINDS = ['perm', 'imp', 'snow', 'wind', 'other', 'acc'];
function loadPopup(tg) {
  const m = $('#modal');
  const draw = () => {
    const md = model();
    let title, sub, ctx, own, segScope = null, sg = null, e = null, multiSel = null;
    if (tg.spans && tg.spans.length > 1) {
      multiSel = tg.spans.slice().sort((a, b) => a - b);
      title = `przęsła ${multiSel.map(j => md.segs[j - 1] ? md.segs[j - 1].label.replace('przęsło ', '') : j).join(', ')}`;
      sub = 'Obciążenie rozłożone na całych zaznaczonych przęsłach – jedno oddziaływanie (w kombinacjach i układach obciążeń zmiennych przęsła są obciążane oddzielnie).';
      ctx = { span: multiSel[0], el: '', spans: multiSel };
      const key = multiSel.join(',');
      own = it => it.spans && it.spans.length > 1 && it.spans.join(',') === key;
    } else if (tg.all || !md.segs[tg.seg]) {
      title = 'cała belka'; sub = `Działają na całej długości belki L = ${fmt(md.Ltot / 1000, 2)} m (lub na jej części – pola „od / do”). Położenia od lewego końca belki.`;
      ctx = { span: 0, el: '' }; own = it => (!(it.span > 0) || !md.segs[it.span - 1]) && !(it.spans && it.spans.length > 1);
    } else {
      sg = md.segs[tg.seg]; const multi = sg.els.length > 1; e = sg.els[Math.min(tg.el || 0, sg.els.length - 1)];
      title = multi ? `${sg.label} – element ${e.k + 1} z ${sg.els.length}` : sg.label;
      sub = `x = ${fmt(e.x0 / 1000, 2)} ÷ ${fmt(e.x1 / 1000, 2)} m od lewego końca belki, długość ${fmt(e.L / 1000, 2)} m. Położenia (od / do, x siły) mierzone od początku ${multi ? 'elementu' : 'przęsła'}.`;
      ctx = { span: sg.idx + 1, el: multi ? e.k : '' };
      const solo = md.segs.length === 1 && !multi;
      own = it => !(it.spans && it.spans.length > 1) && ((it.span === sg.idx + 1 && (multi ? it.el !== '' && Math.min(+it.el, sg.els.length - 1) === e.k : true)) || (solo && (!(it.span > 0) || !md.segs[it.span - 1])));
      if (multi) segScope = it => it.span === sg.idx + 1 && it.el === '' && !(it.spans && it.spans.length > 1);
    }
    let h = `<div class="dlg fpop lpop"><h3>Obciążenia – ${esc(title)}</h3><p class="hint">${sub} Wartości charakterystyczne (wyjątkowe – obliczeniowe A<sub>d</sub>); kierunek Y – pionowo (+ w dół), Z – poziomo, prostopadle do układu; moment skręcający – wokół osi belki.</p>`;
    h += `<div class="addbar"><span>Dodaj:</span>${KINDS.map(k => `<button class="addb" data-add="${k}" data-span="${ctx.span}" data-el="${ctx.el}"${ctx.spans ? ` data-spans="${ctx.spans.join(',')}"` : ''}>+ ${KIND_NAME[k]}</button>`).join('')}</div>`;
    const lists = (filt, cx) => KINDS.filter(k => listArr(k).some(it => (k === 'acc' || k === 'perm' || it.kind === k) && filt(it))).map(k => renderList(k, filt, cx)).join('');
    const ownH = lists(own, Object.assign({ noAdd: true }, ctx));
    h += `<div class="fields">${ownH || '<p class="lnone">Brak obciążeń – dodaj je przyciskami powyżej.</p>'}</div>`;
    if (segScope) { const sh = lists(segScope, { noAdd: true, span: ctx.span, el: '', where: it => `na przęśle: ${it.x1 === '' ? 0 : showNum(it.x1)} ÷ ${it.x2 === '' ? 'L' : showNum(it.x2)} m od początku przęsła` }); if (sh) h += `<h4 class="lsec">Obciążenia całego przęsła (obejmują też ten element)</h4><div class="fields">${sh}</div>`; }
    if (sg) {
      h += `<h4 class="lsec">Węzły i podział elementu</h4><div class="zg"><span>Wstaw węzeł w odległości</span><input class="txt" id="nA" value="${esc(showNum(+(e.L / 2000).toFixed(3)))}"><span>m od początku elementu</span><label class="chk"><input type="checkbox" id="nH"><span>przegub</span></label><button class="btn sm" id="nIns">Wstaw</button></div>`;
      h += `<div class="zg"><span>Podziel element na</span><select id="nDiv">${[2, 3, 4, 5, 6].map(v => `<option value="${v}">${v} równe części</option>`).join('')}</select><button class="btn sm" id="nDivB">Podziel</button></div>`;
      const ns = md.unodes.filter(q => q.seg === sg.idx);
      if (ns.length) h += `<div class="zg"><span>Węzły w przęśle:</span>${ns.map(q => `<button class="btn sm" data-node="${q.i}">${q.hinge ? '◯ przegub' : '● węzeł'} a = ${fmt(q.a / 1000, 2)} m</button>`).join('')}</div>`;
    }
    h += `<div class="dbtn"><button class="btn pri" id="nClose">Zamknij</button></div></div>`;
    const keep = $('.dlg.lpop', m) ? $('.dlg.lpop', m).scrollTop : 0;
    m.innerHTML = h; m.style.display = 'flex';
    $('.dlg.lpop', m).scrollTop = keep;
    bindInputs(m);
    $('#nClose', m).onclick = () => { m.style.display = 'none'; popRedraw = null; };
    $$('[data-node]', m).forEach(b => b.addEventListener('click', () => nodePopup(+b.dataset.node)));
    const ins = $('#nIns', m);
    if (ins) ins.onclick = () => { const a = parseNum($('#nA', m).value); if (a === null) return; if (insertNode(sg.idx, e.k, a)) { if ($('#nH', m).checked) S.nodes[S.nodes.length - 1].hinge = true; changed(true); } };
    const dv = $('#nDivB', m);
    if (dv) dv.onclick = () => { const n = +$('#nDiv', m).value; for (let j = n - 1; j >= 1; j--) insertNode(sg.idx, e.k, e.L / 1000 * j / n); changed(true); };
    themeSvgIn(m);
  };
  popRedraw = draw;
  draw();
}
// okno węzła: położenie, przegub, usunięcie
// obciążenie w węźle / węźle podporowym: siła pionowa P (stała lub użytkowa), siła podłużna N_Ed (stała na długości belki), moment skręcający T
const nodeItem = xk => { for (const k of ['perm', 'var']) { const i = S.loads[k].findIndex(it => it.node === xk); if (i >= 0) return { k, i, it: S.loads[k][i] }; } return null; };
function nodeLoadHTML(x) {
  const xk = Math.round(x), f = nodeItem(xk), P = f && f.it.pts[0] ? f.it.pts[0].P : '', T = f && f.it.pts[0] ? f.it.pts[0].T || '' : '';
  return `<h4 class="lsec">Obciążenie w węźle (x = ${fmt(x / 1000, 2)} m)</h4>
    <div class="zg"><span>Siła pionowa P (+ w dół)</span><input class="txt" id="ndP" value="${esc(showNum(P))}" placeholder="brak" autocomplete="off"><span>kN</span></div>
    <div class="zg"><span>Moment skręcający T</span><input class="txt" id="ndT" value="${esc(showNum(T))}" placeholder="brak" autocomplete="off"><span>kNm</span></div>
    <div class="zg"><span>Rodzaj obciążenia P, T</span><select id="ndK"><option value="perm" ${!f || f.k === 'perm' ? 'selected' : ''}>stałe (G)</option><option value="var" ${f && f.k === 'var' ? 'selected' : ''}>użytkowe (Q, kat. ${f && f.k === 'var' ? f.it.cat : 'B'})</option></select><span></span></div>
    <div class="zg"><span>Siła pozioma – podłużna N<sub>Ed</sub> (+ ściska)</span><input class="txt" id="ndN" value="${esc(showNum(S.loads.NEd || ''))}" placeholder="0" autocomplete="off"><span>kN</span></div>
    <p class="hint">P i T – wartości charakterystyczne (zestawienie obciążeń, kombinacje SGN/SGU). N<sub>Ed</sub> – wartość obliczeniowa (+ ściska), w modelu stała na całej długości belki (przeniesiona przez podporę nieprzesuwną); na schemacie – pozioma strzałka przy tym węźle.</p>`;
}
function nodeLoadSave(m, x) {
  const xk = Math.round(x), P = parseNum($('#ndP', m).value || '0') || 0, T = parseNum($('#ndT', m).value || '0') || 0, k = $('#ndK', m).value, N = parseNum($('#ndN', m).value || '0');
  const f = nodeItem(xk);
  if (f && (f.k !== k || (!P && !T))) S.loads[f.k].splice(f.i, 1);
  if (P || T) {
    const g = nodeItem(xk), base = { name: `Węzeł x = ${fmt(x / 1000, 2)} m`, q: 0, span: 0, x1: '', x2: '', node: xk, dir: T && !P ? 't' : 'y', tor: !!T, pts: [{ P: P || 0, T: T || 0, a: +(x / 1000).toFixed(4), ref: 'L' }] };
    if (g) Object.assign(g.it, base); else S.loads[k].push(k === 'var' ? Object.assign({ kind: 'imp', cat: 'B', alt: 'low', qz: 0, p0: 0.7, p1: 0.5, p2: 0.3 }, base) : base);
  }
  if (N !== null) { if (N !== S.loads.NEd || N) S.loads.NEdX = N ? xk : ''; S.loads.NEd = N; }
}
// okno obciążenia węzłowego (kropka węzła na schemacie)
function nEdAt(md) {
  if (!S.loads.NEd || (R && R.st && R.st.manual)) return null;
  if (S.loads.NEdX !== '' && S.loads.NEdX !== undefined) return Math.max(0, Math.min(md.Ltot, +S.loads.NEdX));
  const p0 = md.sups.find(p => p.fx); return p0 && p0.x < md.Ltot / 2 ? md.Ltot : 0;
}
function nodeLoadPopup(x, label) {
  const m = $('#modal');
  m.innerHTML = `<div class="dlg barpop"><h3>Obciążenie w węźle – ${esc(label || '')}</h3><div class="zl">${nodeLoadHTML(x).replace(/<h4 class="lsec">[^<]*<\/h4>/, '')}</div>
    <div class="dbtn"><button class="btn dng" id="ndDel" ${nodeItem(Math.round(x)) ? '' : 'disabled'}>Usuń P i T</button><span class="sp"></span><button class="btn" id="ndCancel">Anuluj</button><button class="btn pri" id="ndOk">Zastosuj</button></div></div>`;
  m.style.display = 'flex';
  const ok = () => { nodeLoadSave(m, x); m.style.display = 'none'; changed(true); };
  $('#ndOk', m).onclick = ok; $('#ndCancel', m).onclick = () => { m.style.display = 'none'; };
  $('#ndDel', m).onclick = () => { $('#ndP', m).value = ''; $('#ndT', m).value = ''; ok(); };
  $$('input', m).forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') ok(); }));
  setTimeout(() => { const f = $('#ndP', m); if (f) { f.focus(); f.select(); } }, 30);
}
function nodePopup(i) {
  const n = S.nodes[i]; if (!n) return;
  const md = model(), sg = md.segs[n.seg], m = $('#modal');
  m.innerHTML = `<div class="dlg fpop sm"><h3>Węzeł – ${esc(sg ? sg.label : '')}</h3><p class="hint">Węzeł dzieli przęsło na elementy (do zadawania obciążeń). Przegub uwalnia obrót – moment zginający w tym miejscu jest równy zeru (np. belka przegubowa typu Gerbera).</p>
    <div class="zg"><span>Położenie a</span><input class="txt" id="nA" value="${esc(showNum(n.a))}"><span>m od początku przęsła (L = ${fmt(sg ? sg.L / 1000 : 0, 2)} m)</span></div>
    <label class="chk"><input type="checkbox" id="nH" ${n.hinge ? 'checked' : ''}><span>Przegub w belce (moment = 0)</span></label>
    <div class="dbtn"><button class="btn dng" id="nDel">Usuń węzeł</button><span style="flex:1"></span><button class="btn" id="nCancel">Anuluj</button><button class="btn pri" id="nOk">Zastosuj</button></div></div>`;
  m.style.display = 'flex'; popRedraw = null;
  $('#nCancel', m).onclick = () => { m.style.display = 'none'; };
  $('#nDel', m).onclick = () => { segToSegLevel(n.seg); S.nodes.splice(i, 1); m.style.display = 'none'; changed(true); };
  $('#nOk', m).onclick = () => {
    const a = parseNum($('#nA', m).value);
    if (a === null || !(a > 0.05 && sg && a < sg.L / 1000 - 0.05)) { $('#nA', m).classList.add('bad'); return; }
    if (Math.abs(a - n.a) > 1e-6) segToSegLevel(n.seg);
    { const f = nodeItem(Math.round(sg.x0 + n.a * 1000)); if (f && Math.abs(a - n.a) > 1e-6) { f.it.node = Math.round(sg.x0 + a * 1000); f.it.pts[0].a = +((sg.x0 + a * 1000) / 1000).toFixed(4); f.it.name = `Węzeł x = ${fmt((sg.x0 + a * 1000) / 1000, 2)} m`; } }   // obciążenie węzłowe przesuwa się z węzłem
    n.a = a; n.hinge = $('#nH', m).checked; m.style.display = 'none'; changed(true);
  };
}
// zestawienie obciążeń pod schematem (kliknięcie – edycja tego obciążenia)
function loadSummaryHTML() {
  const md = model(), rows = [];
  const val = it => { const c = []; const sub = it.kind === 'acc' ? 'd' : 'k';
    if (it.dir !== 'z' && it.dir !== 't' && it.shape === 't' && (it.q || it.q2)) c.push(`q<sub>${sub}</sub> = ${fmt(+it.q || 0, 2)} → ${fmt(+it.q2 || 0, 2)} kN/m`);
    else if (it.dir !== 'z' && it.dir !== 't' && it.shape === 'p' && it.prof) c.push(`q<sub>${sub}</sub>(x) = ${esc(it.prof)} [m : kN/m]`);
    else if (it.dir !== 'z' && it.dir !== 't' && it.q) c.push(`q<sub>${sub}</sub> = ${fmt(it.q, 2)} kN/m`);
    if (it.dir === 'y' && +it.ang) c.push(`α = ${fmt(+it.ang, 0)}° od pionu`);
    if ((it.dir === 'z' || it.dir === 'yz') && it.qz) c.push(`q<sub>z</sub> = ${fmt(it.qz, 2)} kN/m`);
    if ((it.dir === 't' || it.tor) && it.mt) c.push(`m<sub>t</sub> = ${fmt(it.mt, 2)} kNm/m`);
    (it.spans && it.spans.length > 1 ? [] : it.pts || []).forEach(p => { if (p.P && it.dir !== 'z' && it.dir !== 't') c.push(`P = ${fmt(p.P, 1)} kN`); if (p.Pz && it.dir !== 'y') c.push(`P<sub>z</sub> = ${fmt(p.Pz, 1)} kN`); if (p.T && (it.dir === 't' || it.tor)) c.push(`T = ${fmt(p.T, 1)} kNm`); });
    return c.join(', ') || '—'; };
  const wh = it => it.spans && it.spans.length > 1 ? `przęsła ${it.spans.map(j => md.segs[j - 1] ? md.segs[j - 1].label.replace('przęsło ', '') : j).join(', ')}` : locTxt(it, md) + ((it.x1 !== '' || it.x2 !== '') ? ` (${it.x1 === '' ? 0 : showNum(it.x1)}÷${it.x2 === '' ? 'L' : showNum(it.x2)} m)` : '');
  if (S.loads.sw && R && R.md && R.md.segs[0].g) rows.push(`<tr class="info"><td>G₀</td><td>ciężar własny</td><td>stałe</td><td>${R.gVar ? R.md.segs.map(sg => fmt(sg.g.selfW, 2)).join(' / ') : fmt(R.g.selfW, 2)} kN/m</td><td>cała belka</td></tr>`);
  const ck = (k, i, it) => `<input type="checkbox" class="ldon" data-ldon="${k}.${i}" ${it.off ? '' : 'checked'} title="${it.off ? 'Wyłączone – zaznacz, aby uwzględnić w obliczeniach' : 'Uwzględniane – odznacz, aby pominąć w obliczeniach i wykresach'}" aria-label="uwzględnij obciążenie">`;
  const cls = it => it.off ? ' class="ldoff"' : '';
  S.loads.perm.forEach((it, i) => { if (E.hasVal(it)) rows.push(`<tr data-openload="perm.${i}"${cls(it)}><td>${ck('perm', i, it)} G</td><td>${esc(it.name || 'stałe')}</td><td>stałe</td><td>${val(it)}</td><td>${esc(wh(it))}</td></tr>`); });
  S.loads.var.forEach((it, i) => { if (E.hasVal(it)) rows.push(`<tr data-openload="var.${i}"${cls(it)}><td>${ck('var', i, it)} ${esc(it.off ? '–' : idOf('imp', i))}</td><td>${esc(it.name || KIND_NAME[it.kind])}</td><td>${esc(KIND_NAME[it.kind])}</td><td>${val(it)}</td><td>${esc(wh(it))}</td></tr>`); });
  S.loads.acc.forEach((it, i) => { if (E.hasVal(it)) rows.push(`<tr data-openload="acc.${i}"${cls(it)}><td>${ck('acc', i, it)} ${esc(it.off ? '–' : idOf('acc', i))}</td><td>${esc(it.name || 'wyjątkowe')}</td><td>wyjątkowe</td><td>${val(it)}</td><td>${esc(wh(it))}</td></tr>`); });
  if (S.loads.TEd) rows.push(`<tr class="info"><td>T<sub>Ed</sub></td><td>moment skręcający (podany wprost)</td><td>obliczeniowe</td><td>${fmt(S.loads.TEd, 1)} kNm</td><td>stały na długości</td></tr>`);
  return `<table class="ldsum"><tr><th></th><th>Nazwa</th><th>Rodzaj</th><th>Wartość</th><th>Położenie</th></tr>${rows.join('') || '<tr><td colspan="5" class="lnone">brak obciążeń – kliknij element belki na schemacie</td></tr>'}</table>${combSumHTML()}`;
}
// wartości kombinacji dla obciążeń równomiernych na całej długości – do porównania z innymi programami (q_Ed, q_k, q_qp)
function combSumHTML() {
  const L = S.loads, gG = +L.gG || 1.35, gQ = +L.gQ || 1.5, xi = +L.xi || 0.85;
  const fullU = it => E.hasLoad(it) && (it.dir === 'y' || !it.dir) && !(it.qz || it.mt) && !(it.pts || []).some(p => p.P || p.Pz || p.T) && (it.x1 === '' || +it.x1 === 0) && it.x2 === '' && (!it.spans || it.spans.length <= 1) && (+it.span || 0) === 0 && (it.el === undefined || it.el === '' || it.el === null) && !it.tor;
  const perm = L.perm.filter(E.hasLoad), vars = L.var.filter(E.hasLoad);
  const formula = L.comb === '610' ? `(6.10): ${fmt(gG, 2)}·G + ${fmt(gQ, 2)}·Q<sub>1</sub> + ${fmt(gQ, 2)}·Σψ<sub>0</sub>Q<sub>i</sub>` : `(6.10a): ${fmt(gG, 2)}·G + ${fmt(gQ, 2)}·Σψ<sub>0</sub>Q<sub>i</sub> oraz (6.10b): ${fmt(xi, 2)}·${fmt(gG, 2)}·G + ${fmt(gQ, 2)}·Q<sub>1</sub> + ${fmt(gQ, 2)}·Σψ<sub>0</sub>Q<sub>i</sub> – mniej korzystna`;
  let h = `<div class="combsum xres"><b>Kombinacje SGN</b> wg PN-EN 1990 ${formula} <small>(zmiana: Dane → Obciążenia → „Kombinacja SGN”); SGU: charakterystyczna G + Q<sub>1</sub> + Σψ<sub>0</sub>Q<sub>i</sub>, quasi-stała G + Σψ<sub>2</sub>Q<sub>i</sub>.</small>`;
  if (!perm.concat(vars).every(fullU) || !(R && R.md && R.md.segs[0].g) || (R.gVar && S.loads.sw)) return h + '</div>';
  const G = (S.loads.sw ? R.g.selfW : 0) + perm.reduce((a, it) => a + (+it.q || 0), 0);
  const Q = vars.map(it => ({ q: +it.q || 0, p: E.psiOf(it) }));
  const lead = f => Q.length ? Math.max(...Q.map((q1, i) => f(q1, Q.filter((_, j) => j !== i)))) : f(null, []);
  const a = gG * G + gQ * Q.reduce((s2, q) => s2 + q.p.p0 * q.q, 0);
  const b = lead((q1, rest) => xi * gG * G + gQ * (q1 ? q1.q : 0) + gQ * rest.reduce((s2, q) => s2 + q.p.p0 * q.q, 0));
  const c610 = lead((q1, rest) => gG * G + gQ * (q1 ? q1.q : 0) + gQ * rest.reduce((s2, q) => s2 + q.p.p0 * q.q, 0));
  const qd = L.comb === '610' ? c610 : Math.max(a, b);
  const qk = lead((q1, rest) => G + (q1 ? q1.q : 0) + rest.reduce((s2, q) => s2 + q.p.p0 * q.q, 0)), qqp = G + Q.reduce((s2, q) => s2 + q.p.p2 * q.q, 0);
  h += `<br>Obciążenie równomierne na całej długości: G<sub>k</sub> = ${fmt(G, 2)} kN/m${S.loads.sw ? ` (w tym ciężar własny ${fmt(R.g.selfW, 2)})` : ''}, Q<sub>k</sub> = ${Q.map(q => fmt(q.q, 2)).join(' + ') || '0'} kN/m → <b>q<sub>Ed</sub> = ${fmt(qd, 3)} kN/m</b>${L.comb === '610' ? '' : ` (6.10a: ${fmt(a, 3)}, 6.10b: ${fmt(b, 3)}; dla porównania 6.10: ${fmt(c610, 3)})`}, q<sub>k</sub> = ${fmt(qk, 3)} kN/m, q<sub>qp</sub> = ${fmt(qqp, 3)} kN/m.`;
  return h + '</div>';
}
function renderDataSide() {
  const el = $('#dataside'); if (!el) return;
  const W = Math.max(300, Math.min(820, ((el.clientWidth || 600) - 26) * 0.78));     // rysunek skalowany do szerokości panelu (większe opisy)
  const md = R && R.md ? R.md : model();
  const dgSw = `<span class="segsw sm dgsw" role="tablist" aria-label="Wykres pod belką">${[['M', 'M + pręty'], ['V', 'V + strzemiona'], ['f', 'ugięcie'], ['N', 'N'], ['R', 'R'], ['off', 'bez wykresu']].map(([k, l]) => `<button data-dgm="${k}" class="${diagMode === k ? 'on' : ''}" title="${k === 'M' ? 'Momenty zginające (obwiednia SGN) i wymagana liczba prętów w każdym miejscu belki' : k === 'V' ? 'Siły poprzeczne (obwiednia SGN), strefy strzemion i wymagany zasięg zagęszczenia' : k === 'f' ? 'Linia ugięcia długotrwałego (quasi-stałe + skurcz, 7.4.3), ugięcie graniczne i odwrotna strzałka' : k === 'N' ? 'Siła podłużna N_Ed' : k === 'R' ? 'Reakcje podpór: R_Ed (obwiednia SGN max / min) i R_k (charakterystyczne)' : 'Ukryj wykres'}">${l}</button>`).join('')}</span>`;
  let h = `<div class="box"><div class="schsticky">${beamTabsHTML()}<h4 class="schhd">Schemat statyczny i obciążenia${dgSw}</h4><div class="schemewrap ${selMode ? 'selmode' : ''}">${schemeSVG(W, { edit: true, sel: selSpans, diag: diagMode === 'off' ? null : diagMode })}</div></div>`;
  const spanSegs = md.segs.filter(sg => sg.kind === 'span');
  const selTxt = Array.from(selSpans).sort((a, b) => a - b).map(i => md.segs[i] ? md.segs[i].label.replace('przęsło ', '') : '').filter(Boolean);
  h += `<div class="selbar">${md.segs.length > 1 ? `<label class="chk sm"><input type="checkbox" id="selMode" ${selMode ? 'checked' : ''}><span>zaznacz kilka przęseł</span></label>` : ''}${selSpans.size ? `<span>Zaznaczone: <b>przęsła ${selTxt.join(', ')}</b></span><button class="btn sm pri" id="selLoad">Obciąż zaznaczone…</button><button class="btn sm" id="selClr">Wyczyść</button>` : (md.segs.length > 1 ? `<button class="btn sm" id="selAll">Zaznacz wszystkie przęsła</button>` : '')}<button class="lnk" data-openall="1">obciążenia całej belki…</button></div>`;
  h += `<div class="optchk"><label class="chk sm"><input type="checkbox" data-ck="loads.sw" ${S.loads.sw ? 'checked' : ''}><span>Uwzględnij ciężar własny belki (25 kN/m³; dla teowej – tylko żebro)</span></label>
    <label class="chk sm"><input type="checkbox" data-ck="reb.useComp" ${S.reb.useComp !== false ? 'checked' : ''}><span>Uwzględnij zbrojenie górne w nośności na zginanie (przekrój podwójnie zbrojony)</span></label>
    <label class="chk sm"><input type="checkbox" data-ck="loads.redM" ${S.loads.redM ? 'checked' : ''}><span>Redukcja momentu nad szerokimi podporami wg <span class="nrefx">5.3.2.2</span> (moment przy licu / ΔM = F·t/8)</span></label>
    <label class="chk sm"><input type="checkbox" data-ck="stir.redV" ${S.stir.redV ? 'checked' : ''}><span>Redukcja siły poprzecznej przy podporach wg 6.2.1(8) – V<sub>Ed</sub> w odległości d od lica</span></label>
    ${CONT(S) ? `<div class="firerow" id="redRow"><label class="chk sm"><input type="checkbox" id="redOn" ${S.loads.redist ? 'checked' : ''}><span>Redystrybucja momentów zginających wg <span>5.5</span> (belka ciągła)</span></label><select id="redD" ${S.loads.redist ? '' : 'disabled'} title="Współczynnik redystrybucji δ = M po redystrybucji / M sprężysty">${[['auto', 'δ automatycznie (min. dopuszczalne)'], ['0.9', 'δ = 0,90'], ['0.85', 'δ = 0,85'], ['0.8', 'δ = 0,80'], ['0.75', 'δ = 0,75'], ['0.7', 'δ = 0,70']].map(([v, l]) => `<option value="${v}" ${String(S.loads.redist || 'auto') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>${R && R.st && R.st.redist && R.st.redist.length ? `<span class="hint" style="margin:0">${R.st.redist.map(q => `${esc(q.sup.label)}: δ = ${fmt(q.delta, 2)}, M = ${fmt(q.M0 / 1e6, 1)} → ${fmt(q.M / 1e6, 1)} kNm`).join('; ')}</span>` : ''}</div>` : ''}
    <div class="firerow" id="fireRow"><label class="chk sm"><input type="checkbox" id="fireOn" ${S.fire.R && S.fire.R !== '-' ? 'checked' : ''}><span>Odporność ogniowa (REI) wg EN 1992-1-2</span></label><select id="fireR" ${S.fire.R && S.fire.R !== '-' ? '' : 'disabled'}>${['R30', 'R60', 'R90', 'R120', 'R180', 'R240'].map(r => `<option value="${r}" ${S.fire.R === r || (!(S.fire.R && S.fire.R !== '-') && r === 'R60') ? 'selected' : ''}>${r}</option>`).join('')}</select></div>
    ${fireStatusHTML()}</div>`;
  h += `<div class="hint">${exDetails('Kliknij <b>element belki</b>, aby dodać obciążenie albo wstawić węzeł lub przegub (Ctrl + klik – zaznaczanie kilku przęseł); <b>obciążenie</b> – aby je zmienić; <b>węzeł</b> – aby go przesunąć lub zamienić w przegub; <b>podporę</b> – aby zablokować / odblokować przesuw x, y, z i obrót, ustawić szerokość, podatność i rodzaj podparcia. Redukcja siły poprzecznej (6.2.1(8)) jest stosowana tylko przy obciążeniu przyłożonym do górnej powierzchni i podparciu bezpośrednim (ustawienia w oknie obciążenia i podpory).', 'Jak zadawać obciążenia i podpory?')}</div>`;
  h += `<h4 class="lsec">Zestawienie obciążeń</h4>${loadSummaryHTML()}`;
  h += `<h4 class="lsec">Podpory</h4><table class="kv suptab">${md.sups.map(p => `<tr data-sup="${p.idx}" title="Kliknij, aby zmienić"><td><b>${esc(p.label)}</b></td><td>${supRowTxt(p)}</td><td><button class="lnk" data-sup="${p.idx}">zmień…</button></td></tr>`).join('')}</table></div>`;
  if (R && R.errors && R.errors.length) h += errBox();
  else if (R && R.warnings && R.warnings.length) h += `<div class="msgs">${R.warnings.map(e => `<div class="msg wrn">${esc(e)}</div>`).join('')}</div>`;
  if (R && R.secs && R.secs.length && !(R.errors && R.errors.length)) {
    const ss = R.secs.filter(q => q.kind === 'span');
    const list = (ss.length ? ss : [R.secs[0]]);
    const w = list.length > 1 ? 200 : 250;
    h += `<div class="box"><h4>${list.length > 1 ? 'Przekroje przęseł' : 'Przekrój – ' + esc(list[0].loc)}</h4><div class="minisecs">${list.map(sec => `<div class="minisec">${list.length > 1 ? `<div class="mst">${esc(cap(sec.loc))} – ${sec.g.bw}×${sec.g.h}</div>` : ''}${sectionSVG(sec, { W: w, H: w + 20, na: false, edit: sectionZones(sec) })}<div class="msd">dół ${esc(sec.tens.desc)} · góra ${esc(sec.comp && sec.comp.n ? sec.comp.desc : '—')}</div></div>`).join('')}</div><p class="hint">Kliknij krawędź przekroju (dół, góra, bok), wnętrze (strzemiona), wymiar b lub h albo opis otuliny, aby zmienić zbrojenie, wymiary lub otulinę.</p></div>`;
  }
  el.innerHTML = h;
  themeSvgIn(el);
  applyFailMarks(el);
  zoomApply(el);
  $$('.supp', el).forEach(g => g.addEventListener('click', ev => { ev.stopPropagation(); supportPopup(+g.dataset.sup); }));
  $$('tr[data-sup], button[data-sup]', el).forEach(b => b.addEventListener('click', ev => { ev.stopPropagation(); supportPopup(+b.dataset.sup); }));
  $$('.elm', el).forEach(g => g.addEventListener('click', ev => {
    const seg = +g.dataset.seg, k = +g.dataset.el;
    if (moveLoad) { const it = moveLoad.it, md2 = model(), sg2 = md2.segs[seg]; it.spans = []; it.span = seg + 1; it.el = sg2.els.length > 1 ? k : ''; it.x1 = ''; it.x2 = ''; moveLoad = null; changed(true); return; }
    if (ev.ctrlKey || ev.metaKey || ev.shiftKey || selMode) { if (selSpans.has(seg)) selSpans.delete(seg); else selSpans.add(seg); rendered.data = false; renderDataSide(); return; }
    loadPopup({ seg, el: k });
  }));
  $$('.nod', el).forEach(g => g.addEventListener('click', ev => { ev.stopPropagation(); nodePopup(+g.dataset.node); }));
  $$('.ldnode', el).forEach(g => g.addEventListener('click', ev => { ev.stopPropagation(); nodeLoadPopup(+g.dataset.nx, g.dataset.nl); }));
  bindZoneEdit(el);
  $$('.nedarr[data-nx]', el).forEach(g => g.addEventListener('click', ev => { ev.stopPropagation(); const x = +g.dataset.nx; nodeLoadPopup(x, x < 1 ? 'koniec lewy' : x > R.md.Ltot - 1 ? 'koniec prawy' : `x = ${fmt(x / 1000, 2)} m`); }));
  $$('.ldchk', el).forEach(g => g.addEventListener('click', ev => { ev.stopPropagation(); const k = g.dataset.lk, i = +g.dataset.li; const arr = k === 'perm' ? S.loads.perm : k === 'acc' ? S.loads.acc : S.loads.var; const it = arr[i]; if (!it) return; it.off = !it.off; changed(true); }));
  $$('.ld', el).forEach(g => g.addEventListener('click', ev => { ev.stopPropagation(); const lk = g.dataset.lk; if (lk === 'sw' || lk === 'gk') { const f = $('#inputs [data-k="loads.sw"]'); if (f) { f.focus(); f.closest('label').scrollIntoView({ block: 'center' }); } return; } openLoad(lk, +g.dataset.li); }));
  $$('[data-go]', el).forEach(b => b.addEventListener('click', () => U.selectTab(b.dataset.go)));
  $$('input[data-ldon]', el).forEach(cb => { cb.addEventListener('click', ev => ev.stopPropagation()); cb.addEventListener('change', () => { const [k, i] = cb.dataset.ldon.split('.'); const it = (k === 'perm' ? S.loads.perm : k === 'acc' ? S.loads.acc : S.loads.var)[+i]; if (it) { it.off = !cb.checked; changed(true); } }); });
  $$('.minisec .zhit, .minisec .covhit', el).forEach(r => r.addEventListener('click', ev => { ev.stopPropagation(); zoneClick(r.dataset.z); }));
  $$('.geohit', el).forEach(r => r.addEventListener('click', ev => { ev.stopPropagation(); geoPopup(+r.dataset.geo); }));
  $$('[data-ck]', el).forEach(cb => cb.addEventListener('change', () => { setP(S, cb.dataset.ck, cb.checked); changed(false); }));
  $$('[data-dgm]', el).forEach(b => b.addEventListener('click', () => { diagMode = b.dataset.dgm; try { localStorage.setItem('bz.diag', diagMode); } catch (e) { /* */ } renderDataSide(); }));
  const ro = $('#redOn', el), rdd = $('#redD', el);
  if (ro) ro.onchange = () => { S.loads.redist = ro.checked ? (rdd.value === 'auto' ? 'auto' : +rdd.value) : ''; changed(false); };
  if (rdd) rdd.onchange = () => { if (ro.checked) { S.loads.redist = rdd.value === 'auto' ? 'auto' : +rdd.value; changed(false); } };
  const fo = $('#fireOn', el), fr = $('#fireR', el);
  if (fo) fo.onchange = () => { S.fire.R = fo.checked ? fr.value : '-'; changed(false); };
  if (fr) fr.onchange = () => { if (fo.checked) { S.fire.R = fr.value; changed(false); } };
  const sm = $('#selMode', el); if (sm) sm.onchange = () => { selMode = sm.checked; if (!selMode) selSpans.clear(); renderDataSide(); };
  const sa = $('#selAll', el); if (sa) sa.onclick = () => { spanSegs.forEach(sg => selSpans.add(sg.idx)); md.segs.forEach(sg => selSpans.add(sg.idx)); renderDataSide(); };
  const sc = $('#selClr', el); if (sc) sc.onclick = () => { selSpans.clear(); renderDataSide(); };
  const sl = $('#selLoad', el); if (sl) sl.onclick = () => { const sp = Array.from(selSpans).map(i => i + 1); if (sp.length === 1) loadPopup({ seg: sp[0] - 1, el: 0 }); else loadPopup({ spans: sp }); };
}
// okno podpory: blokady przesuwu x, y, z i obrotu, szerokość, podatność, przegub nad podporą pośrednią
function supportPopup(i) {
  const md = model(), sp = md.sups[i]; if (!sp) return;
  const c0 = (S.supCfg || [])[i] || {};
  const w = { dof: Object.assign({}, sp.dof), kv: c0.kv === undefined ? '' : c0.kv, kr: c0.kr === undefined ? '' : c0.kr, t: c0.t === undefined ? '' : c0.t, hinge: !!c0.hinge, direct: c0.direct !== false };
  const m = $('#modal'); popRedraw = null;
  const icon = t => {
    const p = Object.assign({}, sp, { type: t, kv: 0, kr: 0, idx: -1, fy: true, fz: true, custom: false, hinge: false });
    const x1 = sp.segL === null ? 22 : 2, x2 = sp.segR === null ? 22 : 42;
    return svgOpen(44, 42) + `<line x1="${x1}" y1="16" x2="${x2}" y2="16" stroke="#1b2230" stroke-width="3"/>` + supportSym(p, 22, 16, { compact: true }).replace(/<title>[^<]*<\/title>/, '') + `</svg>`;
  };
  const desc = { roller: 'blokady y, z – przesuw podłużny i obrót swobodne', pin: 'blokady x, y, z – obrót swobodny', fix: 'utwierdzenie – blokady x, y, z i obrotu' };
  const same = (a, b) => ['x', 'y', 'z', 'r'].every(k => !!a[k] === !!b[k]);
  const test = () => {
    const S2 = JSON.parse(JSON.stringify(S)); S2.supCfg = S2.supCfg || []; while (S2.supCfg.length <= i) S2.supCfg.push({ dof: null, kv: '', kr: '', t: '', hinge: false });
    S2.supCfg[i] = { dof: Object.assign({}, w.dof), kv: w.kv, kr: w.kr, t: w.t, hinge: w.hinge };
    try { return E.beamModel(E.normalize(S2)); } catch (e) { return null; }
  };
  const hasZ = () => { try { return E.loadLayout(S, 0).hasZ; } catch (e) { return false; } };
  const draw = () => {
    const md2 = test(), bad = !md2 || md2.unstable, badZ = md2 && md2.unstableZ, zl = hasZ();
    const cur = ['roller', 'pin', 'fix'].find(t => same(w.dof, E.SUP_DOF[t]));
    const chk = (k, lab, note) => `<label class="dofc ${w.dof[k] ? 'on' : ''}"><input type="checkbox" data-dof="${k}" ${w.dof[k] ? 'checked' : ''}><span><b>${lab}</b><br><small>${note}</small></span></label>`;
    m.innerHTML = `<div class="dlg suppop"><h3>${esc(cap(sp.name))}${md.cont ? '' : ` (${esc(sp.label)})`}</h3>
      <div class="zg">${['roller', 'pin', 'fix'].map(t => `<label class="rad ${cur === t ? 'on' : ''}"><input type="radio" name="spt" value="${t}" ${cur === t ? 'checked' : ''}>${icon(t)}<span><b>${cap(E.SUP_NAME[t])}</b><br><small>${desc[t]}</small></span></label>`).join('')}</div>
      <h4 class="lsec">Blokady (zaznaczona – kierunek zablokowany)</h4>
      <div class="zg">${chk('x', 'x – przesuw podłużny', 'wzdłuż osi belki')}${chk('y', 'y – przesuw pionowy', 'podparcie pionowe (płaszczyzna Y)')}${chk('z', 'z – przesuw poprzeczny', 'poziomo, prostopadle do układu (płaszczyzna Z)')}${chk('r', 'φ – obrót', 'utwierdzenie (w obu płaszczyznach)')}</div>
      <div class="zg"><span>Szerokość podpory t</span><input class="txt" data-sk="t" value="${esc(showNum(w.t))}" placeholder="${esc(showNum(S.geom.t))} (wspólna)"><span>mm</span></div>
      ${w.dof.y ? `<div class="zg"><span>Podatność pionowa k<sub>v</sub></span><input class="txt" data-sk="kv" value="${esc(showNum(w.kv))}" placeholder="sztywna"><span>kN/m</span></div>` : ''}
      ${w.dof.r ? `<div class="zg"><span>Podatność obrotowa k<sub>φ</sub></span><input class="txt" data-sk="kr" value="${esc(showNum(w.kr))}" placeholder="pełne utwierdzenie"><span>kNm/rad</span></div>` : ''}
      ${!sp.end ? `<label class="chk"><input type="checkbox" id="sHinge" ${w.hinge ? 'checked' : ''}><span>Przegub w belce nad podporą (belka nieciągła – moment nad podporą = 0)</span></label>` : ''}
      <label class="chk"><input type="checkbox" id="sDirect" ${w.direct ? 'checked' : ''}><span>Podparcie bezpośrednie – reakcja działa na dolną powierzchnię belki (np. mur, słup, ściana). Odznacz dla podparcia pośredniego (belka wpuszczona w podciąg, podwieszona) – wtedy bez redukcji V<sub>Ed</sub> wg 6.2.1(8).</span></label>
      <p class="hint">Puste pola podatności – podpora niepodatna. Przykładowe wartości: podparcie na belce (podciągu) k<sub>v</sub> ≈ 48·E·I/L³ (w środku przęsła podciągu), na słupie k<sub>v</sub> = E·A/H; utwierdzenie w słupie k<sub>φ</sub> ≈ 4·E·I/H (słup utwierdzony u dołu) lub 3·E·I/H (przegub u dołu), dla słupów powyżej i poniżej – suma. Blokada z i obrót dotyczą zginania w płaszczyźnie Z (obciążenia poziome) – bez podatności.</p>
      ${bad ? '<div class="msg err">Układ byłby geometrycznie zmienny w płaszczyźnie pionowej – za mało więzów (np. wspornik musi mieć utwierdzenie).</div>' : ''}
      ${!bad && badZ ? `<div class="msg ${zl ? 'err' : 'wrn'}">W płaszczyźnie poziomej (Z) układ byłby geometrycznie zmienny${zl ? ' – działają obciążenia Z, obliczenia nie będą możliwe' : ' – bez znaczenia, dopóki nie ma obciążeń w kierunku Z'}.</div>` : ''}
      ${!bad && md2 && md2.noHor ? '<div class="msg wrn">Żadna podpora nie blokuje przesuwu x – belka nie będzie ustalona w kierunku podłużnym.</div>' : ''}
      <div class="dbtn"><button class="btn" id="sDef">Przywróć domyślną</button><span style="flex:1"></span><button class="btn" id="sCancel">Anuluj</button><button class="btn pri" id="sOk" ${bad || (badZ && zl) ? 'disabled' : ''}>Zastosuj</button></div></div>`;
    m.style.display = 'flex';
    $$('input[name=spt]', m).forEach(r => r.addEventListener('change', () => { w.dof = Object.assign({}, E.SUP_DOF[r.value]); draw(); }));
    $$('[data-dof]', m).forEach(c => c.addEventListener('change', () => { w.dof[c.dataset.dof] = c.checked; draw(); }));
    const hg = $('#sHinge', m); if (hg) hg.addEventListener('change', () => { w.hinge = hg.checked; draw(); });
    const dr = $('#sDirect', m); if (dr) dr.addEventListener('change', () => { w.direct = dr.checked; });
    $$('[data-sk]', m).forEach(el => el.addEventListener('input', () => {
      const raw = el.value.trim(), v = parseNum(raw), bad2 = raw !== '' && (v === null || v < 0);
      el.classList.toggle('bad', bad2); if (!bad2) w[el.dataset.sk] = raw === '' ? '' : v;
    }));
    const close = () => { m.style.display = 'none'; };
    $('#sCancel', m).onclick = close;
    const save = cfg => {
      S.supCfg = S.supCfg || [];
      while (S.supCfg.length <= i) S.supCfg.push({ dof: null, kv: '', kr: '', t: '', hinge: false });
      S.supCfg[i] = cfg;
      close(); changed(true);
    };
    $('#sDef', m).onclick = () => save({ dof: null, kv: '', kr: '', t: '', hinge: false, direct: true });
    $('#sOk', m).onclick = () => { if (!$('#sOk', m).disabled) save({ dof: same(w.dof, E.SUP_DOF[sp.def]) ? null : Object.assign({}, w.dof), kv: w.dof.y ? w.kv : '', kr: w.dof.r ? w.kr : '', t: w.t, hinge: !sp.end && w.hinge, direct: w.direct }); };
  };
  draw();
}

/* ------------------------------------------------------ schemat obciążeń */
function schemeData() {
  const gSelf = !S.loads.sw ? 0 : (R && R.md && R.md.segs[0] && R.md.segs[0].g ? R.md.segs.map(sg => sg.g.selfW) : (R && R.g && R.g.selfW ? R.g.selfW : 0));
  const offOf = { perm: S.loads.perm.map(it => !!it.off), var: S.loads.var.map(it => !!it.off), acc: S.loads.acc.map(it => !!it.off) };
  let lay; try { const S2 = JSON.parse(JSON.stringify(S)); ['perm', 'var', 'acc'].forEach(k => S2.loads[k].forEach(it => { delete it.off; })); lay = E.loadLayout(S2, gSelf); } catch (e) { return null; }
  const ids = {}; if (R && R.st && R.st.vars) { R.st.vars.forEach(v => ids['var' + v.si] = v.id); R.st.accs.forEach(a => ids['acc' + a.si] = a.id); }
  const rows = [];
  lay.G.forEach(r => rows.push(Object.assign({}, r, { id: r.sw ? 'G₀' : 'G', col: KIND_COLOR.G, isG: true, off: r.si !== undefined && !r.sw && offOf.perm[r.si] })));
  lay.vars.forEach(r => rows.push(Object.assign({}, r, { id: offOf.var[r.si] ? '–' : ids['var' + r.si] || 'Q', col: KIND_COLOR[r.kind], off: offOf.var[r.si] })));
  lay.accs.forEach(r => rows.push(Object.assign({}, r, { id: offOf.acc[r.si] ? '–' : ids['acc' + r.si] || 'A', col: KIND_COLOR.acc, off: offOf.acc[r.si] })));
  return { lay, rows };
}
// symbol podpory: przesuwna (rolki), nieprzesuwna (przegub), sztywna (utwierdzenie); podatna – sprężyna
function supportSym(sp, xx, yb, opt) {
  let s = `<g class="supp" data-sup="${sp.idx}"><title>${esc(sp.name)}: ${E.SUP_NAME[sp.type]}${sp.fy === false ? ', bez blokady y' : ''}${sp.fz === false ? ', bez blokady z' : ''}${sp.kv ? `, k_v = ${fmt(sp.kv, 0)} kN/m` : ''}${sp.kr ? `, k_φ = ${fmt(sp.kr, 0)} kNm/rad` : ''} – kliknij, aby zmienić</title>`;
  if (sp.fy === false) s += `<g opacity="0.4">`;
  s += `<rect class="suphl" x="${xx - 16}" y="${yb - 18}" width="32" height="${opt.compact ? 40 : 52}" rx="4" fill="transparent" stroke="transparent"/>`;
  const spring = sp.kv > 0 ? 8 : 0;
  if (spring) s += `<path d="M${xx},${yb + 2} l0,2 l-4,1.5 l8,1.5 l-8,1.5 l8,1.5 l-4,1 l0,1" fill="none" stroke="#1b2230" stroke-width="1"/>`;
  const y0 = yb + 2 + spring;
  if (sp.type === 'fix') {
    const d = sp.segL === null ? -1 : sp.segR === null ? 1 : 0;
    if (d) {
      s += `<line x1="${xx}" y1="${yb - 14}" x2="${xx}" y2="${yb + 14}" stroke="#1b2230" stroke-width="2"/>`;
      for (let k = -14; k < 14; k += 5) s += `<line x1="${xx}" y1="${yb + k}" x2="${xx + d * 6}" y2="${yb + k + 5}" stroke="#1b2230" stroke-width="0.8"/>`;
    } else {
      s += `<rect x="${xx - 7}" y="${y0}" width="14" height="12" fill="#cfd4db" stroke="#1b2230" stroke-width="1"/>`;
      for (let k = -7; k < 7; k += 4) s += `<line x1="${xx + k}" y1="${y0 + 12}" x2="${xx + k + 4}" y2="${y0 + 16}" stroke="#1b2230" stroke-width="0.7"/>`;
    }
    if (sp.kr > 0) s += `<path d="M${xx - 9},${yb - 8} a10,10 0 1,1 4,13" fill="none" stroke="#a35d00" stroke-width="1.2"/>`;
  } else {
    s += `<path d="M${xx},${y0} l-7,12 h14 z" fill="#ffffff" stroke="#1b2230" stroke-width="1.2"/>`;
    if (sp.type === 'roller') s += `<circle cx="${xx - 4}" cy="${y0 + 14.5}" r="2.3" fill="#ffffff" stroke="#1b2230" stroke-width="0.9"/><circle cx="${xx + 4}" cy="${y0 + 14.5}" r="2.3" fill="#ffffff" stroke="#1b2230" stroke-width="0.9"/><line x1="${xx - 10}" y1="${y0 + 17.5}" x2="${xx + 10}" y2="${y0 + 17.5}" stroke="#1b2230"/>`;
    else { s += `<line x1="${xx - 10}" y1="${y0 + 14}" x2="${xx + 10}" y2="${y0 + 14}" stroke="#1b2230"/>`; for (let k = -10; k < 10; k += 4) s += `<line x1="${xx + k}" y1="${y0 + 14}" x2="${xx + k - 3}" y2="${y0 + 18}" stroke="#1b2230" stroke-width="0.7"/>`; }
  }
  if (sp.fy === false) s += '</g>';
  const lab = sp.custom ? `${sp.label} [${[['x', sp.fx], ['y', sp.fy], ['z', sp.fz], ['φ', sp.type === 'fix']].filter(q => q[1]).map(q => q[0]).join(',')}]` : sp.label;
  if (!opt.compact) s += tx(xx, yb + 34 + spring, esc(lab), { fs: 10, c: '#3d4656', w: 650 });
  return s + '</g>';
}
function schemeSVG(W, opt) {
  opt = opt || {};
  const D = schemeData(); if (!D) return '';
  const { lay, rows } = D, L = lay.L, md = lay.md;
  const fs = opt.compact ? 9.5 : 10.5;
  const xN = nEdAt(md), nR = xN !== null && xN >= L / 2;           // siła podłużna N_Ed – pozioma strzałka przy krawędzi belki
  const ml = (opt.compact ? 16 : 40) + (xN !== null && !nR && xN < 1 ? (opt.compact ? 34 : 52) : 0), mr = (opt.compact ? 16 : 40) + (xN !== null && nR && xN > L - 1 ? (opt.compact ? 34 : 52) : 0);
  const sx = (W - ml - mr) / L, X = x => ml + x * sx;
  const bands = [];
  rows.forEach(r => { if (r.qy) bands.push({ r, q: r.qy, z: false }); if (r.qz) bands.push({ r, q: r.qz, z: true }); if (r.mt) bands.push({ r, q: r.mt, t: true }); });
  const TEdAdd = Math.abs(S.loads.TEd || 0);
  const pts = [], ptsZ = [], ptsT = [];
  const lkOf = r => r.isG ? (r.sw ? 'sw' : r.si === undefined ? 'gk' : 'perm') : r.kind === 'acc' ? 'acc' : 'var';
  // pole wyboru obciążenia (uwzględniane / wyłączone z obliczeń)
  const ldChk = (r, x, y) => `<g class="ldchk" data-lk="${lkOf(r)}" data-li="${r.si === undefined ? -1 : r.si}"><title>${r.off ? 'Obciążenie wyłączone – kliknij, aby uwzględnić' : 'Kliknij, aby wyłączyć obciążenie z obliczeń'}</title><rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="9" height="9" rx="1.5" fill="#ffffff" stroke="${r.col}" stroke-width="1.1"/>${r.off ? '' : `<path d="M${(x + 1.8).toFixed(1)},${(y + 4.6).toFixed(1)} l2.2,2.3 l3.6,-4.4" fill="none" stroke="${r.col}" stroke-width="1.5"/>`}</g>`;
  const gO = r => opt.edit ? `<g class="ld" data-lk="${lkOf(r)}" data-li="${r.si === undefined ? -1 : r.si}"><title>${esc(r.name || r.id)} – kliknij, aby zmienić</title>` : '', gC = () => opt.edit ? '</g>' : '';
  rows.forEach(r => r.pts.forEach(p => { if (p.Py) pts.push({ x: p.x, P: p.Py, id: r.id, col: r.col, r }); if (p.Pz) ptsZ.push({ x: p.x, P: p.Pz, id: r.id, col: r.col, r }); if (p.T) ptsT.push({ x: p.x, P: p.T, id: r.id, col: r.col, r }); }));
  const bh = opt.compact ? 11 : 14, gap = 3, top = 6 + (TEdAdd ? 16 : 0);
  const qMax = Math.max(1e-9, ...bands.filter(b => !b.t).map(b => Math.abs(b.q))), tMax = Math.max(1e-9, ...bands.filter(b => b.t).map(b => Math.abs(b.q)));
  let yAcc = top; bands.forEach(bd => { bd.h = Math.round(Math.max(bh * 0.7, Math.min(bh * 1.9, bh * 1.9 * Math.abs(bd.q) / (bd.t ? tMax : qMax)))); bd.y = yAcc; yAcc += bd.h + gap; });
  const yBandsEnd = yAcc;
  const arrowH = pts.length ? (opt.compact ? 30 : 38) : 8;
  const stack = {}; pts.forEach(p => { const k = Math.round(p.x); p.lvl = stack[k] = (stack[k] === undefined ? 0 : stack[k] + 1); });
  const maxLvl = Math.max(0, ...pts.map(p => p.lvl));
  const yLab0 = yBandsEnd + 10 + maxLvl * 11;
  const yb = yLab0 + arrowH;
  const zLane = ptsZ.length ? (opt.compact ? 20 : 30) : 0;
  const dgOn = opt.diag && R && R.st && !(R.errors && R.errors.length) && ((!R.st.manual && R.req) || opt.diag === 'N');
  const HB = dgOn ? (opt.diag === 'V' ? (opt.compact ? 130 : 150) : opt.diag === 'N' ? 80 : opt.diag === 'f' ? (opt.compact ? 110 : 130) : opt.diag === 'R' ? (opt.compact ? 100 : 118) : (opt.compact ? 120 : 140)) : 0, yBand = yb + zLane + (opt.compact ? 34 : 44);
  const dShift = dgOn ? HB + (opt.compact ? 8 : 12) + 10 + (opt.diag === 'M' ? 22 : 0) : 0;
  const extraDim = opt.compact ? 0 : 44;                                  // wymiary: lica podpór / przęsła w świetle oraz długość całkowita z podporami
  const H = yb + zLane + (opt.compact ? 52 : 74) + dShift + extraDim;
  let s = svgOpen(W, H, 'class="schemesvg"');
  const mid = opt.compact ? 'c' : 'f';
  s += `<defs><marker id="ah${mid}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="context-stroke"/></marker></defs>`;
  if (TEdAdd) s += tx(ml, 14, esc(`T_Ed = ${fmt(TEdAdd, 1)} kNm – moment skręcający obliczeniowy podany wprost (stały na długości)`), { a: 'start', fs: fs - 1, c: KIND_COLOR.other, w: 600 });
  bands.forEach((bd, i) => {
    const r = bd.r, y = bd.y, neg = bd.q < 0, bh = bd.h;
    const rgs = r.ranges || [[r.x1, r.x2]];
    s += gO(r) + (r.off ? '<g opacity="0.3">' : '');
    rgs.forEach(([u, v]) => {
      const x1 = X(u), x2 = X(v);
      if (r.prof && !bd.t) {                                       // obciążenie o zmiennej wartości – wykres q(x)
        const pk = Math.max(1e-9, ...r.prof.map(q => Math.abs(q[1])));
        const pts2 = r.prof.map(([xx, qv]) => `${X(xx).toFixed(1)},${(y + bh - bh * Math.abs(qv) / pk).toFixed(1)}`).join(' ');
        s += `<polygon points="${X(r.prof[0][0]).toFixed(1)},${y + bh} ${pts2} ${X(r.prof[r.prof.length - 1][0]).toFixed(1)},${y + bh}" fill="${r.col}" fill-opacity="${neg || bd.z ? 0.08 : 0.16}" stroke="${r.col}" stroke-width="0.8"/>`;
        return;
      }
      s += `<rect x="${x1.toFixed(1)}" y="${y}" width="${Math.max(1, x2 - x1).toFixed(1)}" height="${bh}" fill="${r.col}" fill-opacity="${neg || bd.z || bd.t ? 0.08 : 0.16}" stroke="${r.col}" stroke-width="0.8" ${neg || bd.z || bd.t ? 'stroke-dasharray="3 2"' : ''}/>`;
      const nArr = Math.max(2, Math.min(40, Math.round((x2 - x1) / (opt.compact ? 14 : 22))));
      // kierunek działania: strzałki w dół (q > 0) lub w górę (q < 0); skręcanie – zakręcone strzałki; Z – prostopadle (⊙)
      for (let k = 0; k <= nArr; k++) {
        const xx = x1 + (x2 - x1) * k / nArr;
        if (bd.t) { if (k % 2 === 0 && k < nArr) s += `<path d="M${(xx + 3).toFixed(1)},${y + bh - 3} a4,4 0 1,${bd.q > 0 ? 1 : 0} 6,0" fill="none" stroke="${r.col}" stroke-width="0.8"/>`; continue; }
        if (bd.z) { if (k % 2 === 0) s += `<circle cx="${xx.toFixed(1)}" cy="${y + bh / 2}" r="2" fill="none" stroke="${r.col}" stroke-width="0.6"/>`; continue; }
        s += `<line x1="${xx.toFixed(1)}" y1="${y + 2}" x2="${xx.toFixed(1)}" y2="${y + bh - 1}" stroke="${r.col}" stroke-width="0.6" stroke-opacity="0.7"/>`;
        s += neg ? `<path d="M${xx.toFixed(1)},${y + 1} l-2.2,3.6 h4.4 z" fill="${r.col}" fill-opacity="0.8"/>` : `<path d="M${xx.toFixed(1)},${y + bh} l-2.2,-3.6 h4.4 z" fill="${r.col}" fill-opacity="0.8"/>`;
      }
    });
    const x1 = X(rgs[0][0]);
    const nm = r.name ? (r.sw ? r.name : `${r.id} ${r.name}`) : r.id;
    const qTxt = r.prof && !bd.t ? r.prof.map(q => fmt(q[1] * (bd.z ? (r.cz || 1) : (r.cy || 1)), 1)).join(' → ') : fmt(bd.q, 2);
    const lab = `${nm}${bd.z ? ' [Z]' : ''}: ${bd.t ? 'm_t' : 'q'} = ${qTxt} ${bd.t ? 'kNm/m' : 'kN/m'}${r.ang && !bd.t ? ` (α = ${fmt(r.ang, 0)}°)` : ''}` + (r.ranges ? ` (${r.segs.map(i => md.segs[i] ? md.segs[i].label : '').join(', ')})` : r.partial ? ` (${fmt(r.x1 / 1000, 2)}–${fmt(r.x2 / 1000, 2)} m)` : '');
    const cw = fs * 0.52, lx = Math.max(2, Math.min(Math.max(x1 + 3, ml), W - mr - lab.length * cw));
    const maxC = Math.floor((W - 4 - lx) / cw), labT = lab.length > maxC ? lab.slice(0, Math.max(8, maxC - 1)) + '…' : lab;
    s += tx(lx + (opt.edit && !r.sw ? 12 : 0), y + bh - 3, esc(labT), { a: 'start', fs: fs - 1, c: r.col, w: 600 }) + (r.off ? '</g>' : '') + gC();
    if (opt.edit && !r.sw) s += ldChk(r, lx + 1, y + bh / 2 - 4.5);
  });
  s += `<line x1="${X(0)}" y1="${yb}" x2="${X(L)}" y2="${yb}" stroke="#1b2230" stroke-width="${opt.compact ? 3 : 4}"/>`;
  // elementy belki (klikane), węzły i przeguby
  if (opt.edit) md.segs.forEach(sg => (sg.els || [{ k: 0, x0: sg.x0, x1: sg.x1, L: sg.L }]).forEach(e => {
    const on = opt.sel && opt.sel.has(sg.idx);
    s += `<g class="elm${on ? ' sel' : ''}" data-seg="${sg.idx}" data-el="${e.k}"><title>${esc(cap(sg.label))}${sg.els && sg.els.length > 1 ? `, element ${e.k + 1}` : ''} (${fmt(e.L / 1000, 2)} m) – kliknij, aby zadać obciążenia lub wstawić węzeł; Ctrl + klik – zaznacz przęsło</title><rect class="elhl" x="${(X(e.x0) + 1).toFixed(1)}" y="${yb - 10}" width="${Math.max(2, X(e.x1) - X(e.x0) - 2).toFixed(1)}" height="20" rx="3" fill="${on ? '#1d5bb8' : 'transparent'}" fill-opacity="${on ? 0.22 : 1}" stroke="${on ? '#1d5bb8' : 'transparent'}"/></g>`;
  }));
  md.sups.forEach(sp => { s += supportSym(sp, X(sp.x), yb, opt); });
  (md.unodes || []).forEach(q => {
    const xx = X(q.x);
    s += `<g class="nod" data-node="${q.i}"><title>${q.hinge ? 'Przegub' : 'Węzeł'} x = ${fmt(q.x / 1000, 2)} m – kliknij znacznik pod belką, aby zmienić położenie lub przegub (kropka – obciążenie węzłowe)</title><rect x="${xx - 8}" y="${yb - 16}" width="16" height="42" fill="transparent"/>` +
      (q.hinge ? `<circle cx="${xx}" cy="${yb}" r="7" fill="#ffffff" stroke="#1b2230" stroke-width="1.6"/>` : '') + `<line x1="${xx}" y1="${yb - 12}" x2="${xx}" y2="${yb + 20}" stroke="#1b2230" stroke-width="1.2"/><path d="M${xx - 5},${yb + 20} h10" stroke="#1b2230" stroke-width="1.4"/></g>`;
  });
  md.sups.filter(p => p.hinge).forEach(p => { s += `<circle cx="${X(p.x)}" cy="${yb}" r="4.2" fill="#ffffff" stroke="#1b2230" stroke-width="1.6"/>`; });
  if (xN !== null) {   // N_Ed: ściskanie – strzałka do belki, rozciąganie – od belki; wartość obliczeniowa
    const N = S.loads.NEd, xx = X(xN), sd = nR ? 1 : -1, L1 = opt.compact ? 30 : 44, cN = '#155e2c', yN = yb;
    const xa = N > 0 ? xx + sd * (L1 + 7) : xx + sd * 7, xb = N > 0 ? xx + sd * 7 : xx + sd * (L1 + 7), dir = Math.sign(xb - xa);
    s += `<g class="nedarr"${opt.edit ? ` data-nx="${Math.round(xN)}"` : ''}><title>Siła podłużna N_Ed = ${fmt(N, 1)} kN (${N > 0 ? 'ściskająca' : 'rozciągająca'}) – wartość obliczeniowa, stała na długości belki${opt.edit ? '; kliknij, aby zmienić' : ''}</title>`;
    s += `<rect x="${Math.min(xa, xb) - 4}" y="${yN - 16}" width="${L1 + 8}" height="24" fill="transparent"/><line x1="${xa.toFixed(1)}" y1="${yN}" x2="${(xb - dir * 7).toFixed(1)}" y2="${yN}" stroke="${cN}" stroke-width="2"/><path d="M${xb.toFixed(1)},${yN} l${-dir * 8},-4.5 v9 z" fill="${cN}"/>`;
    s += tx((xa + xb) / 2, yN - 7, `N = ${fmt(Math.abs(N), 1)} kN`, { fs: fs - 1, c: cN, w: 650 }) + '</g>';
  }
  if (opt.edit) {   // węzły obciążeń: podpory, węzły w przęsłach, swobodne końce – kliknięcie dodaje siłę pionową, moment skręcający, siłę podłużną
    const nx = []; md.sups.forEach(p => nx.push({ x: p.x, l: p.name })); (md.unodes || []).forEach(q => nx.push({ x: q.x, l: `węzeł x = ${fmt(q.x / 1000, 2)} m` }));
    if (!nx.some(q => Math.abs(q.x) < 1)) nx.push({ x: 0, l: 'koniec lewy' }); if (!nx.some(q => Math.abs(q.x - md.Ltot) < 1)) nx.push({ x: md.Ltot, l: 'koniec prawy' });
    nx.forEach(q => { const has = !!nodeItem(Math.round(q.x)), xx = X(q.x);
      s += `<g class="ldnode${has ? ' has' : ''}" data-nx="${Math.round(q.x)}" data-nl="${esc(q.l)}"><title>Węzeł obciążenia – ${esc(q.l)} (x = ${fmt(q.x / 1000, 2)} m): kliknij, aby dodać lub zmienić obciążenie węzłowe (siła pionowa P, moment skręcający T, siła podłużna N_Ed)</title><circle cx="${xx}" cy="${yb}" r="7" fill="transparent"/><circle class="ldn" cx="${xx}" cy="${yb}" r="4.6" fill="${has ? '#c0262d' : '#1d5bb8'}" stroke="#ffffff" stroke-width="1.6"/></g>`; });
  }
  const PMax = Math.max(1e-9, ...pts.map(p => Math.abs(p.P)));
  pts.forEach(p => {
    const xx = X(p.x), y0 = yb - 2 - (yb - 2 - (yLab0 + 3)) * (0.35 + 0.65 * Math.abs(p.P) / PMax), ylab = y0 - 3 - p.lvl * 11;
    s += gO(p.r) + (p.r.off ? '<g opacity="0.3">' : '');
    if (p.P >= 0) s += `<line x1="${xx}" y1="${y0.toFixed(1)}" x2="${xx}" y2="${yb - 2}" stroke="${p.col}" stroke-width="1.6" marker-end="url(#ah${mid})"/>`;
    else s += `<line x1="${xx}" y1="${yb - 2}" x2="${xx}" y2="${y0.toFixed(1)}" stroke="${p.col}" stroke-width="1.6" stroke-dasharray="3 2" marker-end="url(#ah${mid})"/>`;
    const lab = `${p.r.name ? p.r.name : p.id}: ${fmt(p.P, Math.abs(p.P) < 10 ? 1 : 0)} kN`;
    const a = xx < ml + 30 ? 'start' : xx > W - mr - 30 ? 'end' : 'middle';
    s += tx(xx + (a === 'start' ? -2 : a === 'end' ? 2 : 0), ylab, esc(lab), { fs: fs - 0.5, c: p.col, w: 600, a }) + (p.r.off ? '</g>' : '') + gC();
    if (opt.edit && !(p.r.qy || p.r.qz || p.r.mt)) { const tw = lab.length * (fs - 0.5) * 0.55, xl = a === 'start' ? xx - 2 : a === 'end' ? xx + 2 - tw : xx - tw / 2; s += ldChk(p.r, xl - 13, ylab - 8.5); }
  });
  // siły w płaszczyźnie Z (⊙ – prostopadle do rysunku)
  ptsZ.forEach(p => {
    const xx = X(p.x), yy = yb + (opt.compact ? 24 : 42);
    s += gO(p.r) + `<circle cx="${xx}" cy="${yy}" r="4.5" fill="#ffffff" stroke="${p.col}" stroke-width="1.3"/>` + (p.P >= 0 ? `<circle cx="${xx}" cy="${yy}" r="1.4" fill="${p.col}"/>` : `<path d="M${xx - 3},${yy - 3} l6,6 M${xx + 3},${yy - 3} l-6,6" stroke="${p.col}" stroke-width="1"/>`);
    s += tx(xx + 7, yy + 3.5, esc(`${p.r.name || p.id} [Z]: ${fmt(p.P, Math.abs(p.P) < 10 ? 1 : 0)} kN`), { fs: fs - 1, c: p.col, w: 600, a: xx > W - mr - 60 ? 'end' : 'start' }) + gC();
  });
  // momenty skręcające skupione (strzałka zakręcona wokół osi belki)
  ptsT.forEach(p => {
    const xx = X(p.x), yy = yb - (opt.compact ? 5 : 7);
    s += gO(p.r) + `<path d="M${xx - 8},${yy + 4} a8,7 0 1,${p.P > 0 ? 1 : 0} 16,0" fill="none" stroke="${p.col}" stroke-width="1.4" marker-end="url(#ah${mid})"/><circle cx="${xx}" cy="${yb}" r="1.8" fill="${p.col}"/>`;
    const right = xx <= W - mr - 80;
    s += tx(xx + (right ? 11 : -11), yy - 4, esc(`${p.r.name || p.id}: T = ${fmt(p.P, 1)} kNm`), { fs: fs - 1, c: p.col, w: 600, a: right ? 'start' : 'end' }) + gC();
  });
  const ticks = [0, L];
  md.sups.forEach(sp => ticks.push(sp.x)); md.segs.forEach(sg => ticks.push(sg.x0)); (md.unodes || []).forEach(q => ticks.push(q.x));
  pts.concat(ptsZ, ptsT).forEach(p => ticks.push(p.x));
  rows.filter(r => (r.qy || r.qz || r.mt) && r.partial).forEach(r => (r.ranges || [[r.x1, r.x2]]).forEach(q => ticks.push(q[0], q[1])));
  const tk = Array.from(new Set(ticks.map(t => Math.round(t)))).sort((u, v) => u - v);
  const fsD = (fs - 0.5) * 1.15;                                           // czcionka wymiarów (+15%)
  if (dgOn) s += diagBand(opt.diag, X, yBand, HB, fs, W, ml, mr, !!opt.edit);
  const yd = yb + zLane + (opt.compact ? 30 : 48) + dShift;
  s += `<line x1="${X(0)}" y1="${yd}" x2="${X(L)}" y2="${yd}" stroke="#5d6778" stroke-width="0.8"/>`;
  tk.forEach(t => { const xx = X(t); s += `<line x1="${xx}" y1="${yd - 5}" x2="${xx}" y2="${yd + 5}" stroke="#5d6778" stroke-width="0.8"/><line x1="${xx - 3}" y1="${yd + 3}" x2="${xx + 3}" y2="${yd - 3}" stroke="#5d6778" stroke-width="0.8"/>`; });
  for (let i = 0; i < tk.length - 1; i++) {
    const a = tk[i], b = tk[i + 1], w = (b - a) * sx;
    if (b - a < 1) continue;
    const lab = fmt((b - a) / 1000, (b - a) % 10 ? 3 : 2);
    if (w >= lab.length * fsD * 0.55) s += tx((X(a) + X(b)) / 2, yd - 3, lab, { fs: fsD, c: '#3d4656' });
  }
  const lt = md.cont ? `L = ${md.segs.map(sg => fmt(sg.L / 1000, 2)).join(' + ')} = ${fmt(L / 1000, 2)} m (w osiach)` : `L = ${fmt(L / 1000, 2)} m (w osiach)`;
  s += tx((X(0) + X(L)) / 2, yd + (tk.length > 2 ? 16 : 14), lt, { fs: fsD, c: '#3d4656' });
  if (extraDim) {
    // podpora – przęsło w świetle – podpora; długość całkowita belki z szerokościami podpór
    const yd2 = yd + 34, ed = [];
    md.sups.forEach(p => { const t2 = (p.t || 0) / 2; ed.push(p.x - t2, p.x + t2); });
    const x0e = Math.min(0, ...ed), x1e = Math.max(L, ...ed);
    const tk2 = Array.from(new Set([x0e, x1e, ...ed].map(t => Math.round(Math.max(x0e, Math.min(x1e, t)))))).sort((u, v) => u - v);
    s += `<line x1="${X(tk2[0])}" y1="${yd2}" x2="${X(tk2[tk2.length - 1])}" y2="${yd2}" stroke="#5d6778" stroke-width="0.8"/>`;
    tk2.forEach(t => { const xx = X(t); s += `<line x1="${xx}" y1="${yd2 - 4}" x2="${xx}" y2="${yd2 + 4}" stroke="#5d6778" stroke-width="0.8"/><line x1="${xx - 3}" y1="${yd2 + 3}" x2="${xx + 3}" y2="${yd2 - 3}" stroke="#5d6778" stroke-width="0.8"/>`; });
    for (let i = 0; i < tk2.length - 1; i++) { const a = tk2[i], b = tk2[i + 1], w = (b - a) * sx; if (b - a < 1) continue; const isSup = md.sups.some(p => Math.abs(p.x - (a + b) / 2) < (p.t || 0) / 2 + 1);
      const lab = isSup ? fmt(b - a, 0) : fmt((b - a) / 1000, 2); if (w >= lab.length * (fsD - 1) * 0.55) s += tx((X(a) + X(b)) / 2, yd2 - 3, lab, { fs: fsD - 1, c: isSup ? '#7a8494' : '#3d4656' }); }
    s += dimH(X(x0e), X(x1e), yd2 + 26, `długość całkowita belki (z podporami) = ${fmt((x1e - x0e) / 1000, 2)} m`, { fs: fsD });
    s += tx(X(x0e), yd2 - 14, 'podpory | przęsła w świetle', { fs: fsD - 2.5, a: 'start', c: '#7a8494' });
  }
  if (!rows.length) s += tx(W / 2, top + 14, 'brak obciążeń', { fs, c: '#7a8494' });
  s += '</svg>';
  return s;
}
U.schemeSVG = schemeSVG;
// wykres pod belką (panel Danych, nie w raporcie): M – obwiednia SGN i wymagana liczba prętów (dobór optymalny, obwiednia przesunięta o a_l),
// V – obwiednia SGN, strefy strzemion (s₁, s_p, s₂) i wymagany zasięg zagęszczenia; półprzezroczysty, pod linią belki i obciążeniami
let noComb = (() => { try { return localStorage.getItem('bz.nocomb') === '1'; } catch (e) { return false; } })();
let diagMode = (() => { try { const v = localStorage.getItem('bz.diag'); return ['M', 'V', 'f', 'N', 'R', 'off'].includes(v) ? v : 'M'; } catch (e) { return 'M'; } })();
// siła podłużna N (stała na długości) i reakcje podpór R pod schematem w Danych
function diagNR(kind, X, yTop, HB, fs, W, ml, mr) {
  const st = R.st, md = R.md, f2 = fs - 1.5; let s = '';
  s += tx(ml - 4, yTop + 9, kind === 'N' ? 'N [kN]' : 'R [kN]', { fs: f2, a: 'end', c: '#7a8494' });
  if (kind === 'N') {
    const N = (st.NEd || 0) / 1e3, y0 = yTop + HB / 2, h = N ? Math.min(HB / 2 - 14, 26) : 0, yy = y0 - Math.sign(N) * h;
    s += `<line x1="${X(0)}" y1="${y0}" x2="${X(md.Ltot)}" y2="${y0}" stroke="#7a8494" stroke-width="0.7" stroke-dasharray="3 2"/>`;
    if (N) s += `<rect x="${X(0)}" y="${Math.min(y0, yy).toFixed(1)}" width="${(X(md.Ltot) - X(0)).toFixed(1)}" height="${h.toFixed(1)}" fill="#1d7f3c" fill-opacity="0.12" stroke="#1d7f3c" stroke-opacity="0.7"/>`;
    s += tx((X(0) + X(md.Ltot)) / 2, N ? (N > 0 ? yy - 4 : yy + 12) : y0 - 5, N ? `N_Ed = ${fmt(N, 1)} kN (${N > 0 ? 'ściskanie' : 'rozciąganie'}), stała na długości belki` : 'N_Ed = 0 na całej długości belki', { fs: f2, c: '#155e2c', w: 600 });
    return s;
  }
  if (!st.reac) return s + tx((X(0) + X(md.Ltot)) / 2, yTop + HB / 2, 'reakcje – brak (siły wewnętrzne zadane ręcznie)', { fs: f2, c: '#7a8494' });
  const U = st.reac.U, K = st.reac.K, mx = Math.max(1e-6, ...md.sups.map((p, i) => Math.max(Math.abs(U.max[i]), Math.abs(U.min[i]))));
  const yb = yTop + HB - 30, Lm = HB - 52;
  md.sups.forEach((p, i) => {
    const v = U.max[i] / 1e3, vmin = U.min[i] / 1e3, xx = X(p.x), len = Math.max(10, Lm * Math.abs(U.max[i]) / mx), up = v >= 0;
    s += `<line x1="${xx}" y1="${up ? yb : yb - len}" x2="${xx}" y2="${up ? yb - len : yb}" stroke="#c0262d" stroke-width="2"/><path d="M${xx},${up ? yb - len - 1 : yb + 1} l-4,${up ? 7 : -7} h8 z" fill="#c0262d"/>`;
    const a = xx < ml + 40 ? 'start' : xx > W - mr - 40 ? 'end' : 'middle', dx = a === 'start' ? -4 : a === 'end' ? 4 : 0;
    s += tx(xx + dx, yb + 13, `R_Ed = ${fmt(v, 1)}${Math.abs(vmin - v) > 0.05 ? ` / ${fmt(vmin, 1)}` : ''}`, { fs: f2, c: '#c0262d', w: 650, a });
    if (K) s += tx(xx + dx, yb + 25, `R_k = ${fmt(K.max[i] / 1e3, 1)}`, { fs: f2 - 0.5, c: '#1d5bb8', a });
  });
  return s;
}
// odwrotna strzałka ugięcia w jednym odcinku belki (przęśle / wsporniku): jak ogólna, brak, auto albo w₀ [mm]
function camberPopup(si) {
  const md = R && R.md; if (!md || !md.segs[si]) return;
  const sg = md.segs[si], own = (S.sls.camberSeg || {})[si], ds = R.sls && R.sls.defl ? R.sls.defl.spans.find(q => q.seg && q.seg.idx === si) : null;
  const glob = S.sls.camber === 'auto' ? 'auto' : +S.sls.camber > 0 ? `${S.sls.camber} mm` : 'brak';
  const mode0 = own === undefined ? 'glob' : own === 'auto' ? 'auto' : +own > 0 ? 'val' : 'none', m = $('#modal');
  m.innerHTML = `<div class="dlg barpop"><h3>Odwrotna strzałka ugięcia – ${esc(sg.label)}</h3>
    <div class="zl"><div class="zg"><span>Strzałka w₀ w tym ${sg.kind === 'span' ? 'przęśle' : 'wsporniku'}</span><select id="cbM"><option value="glob" ${mode0 === 'glob' ? 'selected' : ''}>jak ogólna (${esc(glob)})</option><option value="none" ${mode0 === 'none' ? 'selected' : ''}>bez strzałki</option><option value="auto" ${mode0 === 'auto' ? 'selected' : ''}>auto – równa ugięciu, ≤ L/250</option><option value="val" ${mode0 === 'val' ? 'selected' : ''}>podana</option></select>
      <input class="txt" id="cbV" value="${mode0 === 'val' ? esc(showNum(own)) : ''}" placeholder="mm" inputmode="decimal" style="width:80px;${mode0 === 'val' ? '' : 'display:none'}"><span id="cbU" style="${mode0 === 'val' ? '' : 'display:none'}">mm</span></div>
      <label class="chk sm"><input type="checkbox" id="cbAll"><span>Zastosuj we wszystkich przęsłach (strzałka ogólna)</span></label></div>
    ${ds ? `<p class="hint keep">Ugięcie długotrwałe f = <b>${fmt(ds.tot.f, 1)} mm</b>, f<sub>lim</sub> = ${fmt(ds.lim, 1)} mm (L/${S.sls.lim}); największa strzałka L/250 = ${fmt(ds.w0max || ds.lim * S.sls.lim / 250, 1)} mm${ds.camber > 0 ? `; obecnie w₀ = <b>${fmt(ds.camber, 0)} mm</b> → f − w₀ = ${fmt(ds.tot.f - (ds.camberUse ? ds.camber : 0), 1)} mm` : ''}.</p>` : ''}
    <div class="hint">${hintCamber()}</div>
    <div class="iss" id="cbErr" style="display:none">Strzałka od 0 do 200 mm.</div>
    <p><button class="lnk" id="cbExp">Jak obliczono ugięcie…</button></p>
    <div class="dbtn"><span class="sp"></span><button class="btn" id="cbCancel">Anuluj</button><button class="btn pri" id="cbOk">Zastosuj</button></div></div>`;
  m.style.display = 'flex';
  const sel = $('#cbM', m), inp = $('#cbV', m), un = $('#cbU', m);
  sel.onchange = () => { const v = sel.value === 'val'; inp.style.display = v ? '' : 'none'; un.style.display = v ? '' : 'none'; if (v) inp.focus(); };
  $('#cbCancel', m).onclick = () => { m.style.display = 'none'; };
  $('#cbExp', m).onclick = () => { m.style.display = 'none'; explainRowPopup('ugięcie f', ds && ds.seg ? md0(ds.seg) : '', `Ugięcie – ${sg.label}`, '', ds ? fmt(ds.tot.f, 2) : ''); };
  $('#cbOk', m).onclick = () => {
    const md2 = sel.value; let v = null;
    if (md2 === 'val') { v = parseNum(inp.value); if (v === null || v < 0 || v > 200) { $('#cbErr', m).style.display = ''; inp.classList.add('bad'); return; } }
    const val = md2 === 'glob' ? undefined : md2 === 'none' ? 0 : md2 === 'auto' ? 'auto' : v;
    S.sls.camberSeg = Object.assign({}, S.sls.camberSeg || {});
    if ($('#cbAll', m).checked) { S.sls.camber = val === undefined ? S.sls.camber : val === 0 ? '' : val; S.sls.camberSeg = {}; }
    else if (val === undefined) delete S.sls.camberSeg[si]; else S.sls.camberSeg[si] = val;
    m.style.display = 'none'; changed(true);
  };
  inp.addEventListener('keydown', ev => { if (ev.key === 'Enter') $('#cbOk', m).click(); });
}
// linia ugięcia długotrwałego (quasi-stałe + skurcz, MES z krzywiznami 7.4.3) pod schematem w Danych: f w każdym przęśle, f_lim, odwrotna strzałka
function diagF(X, yTop, HB, fs, W, ml, mr, putVal) {
  const md = R.md, f2 = fs - 1.5; let s = tx(ml - 4, yTop + 9, 'w [mm]', { fs: f2, a: 'end', c: '#7a8494' });
  const d = R.sls && R.sls.defl;
  if (!d || !d.x || !d.w) return s + tx((X(0) + X(md.Ltot)) / 2, yTop + HB / 2, 'ugięcie – po zadaniu zbrojenia podłużnego (przekroje bez zbrojenia)', { fs: f2, c: '#7a8494' });
  const lims = d.spans.map(q => q.lim), wMin = Math.min(0, ...d.w, ...lims.map(v => -v)), wMax = Math.max(0, ...d.w, ...d.spans.map(q => q.camber || 0));
  const lab = fs + 3, sc = (HB - 2 * lab - 6) / Math.max(1e-6, wMax - wMin), y0 = yTop + lab + 3 + wMax * sc, Y = w => y0 - w * sc;
  s += `<line x1="${X(0)}" y1="${y0.toFixed(1)}" x2="${X(md.Ltot)}" y2="${y0.toFixed(1)}" stroke="#7a8494" stroke-width="0.7" stroke-dasharray="3 2"/>`;
  const pts = d.x.map((x, k) => `${X(x).toFixed(1)},${Y(d.w[k]).toFixed(1)}`);
  s += `<path d="M${X(d.x[0]).toFixed(1)},${y0.toFixed(1)} L${pts.join(' L')} L${X(d.x[d.x.length - 1]).toFixed(1)},${y0.toFixed(1)} Z" fill="#1d5bb8" fill-opacity="0.1" stroke="#1d5bb8" stroke-width="1.4"><title>Linia ugięcia długotrwałego w(x): obciążenia quasi-stałe + skurcz (7.4.3)${d.patterned ? '; obciążenie zmienne naprzemiennie w przęsłach' : ''}</title></path>`;
  const wAt = xx => { let bi = 0; d.x.forEach((v, i) => { if (Math.abs(v - xx) < Math.abs(d.x[bi] - xx)) bi = i; }); return d.w[bi]; };
  // obszary kliknięcia: odwrotna strzałka w tym przęśle
  d.spans.forEach(q => { const sg = q.seg; if (!sg) return; s += `<rect class="cmbhit" data-seg="${sg.idx}" x="${X(sg.x0).toFixed(1)}" y="${yTop + lab - 4}" width="${(X(sg.x1) - X(sg.x0)).toFixed(1)}" height="${HB - lab}" fill="transparent"><title>${esc(sg.label)} – kliknij, aby ustawić odwrotną strzałkę ugięcia w₀ w tym ${sg.kind === 'span' ? 'przęśle' : 'wsporniku'}${q.camber > 0 ? ` (obecnie ${fmt(q.camber, 0)} mm)` : ''}</title></rect>`; });
  d.spans.forEach(q => {
    const sg = q.seg; if (!sg) return; const xa = X(sg.x0), xb = X(sg.x1), yl = Y(-q.lim);
    s += `<line x1="${xa.toFixed(1)}" y1="${yl.toFixed(1)}" x2="${xb.toFixed(1)}" y2="${yl.toFixed(1)}" stroke="#c0262d" stroke-width="0.9" stroke-dasharray="5 3"><title>${esc(q.label)}: f_lim = L${sg.kind !== 'span' ? '_ref' : ''}/${S.sls.lim} = ${fmt(q.lim, 1)} mm</title></line>`;
    if (xb - xa > 60) s += tx(xb - 3, yl + 10, `f_lim ${fmt(q.lim, 1)}`, { fs: f2 - 1, a: 'end', c: '#c0262d' });
    if (q.camber > 0) {        // odwrotna strzałka w₀ – kształt sinusoidalny w przęśle (wspornik – liniowo)
      const n = 24, cp = []; for (let i = 0; i <= n; i++) { const xx = sg.x0 + sg.L * i / n, w0 = sg.kind === 'span' ? q.camber * Math.sin(Math.PI * i / n) : q.camber * (sg.supL ? i / n : 1 - i / n); cp.push(`${X(xx).toFixed(1)},${Y(w0).toFixed(1)}`); }
      s += `<path d="M${cp.join(' L')}" fill="none" stroke="#a35d00" stroke-width="1.3" stroke-dasharray="6 4" pointer-events="none"/>`;
      const xm = sg.kind === 'span' ? (sg.x0 + sg.x1) / 2 : (sg.supL ? sg.x1 : sg.x0);
      s += putVal(X(xm), Y(q.camber), `w₀ = ${fmt(q.camber, 0)} mm`, '#a35d00', [[0, 'middle', -5], [8, 'start', -2], [-8, 'end', -2], [0, 'middle', 12]]);
    }
    const w = wAt(q.tot.x), fe = q.tot.f - (q.camberUse ? q.camber : 0), ok = fe <= q.lim + 1e-9;
    const txt = q.camberUse ? `f − w₀ = ${fmt(fe, 1)} mm` : `f = ${fmt(q.tot.f, 1)} mm`;
    s += putVal(X(q.tot.x), Y(w), txt, ok ? '#163f86' : '#c0262d', [[0, 'middle', 13], [6, 'start', 12], [-6, 'end', 12], [0, 'middle', -5]]);
  });
  return s;
}
function diagBand(kind, X, yTop, HB, fs, W, ml, mr, edit) {
  const st = R.st, md = R.md, req = R.req; let s = '';
  // indeksy punktów wykresu w każdym odcinku (przęśle / wsporniku); przy skoku (dwa punkty w tym samym x na podporze) – wartość od strony odcinka
  const segKs = xs => md.segs.map(sg => { const ks = []; xs.forEach((x, k) => { if (x >= sg.x0 - 1e-6 && x <= sg.x1 + 1e-6) ks.push(k); });
    while (ks.length > 1 && Math.abs(xs[ks[0]] - xs[ks[1]]) < 1e-6) ks.shift(); while (ks.length > 1 && Math.abs(xs[ks[ks.length - 1]] - xs[ks[ks.length - 2]]) < 1e-6) ks.pop(); return ks; });
  // opisy wartości ekstremalnych w każdym odcinku – bez nakładania (kolejne położenia: z prawej, z lewej, wyżej/niżej)
  const vBoxes = [];
  // cs – kolejne położenia opisu względem punktu: [dx, wyrównanie, dy]
  const putVal = (xx, yy, txt, c, cs) => { const tw = txt.length * (fs - 2) * 0.58 + 2, cands = cs.map(([dx, a, dy]) => [xx + dx, a, yy + dy]);
    for (const [x0, a, ty] of cands) { const bx = a === 'start' ? x0 : a === 'end' ? x0 - tw : x0 - tw / 2; if (bx < ml - 30 || bx + tw > W - mr + 30) continue; if (vBoxes.some(q => bx < q[2] && bx + tw > q[0] && ty - 8 < q[3] && ty + 1 > q[1])) continue;
      vBoxes.push([bx, ty - 8, bx + tw, ty + 1]); return `<circle cx="${xx.toFixed(1)}" cy="${yy.toFixed(1)}" r="2" fill="${c}"/>` + tx(x0, ty, txt, { fs: fs - 2, a, c, w: 600 }); }
    return `<circle cx="${xx.toFixed(1)}" cy="${yy.toFixed(1)}" r="2" fill="${c}"/>`; };
  const lab = fs + 3, f2 = fs - 1.5, cw = f2 * 0.56;
  const run = (arr, keyOf) => { const out = []; let k0 = 0; for (let k = 1; k <= arr.length; k++) { if (k === arr.length || keyOf(arr[k]) !== keyOf(arr[k0])) { out.push([k0, k - 1, keyOf(arr[k0])]); k0 = k; } } return out; };
  s += `<g class="diag" pointer-events="visiblePainted">`;
  if (kind === 'N' || kind === 'R') return s + diagNR(kind, X, yTop, HB, fs, W, ml, mr) + '</g>';
  if (kind === 'f') return s + diagF(X, yTop, HB, fs, W, ml, mr, putVal) + '</g>';
  s += tx(ml - 4, yTop + 9, kind === 'M' ? 'M [kNm]' : 'V [kN]', { fs: f2, a: 'end', c: '#7a8494' });
  if (kind === 'M') {
    // wykres M z redukcją nad szerokimi podporami (5.3.2.2): obwiednia zredukowana; bez redukcji – linia przerywana nad podporą
    const xs = st.x, pos = st.MEdMax.map(v => Math.max(0, v) / 1e6), neg = (st.MEdMinR || st.MEdMin).map(v => Math.max(0, -v) / 1e6), neg0 = st.MEdMin.map(v => Math.max(0, -v) / 1e6);
    const pM = Math.max(0, ...pos), nM = Math.max(0, ...neg0), tot = Math.max(1e-6, pM + nM);
    const inner = HB - 2 * lab - 6, sc = inner / tot, y0 = yTop + lab + 3 + nM * sc;
    const path = (arr, sg) => `M${X(xs[0]).toFixed(1)},${y0.toFixed(1)}` + xs.map((x, k) => ` L${X(x).toFixed(1)},${(y0 + sg * arr[k] * sc).toFixed(1)}`).join('') + ` L${X(xs[xs.length - 1]).toFixed(1)},${y0.toFixed(1)} Z`;
    s += `<line x1="${X(0)}" y1="${y0.toFixed(1)}" x2="${X(md.Ltot)}" y2="${y0.toFixed(1)}" stroke="#7a8494" stroke-width="0.7" stroke-dasharray="3 2"/>`;
    if (pM > 1e-3) s += `<path d="${path(pos, 1)}" fill="#c0262d" fill-opacity="0.12" stroke="#c0262d" stroke-opacity="0.7" stroke-width="1.2"/>`;
    if (nM > 1e-3) s += `<path d="${path(neg, -1)}" fill="#1d5bb8" fill-opacity="0.11" stroke="#1d5bb8" stroke-opacity="0.7" stroke-width="1.2"/>`;
    (st.supRed || []).forEach(q => { if (!q || !q.U) return; const p = q.sup, ks = []; xs.forEach((x, k) => { if (Math.abs(x - p.x) <= p.t / 2 + 1e-6) ks.push(k); }); if (ks[0] > 0) ks.unshift(ks[0] - 1); if (ks[ks.length - 1] < xs.length - 1) ks.push(ks[ks.length - 1] + 1);
      if (ks.length > 1) s += `<path d="M${ks.map(k => `${X(xs[k]).toFixed(1)},${(y0 - neg0[k] * sc).toFixed(1)}`).join(' L')}" fill="none" stroke="#1d5bb8" stroke-opacity="0.75" stroke-width="0.9" stroke-dasharray="2.5 1.5"><title>${esc(p.name)}: bez redukcji (w osi) ${fmt(-q.U.M0 / 1e6, 1)} kNm → zredukowany ${fmt(-q.U.M / 1e6, 1)} kNm (${q.U.kind === 'free' ? `ΔM = F·t/8 = ${fmt(q.U.dM / 1e6, 1)} kNm` : 'moment w licu, ≥ 0,65·M'}; 5.3.2.2)</title></path>`; });
    const P = req.pts;
    // opisy prętów: zbrojenie z pełnego automatycznego doboru (wszystkie warunki – SGN, rysy, ugięcie, rozstaw, zakotwienie; to samo co „Dobierz zbrojenie”);
    // do czasu zakończenia doboru (w tle) – bez opisów; gdy dobór niemożliwy – pręty wymagane ze zginania (szare)
    const A = autoBars(), aSt = A ? 'ok' : autoPending() ? 'pend' : 'none', dS = S.reb.dSel || {};
    const prt = ps => ps.map(p => `${p.n}⌀${p.d}`).join('+');
    const keyB = q => !(q.nB > 0) ? '' : A ? JSON.stringify(A.at(q.x).bot) : aSt === 'pend' ? '' : `${q.nB}⌀${q.dB}`;
    const keyT = q => !(q.AsT > 0) ? '' : A ? JSON.stringify(A.at(q.x).top) : aSt === 'pend' ? '' : `${q.nT}⌀${q.dT}` + (q.nX > 0 ? `+${q.nX}⌀${q.dX}` : '');
    const partsOf = key => A ? JSON.parse(key) : null;
    const plain = key => A ? prt(partsOf(key)) : key;
    const asOf = key => A ? partsOf(key).reduce((a, p) => a + p.n * Math.PI * p.d * p.d / 4, 0) : key.split('+').reduce((a, t) => a + (+t.split('⌀')[0]) * Math.PI * (+t.split('⌀')[1]) ** 2 / 4, 0);
    // opis z klikalnymi średnicami (wybór średnicy strefy – liczba prętów dobierana do niej)
    const labTxt = (xc, yt, key, c) => { if (!A) return tx(xc, yt, key, { fs: f2, c: aSt === 'none' ? '#7a8494' : c, w: 650 });
      return tx(xc, yt, partsOf(key).map((p, i) => (i ? '+' : '') + (edit && p.dz ? `<tspan class="dsel${dS[p.dz] ? ' dfix' : ''}" data-dz="${p.dz}"${dS[p.dz] ? ' fill="#a35d00"' : ''}><title>${esc(`${dzName(p.dz)}: ${p.n}⌀${p.d}${dS[p.dz] ? ' – średnica wybrana ręcznie' : ' – średnica dobrana automatycznie'}; kliknij, aby wybrać średnicę (liczba prętów zostanie dobrana do niej)`)}</title>${p.n}⌀${p.d}</tspan>` : `${p.n}⌀${p.d}`)).join(''), { fs: f2, c, w: 650 }); };
    const SRC = A ? 'zbrojenie z automatycznego doboru – wszystkie warunki (SGN, A_s,min, rysy, naprężenia, ugięcie, rozstaw 8.2, zakotwienie); to samo zbrojenie zada „Dobierz zbrojenie”' : 'pręty wymagane z warunku zginania (SGN + A_s,min) – pełny dobór zbrojenia niemożliwy przy tych danych';
    const placed = { b: [], t: [] };
    const free = (lane, x0, x1) => !placed[lane].some(([u, v]) => x0 < v + 3 && x1 > u - 3);
    // odcinki z ekstremum w każdym obszarze M > 0 (M < 0) – etykieta zawsze
    const peaks = (arr, ok) => { const out = new Set(); let k = 0; while (k < arr.length) { if (!ok(k)) { k++; continue; } let j = k, best = k; while (j < arr.length && ok(j)) { if (arr[j] > arr[best]) best = j; j++; } out.add(best); k = j; } return out; };
    const pkB = peaks(pos, k => P[k] && P[k].nB > 0), pkT = peaks(neg, k => P[k] && P[k].AsT > 0);
    const bot = run(P, keyB);
    bot.forEach(([a, b, key]) => {
      if (!key) return;
      const xa = X(P[a].x), xb = X(P[b].x), w = xb - xa, dep = Math.max(...pos.slice(a, b + 1)) * sc;
      const As = Math.max(...P.slice(a, b + 1).map(q => q.AsB)), txt = plain(key);
      s += `<rect x="${xa.toFixed(1)}" y="${y0.toFixed(1)}" width="${Math.max(1, w).toFixed(1)}" height="${Math.max(4, dep).toFixed(1)}" fill="transparent"><title>${esc(`dół, x = ${fmt(P[a].x / 1000, 2)}–${fmt(P[b].x / 1000, 2)} m: A_s,req (zginanie) ≤ ${fmt(As, 0)} mm² → ${txt} (${fmt(asOf(key), 0)} mm²) – ${SRC}`)}</title></rect>`;
      if (a > 0) s += `<line x1="${xa.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${xa.toFixed(1)}" y2="${(y0 + dep).toFixed(1)}" stroke="#c0262d" stroke-opacity="0.35" stroke-width="0.7"/>`;
      let pk = -1; for (let k = a; k <= b; k++) if (pkB.has(k)) pk = k;
      const tw = txt.length * cw, xc = w >= tw + 4 ? (xa + xb) / 2 : pk >= 0 ? Math.max(ml + tw / 2, Math.min(W - mr - tw / 2, X(P[pk].x))) : null;
      if (xc !== null && free('b', xc - tw / 2, xc + tw / 2)) { placed.b.push([xc - tw / 2, xc + tw / 2]); const yt = Math.min(yTop + HB - 2, y0 + dep + f2 + 1); vBoxes.push([xc - tw / 2, yt - f2, xc + tw / 2, yt + 2]); s += labTxt(xc, yt, key, '#9b1c22'); }
    });
    { // zasięg stref: dozbrojenie górą (pręty dodatkowe) i dołem (więcej niż pręty doprowadzone do podpór) – wymiary pod wykresem
      // (z doboru automatycznego – rzeczywiste długości prętów dodatkowych nad podporami i prętów skróconych w przęśle)
      const yz = yTop + HB + 10, nB0 = Math.min(...P.filter(q => q.nB > 0).map(q => q.nB));
      const zs = A ? A.ext.map(q => [q.x0, q.x1, q.top ? '#1d5bb8' : '#9b1c22', q.top ? 'góra +' : 'dół', q.parts])
        : aSt === 'pend' ? [] : [...run(P, q => q.nX > 0 ? 't' : '').filter(r => r[2]).map(r => [P[r[0]].x, P[r[1]].x, '#1d5bb8', 'góra +']), ...run(P, q => q.nB > nB0 ? 'b' : '').filter(r => r[2]).map(r => [P[r[0]].x, P[r[1]].x, '#9b1c22', 'dół'])];
      const lanes = [];
      zs.sort((u, v) => u[0] - v[0]).forEach(([x0, x1, c, nm, pp]) => { const xa = X(x0), xb = X(x1); if (xb - xa < 6) return;
        let ln = 0; while (lanes[ln] && lanes[ln] > xa - 4) ln++; lanes[ln] = xb; const yy = yz + ln * 11, L2 = (x1 - x0) / 1000, lab = `${nm} ${fmt(L2, 2)}`;
        s += `<g stroke="${c}" stroke-width="0.8" stroke-opacity="0.85"><line x1="${xa.toFixed(1)}" y1="${yy}" x2="${xb.toFixed(1)}" y2="${yy}"/><line x1="${xa.toFixed(1)}" y1="${yy - 3}" x2="${xa.toFixed(1)}" y2="${yy + 3}"/><line x1="${xb.toFixed(1)}" y1="${yy - 3}" x2="${xb.toFixed(1)}" y2="${yy + 3}"/><title>${esc(`${nm === 'dół' ? 'pręty dolne skrócone (dozbrojenie przęsła)' : 'pręty górne dodatkowe nad podporą'}: ${fmt(L2, 2)} m${A ? ' – długość pręta z doboru automatycznego (z zakotwieniem)' : ' – zasięg wymagany'}`)}</title></g>`;
        // z doboru automatycznego: pręty w opisie wymiaru (klikalna średnica – także tam, gdzie nie ma opisu nad wykresem, np. 0,15·A_s przy podporze skrajnej)
        const pt = pp && pp.length ? prt(pp) : '', lab2 = pt ? `${nm} ${pt} · ${fmt(L2, 2)}` : lab;
        if (pt && xb - xa > lab2.length * cw + 4) s += tx((xa + xb) / 2, yy - 2, `${nm} ` + pp.map((p, i) => (i ? '+' : '') + (edit && p.dz ? `<tspan class="dsel${dS[p.dz] ? ' dfix' : ''}" data-dz="${p.dz}"${dS[p.dz] ? ' fill="#a35d00"' : ''}><title>${esc(`${dzName(p.dz)}: kliknij, aby wybrać średnicę`)}</title>${p.n}⌀${p.d}</tspan>` : `${p.n}⌀${p.d}`)).join('') + ` · ${fmt(L2, 2)}`, { fs: f2 - 0.5, c });
        else if (xb - xa > lab.length * cw + 4) s += tx((xa + xb) / 2, yy - 2, lab, { fs: f2 - 0.5, c }); });
    }
    const top = run(P, keyT);
    top.forEach(([a, b, key]) => {
      if (!key) return;
      const xa = X(P[a].x), xb = X(P[b].x), w = xb - xa, hgt = Math.max(...neg.slice(a, b + 1)) * sc;
      const As = Math.max(...P.slice(a, b + 1).map(q => q.AsT)), txt = plain(key);
      s += `<rect x="${xa.toFixed(1)}" y="${(y0 - Math.max(4, hgt)).toFixed(1)}" width="${Math.max(1, w).toFixed(1)}" height="${Math.max(4, hgt).toFixed(1)}" fill="transparent"><title>${esc(`góra, x = ${fmt(P[a].x / 1000, 2)}–${fmt(P[b].x / 1000, 2)} m: A_s,req (zginanie) ≤ ${fmt(As, 0)} mm² → ${A ? partsOf(key).map(p => `${p.n}⌀${p.d} ${p.dz === 't' ? 'ciągłe' : 'dodatkowe'}`).join(' + ') : key.replace('+', ' ciągłe + ')} (${fmt(asOf(key), 0)} mm²) – ${SRC}`)}</title></rect>`;
      if (a > 0) s += `<line x1="${xa.toFixed(1)}" y1="${y0.toFixed(1)}" x2="${xa.toFixed(1)}" y2="${(y0 - hgt).toFixed(1)}" stroke="#1d5bb8" stroke-opacity="0.35" stroke-width="0.7"/>`;
      let pk = -1; for (let k = a; k <= b; k++) if (pkT.has(k)) pk = k;
      const tw = txt.length * cw, xc = w >= tw + 4 ? (xa + xb) / 2 : pk >= 0 ? Math.max(ml + tw / 2, Math.min(W - mr - tw / 2, X(P[pk].x))) : null;
      if (xc !== null && free('t', xc - tw / 2, xc + tw / 2)) { placed.t.push([xc - tw / 2, xc + tw / 2]); const yt = Math.max(yTop + f2, y0 - hgt - 3); vBoxes.push([xc - tw / 2, yt - f2, xc + tw / 2, yt + 2]); s += labTxt(xc, yt, key, '#163f86'); }
    });
    if (aSt === 'pend') s += tx(ml + 2, yTop + 9, 'dobór zbrojenia (wszystkie warunki)…', { fs: f2 - 1, a: 'start', c: '#7a8494' });
    else if (A && dimSt.auto && dimSt.auto.ok === false) { const a = dimSt.auto, ids = new Set(a.fails || []), nm = [...new Set(a.R.checks.filter(c => ids.has(c.id)).map(c => c.name.replace(/\s*\(.*$/, '').replace(/ [≤≥].*$/, '')))];
      s += `<g><title>${esc(`Zbrojenie dobrane przy tych wymiarach${Object.keys(dS).length ? ' i wybranych średnicach' : ''} nie spełnia: ${nm.join('; ')}. ${Object.keys(dS).length ? 'Zmień wybraną średnicę (kliknij n⌀) albo powiększ przekrój.' : 'Powiększ przekrój (✖ przy wymiarach b × h).'}`)}</title>${tx(ml + 2, yTop + 9, `✖ nie spełnia: ${nm.slice(0, 2).join('; ')}${nm.length > 2 ? '…' : ''}`, { fs: f2 - 1, a: 'start', c: '#c0262d' })}</g>`; }
    else if (aSt === 'none' && !MAN(S)) s += tx(ml + 2, yTop + 9, 'pełny dobór zbrojenia niemożliwy – pręty ze zginania', { fs: f2 - 1, a: 'start', c: '#c0262d' });
    // wartości ekstremalne – w każdym przęśle (wsporniku): największy moment dodatni i ujemny w tym odcinku (nad podporą – w osi)
    { const done = new Set(), KS = segKs(xs);
      KS.forEach(ks => [[pos, 1, '#c0262d', pM], [neg, -1, '#1d5bb8', nM]].forEach(([arr, sgn, c, gm]) => { if (!ks.length) return;
        const k = ks.reduce((a, q) => (arr[q] > arr[a] ? q : a), ks[0]); if (arr[k] < Math.max(1e-3, 0.02 * gm) || done.has(sgn + ':' + Math.round(xs[k]))) return; done.add(sgn + ':' + Math.round(xs[k]));
        const cs = sgn > 0 ? [[0, 'middle', -5], [5, 'start', -4], [-5, 'end', -4], [5, 'start', 10], [-5, 'end', 10]] : [[0, 'middle', 12], [5, 'start', 11], [-5, 'end', 11], [5, 'start', -4], [-5, 'end', -4]];
        s += putVal(X(xs[k]), y0 + sgn * arr[k] * sc, fmt(sgn * arr[k], 1), c, cs); })); }
    // nad podporą z redukcją (5.3.2.2): wartość w osi bez redukcji – szara, przy szczycie linii przerywanej
    (st.supRed || []).forEach(q => { if (!q || !q.U || q.U.dM < 0.005 * q.U.M0) return; const xr = X(q.sup.x), yr = y0 - q.U.M0 / 1e6 * sc;
      s += putVal(xr, yr, `bez red. ${fmt(-q.U.M0 / 1e6, 1)}`, '#7a8494', [[0, 'middle', -4], [8, 'start', -2], [-8, 'end', -2], [8, 'start', 8], [-8, 'end', 8]]); });
    s += `<g class="cinfo"><title>${esc(`${A ? 'pręty n⌀ z automatycznego doboru zbrojenia – spełniają wszystkie warunki (SGN, A_s,min, rysy, naprężenia, ugięcie, rozstaw prętów 8.2, zakotwienie); to samo zbrojenie zada „Dobierz zbrojenie” w zakładce Zbrojenie belki. Kliknij n⌀ – wybór średnicy prętów w tej strefie (liczba prętów dobierana do wybranej średnicy; pomarańczowe – średnica wybrana ręcznie)' : `pręty wymagane n⌀ (SGN + A_s,min, przesunięcie a_l = ${fmt(req.aL, 0)} mm)`}: dół / góra${(st.supRed || []).some(q => q && q.U) ? '; nad szerokimi podporami – wykres zredukowany wg 5.3.2.2 (linia przerywana – bez redukcji, wartość w osi)' : ''}`)}</title>${tx(W - mr, yTop + 9, 'ⓘ objaśnienie', { fs: f2 - 1, a: 'end', c: '#1d5bb8' })}</g>`;
  } else {
    const xs = st.xV, vp = st.VEdMax.map(v => Math.max(0, v) / 1e3), vn = st.VEdMin.map(v => Math.max(0, -v) / 1e3);
    const pM = Math.max(0, ...vp), nM = Math.max(0, ...vn), tot = Math.max(1e-6, pM + nM);
    const strip = 26, inner = HB - lab - strip - 4, sc = inner / tot, y0 = yTop + lab + pM * sc;
    const path = (arr, sg) => `M${X(xs[0]).toFixed(1)},${y0.toFixed(1)}` + xs.map((x, k) => ` L${X(x).toFixed(1)},${(y0 - sg * arr[k] * sc).toFixed(1)}`).join('') + ` L${X(xs[xs.length - 1]).toFixed(1)},${y0.toFixed(1)} Z`;
    // strefy strzemion (tło)
    const ySt = yTop + HB - strip + 2;
    (R.stirZones || []).forEach(z => (z.parts || []).forEach(pt => {
      const q = z.seg.stir || S.stir, isS1 = Math.abs(pt.s - q.s1) < 0.5 && !(z.uniform && q.s1 >= q.s2), isSp = q.sp && Math.abs(pt.s - q.sp) < 0.5;
      const c = isS1 ? '#1d7f3c' : isSp ? '#5aa469' : '#9aa3b0', op = isS1 ? 0.2 : isSp ? 0.14 : 0.08;
      const xa = X(pt.x0), xb = X(pt.x1), w = xb - xa;
      s += `<rect x="${xa.toFixed(1)}" y="${yTop + lab - 2}" width="${Math.max(0.5, w).toFixed(1)}" height="${(ySt - yTop - lab + 12).toFixed(1)}" fill="${c}" fill-opacity="${op * 0.5}"/>`;
      s += `<rect x="${xa.toFixed(1)}" y="${ySt.toFixed(1)}" width="${Math.max(0.5, w).toFixed(1)}" height="11" fill="${c}" fill-opacity="${op + 0.1}" stroke="${c}" stroke-opacity="0.6" stroke-width="0.6"><title>${isS1 ? 'strefa 1 (przy podporze)' : isSp ? 'strefa pośrednia' : 'część środkowa'}: rozstaw ${fmt(pt.s, 0)} mm, ${pt.n} odstępów, ${fmt((pt.x1 - pt.x0) / 1000, 2)} m</title></rect>`;
      const t = `${isS1 ? 's₁' : isSp ? 's_p' : 's₂'} ${fmt(pt.s, 0)}`;
      if (w >= t.length * cw * 0.95 + 4) { const tw3 = t.length * cw * 0.95; vBoxes.push([(xa + xb) / 2 - tw3 / 2, ySt, (xa + xb) / 2 + tw3 / 2, ySt + 11]); s += tx((xa + xb) / 2, ySt + 8.6, t, { fs: f2 - 1, c: isS1 ? '#155e2c' : '#3d4656', w: 600 }); }
    }));
    s += `<line x1="${X(0)}" y1="${y0.toFixed(1)}" x2="${X(md.Ltot)}" y2="${y0.toFixed(1)}" stroke="#7a8494" stroke-width="0.7" stroke-dasharray="3 2"/>`;
    if (pM > 1e-3) s += `<path d="${path(vp, 1)}" fill="#c0262d" fill-opacity="0.12" stroke="#c0262d" stroke-opacity="0.7" stroke-width="1.2"/>`;
    if (nM > 1e-3) s += `<path d="${path(vn, -1)}" fill="#c0262d" fill-opacity="0.12" stroke="#c0262d" stroke-opacity="0.7" stroke-width="1.2"/>`;
    // V_Rd,s(s₂) i wymagany zasięg zagęszczenia od lica
    (R.sh.ends || []).forEach(e => {
      const face = e.x + e.dir * e.sup.t / 2, need = e.sp ? e.l12req : e.l1req, sgn = e.dir > 0 ? 1 : -1;
      const sideV = st.Vat(face + e.dir * 10) >= 0 ? 1 : -1, yR = y0 - sideV * e.VRds2 / 1e3 * sc;
      const xr = face + e.dir * Math.min(e.reach, Math.max(need, 0) + 600);
      if (yR >= yTop + 2 && yR <= ySt - 6) s += `<line x1="${X(Math.min(face, xr)).toFixed(1)}" y1="${yR.toFixed(1)}" x2="${X(Math.max(face, xr)).toFixed(1)}" y2="${yR.toFixed(1)}" stroke="#1d5bb8" stroke-opacity="0.7" stroke-width="0.9" stroke-dasharray="5 3"><title>V_Rd,s(s₂ = ${e.stir.s2} mm) = ${fmt(e.VRds2 / 1e3, 1)} kN</title></line>`;
      if (!(need > 1)) return;
      const xa = X(face), xb = X(face + e.dir * need), yb2 = ySt - 4;
      s += `<path d="M${xa.toFixed(1)},${(yb2 - 3).toFixed(1)} v3 H${xb.toFixed(1)} v-3" fill="none" stroke="#155e2c" stroke-width="1.3"/>`;
      const t = `wym. ${fmt(need / 1000, 2)} m`, mx = (xa + xb) / 2;
      const tw2 = t.length * cw * 0.95;
      if (Math.abs(xb - xa) >= t.length * cw * 0.9) { vBoxes.push([mx - tw2 / 2, yb2 - 13, mx + tw2 / 2, yb2 - 3]); s += tx(mx, yb2 - 5, t, { fs: f2 - 1, c: '#155e2c', w: 650 }); }
      else { const bx = sgn > 0 ? xa + 2 : xa - 2 - tw2; vBoxes.push([bx, yb2 - 13, bx + tw2, yb2 - 3]); s += tx(sgn > 0 ? xa + 2 : xa - 2, yb2 - 5, t, { fs: f2 - 1, c: '#155e2c', w: 650, a: sgn > 0 ? 'start' : 'end' }); }
      void sgn;
    });
    { const KS = segKs(xs);   // w każdym przęśle (wsporniku): największa siła dodatnia i ujemna w tym odcinku (przy podporach – w osi, od strony przęsła)
      KS.forEach((ks, si) => [[vp, 1, pM], [vn, -1, nM]].forEach(([arr, sg, gm]) => { if (!ks.length) return; const k = ks.reduce((a, q) => (arr[q] > arr[a] ? q : a), ks[0]); if (arr[k] < Math.max(1e-3, 0.02 * gm)) return;
        const atR = Math.abs(xs[k] - md.segs[si].x1) < 1, d = atR ? -1 : 1, a1 = d > 0 ? 'start' : 'end', a2 = d > 0 ? 'end' : 'start', v1 = sg > 0 ? -3 : 10, v2 = sg > 0 ? -12 : 19;
        s += putVal(X(xs[k]), y0 - sg * arr[k] * sc, fmt(sg * arr[k], 1), '#c0262d', [[4 * d, a1, v1], [4 * d, a1, v2], [8 * d, a1, sg > 0 ? 10 : -4], [-4 * d, a2, v1]]); })); }
    const pk = (arr, sg) => { let k = 0; arr.forEach((v, i) => { if (v > arr[k]) k = i; }); if (arr[k] < 1e-3) return; const xx = X(xs[k]), yy = y0 - sg * arr[k] * sc;
      s += tx(xx + (xx > W - mr - 40 ? -4 : 4), yy + (sg > 0 ? 9 : -3), fmt(sg * arr[k], 1), { fs: f2 - 0.5, a: xx > W - mr - 40 ? 'end' : 'start', c: '#c0262d' }); };
    void pk;
    // ręczna długość stref zagęszczenia (tylko w Danych): uchwyt na końcu strefy s₁ (i s_p) – przeciągnij lub kliknij strefę
    if (edit) (R.sh.ends || []).forEach((e, i) => {
      const face = e.x + e.dir * e.sup.t / 2, xa = X(face), seg = [['l1', e.l1, e.l1Own], ...(e.sp ? [['lp', e.l1 + e.lp, e.lpOwn]] : [])];
      const x1 = X(face + e.dir * Math.max(e.l1 + (e.sp ? e.lp : 0), 1));
      s += `<rect class="zclick" data-end="${i}" x="${Math.min(xa, x1).toFixed(1)}" y="${(ySt - 1).toFixed(1)}" width="${Math.max(6, Math.abs(x1 - xa)).toFixed(1)}" height="13" fill="transparent"><title>${esc(e.sup.name)}, ${esc(e.seg.label)}: strefa zagęszczenia s₁ = ${fmt(e.l1 / 1000, 2)} m${e.sp ? `, s_p = ${fmt(e.lp / 1000, 2)} m` : ''} od lica (wymagana ${fmt((e.sp ? e.l12req : e.l1req) / 1000, 2)} m) – kliknij, aby wpisać długość</title></rect>`;
      seg.forEach(([k, L, own]) => { const xh = X(face + e.dir * L), c = own ? '#a35d00' : '#155e2c';
        s += `<g class="zh" data-end="${i}" data-k="${k}"><title>Przeciągnij – długość strefy ${k === 'l1' ? 's₁' : 's_p'} (${fmt(L / 1000, 2)} m od lica${own ? ', ustawiona ręcznie' : ''}); kliknij – wpisz</title><rect x="${(xh - 5).toFixed(1)}" y="${(ySt - 6).toFixed(1)}" width="10" height="23" fill="transparent"/><path d="M${xh.toFixed(1)},${(ySt - 4).toFixed(1)} V${(ySt + 14).toFixed(1)} M${(xh - 3).toFixed(1)},${(ySt - 4).toFixed(1)} h6 M${(xh - 3).toFixed(1)},${(ySt + 14).toFixed(1)} h6" stroke="${c}" stroke-width="1.6" fill="none"/></g>`; });
      if (e.l1Own || e.lpOwn) s += tx(xa + e.dir * 3, ySt + 22, '✎', { fs: f2 - 1, c: '#a35d00', a: e.dir > 0 ? 'start' : 'end' });
    });
    if (edit) s += `<g class="zmap" data-xa="${X(0).toFixed(3)}" data-xk="${((X(1000) - X(0)) / 1000).toFixed(6)}"></g>`;
    const e0 = (R.sh.ends || [])[0];
    s += `<g class="cinfo"><title>${esc(`strefy s₁ / s_p / s₂; wym. – zasięg zagęszczenia: V_Ed > V_Rd,s(s₂)${e0 ? ` = ${fmt(e0.VRds2 / 1e3, 0)} kN` : ''} (przerywana)${edit ? '; uchwyt ⊢ na końcu strefy – przeciągnij lub kliknij (✎ – długość ręczna)' : ''}`)}</title>${tx(W - mr, yTop + 9, 'ⓘ objaśnienie', { fs: f2 - 1, a: 'end', c: '#1d5bb8' })}</g>`;
  }
  return s + '</g>';
}

/* ------------------------------------------------------------- wykresy */
function lineChart(o) {
  const W = o.W || 820, narrow = W < 640, wrapT = narrow && (o.title || '').length * 6.2 > W, H = (o.H || 230) + 14 + (wrapT ? 12 : 0), ml = narrow ? 46 : 62, mr = narrow ? 86 : 130, mt = narrow ? (wrapT ? 64 : 52) : 40, mb = 34;
  const xs = o.series.flatMap(s => s.x), ys = o.series.flatMap(s => s.y).concat((o.hl || []).map(h => h.y), (o.hseg || []).map(h => h.y)).concat([0]);
  const xmin = o.xmin !== undefined ? o.xmin : Math.min(...xs), xmax = o.xmax !== undefined ? o.xmax : Math.max(...xs);
  let ymin = Math.min(...ys), ymax = Math.max(...ys);
  if (ymax - ymin < 1e-9) { ymax += 1; ymin -= 1; }
  const ph = H - mt - mb, padPx = (o.marks || []).some(m => m.l) ? 20 : 0, pad = (ymax - ymin) * Math.max(0.08, padPx / Math.max(40, ph - 2 * padPx)); ymin -= pad; ymax += pad;   // miejsce na opisy ekstremów nad/pod wykresem
  const inv = !!o.invert;
  const X = x => ml + (x - xmin) / (xmax - xmin) * (W - ml - mr);
  const Y = y => inv ? mt + (y - ymin) / (ymax - ymin) * (H - mt - mb) : H - mb - (y - ymin) / (ymax - ymin) * (H - mt - mb);
  const cid = 'c' + (++chartSeq);
  CHARTS[cid] = { ml, mr, W, H, mt, mb, xmin, xmax, ymin, ymax, inv, series: o.series, unit: o.unit || '', dp: o.dp !== undefined ? o.dp : 1, name: o.short || '', yl: o.yl || '', title: o.title || '' };
  let s = svgOpen(W, H, `class="lchart" data-cid="${cid}"`);
  if (narrow && (o.title || '').length * 6.2 > W) {
    const t = o.title, cut = Math.max(t.lastIndexOf(' (', Math.floor(W / 6.2)), t.lastIndexOf(' – ', Math.floor(W / 6.2)), t.lastIndexOf(' ', Math.floor(W / 6.2)));
    s += tx(4, 13, esc(t.slice(0, cut)), { a: 'start', fs: 11, w: 650 }) + tx(4, 26, esc(t.slice(cut).replace(/^ – /, '').trim()), { a: 'start', fs: 10.5, c: '#4a5466' });
  } else s += tx(narrow ? 4 : ml, 14, esc(o.title || ''), { a: 'start', fs: narrow ? 11 : 12, w: 650 });
  // siatka
  const ticks = niceTicks(ymin, ymax, 6);
  ticks.forEach(t => { s += `<line x1="${ml}" y1="${Y(t)}" x2="${W - mr}" y2="${Y(t)}" stroke="#eef0f3"/>` + tx(ml - 6, Y(t) + 3.5, fmt(t, Math.abs(ticks[1] - ticks[0]) < 1 ? 1 : 0), { a: 'end', fs: 10, c: '#7a8494' }); });
  const xt = niceTicks(xmin, xmax, narrow ? 5 : 10);
  xt.forEach(t => { if (t < xmin - 1e-9 || t > xmax + 1e-9) return; s += `<line x1="${X(t)}" y1="${mt}" x2="${X(t)}" y2="${H - mb}" stroke="#f3f4f6"/>` + tx(X(t), H - mb + 14, fmt(t, xt[1] - xt[0] < 1 ? 1 : 0), { fs: 10, c: '#7a8494' }); });
  s += tx((ml + W - mr) / 2, H - 4, o.xl || 'x [m]', { fs: 10.5, c: '#4a5466' });
  s += tx(14, (mt + H - mb) / 2, o.yl || '', { fs: 10.5, c: '#4a5466', rot: -90 });
  (o.bands || []).forEach(b => { s += `<rect x="${X(b.x0)}" y="${mt}" width="${X(b.x1) - X(b.x0)}" height="${H - mt - mb}" fill="${b.c}"/>`; });   // opisy pasm – po opisach ekstremów
  (o.vl || []).forEach(v => { s += `<line x1="${X(v.x)}" y1="${mt}" x2="${X(v.x)}" y2="${H - mb}" stroke="#9aa3b0" stroke-width="0.8" stroke-dasharray="4 3"/>` + (v.l ? tx(X(v.x), mt - 3, v.l, { fs: 9.5, c: '#5b6576', w: 600 }) : ''); });
  s += `<line x1="${ml}" y1="${Y(0)}" x2="${W - mr}" y2="${Y(0)}" stroke="#39414f" stroke-width="1"/>`;
  const hsegL = [];                                                       // opisy odcinków (M_Rd, V_Rd) – rysowane po opisach ekstremów, tak by ich nie zasłaniały
  (o.hseg || []).forEach(h => {
    const a = X(Math.max(xmin, h.x0)), b = X(Math.min(xmax, h.x1));
    s += `<line x1="${a}" y1="${Y(h.y)}" x2="${b}" y2="${Y(h.y)}" stroke="${h.c}" stroke-width="1.2" stroke-dasharray="6 4"/>`;
    if (h.l && b - a > h.l.length * 5.4 + 6) hsegL.push({ a, b, y: Y(h.y), up: !(inv ? h.y < 0 : h.y > 0), l: h.l, c: h.c });
  });
  o.series.forEach(se => {
    const pts = se.x.map((x, i) => `${X(x).toFixed(1)},${Y(se.y[i]).toFixed(1)}`).join(' ');
    if (se.fill) s += `<polygon points="${X(se.x[0]).toFixed(1)},${Y(0).toFixed(1)} ${pts} ${X(se.x[se.x.length - 1]).toFixed(1)},${Y(0).toFixed(1)}" fill="${se.fill}"/>`;
    s += `<polyline points="${pts}" fill="none" stroke="${se.c}" stroke-width="${se.w || 1.6}" ${se.dash ? `stroke-dasharray="${se.dash}"` : ''}/>`;
  });
  const used = [];
  (o.hl || []).forEach(h => {
    s += `<line x1="${ml}" y1="${Y(h.y)}" x2="${W - mr}" y2="${Y(h.y)}" stroke="${h.c}" stroke-width="1.2" stroke-dasharray="6 4"/>`;
    if (!h.l) return;
    let yy = Y(h.y) + 3.5; while (used.some(u => Math.abs(u - yy) < 12)) yy += 12; used.push(yy);
    s += tx(W - mr + 4, yy, h.l, { a: 'start', fs: 10, c: h.c });
  });
  { const boxes = (o.vl || []).filter(v => v.l).map(v => [X(v.x) - 8, mt - 13, X(v.x) + 8, mt - 1]); const fsM = 10;   // litery podpór nad wykresem – nie zasłaniać
    (o.marks || []).slice().sort((a, b) => (a.pri || 0) - (b.pri || 0)).forEach(mk => {
      const below = inv ? mk.y >= 0 : mk.y < 0, px = X(mk.x), py = Y(mk.y);
      const dot = mk.k === 'face' ? `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="2.8" fill="#ffffff" stroke="${mk.c}" stroke-width="1.3"/>` : mk.k === 'kink' ? `<path d="M${px.toFixed(1)},${(py - 3.4).toFixed(1)} l3.4,3.4 l-3.4,3.4 l-3.4,-3.4 z" fill="${mk.c}"/>` : `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="3" fill="${mk.c}"/>`;
      s += dot;
      if (!mk.l) return;
      const tw = mk.l.length * 5.7 + 4, dir = below ? 1 : -1, ty0 = py + (mk.dy !== undefined ? mk.dy : (below ? 14 : -7)), side = mk.a === 'end' ? -1 : 1;
      // kolejne położenia opisu: po swojej stronie wykresu (coraz dalej), po przeciwnej, z boku znacznika (prawo/lewo)
      const cand = [0, 1, 2, 3].map(t => [mk.a || 'middle', px + (mk.dx || 0), ty0 + dir * t * 11])
        .concat([0, 1].map(t => [mk.a || 'middle', px + (mk.dx || 0), py + (below ? -7 : 14) - dir * t * 11]))
        .concat([side, -side].map(sd => [sd < 0 ? 'end' : 'start', px + sd * 6, py + 3.5]));
      const place = ([a0, x0, y0]) => { let a = a0, tx0 = x0, bx = a === 'start' ? tx0 : a === 'end' ? tx0 - tw : tx0 - tw / 2;
        if (bx + tw > W - 3) { tx0 -= bx + tw - (W - 3); bx = W - 3 - tw; } else if (bx < 3) { tx0 += 3 - bx; bx = 3; }   // opis przy krawędzi – w obrębie rysunku
        return { a, tx0, bx, ty: y0 }; };
      const free = c => !boxes.some(q => c.bx < q[2] && c.bx + tw > q[0] && c.ty - 9 < q[3] && c.ty + 2 > q[1]) && c.ty > mt - 2 && c.ty < H - mb + 2;
      let c = cand.map(place).find(free);
      if (!c) { if (mk.k) return; c = place(cand[0]); c.ty = Math.max(mt + 9, Math.min(H - mb, c.ty)); }   // ekstremum – zawsze z opisem; lico/załamanie – sam znacznik
      const { a, tx0, bx } = c, ty = c.ty;
      boxes.push([bx, ty - 9, bx + tw, ty + 2]);
      s += tx(tx0, ty, mk.l, { fs: mk.k === 'face' || mk.k === 'kink' ? fsM - 1 : fsM, c: mk.c, w: mk.k ? 500 : 650, a });
    });
    (o.bands || []).filter(b => b.l).forEach(b => {
      const cx = (X(b.x0) + X(b.x1)) / 2, w2 = b.l.length * 3 + 3, y = [mt + 11, H - mb - 4].find(y => !boxes.some(q => cx - w2 < q[2] && cx + w2 > q[0] && y - 9 < q[3] && y + 2 > q[1]));
      if (y === undefined) return; boxes.push([cx - w2, y - 9, cx + w2, y + 2]); s += tx(cx, y, b.l, { fs: 9.5, c: '#5b6576' });
    });
    hsegL.forEach(h => {
      const tw = h.l.length * 5.4 + 4, hit = (x, y) => boxes.some(q => x < q[2] && x + tw > q[0] && y - 9 < q[3] && y + 2 > q[1]);
      const xs = [h.a + 3, h.b - tw - 3, (h.a + h.b - tw) / 2], ys = h.up ? [h.y - 3, h.y + 11] : [h.y + 11, h.y - 3];
      let at = null; ys.some(y => xs.some(x => { if (x >= h.a && x + tw <= h.b + 1 && !hit(x, y)) { at = [x, y]; return true; } return false; }));
      if (!at) return;                                                      // brak miejsca – sam odcinek (wartość w tytule/tabeli i po najechaniu kursorem)
      boxes.push([at[0], at[1] - 9, at[0] + tw, at[1] + 2]);
      s += tx(at[0], at[1], h.l, { a: 'start', fs: 9.5, c: h.c });
    }); }
  // legenda (w wierszu tytułu, od prawej)
  if (narrow) {
    let lx = ml, ly = (o.title || '').length * 6.2 > W ? 40 : 28;
    o.series.filter(se => se.l).forEach(se => { const tw = se.l.length * 5.6 + 30; if (lx + tw > W - 4 && lx > ml) { lx = ml; ly += 13; } s += `<line x1="${lx}" y1="${ly - 3.5}" x2="${lx + 18}" y2="${ly - 3.5}" stroke="${se.c}" stroke-width="2" ${se.dash ? `stroke-dasharray="${se.dash}"` : ''}/>` + tx(lx + 22, ly, se.l, { a: 'start', fs: 10 }); lx += tw; });
  } else {
    let lx = W - mr;
    o.series.filter(se => se.l).reverse().forEach(se => { const tw = se.l.length * 5.6 + 30; lx -= tw; s += `<line x1="${lx}" y1="26" x2="${lx + 18}" y2="26" stroke="${se.c}" stroke-width="2" ${se.dash ? `stroke-dasharray="${se.dash}"` : ''}/>` + tx(lx + 22, 29.5, se.l, { a: 'start', fs: 10 }); });
  }
  // kursor (pokazywany po najechaniu myszą – wartości w miejscu kursora)
  s += `<g class="cur" style="display:none;pointer-events:none"><line class="curl" x1="0" y1="${mt}" x2="0" y2="${H - mb}" stroke="#1d5bb8" stroke-width="1" stroke-dasharray="3 2"/><g class="curd"></g><rect class="curbg" x="0" y="${mt - 2}" width="10" height="16" rx="3" fill="#ffffff" fill-opacity="0.92" stroke="#c9ced6"/><text class="curtx" x="0" y="${mt + 10}" font-size="10.5" fill="#1b2230"></text></g>`;
  s += '</svg>';
  return s;
}
let chartSeq = 0;
const CHARTS = {};
// wartość serii w punkcie x (interpolacja liniowa; serie V – skoki w węzłach)
function serAt(se, x) {
  const xs = se.x, ys = se.y; let best = null;
  for (let i = 0; i < xs.length - 1; i++) {
    if (x >= xs[i] - 1e-9 && x <= xs[i + 1] + 1e-9 && xs[i + 1] > xs[i]) { best = ys[i] + (ys[i + 1] - ys[i]) * (x - xs[i]) / (xs[i + 1] - xs[i]); break; }
  }
  if (best === null) { let bi = 0; xs.forEach((v, i) => { if (Math.abs(v - x) < Math.abs(xs[bi] - x)) bi = i; }); best = ys[bi]; }
  return best;
}
// wspólny kursor wszystkich wykresów zakładki – bez klikania
function bindChartCursor(root) {
  const svgs = $$('svg.lchart', root);
  const show = xm => svgs.forEach(svg => {
    const c = CHARTS[svg.dataset.cid]; if (!c) return;
    const g = $('.cur', svg); if (xm === null || xm < c.xmin - 1e-9 || xm > c.xmax + 1e-9) { g.style.display = 'none'; return; }
    const px = c.ml + (xm - c.xmin) / (c.xmax - c.xmin) * (c.W - c.ml - c.mr);
    const Yv = y => c.inv ? c.mt + (y - c.ymin) / (c.ymax - c.ymin) * (c.H - c.mt - c.mb) : c.H - c.mb - (y - c.ymin) / (c.ymax - c.ymin) * (c.H - c.mt - c.mb);
    const grp = new Map(); let dots = '', lastL = '';
    c.series.forEach(se => {
      const v = serAt(se, xm); if (v === null || !isFinite(v)) return;
      const lab = (se.l || lastL || '').replace(/\s*\((obwiednia)\)/, ''); if (se.l) lastL = se.l;
      if (!lab) return;
      if (!grp.has(lab)) grp.set(lab, []);
      const g = grp.get(lab); if (!g.some(w => Math.abs(w - v) < 1e-6)) g.push(v);
      dots += `<circle cx="${px.toFixed(1)}" cy="${Yv(v).toFixed(1)}" r="2.6" fill="${se.c}"/>`;
    });
    const parts = [...grp].map(([l, vs]) => `${l} = ${vs.map(v => fmt(v, c.dp)).join(' / ')}`);
    const txt = `x = ${fmt(xm, 2)} m:  ` + parts.join(';  ') + (c.unit ? ` ${c.unit}` : '');
    g.style.display = '';
    $('.curl', g).setAttribute('x1', px); $('.curl', g).setAttribute('x2', px);
    $('.curd', g).innerHTML = dots;
    const t = $('.curtx', g); t.textContent = txt;
    const tw = txt.length * 5.6 + 10, tx0 = Math.max(c.ml, Math.min(c.W - c.mr - tw, px + 8));
    t.setAttribute('x', tx0 + 5); const bg = $('.curbg', g); bg.setAttribute('x', tx0); bg.setAttribute('width', tw);
  });
  const xOf = (svg, ev) => { const c = CHARTS[svg.dataset.cid]; const r = svg.getBoundingClientRect(), vb = svg.viewBox.baseVal; const px = vb.x + (ev.clientX - r.left) * vb.width / r.width; const xm = c.xmin + (px - c.ml) / (c.W - c.ml - c.mr) * (c.xmax - c.xmin); return xm < c.xmin || xm > c.xmax ? null : xm; };
  svgs.forEach(svg => {
    svg.addEventListener('mousemove', ev => show(xOf(svg, ev)));
    svg.addEventListener('touchmove', ev => { if (ev.touches[0]) show(xOf(svg, ev.touches[0])); }, { passive: true });
    svg.addEventListener('mouseleave', () => show(null));
    // kliknięcie wykresu – znacznik w tym miejscu belki: kropki i wartości na wszystkich wykresach (jak przy ekstremach); ponowne kliknięcie
    // przy znaczniku – usunięcie; kliknięcie wartości znacznika – „jak obliczono” w tym miejscu
    svg.style.cursor = 'crosshair';
    svg.addEventListener('click', ev => {
      const lab = ev.target.closest && ev.target.closest('.pinlab'); if (lab) { chartExplain(svg, +lab.dataset.px); return; }
      const c = CHARTS[svg.dataset.cid]; if (!c) return; const xm = xOf(svg, ev); if (xm === null || !isFinite(xm)) return;
      const tol = 7 * (c.xmax - c.xmin) / (c.W - c.ml - c.mr), j = chartPins.findIndex(v => Math.abs(v - xm) <= tol);
      if (j >= 0) chartPins.splice(j, 1); else { chartPins.push(+xm.toFixed(3)); if (chartPins.length > 8) chartPins.shift(); }
      svgs.forEach(drawPins); updPinBar();
    });
    // prawy przycisk – usunięcie wszystkich znaczników (gdy są; inaczej zwykłe menu przeglądarki)
    svg.addEventListener('contextmenu', ev => { if (!chartPins.length) return; ev.preventDefault(); chartPins.length = 0; svgs.forEach(drawPins); updPinBar(); toast('Usunięto znaczniki z wykresów.', 1500); });
  });
  svgs.forEach(drawPins); updPinBar();
  function updPinBar() { const b = $('#pinClr', root); if (b) b.style.display = chartPins.length ? '' : 'none'; }
  const pc = $('#pinClr', root); if (pc) pc.onclick = () => { chartPins.length = 0; svgs.forEach(drawPins); updPinBar(); };
}
// znaczniki wartości (kliknięcie wykresu): wspólne położenia x [m] dla wszystkich wykresów zakładki
const chartPins = [];
function drawPins(svg) {
  const c = CHARTS[svg.dataset.cid]; if (!c) return;
  let g = svg.querySelector('g.pins'); if (!g) { g = document.createElementNS('http://www.w3.org/2000/svg', 'g'); g.setAttribute('class', 'pins'); const cur = svg.querySelector('g.cur'); svg.insertBefore(g, cur || null); }
  const Yv = y => c.inv ? c.mt + (y - c.ymin) / (c.ymax - c.ymin) * (c.H - c.mt - c.mb) : c.H - c.mb - (y - c.ymin) / (c.ymax - c.ymin) * (c.H - c.mt - c.mb);
  const boxes = []; let s = '';
  chartPins.forEach(xm => {
    if (xm < c.xmin - 1e-9 || xm > c.xmax + 1e-9) return;
    const px = c.ml + (xm - c.xmin) / (c.xmax - c.xmin) * (c.W - c.ml - c.mr);
    s += `<line x1="${px.toFixed(1)}" y1="${c.mt}" x2="${px.toFixed(1)}" y2="${c.H - c.mb}" stroke="#a35d00" stroke-width="0.8" stroke-dasharray="2 3" pointer-events="none"/>`;
    const xt = `x = ${fmt(xm, 2)}`, xw = xt.length * 5.4 + 6; boxes.push([px - xw / 2, c.H - c.mb - 12, px + xw / 2, c.H - c.mb]);
    s += `<rect x="${(px - xw / 2).toFixed(1)}" y="${c.H - c.mb - 12}" width="${xw.toFixed(1)}" height="12" rx="2" fill="#a35d00" fill-opacity="0.9" pointer-events="none"/>` + tx(px, c.H - c.mb - 3, xt, { fs: 9, c: '#ffffff', w: 600 });
    const seen = [], vals = c.series.map(se => serAt(se, xm)).filter(v => v !== null && isFinite(v)), nz = vals.some(v => Math.abs(v) >= 0.5 * Math.pow(10, -c.dp));
    c.series.forEach(se => {
      const v = serAt(se, xm); if (v === null || !isFinite(v)) return;
      if (nz && Math.abs(v) < 0.5 * Math.pow(10, -c.dp)) return;                    // zero obwiedni drugiego znaku – bez opisu, gdy są wartości niezerowe
      if (seen.some(q => Math.abs(q - v) < 1e-6)) return; seen.push(v);
      const py = Yv(v), below = c.inv ? v >= 0 : v < 0, lab = fmt(v, c.dp), tw = lab.length * 5.7 + 4;
      s += `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="3" fill="${se.c}" stroke="#ffffff" stroke-width="0.8" pointer-events="none"/>`;
      // opis: po stronie wartości (nad / pod kropką), dalej z boku – bez nakładania na inne opisy znaczników
      const cand = [[px, py + (below ? 14 : -7), 'middle'], [px, py + (below ? 25 : -18), 'middle'], [px + 6, py + 3.5, 'start'], [px - 6, py + 3.5, 'end'], [px, py + (below ? -7 : 14), 'middle']];
      const box = ([x, y, a]) => { let bx = a === 'start' ? x : a === 'end' ? x - tw : x - tw / 2; bx = Math.max(2, Math.min(c.W - tw - 2, bx)); return [bx, y - 9, bx + tw, y + 2]; };
      const ok = cand.find(q => { const b = box(q); return b[1] > c.mt - 4 && b[3] < c.H - c.mb + 4 && !boxes.some(z => b[0] < z[2] && b[2] > z[0] && b[1] < z[3] && b[3] > z[1]); }) || cand[0];
      const b = box(ok); boxes.push(b);
      s += `<g class="pinlab" data-px="${xm}"><title>${esc(`${se.l || c.name || ''} x = ${fmt(xm, 2)} m: ${lab}${c.unit ? ' ' + c.unit : ''} – kliknij: jak obliczono w tym miejscu; kliknij wykres przy znaczniku, aby go usunąć`)}</title><rect x="${b[0].toFixed(1)}" y="${b[1].toFixed(1)}" width="${tw.toFixed(1)}" height="11" rx="2" fill="#ffffff" fill-opacity="0.85"/>${tx(b[0] + tw / 2, ok[1], lab, { fs: 10, c: se.c, w: 650 })}</g>`;
    });
  });
  g.innerHTML = s; if (svg.parentNode) themeSvgIn(svg.parentNode);
}
// „jak obliczono” w miejscu x wykresu (przekrój / podpora / przęsło najbliższe)
function chartExplain(svg, xm) {
  const c = CHARTS[svg.dataset.cid]; if (!c || !R || !R.md) return; if (xm === null || !isFinite(xm)) return; const xx = xm * 1000, yl = String(c.yl || c.title || '');
      const near = (arr, f) => arr.reduce((a, q) => (!a || Math.abs(f(q) - xx) < Math.abs(f(a) - xx) ? q : a), null);
      const val = (() => { const v = c.series && c.series[0] ? serAt(c.series[0], xm) : null; return v !== null && isFinite(v) ? `${fmt(v, c.dp || 1)}${c.unit ? ' ' + c.unit : ''}` : ''; })();
      const at = `x = ${fmt(xm, 2)} m${val ? `: ${val}` : ''}`;
      if (/^V/.test(yl)) { const e = near(R.sh.ends || [], q => q.x); if (e) explainRowPopup('VEd VRd', `${e.sup.name}, ${e.seg.label}`, `Siła poprzeczna – ${at}`, '', `${fmt(e.V0 / 1e3, 1)} ${fmt(e.Vred / 1e3, 1)}`); return; }
      if (/^T/.test(yl)) { const e = near(R.sh.ends || [], q => q.x); explainRowPopup('TEd TRd skręcanie', e ? `${e.sup.name}, ${e.seg.label}` : '', `Moment skręcający – ${at}`); return; }
      if (/^N/.test(yl)) { const q = near(R.secs || [], q => q.x); explainRowPopup('NEd MEd MRd', q ? q.loc : '', `Siła podłużna – ${at}`); return; }
      if (/^w|ugię|f \[/i.test(yl) || /ugię/i.test(c.title || '')) { const sg = R.md.segs.find(z => xx >= z.x0 - 1 && xx <= z.x1 + 1); if (sg) camberPopup(sg.idx); return; }
      const q = near(R.secs || [], q => q.x); if (q) explainRowPopup(/z/i.test(yl.slice(0, 3)) ? 'Mz MRd' : 'MEd MRd', q.loc, `Moment zginający – ${at} (najbliższy przekrój obliczeniowy: ${q.loc})`, '', q.MEd ? fmt(q.MEd / 1e6, 1) : '');
}
function niceTicks(a, b, n) {
  const span = b - a; if (!(span > 0)) return [a];
  const step0 = span / n, mag = Math.pow(10, Math.floor(Math.log10(step0)));
  const f = step0 / mag, step = (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * mag;
  const out = []; for (let v = Math.ceil(a / step) * step; v <= b + 1e-9; v += step) out.push(+v.toFixed(10));
  return out;
}
U.lineChart = lineChart; U.chartsData = () => { const k = noComb; noComb = false; try { return chartsData(); } finally { noComb = k; } };
function chartsData() {
  const st = R.st, md = R.md, x = st.x.map(v => v / 1000), multi = md.cont;
  // opisy ekstremów w każdym przęśle / wsporniku (xs w m; przy skoku na podporze – wartość od strony odcinka)
  const segMarks = (xs, ys, c, minRel) => { const gm = Math.max(1e-9, ...ys.map(Math.abs)), out = [], seen = new Set();
    md.segs.forEach(sg => { const ks = []; xs.forEach((xx, k) => { if (xx * 1000 >= sg.x0 - 1e-3 && xx * 1000 <= sg.x1 + 1e-3) ks.push(k); });
      while (ks.length > 1 && Math.abs(xs[ks[0]] - xs[ks[1]]) < 1e-9) ks.shift(); while (ks.length > 1 && Math.abs(xs[ks[ks.length - 1]] - xs[ks[ks.length - 2]]) < 1e-9) ks.pop(); if (!ks.length) return;
      const k = ks.reduce((a, q) => (Math.abs(ys[q]) > Math.abs(ys[a]) ? q : a), ks[0]), id = Math.round(xs[k] * 1000) + ':' + Math.round(ys[k] * 100);
      if (Math.abs(ys[k]) < (minRel || 0.02) * gm || seen.has(id)) return; seen.add(id);
      const atL = Math.abs(xs[k] * 1000 - sg.x0) < 1, atR = Math.abs(xs[k] * 1000 - sg.x1) < 1;
      out.push({ x: xs[k], y: ys[k], l: fmt(ys[k], 1), c, pri: 0, ...(atL ? { a: 'start', dx: 4 } : atR ? { a: 'end', dx: -4 } : {}) }); });
    return out; };
  const pos = st.MEdMax.map(v => Math.max(0, v) / 1e6), neg = st.MEdMin.map(v => Math.min(0, v) / 1e6);
  const ser = [];
  if (pos.some(v => v > 1e-3) || !neg.some(v => v < -1e-3)) ser.push({ x, y: pos, c: '#c0262d', l: 'M_Ed (obwiednia)', w: 2, fill: 'rgba(192,38,45,.07)' });
  if (neg.some(v => v < -1e-3)) ser.push({ x, y: neg, c: '#c0262d', l: ser.length ? '' : 'M_Ed (obwiednia)', w: 2, fill: 'rgba(192,38,45,.07)' });
  if (st.envA) {
    const pa = st.envA.M.max.map(v => Math.max(0, v) / 1e6), na = st.envA.M.min.map(v => Math.min(0, v) / 1e6);
    if (pa.some(v => v > 1e-3)) ser.push({ x, y: pa, c: '#b5651d', l: 'M_Ed,A (wyjątk.)', w: 1.6, dash: '7 3' });
    if (na.some(v => v < -1e-3)) ser.push({ x, y: na, c: '#b5651d', l: pa.some(v => v > 1e-3) ? '' : 'M_Ed,A (wyjątk.)', w: 1.6, dash: '7 3' });
  }
  if (multi) { ser.push({ x, y: st.MkMax.map(v => v / 1e6), c: '#1d5bb8', l: 'M_Ek (obwiednia)', dash: '5 3' }, { x, y: st.MkMin.map(v => v / 1e6), c: '#1d5bb8', dash: '5 3' }); }
  else { ser.push({ x, y: st.Mk.map(v => v / 1e6), c: '#1d5bb8', l: 'M_Ek (char.)', dash: '5 3' }); ser.push({ x, y: st.Mqp.map(v => v / 1e6), c: '#1d7f3c', l: 'M_Eqp (q-st.)', dash: '2 3' }); }
  const mMax = Math.max(1, ...st.MEdMax.map(Math.abs), ...st.MEdMin.map(Math.abs)) / 1e6;
  const rdTxt = [], hseg = [];
  const Lt = md.Ltot;
  R.secs.forEach(sec => {
    if (!sec.MRd) return;
    const v = (sec.kind === 'span' ? 1 : -1) * sec.MRd / 1e6, lab = `M_Rd = ${fmt(v, 1)}`;
    if (Math.abs(v) > 1.8 * mMax) { rdTxt.push((multi ? sec.loc + ': ' : '') + lab); return; }
    let x0, x1;
    if (sec.kind === 'span') { x0 = sec.seg.x0; x1 = sec.seg.x1; }
    else { const p = sec.sup, l = p.segL !== null ? md.segs[p.segL].L : 0, r = p.segR !== null ? md.segs[p.segR].L : 0; x0 = p.x - (p.segL !== null && md.segs[p.segL].kind === 'span' ? l / 3 : l); x1 = p.x + (p.segR !== null && md.segs[p.segR].kind === 'span' ? r / 3 : r); }
    hseg.push({ x0: x0 / 1000, x1: x1 / 1000, y: v, c: '#6a3fb5', l: lab });
  });
  const mk = [];
  const kinks = []; { const Dd = schemeData(); if (Dd) Dd.rows.forEach(r => (r.pts || []).forEach(q => { if (q.Py) kinks.push(q.x); })); }
  const mAt = xx => { const k = st.kAt(xx), a = st.MEdMax[k], b = st.MEdMin[k]; return (Math.abs(b) > Math.abs(a) && b < 0 ? Math.min(0, b) : Math.max(0, a)) / 1e6; };
  // ekstrema: w przęsłach – maksimum obwiedni, na podporach – wartość w osi podpory (szczyt wykresu; M_Ed w licu / zredukowany – w tabelach i raporcie)
  R.secs.forEach(sec => { const y = sec.kind === 'span' ? sec.MEd / 1e6 : mAt(sec.x); if (Math.abs(y) > 1e-3) { mk.push({ x: sec.x / 1000, y, l: fmt(y, 1), c: '#c0262d', a: sec.x < 0.08 * Lt ? 'start' : sec.x > 0.92 * Lt ? 'end' : 'middle', dx: sec.x < 0.08 * Lt ? 5 : sec.x > 0.92 * Lt ? -5 : 0 }); } });
  const vl = md.sups.map(p => ({ x: p.x / 1000, l: multi ? p.label : '' }));
  // osie podpór bez przekroju obliczeniowego (np. utwierdzenie, wspornik) – wartość w osi; załamania wykresu M (siły skupione)
  md.sups.forEach(p => { const y = mAt(p.x); if (Math.abs(y) > 0.02 * mMax && !mk.some(q => Math.abs(q.x * 1000 - p.x) < 1)) mk.push({ x: p.x / 1000, y, l: fmt(y, 1), c: '#c0262d', a: p.x < 0.08 * Lt ? 'start' : p.x > 0.92 * Lt ? 'end' : 'middle', dx: p.x < 0.08 * Lt ? 5 : p.x > 0.92 * Lt ? -5 : 0 }); });
  kinks.forEach(xx => { const y = mAt(xx); if (Math.abs(y) > 0.02 * mMax && !mk.some(q => Math.abs(q.x * 1000 - xx) < 0.03 * Lt)) mk.push({ x: xx / 1000, y, l: fmt(y, 1), c: '#c0262d', k: 'kink', pri: 1 }); });
  // moment zredukowany nad podporami (5.3.2.2): obwiednia na szerokości podpory i wartość obliczeniowa
  { let first = true; (st.supRed || []).forEach(q => { if (!q || !q.U) return; const p = q.sup, h = p.t / 2, ks = [];
      st.x.forEach((xx, k) => { if (Math.abs(xx - p.x) <= h + 1e-6) ks.push(k); }); if (ks.length && ks[0] > 0) ks.unshift(ks[0] - 1); if (ks.length && ks[ks.length - 1] < st.x.length - 1) ks.push(ks[ks.length - 1] + 1);
      if (ks.length > 1) { ser.push({ x: ks.map(k => x[k]), y: ks.map(k => Math.min(0, st.MEdMinR[k]) / 1e6), c: '#0e8fa8', l: first ? 'M_Ed,red (5.3.2.2)' : '', w: 2, dash: '4 2' }); first = false; }
      mk.push({ x: p.x / 1000, y: -q.U.M / 1e6, l: `red. ${fmt(-q.U.M / 1e6, 1)}`, c: '#0b7285', pri: 1, a: 'end', dx: -6 }); }); }
  const M = { title: 'Momenty zginające M [kNm] – po stronie włókien rozciąganych' + (st.redist && st.redist.length ? ' – po redystrybucji (5.5)' : '') + (rdTxt.length ? ' (' + rdTxt.join(', ') + ')' : ''), series: ser, hseg, invert: true, yl: 'M [kNm]', marks: mk, vl, unit: 'kNm' };
  // znaczniki wykresu jednej serii (bez obwiedni): M – ekstrema w odcinkach, lica podpór, załamania; V – wartości w osi i przy licu podpór, skoki
  const marksOf = (se, kind) => {
    const out = [], sc = Math.max(1e-9, ...se.y.map(Math.abs)), sig = v => Math.abs(v) > 0.03 * sc;
    if (kind === 'M') {
      md.segs.forEach(sg => { let kx = -1, kn = -1; se.x.forEach((xx, k) => { if (xx * 1000 < sg.x0 - 1 || xx * 1000 > sg.x1 + 1) return; if (kx < 0 || se.y[k] > se.y[kx]) kx = k; if (kn < 0 || se.y[k] < se.y[kn]) kn = k; });
        [kx, kn].forEach(k => { if (k < 0 || !sig(se.y[k]) || out.some(q => Math.abs(q.x - se.x[k]) < 0.02 * Lt / 1000 && Math.sign(q.y) === Math.sign(se.y[k]))) return; out.push({ x: se.x[k], y: se.y[k], l: fmt(se.y[k], 1), c: se.c, pri: 0 }); }); });
      kinks.forEach(xx => { const y = serAt(se, xx / 1000); if (sig(y) && !out.some(q => Math.abs(q.x * 1000 - xx) < 0.03 * Lt)) out.push({ x: xx / 1000, y, l: fmt(y, 1), c: se.c, k: 'kink', pri: 1 }); });
    } else {
      md.sups.forEach(p => { [[p.segL, -1], [p.segR, 1]].forEach(([sg, sd]) => { if (sg === null) return; const ya = serAt(se, p.x / 1000 + sd * 1e-4); if (sig(ya)) out.push({ x: p.x / 1000, y: ya, l: fmt(ya, 1), c: se.c, pri: 0, a: sd < 0 ? 'end' : 'start', dx: sd * 4 }); }); });
      kinks.forEach(xx => [-1, 1].forEach(sd => { const y = serAt(se, xx / 1000 + sd * 1e-4); if (sig(y)) out.push({ x: xx / 1000, y, l: fmt(y, 1), c: se.c, k: 'kink', pri: 1, a: sd < 0 ? 'end' : 'start', dx: sd * 4 }); }));
    }
    return out;
  };
  if (noComb && st.E && st.E.G) {                                      // bez kombinacji: G i każde obciążenie zmienne osobno (char.; zmienne – układ najniekorzystniejszy max / min)
    const pal = ['#1d5bb8', '#1d7f3c', '#6a3fb5', '#0e8fa8', '#b5651d', '#8a2027'];
    const cs = [{ x, y: st.E.G.My.map(v => v / 1e6), c: '#4a5466', l: 'G (stałe)', w: 2 }];
    (st.vars || []).forEach((v, i) => { if (!v.My) return; const c = pal[i % pal.length]; cs.push({ x, y: v.My.pos.map(q => q / 1e6), c, l: `${v.id} ${v.name || ''}`.trim().slice(0, 22), w: 1.4 }); if (v.My.neg.some(q => q < -1e3)) cs.push({ x, y: v.My.neg.map(q => q / 1e6), c, w: 1.4, dash: '5 3' }); });
    const gm = []; { let kx = 0, kn = 0; st.E.G.My.forEach((v, k) => { if (v > st.E.G.My[kx]) kx = k; if (v < st.E.G.My[kn]) kn = k; }); [kx, kn].forEach(k => { const y = st.E.G.My[k] / 1e6; if (Math.abs(y) > 1e-3) gm.push({ x: x[k], y, l: fmt(y, 1), c: '#4a5466' }); }); }
    void gm; Object.assign(M, { title: 'Momenty zginające bez kombinacji – od poszczególnych obciążeń, wartości charakterystyczne [kNm] (zmienne: linia ciągła – max, przerywana – min)', series: cs, hseg: [], marks: cs.flatMap(se => marksOf(se, 'M')) });
  }
  let MZ = null;
  if (st.hasZ) {
    const zs = [{ x, y: st.MzEd.map(v => v / 1e6), c: '#c0262d', l: '|M_z,Ed| (obwiednia)', w: 2, fill: 'rgba(192,38,45,.07)' }, { x, y: st.MzK.map(v => v / 1e6), c: '#1d5bb8', l: '|M_z,k| (char.)', dash: '5 3' }];
    MZ = { title: 'Momenty zginające w płaszczyźnie Z – |M_z| [kNm] (zginanie poziome)', series: zs, yl: 'M_z [kNm]', vl, unit: 'kNm', marks: segMarks(x, st.MzEd.map(v => v / 1e6), '#c0262d') };
  }
  // tnące
  const xv = st.xV.map(v => v / 1000);
  const vser = [{ x: xv, y: st.VEdMax.map(v => Math.max(0, v) / 1e3), c: '#c0262d', l: 'V_Ed (obwiednia)', w: 2, fill: 'rgba(192,38,45,.07)' },
    { x: xv, y: st.VEdMin.map(v => Math.min(0, v) / 1e3), c: '#c0262d', w: 2, fill: 'rgba(192,38,45,.07)' }];
  if (st.envA) vser.push({ x: xv, y: st.envA.V.max.map(v => Math.max(0, v) / 1e3), c: '#b5651d', l: 'V_Ed,A (wyjątk.)', w: 1.5, dash: '7 3' }, { x: xv, y: st.envA.V.min.map(v => Math.min(0, v) / 1e3), c: '#b5651d', w: 1.5, dash: '7 3' });
  const vMax = Math.max(1, ...st.Vabs) / 1e3, vTxt = [], vseg = [];
  const face = R.g.t / 2;
  const used = {};
  R.sh.ends.forEach(e => {
    const k = st.kAt(e.x), iV = clampI(e.dir > 0 ? 2 * k : 2 * k - 1, 0, st.xV.length - 1);
    const sg = Math.abs(st.VEdMax[iV]) >= Math.abs(st.VEdMin[iV]) ? 1 : -1;
    const a = e.x, b = e.x + e.dir * e.reach;
    const add = (val, nm, c) => { if (val / 1e3 > 1.8 * vMax) { if (!used[nm]) { vTxt.push(`${nm}=${fmt(val / 1e3, 0)}`); used[nm] = 1; } return; } vseg.push({ x0: Math.min(a, b) / 1000, x1: Math.max(a, b) / 1000, y: sg * val / 1e3, c, nm, l: `${nm}=${fmt(val / 1e3, 0)}` }); };
    add(e.VRds2, 'V_Rd,s(s₂)', '#1d5bb8');
    add(e.VRdc, 'V_Rd,c', '#a35d00');
    if (e.l1 > 0) add(e.VRds1, 'V_Rd,s(s₁)', '#1d7f3c');
  });
  // etykieta każdego rodzaju linii tylko raz – na najdłuższym odcinku
  const best = {}; vseg.forEach(q => { if (!best[q.nm] || q.x1 - q.x0 > best[q.nm].x1 - best[q.nm].x0) best[q.nm] = q; });
  vseg.forEach(q => { if (best[q.nm] !== q) q.l = ''; });
  const bands = R.sh.ends.filter(e => e.l1 > 0).map(e => { const a = e.x + e.dir * face, b = a + e.dir * e.l1; return { x0: Math.min(a, b) / 1000, x1: Math.max(a, b) / 1000, c: 'rgba(29,127,60,.08)', l: 's₁' }; });
  const vmk = [], vAt = (xx, sd) => { const a = serAt({ x: xv, y: st.VEdMax.map(v => v / 1e3) }, xx / 1000 + sd * 1e-4), b = serAt({ x: xv, y: st.VEdMin.map(v => v / 1e3) }, xx / 1000 + sd * 1e-4); return Math.abs(b) > Math.abs(a) ? b : a; };
  // wartości ekstremalne – w osi podpory, po obu jej stronach (V_Ed w licu / w odległości d – w tabelach i raporcie)
  md.sups.forEach(p => { [[p.segL, -1], [p.segR, 1]].forEach(([sg, sd]) => { if (sg === null) return;
    const ya = vAt(p.x, sd); if (Math.abs(ya) > 0.02 * vMax) vmk.push({ x: p.x / 1000, y: ya, l: fmt(ya, 1), c: '#c0262d', pri: 0, a: sd < 0 ? 'end' : 'start', dx: sd * 4 }); }); });
  kinks.forEach(xx => { [-1, 1].forEach(sd => { const y = vAt(xx, sd); if (Math.abs(y) > 0.02 * vMax) vmk.push({ x: xx / 1000, y, l: fmt(y, 1), c: '#c0262d', k: 'kink', pri: 1, a: sd < 0 ? 'end' : 'start', dx: sd * 4 }); }); });
  const V = { title: 'Siły poprzeczne V [kN]' + (vTxt.length ? ' (' + vTxt.join(', ') + ')' : ''), series: vser, hseg: vseg, yl: 'V [kN]', bands, vl, unit: 'kN', marks: vmk };
  if (noComb && st.E && st.E.G && st.E.G.Vy) {
    const pal = ['#1d5bb8', '#1d7f3c', '#6a3fb5', '#0e8fa8', '#b5651d', '#8a2027'];
    const cs = [{ x: xv, y: st.E.G.Vy.map(v => v / 1e3), c: '#4a5466', l: 'G (stałe)', w: 2 }];
    (st.vars || []).forEach((v, i) => { if (!v.Vy) return; const c = pal[i % pal.length]; cs.push({ x: xv, y: v.Vy.pos.map(q => q / 1e3), c, l: `${v.id} ${v.name || ''}`.trim().slice(0, 22), w: 1.4 }, { x: xv, y: v.Vy.neg.map(q => q / 1e3), c, w: 1.4, dash: '5 3' }); });
    Object.assign(V, { title: 'Siły poprzeczne bez kombinacji – od poszczególnych obciążeń, wartości charakterystyczne [kN]', series: cs, hseg: [], bands: [], marks: cs.flatMap(se => marksOf(se, 'V')) });
  }
  // momenty skręcające i siła osiowa
  let TT = null;
  if (st.TEd > 0) {
    const tser = [{ x: xv, y: st.TEdAbs.map(v => v / 1e6), c: '#6a3fb5', l: '|T_Ed| (obwiednia)', w: 2, fill: 'rgba(106,63,181,.08)' }];
    if (st.TEdMax) tser.push({ x: xv, y: st.TEdMax.map(v => v / 1e6), c: '#6a3fb5', l: 'T_Ed,max', dash: '4 3', w: 1.2 }, { x: xv, y: st.TEdMin.map(v => v / 1e6), c: '#6a3fb5', l: 'T_Ed,min', dash: '2 3', w: 1.2 });
    const T = R.tor || {};
    TT = { title: `Momenty skręcające T [kNm]` + (st.TEdAdd ? ` – w tym podany wprost T_Ed = ${fmt(st.TEdAdd / 1e6, 1)} kNm` : '') + (T.TRdc ? ` (T_Rd,c = ${fmt(T.TRdc / 1e6, 1)}, T_Rd,max = ${fmt(T.TRdmax / 1e6, 1)})` : ''), series: tser, yl: 'T [kNm]', vl, unit: 'kNm', marks: segMarks(xv, st.TEdAbs.map(v => v / 1e6), '#6a3fb5'),
      hl: T.TRdc && T.TRdc / 1e6 < 2.5 * Math.max(...st.TEdAbs) / 1e6 ? [{ y: T.TRdc / 1e6, l: `T_Rd,c = ${fmt(T.TRdc / 1e6, 1)}`, c: '#a35d00' }] : [] };
  }
  // siła osiowa – wykres zawsze (także N_Ed = 0)
  const nz = Math.abs(st.NEd || 0) > 0;
  const NN = { title: nz ? `Siła osiowa N [kN] (+ ściskanie) – N_Ed = ${fmt(st.NEd / 1e3, 1)} kN, stała na długości belki` : 'Siła osiowa N [kN] – N_Ed = 0 na całej długości belki', series: [{ x: [0, md.Ltot / 1000], y: [(st.NEd || 0) / 1e3, (st.NEd || 0) / 1e3], c: '#1d7f3c', l: 'N_Ed', w: 2, fill: 'rgba(29,127,60,.08)' }], yl: 'N [kN]', vl, unit: 'kN', H: 150, zero: !nz };
  // ugięcia
  if (!R.sls) return { M, MZ, V, T: TT, N: NN, D: null };
  const d = R.sls.defl;
  const limMin = Math.min(...d.spans.map(q => q.lim));
  const dser = [{ x: d.x.map(v => v / 1000), y: d.w.map(v => v), c: '#1d5bb8', l: 'w(x) [mm]', w: 2, fill: 'rgba(29,91,184,.08)' }];
  if (d.wz && d.wz.some(v => v > 1e-3)) dser.push({ x: d.x.map(v => v / 1000), y: d.wz.map(v => -v), c: '#1d7f3c', l: '|w_z(x)| – płaszczyzna Z', w: 1.6, dash: '5 3' });
  const fmax = Math.max(...d.spans.map(q => q.tot.f));
  const wAt = xx => { let bi = 0; d.x.forEach((v, i) => { if (Math.abs(v - xx) < Math.abs(d.x[bi] - xx)) bi = i; }); return d.w[bi]; };
  const dmk = d.spans.map(q => { const y = wAt(q.tot.x); return { x: q.tot.x / 1000, y, l: fmt(Math.abs(y), 1), c: '#1d5bb8', dy: y > 0 ? -7 : 14 }; });
  const cmb = d.spans.filter(q => q.camber > 0 && q.seg);
  if (cmb.length) {
    const cx = [], cy = []; md.segs.forEach(sg => { const q = cmb.find(z => z.seg.idx === sg.idx); const n = 24; for (let i = 0; i <= n; i++) { const xx = sg.x0 + sg.L * i / n; cx.push(xx / 1000); cy.push(q ? (sg.kind === 'span' ? q.camber * Math.sin(Math.PI * i / n) : q.camber * (sg.supL ? i / n : 1 - i / n) ** 2) : 0); } });
    dser.push({ x: cx, y: cy, c: '#a35d00', l: `odwrotna strzałka w₀ = ${cmb.map(q => fmt(q.camber, 0)).join(' / ')} mm`, w: 1.6, dash: '6 4' });
    cmb.forEach(q => { const sg = q.seg, xm = sg.kind === 'span' ? (sg.x0 + sg.x1) / 2 : (sg.supL ? sg.x1 : sg.x0); dmk.push({ x: xm / 1000, y: q.camber, l: `w₀ = ${fmt(q.camber, 0)}`, c: '#a35d00', dy: -7, pri: 1 }); });
  }
  const D = { title: `Linia ugięcia długotrwałego (quasi-stałe + skurcz) – f_max = ${fmt(fmax, 1)} mm` + (d.patterned ? ' (obc. zmienne naprzemiennie)' : '') + ' – kliknij przęsło: odwrotna strzałka w₀', series: dser,
    hl: [{ y: -limMin, l: `−f_lim = −${fmt(limMin, 1)}`, c: '#c0262d' }], yl: 'w [mm]', vl, marks: dmk, unit: 'mm' };
  return { M, MZ, V, T: TT, N: NN, D };
}
function renderCharts(el) {
  const W = el.clientWidth < 700 ? Math.max(320, el.clientWidth - 60) : Math.min(1100, el.clientWidth - 40);
  const c = chartsData();
  Object.keys(CHARTS).forEach(k => delete CHARTS[k]);
  let html = `<div class="dsumx"></div><p class="hint keep" style="margin:0 0 8px">Najedź kursorem na wykres – w każdym wykresie pokazują się wartości w tym samym miejscu belki. <b>Kliknij wykres</b> – znacznik: kropki i wartości w tym miejscu na wszystkich wykresach (jak przy ekstremach); kliknięcie przy znaczniku – usunięcie, <b>prawy przycisk</b> – usunięcie wszystkich, kliknięcie wartości – jak obliczono. <button class="lnk" id="pinClr" style="display:none">usuń znaczniki</button></p>`;
  if (!R.st.manual) html += `<label class="chk sm" style="margin:0 0 10px"><input type="checkbox" id="noComb" ${noComb ? 'checked' : ''}><span>Wykresy M i V bez obwiedni – od poszczególnych obciążeń (wartości charakterystyczne, bez kombinacji); odznaczone – obwiednie kombinacji SGN</span></label>`;
  html += R.st.manual ? '' : `<div class="box" style="margin-bottom:12px"><div class="h2" style="margin:0 0 4px">Schemat obciążeń<small>wartości charakterystyczne (A – obliczeniowe), x od lewego końca belki; [Z] – w płaszczyźnie prostopadłej</small></div>${schemeSVG(W)}</div>`;
  if (!R.st.manual && R.st.reac) html += `<div class="box" style="margin-bottom:12px"><div class="h2" style="margin:0 0 4px">Reakcje podporowe<small>pionowe: R<sub>Ed</sub> – obwiednia SGN (max / min), R<sub>k,max</sub> – kombinacja charakterystyczna, R<sub>k</sub> od G i od każdego obciążenia zmiennego (+ w górę); poziome H (podpory nieprzesuwne) i R<sub>z</sub>; momenty M<sub>Ed</sub> w utwierdzeniach; przy podporach pośrednich – siły poprzeczne po lewej i prawej stronie</small></div>${reactionsSVG(W)}</div>`;
  html += `<div class="box" style="margin-bottom:12px">${lineChart(Object.assign(c.M, { W }))}</div>`;
  if (c.MZ) html += `<div class="box" data-chart="MZ" style="margin-bottom:12px">${lineChart(Object.assign(c.MZ, { W, H: 190 }))}</div>`;
  html += `<div class="box" data-chart="V" style="margin-bottom:12px">${lineChart(Object.assign(c.V, { W }))}</div>`;
  html += c.T ? `<div class="box" style="margin-bottom:12px">${lineChart(Object.assign(c.T, { W, H: 180 }))}</div>` : `<p class="hint keep">Momenty skręcające: brak (T<sub>Ed</sub> = 0) – zadaj moment skręcający w obciążeniu (mimośród) lub wprost w danych.</p>`;
  html += `<div class="box" style="margin-bottom:12px">${lineChart(Object.assign(c.N, { W, H: c.N.zero ? 120 : 170 }))}</div>`;
  if (c.D) html += `<div class="box" data-chart="D">${lineChart(Object.assign(c.D, { W }))}</div>`;
  else html += `<p class="hint keep">Ugięcia – po zadaniu zbrojenia (przekroje bez zbrojenia podłużnego).</p>`;
  const eZ = R.sh.ends.filter(e => e.l1 > 0 || e.l1req > 0);
  const ss = eZ.length ? eZ.map(e => `${esc(e.name)}: s₁ = ${(e.stir || S.stir).s1} mm na <b>${fmt(e.l1 / 1000, 2)} m</b> od lica (wym. ${fmt(e.l1req / 1000, 2)} m)`).join('; ') : `strefa zagęszczona s₁ nie jest wymagana obliczeniowo – V<sub>Ed</sub> ≤ V<sub>Rd,s</sub>(s₂ = ${[...new Set(R.md.segs.map(sg => (sg.stir || S.stir).s2))].join(' / ')} mm) na całej długości`;
  const dd = !R.sls ? [] : R.sls.defl.spans.map(q => `${R.md.segs.length > 1 ? esc(q.label) + ': ' : ''}f = ${fmt(q.tot.f, 1)} mm (od obciążeń ${fmt(q.load.f, 1)}, od skurczu ${fmt(q.cs, 1)})` + (q.ch ? `, natychmiastowe char. ${fmt(q.ch.f, 1)} mm` : '')).join('; ');
  html += `<p class="hint" style="margin-top:10px">Strefy strzemion – ${ss}.<br>${dd.length ? `Ugięcia – ${dd}.` : ''}` + ((R.sls && (R.sls.defl.z || []).length) ? `<br>Ugięcia poziome (Z) – ${R.sls.defl.z.map(q => `${R.md.segs.length > 1 ? esc(q.label) + ': ' : ''}${fmt(q.f, 1)} mm`).join('; ')}.` : '') + `</p>`;
  if (R.st.tabU) html += combosHTML(R.st);
  if (!R.bare) html += `<div style="margin-top:18px">${mnHTML(el)}</div>`;
  el.innerHTML = html;
  bindChartCursor(el);
  const nc = $('#noComb', el); if (nc) nc.onchange = () => { noComb = nc.checked; try { localStorage.setItem('bz.nocomb', noComb ? '1' : '0'); } catch (e) { /* */ } const y = el.scrollTop; renderCharts(el); el.scrollTop = y; };
}
// schemat z reakcjami podporowymi
// reakcje podpory i: pionowe (SGN max/min, charakterystyczne), poziome (x – siła osiowa, z – płaszczyzna Z), moment (utwierdzenie),
// przy podporze pośredniej siły poprzeczne po lewej i prawej stronie podpory
function reacData(i) {
  const st = R.st, md = R.md, p = md.sups[i], rc = st.reac, k = st.kAt(p.x);
  const xFix = md.sups.filter(q => q.fx);
  const o = { p, V: { max: rc.U.max[i], min: rc.U.min[i] }, K: rc.K ? { max: rc.K.max[i], min: rc.K.min[i] } : null, G: rc.G[i], Q: rc.Q.map(q => ({ id: q.id, name: q.name, max: q.max[i], min: q.min[i] })) };
  if (!p.end) o.VL = st.Vin(p.x, -1), o.VR = st.Vin(p.x, 1);
  if (p.type === 'fix' || p.kr > 0) o.M = { max: st.MEdMax[k], min: st.MEdMin[k], kmax: st.MkMax ? st.MkMax[k] : null, kmin: st.MkMin ? st.MkMin[k] : null };
  if (p.fx) o.H = xFix.length && xFix[0] === p ? (st.NEd || 0) : 0, o.Hshare = xFix.length > 1;
  if (rc.Uz && p.fz) o.Z = Math.max(Math.abs(rc.Uz.max[i]), Math.abs(rc.Uz.min[i]));
  return o;
}
U.reacData = i => reacData(i);
function reactionsSVG(W) {
  const st = R.st, md = R.md, L = md.Ltot, ml = 50, mr = 50, X = x => ml + x / L * (W - ml - mr);
  const rc = st.reac, nQ = rc.Q.length;
  const gapMin = Math.min(...md.sups.slice(1).map((p, i) => X(p.x) - X(md.sups[i].x)), W);
  const compact = gapMin < 175;
  const D = md.sups.map((p, i) => reacData(i));
  const nL = q => 2 + (q.K ? 1 : 0) + Math.min(nQ, 3) + (q.VL !== undefined ? 1 : 0) + (q.M ? 1 : 0) + (q.H !== undefined ? 1 : 0) + (q.Z !== undefined ? 1 : 0);
  const lines = compact ? 1 : Math.max(...D.map(nL));
  // tryb zwarty: opis każdej podpory pod rysunkiem, zawijany do szerokości
  const maxCh = Math.max(30, Math.floor((W - 24) / 5.3));
  const wrap = parts => { const out = []; let cur = ''; parts.forEach(pp => { const nx = cur ? cur + '; ' + pp : pp; if (nx.length > maxCh && cur) { out.push(cur + ';'); cur = pp; } else cur = nx; }); if (cur) out.push(cur); return out; };
  const LST = compact ? D.map(q => wrap([`${q.p.label}: R_Ed = ${fmt(q.V.max / 1e3, 1)} / ${fmt(q.V.min / 1e3, 1)} kN`, ...(q.K ? [`R_k,max = ${fmt(q.K.max / 1e3, 1)} kN`] : []), `R_k,G = ${fmt(q.G / 1e3, 1)}`, ...q.Q.slice(0, 3).map(z => `R_k,${z.id} = ${fmt(z.max / 1e3, 1)}`),
    ...(q.VL !== undefined ? [`V_L = ${fmt(q.VL / 1e3, 1)}, V_P = ${fmt(q.VR / 1e3, 1)} kN`] : []), ...(q.H !== undefined ? [`H = ${fmt(q.H / 1e3, 1)} kN`] : []), ...(q.M ? [`M_Ed = ${fmt(q.M.min / 1e6, 1)} / ${fmt(q.M.max / 1e6, 1)} kNm`] : []), ...(q.Z !== undefined ? [`R_z = ${fmt(q.Z / 1e3, 1)} kN`] : [])])) : [];
  const listH = LST.reduce((a, l) => a + l.length * 12.5 + 4, 0);
  const yb = 40, H = yb + 70 + lines * 13 + listH + (compact ? 8 : 0);
  let s = svgOpen(W, H, 'class="schemesvg"');
  s += `<defs><marker id="ahR" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="context-stroke"/></marker></defs>`;
  s += `<line x1="${X(0)}" y1="${yb}" x2="${X(L)}" y2="${yb}" stroke="#1b2230" stroke-width="4"/>`;
  const f1 = v => fmt(v / 1e3, 1), f1m = v => fmt(v / 1e6, 1);
  D.forEach((q, i) => {
    const p = q.p, xx = X(p.x);
    s += supportSym(p, xx, yb, { compact: true }).replace(/<title>[^<]*<\/title>/, '');
    s += `<line x1="${xx}" y1="${yb + 46}" x2="${xx}" y2="${yb + 24}" stroke="#c0262d" stroke-width="2" marker-end="url(#ahR)"/>`;
    if (q.H !== undefined) { const dir = p.segL === null ? -1 : 1; s += `<line x1="${xx + dir * 30}" y1="${yb + 30}" x2="${xx + dir * 10}" y2="${yb + 30}" stroke="#a35d00" stroke-width="1.8" marker-end="url(#ahR)"/>`; }
    if (q.M) { const sd = p.segL === null ? 1 : -1; s += `<path d="M${xx + sd * 12},${yb - 14} a14,14 0 1,${sd > 0 ? 0 : 1} ${-sd * 4},26" fill="none" stroke="#6a3fb5" stroke-width="1.6" marker-end="url(#ahR)"/>`; }
    const a = xx < ml + 60 ? 'start' : xx > W - mr - 60 ? 'end' : 'middle', dx = a === 'start' ? -8 : a === 'end' ? 8 : 0;
    let y = yb + 60;
    const t = (txt, c, w) => { s += tx(xx + dx, y, txt, { fs: 10, c: c || '#1b2230', a, w }); y += 13; };
    if (compact) {
      t(`${p.label}: ${f1(q.V.max)}`, '#c0262d', 650);
      let yl = yb + 70 + 13 + 8 + LST.slice(0, i).reduce((a, l) => a + l.length * 12.5 + 4, 0);
      LST[i].forEach((ln, j) => { s += tx(j ? 18 : 10, yl, ln, { fs: 9.5, a: 'start', c: j ? '#4a5466' : '#3d4656' }); yl += 12.5; });
      return;
    }
    t(`${p.label}: R_Ed,max = ${f1(q.V.max)} kN`, '#c0262d', 650);
    t(`R_Ed,min = ${f1(q.V.min)} kN${q.V.min < -50 ? ' (odrywanie!)' : ''}`, q.V.min < -50 ? '#c0262d' : '#3d4656');
    if (q.K) t(`R_k,max = ${f1(q.K.max)} kN`, '#3d4656');
    t(`R_k,G = ${f1(q.G)} kN`, '#4a5466');
    q.Q.slice(0, 3).forEach(z => t(`R_k,${z.id} = ${f1(z.max)}${z.min < -50 ? ` / ${f1(z.min)}` : ''} kN`, '#1d5bb8'));
    if (q.VL !== undefined) t(`V_Ed: lewa ${f1(q.VL)} / prawa ${f1(q.VR)} kN`, '#1b2230');
    if (q.H !== undefined) t(`H_Ed = ${f1(q.H)} kN${q.H ? ' (od N_Ed)' : ''}`, '#a35d00');
    if (q.M) t(`M_Ed = ${f1m(q.M.min)} / ${f1m(q.M.max)} kNm`, '#6a3fb5', 600);
    if (q.Z !== undefined) t(`R_Ed,z = ${f1(q.Z)} kN (poziomo)`, '#1d7f3c');
  });
  const sumG = rc.G.reduce((a, b) => a + b, 0);
  s += tx(W - mr, 14, `ΣR_k,G = ${fmt(sumG / 1e3, 1)} kN`, { fs: 10, c: '#4a5466', a: 'end' });
  return s + '</svg>';
}
function combosHTML(st, compact) {
  const cell = (v, gov, dp) => `<td class="n">${gov ? '<b>' : ''}${fmt(v, dp)}${gov ? '</b>' : ''}</td>`;
  const tbl = (title, rows, opts) => {
    opts = opts || {};
    const sx = opts.sx || 'Ed';
    const r0 = rows[0] || {};
    let h = `<div class="h2" style="margin-top:16px">${title}</div><div class="tscroll"><table class="sched"><tr><th>Kombinacja</th><th>Wzór</th><th>M<sub>${sx}</sub> max [kNm]<br><small>x = ${fmt((r0.xPos || 0) / 1000, 2)} m</small></th>${st.hasNeg ? `<th>M<sub>${sx}</sub> min [kNm]<br><small>x = ${fmt((r0.xNeg || 0) / 1000, 2)} m</small></th>` : ''}<th>|V<sub>${sx}</sub>| max [kN]<br><small>x = ${fmt((r0.xV || 0) / 1000, 2)} m</small></th>${st.hasZ ? `<th>|M<sub>z,${sx}</sub>| max [kNm]</th>` : ''}</tr>`;
    rows.forEach(r => { h += `<tr><td>${esc(r.name)}</td><td style="white-space:nowrap">${esc(r.desc)}</td>${cell(r.Mpos / 1e6, r.govMpos, 2)}${st.hasNeg ? cell(r.Mneg / 1e6, r.govMneg, 2) : ''}${cell(r.Vmax / 1e3, r.govVmax, 1)}${st.hasZ ? cell(r.Mz / 1e6, r.govMz, 2) : ''}</tr>`; });
    return h + '</table></div>';
  };
  const leg = `<p class="hint" style="margin-top:6px">Oznaczenia: G – obciążenia stałe; ${st.vars.map(v => `${v.id} – ${esc(v.name)} (ψ₀=${psiF(v.psi.p0)}, ψ₁=${psiF(v.psi.p1)}, ψ₂=${psiF(v.psi.p2)})`).join('; ')}${st.accs.map(a => `; ${a.id} – ${esc(a.name)}`).join('')}. Pogrubiono wartości decydujące. Współczynnik przy G dotyczy działania niekorzystnego (korzystne: γ<sub>G,inf</sub> = 1,0); obciążenia zmienne uwzględniane tylko tam, gdzie są niekorzystne${st.md && st.md.segs.length > 1 ? ' – w belce ciągłej każde obciążenie zmienne rozłożone przęsłami (układ szachownicowy)' : ''}.</p>`;
  let h = tbl('Kombinacje SGN – sytuacja trwała/przejściowa (PN-EN 1990, 6.10)', st.tabU) + leg;
  if (st.tabA) h += tbl('Kombinacje SGN – sytuacja wyjątkowa (6.11b)', st.tabA, { sx: 'Ed,A' });
  h += tbl('Kombinacje SGU – charakterystyczne (6.14b)', st.tabK, { sx: 'Ek' });
  return h;
}
U.combosHTML = combosHTML;

/* ------------------------------------------------------------ M–N */
const CURVE_COLS = ['#1d5bb8', '#6a3fb5', '#1d7f3c', '#b5651d', '#0e8fa8', '#4a5466'];
function mnCurves() {
  const g = R.g, h = g.h;
  const flip = b => b.map(x => Object.assign({}, x, { y: h - x.y }));
  const mk = (bars) => {
    const sg = E.makeULS(g.partsS, h, bars, R.m), hg = E.makeULS(g.partsH, h, flip(bars), R.m);
    const a = sg.curve(160).map(([M, N]) => [M / 1e6, N / 1e3]);
    const b = hg.curve(160).map(([M, N]) => [-M / 1e6, N / 1e3]).reverse();
    return a.concat(b);
  };
  const seen = new Map(), out = [];
  R.secs.forEach(sec => {
    const key = JSON.stringify(sec.bars.map(b => [Math.round(b.x), Math.round(b.y), Math.round(b.A)]));
    let cv = seen.get(key);
    if (!cv) { if (out.length >= CURVE_COLS.length) return; cv = { name: cap(sec.loc), pts: mk(sec.bars), c: CURVE_COLS[out.length], ps: [] }; seen.set(key, cv); out.push(cv); }
    else cv.name += ', ' + sec.loc;
    cv.ps.push({ M: (sec.kind === 'span' ? 1 : -1) * sec.MEd / 1e6, N: R.st.NEd / 1e3 });
  });
  return out;
}
function mnSVG(curves, W, H) {
  W = W || 640; H = H || 520;
  const ml = 70, mr = 20, mt = 20, mb = 40;
  const pts = c => c.ps || [c.p];
  const all = curves.flatMap(c => c.pts).concat(curves.flatMap(c => pts(c).map(p => [p.M, p.N])));
  let xmin = Math.min(...all.map(p => p[0])), xmax = Math.max(...all.map(p => p[0])), ymin = Math.min(...all.map(p => p[1])), ymax = Math.max(...all.map(p => p[1]));
  const px = (xmax - xmin) * 0.06, py = (ymax - ymin) * 0.05; xmin -= px; xmax += px; ymin -= py; ymax += py;
  const X = x => ml + (x - xmin) / (xmax - xmin) * (W - ml - mr), Y = y => H - mb - (y - ymin) / (ymax - ymin) * (H - mt - mb);
  let s = svgOpen(W, H);
  niceTicks(ymin, ymax, 8).forEach(t => { s += `<line x1="${ml}" y1="${Y(t)}" x2="${W - mr}" y2="${Y(t)}" stroke="#eef0f3"/>` + tx(ml - 6, Y(t) + 3.5, fmt(t, 0), { a: 'end', fs: 10, c: '#7a8494' }); });
  niceTicks(xmin, xmax, 8).forEach(t => { s += `<line x1="${X(t)}" y1="${mt}" x2="${X(t)}" y2="${H - mb}" stroke="#eef0f3"/>` + tx(X(t), H - mb + 14, fmt(t, 0), { fs: 10, c: '#7a8494' }); });
  s += `<line x1="${ml}" y1="${Y(0)}" x2="${W - mr}" y2="${Y(0)}" stroke="#39414f"/><line x1="${X(0)}" y1="${mt}" x2="${X(0)}" y2="${H - mb}" stroke="#39414f"/>`;
  s += tx((ml + W - mr) / 2, H - 6, 'M<tspan font-size="8" dy="2">Rd</tspan><tspan dy="-2"> [kNm]  (+ rozciągane włókna dolne)</tspan>', { fs: 11, c: '#4a5466' });
  s += tx(16, (mt + H - mb) / 2, 'N [kN]  (+ ściskanie)', { fs: 11, c: '#4a5466', rot: -90 });
  curves.forEach((c, i) => {
    s += `<polygon points="${c.pts.map(p => X(p[0]).toFixed(1) + ',' + Y(p[1]).toFixed(1)).join(' ')}" fill="${c.c}" fill-opacity="0.07" stroke="${c.c}" stroke-width="1.8"/>`;
    pts(c).forEach((p, j) => {
      s += `<circle cx="${X(p.M)}" cy="${Y(p.N)}" r="4.5" fill="#c0262d" stroke="#ffffff" stroke-width="1.5"/>`;
      if (curves.length === 1 && pts(c).length <= 2) s += tx(X(p.M) + 8, Y(p.N) - 8 - j * 12, `(${fmt(p.M, 1)}; ${fmt(p.N, 1)})`, { fs: 10.5, c: '#c0262d', a: 'start', w: 600 });
    });
    const nm = c.name.length > 44 ? c.name.slice(0, 42) + '…' : c.name;
    s += `<line x1="${W - mr - 250}" y1="${mt + 12 + i * 16}" x2="${W - mr - 230}" y2="${mt + 12 + i * 16}" stroke="${c.c}" stroke-width="2"/>` + tx(W - mr - 226, mt + 16 + i * 16, esc(nm), { a: 'start', fs: 10.5 });
  });
  s += '</svg>';
  return s;
}
// kontur nośności M_y–M_z przy N_Ed (zginanie ukośne)
function biaxSVG(item, W, H) {
  W = W || 380; H = H || 360;
  const B = R.biaxOf(item.bars), N = R.st.NEd;
  const ct = B.contour(N); if (!ct) return '';
  const P = ct.map(([a, b]) => [a / 1e6, b / 1e6]);
  const st = R.st, sy = item.kind === 'supp' ? -1 : 1;
  const pairs = [1, -1].flatMap(sg => (item.kind ? [sy] : [1, -1]).includes(sg) ? st.pairs(st.ulsList, item.k, sg).map(([a, b]) => [a / 1e6, b / 1e6]) : []);
  const allp = pairs.flatMap(([a, b]) => [[a, b], [a, -b]]);
  const all = P.concat(allp);
  let xmin = Math.min(...all.map(p => p[0])), xmax = Math.max(...all.map(p => p[0])), ymin = Math.min(...all.map(p => p[1])), ymax = Math.max(...all.map(p => p[1]));
  const ml = 54, mr = 14, mt = 26, mb = 36;
  const sc = Math.min((W - ml - mr) / (xmax - xmin || 1), (H - mt - mb) / (ymax - ymin || 1)) * 0.92;
  const cx = (ml + W - mr) / 2 - (xmin + xmax) / 2 * sc, cy = (mt + H - mb) / 2 + (ymin + ymax) / 2 * sc;
  const X = x => cx + x * sc, Y = y => cy - y * sc;
  let s = svgOpen(W, H);
  s += tx(ml - 40, 14, esc(cap(item.loc || '')) + ` – kontur M<tspan font-size="8" dy="2">y</tspan><tspan dy="-2">–M</tspan><tspan font-size="8" dy="2">z</tspan><tspan dy="-2"> przy N</tspan><tspan font-size="8" dy="2">Ed</tspan><tspan dy="-2"> = ${fmt(N / 1e3, 0)} kN</tspan>`, { a: 'start', fs: 11, w: 650 });
  s += `<line x1="${ml - 6}" y1="${Y(0)}" x2="${W - mr}" y2="${Y(0)}" stroke="#39414f"/><line x1="${X(0)}" y1="${mt}" x2="${X(0)}" y2="${H - mb}" stroke="#39414f"/>`;
  s += tx(W - mr, Y(0) - 5, 'M<tspan font-size="8" dy="2">y</tspan>', { a: 'end', fs: 10.5, c: '#4a5466' }) + tx(X(0) + 6, mt + 8, 'M<tspan font-size="8" dy="2">z</tspan>', { a: 'start', fs: 10.5, c: '#4a5466' });
  s += `<polygon points="${P.map(p => X(p[0]).toFixed(1) + ',' + Y(p[1]).toFixed(1)).join(' ')}" fill="#6a3fb5" fill-opacity="0.08" stroke="#6a3fb5" stroke-width="1.8"/>`;
  allp.forEach(([a, b]) => { s += `<circle cx="${X(a)}" cy="${Y(b)}" r="2.6" fill="#1d5bb8" fill-opacity="0.6"/>`; });
  if (item.My !== undefined) s += `<circle cx="${X(item.My / 1e6)}" cy="${Y(item.Mz / 1e6)}" r="5" fill="#c0262d" stroke="#ffffff" stroke-width="1.5"/>` + tx(X(item.My / 1e6) + 8, Y(item.Mz / 1e6) - 7, `η = ${fmt(item.u * 100, 0)}%`, { a: 'start', fs: 10.5, c: '#c0262d', w: 650 });
  const ext = [Math.max(...P.map(p => p[0])), Math.min(...P.map(p => p[0])), Math.max(...P.map(p => p[1]))];
  s += tx(X(0) + 4, H - mb + 16, `M<tspan font-size="8" dy="2">Rd,y</tspan><tspan dy="-2"> = ${fmt(ext[0], 0)} / ${fmt(ext[1], 0)}, M</tspan><tspan font-size="8" dy="2">Rd,z</tspan><tspan dy="-2"> = ±${fmt(ext[2], 0)} kNm</tspan>`, { a: 'middle', fs: 10, c: '#4a5466' });
  s += '</svg>';
  return s;
}
function mnHTML(el) {
  const cv = mnCurves();
  const W = el.clientWidth < 700 ? Math.max(320, el.clientWidth - 60) : Math.max(480, Math.min(900, el.clientWidth - (el.clientWidth > 900 ? 360 : 40)));
  let html = `<div class="h2">Krzywa interakcji M–N<small>metoda ogólna – zgodność odkształceń, wykres σ–ε betonu: ${R.m.diag === 'rect' ? 'prostokątny' : 'parabola-prostokąt'}, stal z poziomą gałęzią i ε<sub>ud</sub> = ${fmt(R.m.eud * 1000, 1)}‰</small></div>`;
  const rows = R.secs.map(sec => `<tr><td>${esc(cap(sec.loc))}: |M<sub>Ed</sub>| / M<sub>Rd</sub></td><td>${fmt(sec.MEd / 1e6, 1)} / ${fmt(sec.MRd / 1e6, 1)}</td><td>kNm</td></tr>`).join('');
  html += `<div class="flex"><div class="box">${mnSVG(cv, W, 520)}</div><div class="box"><h4>Wyniki</h4><table class="kv">
    <tr><td>N<sub>Ed</sub></td><td>${fmt(R.st.NEd / 1e3, 1)}</td><td>kN</td></tr>
    <tr><td>N<sub>Rd,max</sub> (ściskanie osiowe)</td><td>${fmt(R.NRdMax / 1e3, 0)}</td><td>kN</td></tr>
    <tr><td>N<sub>Rd,t</sub> (rozciąganie osiowe)</td><td>${fmt(R.NRdMin / 1e3, 0)}</td><td>kN</td></tr>
    ${rows}
    </table><p class="hint" style="max-width:280px;margin-top:10px">Punkt obliczeniowy (M<sub>Ed</sub>; N<sub>Ed</sub>) musi leżeć wewnątrz obszaru ograniczonego krzywą. Siła osiowa działa w środku ciężkości przekroju betonowego. Efekty II rzędu (wyboczenie) nie są uwzględniane.</p></div></div>`;
  if (R.st.hasZ && R.biaxOf) {
    const items = R.secs.filter(x => x.biax).map(x => Object.assign({ bars: x.bars, k: x.k, kind: x.kind, loc: x.loc }, x.biax))
      .concat((R.biaxZ || []).map(b => Object.assign({ bars: b.seg.barsSpan, k: b.k, kind: null, loc: b.loc + ' (max M_z)' }, b)));
    const Wb = el.clientWidth < 700 ? Math.max(300, el.clientWidth - 60) : 380;
    html += `<div class="h2" style="margin-top:18px">Zginanie ukośne – kontur nośności M<sub>y</sub>–M<sub>z</sub><small>punkty: pary (M<sub>y</sub>; ±|M<sub>z</sub>|) wszystkich kombinacji SGN w przekroju; czerwony – decydujący</small></div><div class="flex">${items.map(it => `<div class="box">${biaxSVG(it, Wb, 360)}</div>`).join('')}</div>`;
  }
  return html;
}
U.mnCurves = mnCurves; U.mnSVG = mnSVG;

/* ----------------------------------------------------- elewacja i stal */
// wysokość belki w miejscu x (odcinki o różnych przekrojach; nad podporą – większa z sąsiednich)
function hAtX(md, x, maxAtSup) {
  const sg = md.segs.find(q => x >= q.x0 - 1e-6 && x <= q.x1 + 1e-6) || (x < 0 ? md.segs[0] : md.segs[md.segs.length - 1]);
  if (maxAtSup) { const p = md.sups.find(q => Math.abs(q.x - x) < 1); if (p) return Math.max(...[p.segL, p.segR].filter(i => i !== null).map(i => md.segs[i].g.h)); }
  return sg.g.h;
}
function elevationSVG(W) {
  const md = R.md, cv = R.cov, c = cv.cs, cb = cv.cb, ct = cv.ct;
  const h = Math.max(...md.segs.map(sg => sg.g.h));
  W = W || 1000;
  const sc0 = E.steelSchedule(R), rows = sc0.rows;
  const xL = sc0.xL, xR = sc0.xR;
  const ml = 46, mr = 46;
  const sx = (W - ml - mr) / (xR - xL);
  const bh = Math.max(110, Math.min(220, h * sx * 1.8)), vs = bh / h;
  const X = x => ml + (x - xL) * sx;
  const COL = { bot: '#1d2a3f', top: '#3b5b8f', topX: '#6a3fb5', mid: '#5d7a2e', stir: '#a04848' };
  const colOf = r => r.side === 'top' && r.sup !== undefined ? COL.topX : (COL[r.side] || COL.stir);
  const zones = R.stirZones || E.stirrupZones(R);
  const sTxt = v => fmt(v, Math.abs(v - Math.round(v)) < 1e-6 ? 0 : 1);
  // ---- etykiety pozycji: numer w kółku + n⌀d, długość
  const labs = [], grp = {};
  rows.forEach(r => {
    if (!['bot', 'top', 'mid'].includes(r.side)) return;
    const key = (r.side === 'bot' ? 'b' + r.seg : r.sup !== undefined ? 'x' + r.sup : r.side) + (r.npc > 1 ? 'p' + r.piece : '');
    (grp[key] = grp[key] || []).push(r);
  });
  const longest = md.segs.filter(q => q.kind === 'span').sort((u, v) => v.L - u.L)[0] || md.segs[0];
  Object.entries(grp).forEach(([key, rs]) => {
    let a, b;
    if (/p\d+$/.test(key)) { const r0 = rs[0]; a = Math.max(r0.x0, xL) + 300; b = Math.min(r0.x1, xR) - 300; if (b < a) { a = r0.x0; b = r0.x1; } }
    else if (key[0] === 'b') { const sg = md.segs[+key.slice(1)]; a = sg.x0; b = sg.x1; }
    else if (key[0] === 'x') {
      const p = md.sups[+key.slice(1)], r0 = rs[0];
      const lw = p.x - p.t / 2 - Math.max(r0.x0, xL), rw = Math.min(r0.x1, xR) - p.x - p.t / 2;
      if (lw >= rw) { a = Math.max(r0.x0, xL); b = p.x - p.t / 2; } else { a = p.x + p.t / 2; b = Math.min(r0.x1, xR); }
    } else { a = longest.x0 + (key === 'mid' ? longest.L * 0.15 : 0); b = longest.x1; }
    rs.forEach((r, i) => labs.push({ r, x: a + (b - a) * (i + 1) / (rs.length + 1), up: r.side === 'top', txt: `${r.n}⌀${r.d} l = ${fmt(r.len / 1000, 2)} m` }));
  });
  // odnośniki strzemion – w każdym odcinku o innych strzemionach (dokładnie na strzemieniu)
  rows.filter(r => r.side === 'stir' || r.side === 'stir2').forEach(stR => {
    const zs = zones.filter(z => (stR.segs || []).includes(z.seg.idx));
    const z0 = (zs.length ? zs : zones).reduce((p, q) => (q.b - q.a > p.b - p.a ? q : p), (zs.length ? zs : zones)[0]); if (!z0) return;
    const xt = z0.a + (z0.b - z0.a) * (stR.side === 'stir2' ? 0.38 : 0.62);
    const xs0 = z0.xs.reduce((p, q) => (Math.abs(q - xt) < Math.abs(p - xt) ? q : p), z0.xs[0]);
    const k = stR.set ? stR.set.legs : S.stir.legs;
    labs.push({ r: stR, x: xs0, up: false, zh: z0.seg.g.h, txt: stR.side === 'stir2' ? `${stR.n} szt. ⌀${stR.d} – ${stR.shape.type === 'pin' ? 'szpilki' : 'strzemiona wewnętrzne'}` : `${stR.n} szt. ⌀${stR.d}, ${k}-cięte` });
  });
  // rzędy opisów bez nakładania: od prawej do lewej (odnośnik etykiety położonej bardziej na lewo – wyżej); opis nie może leżeć na drodze
  // odnośnika etykiety z wyższego rzędu, a odnośnik nie może przechodzić przez opis etykiety z niższego rzędu
  const placed = { up: [], dn: [] };
  labs.slice().sort((p, q) => X(q.x) - X(p.x) || (q.up ? 1 : 0) - (p.up ? 1 : 0)).forEach(l => {
    const w = 26 + l.txt.length * 6.1, isSt = l.r.side === 'stir' || l.r.side === 'stir2', xa = X(l.x);
    l.bx = Math.max(4, Math.min(W - 4 - w, xa + (isSt ? 30 : 20)));     // opis z prawej strony punktu wskazania – odnośnik ukośny (pręty) / poziomy (strzemiona)
    l.w = w;
    const P = placed[l.up ? 'up' : 'dn'], lead = [Math.min(xa, l.bx - 3) - 4, Math.max(xa, l.bx - 3) + 4];
    const ok = k => P.every(q => !((q.lane === k && l.bx < q.bx + q.w + 8 && l.bx + w > q.bx - 8)
      || (q.lane > k && l.bx < q.lead[1] && l.bx + w > q.lead[0])
      || (q.lane < k && lead[0] < q.bx + q.w && lead[1] > q.bx - 4)));
    let k = 0; while (k < 40 && !ok(k)) k++;
    l.lane = k; P.push({ bx: l.bx, w, lane: k, lead });
  });
  const lanes = { up: Array.from({ length: placed.up.length ? Math.max(...placed.up.map(q => q.lane)) + 1 : 0 }), dn: Array.from({ length: placed.dn.length ? Math.max(...placed.dn.map(q => q.lane)) + 1 : 0 }) };
  // ---- układ pionowy
  const LH = 18;
  const hasFix = md.sups.some(p => p.type === 'fix');
  const colUp = hasFix ? 26 : 0;
  const topCut = R.anch.topCut || [], lapsT = (sc0.laps || []).filter(l => l.side === 'top'), lapsB = (sc0.laps || []).filter(l => l.side !== 'top');
  const dimTop = topCut.length || lapsT.length ? 34 : 0;
  const top = 12 + dimTop + lanes.up.length * LH + Math.max(colUp, 6) + 8;
  const Y = y => top + y * vs;
  // głębokość słupów podpór sztywnych (pręty górne odgięte w dół)
  let exc = 0;
  rows.forEach(r => { if (r.side === 'top') ['L', 'R'].forEach(sd => { const lg = r['leg' + sd]; if (lg && r['dir' + sd] === 'down') exc = Math.max(exc, (r.y + lg - h) * vs); }); });
  const colDn = Math.min(170, Math.max(26, exc + 14));
  const yLane0 = Y(h) + 40;
  const yLanesEnd = yLane0 + Math.max(0, lanes.dn.length - 1) * LH;
  const yA = Math.max(yLanesEnd + 26, Y(h) + (hasFix ? colDn : 24) + 22);
  const anchE = md.sups.filter(p => p.end || lapsB.length), hasA = anchE.length > 0 || md.sups.some(p => !p.end) || lapsB.length;
  const yD1 = hasA ? yA + 40 : yA;
  const yD2 = yD1 + 30, yD3 = yD2 + 26, yD4 = yD3 + 26;
  const H0 = Math.round(yD4 + 40);
  let s = svgOpen(W, H0, `class="elev" data-ml="${ml}" data-sx="${sx}" data-xl="${xL}" data-top="${top}" data-bh="${bh}"`);
  // ---- podpory (pod belką; sztywne – słup nad i pod belką)
  md.sups.forEach(p => {
    const x0 = X(p.x - p.t / 2), w = Math.max(2, p.t * sx), hp = hAtX(md, p.x, true);
    if (p.type === 'fix') {
      s += `<rect x="${x0}" y="${Y(0) - colUp}" width="${w}" height="${colUp}" fill="#cfd4db" stroke="#39414f"/>`;
      s += `<rect x="${x0}" y="${Y(hp)}" width="${w}" height="${colDn + (h - hp) * vs}" fill="#cfd4db" stroke="#39414f"/>`;
      s += `<path d="M${x0 - 3},${Y(0) - colUp} l${w / 4 + 3},-4 l${w / 4},8 l${w / 4},-8 l${w / 4 + 3},4 M${x0 - 3},${Y(h) + colDn} l${w / 4 + 3},-4 l${w / 4},8 l${w / 4},-8 l${w / 4 + 3},4" fill="none" stroke="#39414f" stroke-width="0.8"/>`;
    } else s += `<rect x="${x0}" y="${Y(hp)}" width="${w}" height="${24 + (h - hp) * vs}" fill="#cfd4db" stroke="#39414f"/>`;
    if (p.type === 'roller') s += `<circle cx="${X(p.x) - 5}" cy="${Y(h) + 28}" r="3" fill="#ffffff" stroke="#39414f"/><circle cx="${X(p.x) + 5}" cy="${Y(h) + 28}" r="3" fill="#ffffff" stroke="#39414f"/>`;
    s += `<line x1="${X(p.x)}" y1="${Y(0) - colUp - 6}" x2="${X(p.x)}" y2="${Y(h) + (p.type === 'fix' ? colDn : 24) + 6}" stroke="#7a8494" stroke-dasharray="8 3 2 3" stroke-width="0.8"/>`;
    s += tx(X(p.x), Y(h) + 16, esc(p.label), { fs: 10.5, w: 700, c: '#1b2230' });
  });
  // ---- belka (odcinki mogą mieć różne wysokości – górna krawędź wspólna)
  { const xs = [xL]; md.segs.forEach((sg, i) => { if (i < md.segs.length - 1) xs.push(E.segEdge(md, i)); }); xs.push(xR);
    let d = `M${X(xL).toFixed(1)},${Y(0).toFixed(1)} H${X(xR).toFixed(1)}`;
    for (let i = md.segs.length - 1; i >= 0; i--) d += ` V${Y(md.segs[i].g.h).toFixed(1)} H${X(xs[i]).toFixed(1)}`;
    s += `<path d="${d} Z" fill="#f1f2f4" fill-opacity="0.92" stroke="#39414f" stroke-width="1.3"/>`; }
  // ---- przekroje obliczeniowe (oznaczenia)
  (R.secs || []).forEach((q, i) => { const xq = X(q.x); s += `<g class="secmk"><line x1="${xq}" y1="${Y(0) - 8}" x2="${xq}" y2="${Y(0) - 2}" stroke="#1d5bb8" stroke-width="1.2"/>` + tx(xq + 3, Y(0) - 9, String(i + 1), { fs: 8.5, c: '#1d5bb8', a: 'start', w: 700 }) + '</g>'; });
  // ---- przeguby w belce
  (md.hinges || []).forEach(xh => { s += `<line x1="${X(xh)}" y1="${Y(0) - 4}" x2="${X(xh)}" y2="${Y(h) + 4}" stroke="#c0262d" stroke-width="0.8" stroke-dasharray="4 3"/><circle cx="${X(xh)}" cy="${Y(h / 2)}" r="5" fill="#ffffff" stroke="#c0262d" stroke-width="1.5"/>` + tx(X(xh) + 8, Y(h / 2) + 4, 'przegub', { fs: 9, a: 'start', c: '#c0262d' }); });
  // ---- strzemiona – od lica podpór
  zones.forEach(z => { const hz = z.seg.g.h; z.xs.forEach(xx => { s += `<line x1="${X(xx)}" y1="${Y(ct)}" x2="${X(xx)}" y2="${Y(hz - cb)}" stroke="${COL.stir}" stroke-width="0.8"/>`; }); });
  // ---- pręty podłużne (z odgięciami)
  const yOf = r => {
    let y = Y(r.y);
    if (r.side === 'bot') { if (md.cont && r.seg % 2) y -= 2.5; if (r.cut) y -= 5; }
    if (r.side === 'top' && r.sup !== undefined) y += 4.5;
    if (r.npc > 1 && r.piece % 2) y += r.side === 'bot' ? -3.2 : 3.2;     // kolejne odcinki prętów na zakład – przesunięte
    return y;
  };
  // pręty z odgięciami – łuki o promieniu gięcia φm/2 + ⌀/2 (oś pręta), w skali widoku (łuki eliptyczne – skala pionowa ≠ pozioma)
  const bendDone = {};
  rows.forEach(r => {
    if (!['bot', 'top', 'mid'].includes(r.side)) return;
    const col = colOf(r), y = yOf(r), x0 = X(r.x0), x1 = X(r.x1);
    const dl = r.dirL === 'up' ? -1 : 1, dr = r.dirR === 'up' ? -1 : 1, F = v => v.toFixed(1);
    let d;
    if (r.legL) {
      const rc = (r.rL || 0) + r.d / 2, ry = Math.min(rc * vs, r.legL * vs * 0.9), rx = Math.min(rc * sx, (x1 - x0) * 0.3);
      d = `M${F(x0)},${F(y + dl * r.legL * vs)} L${F(x0)},${F(y + dl * ry)} A${F(rx)},${F(ry)} 0 0 ${dl < 0 ? 0 : 1} ${F(x0 + rx)},${F(y)}`;
    } else d = `M${F(x0)},${F(y)}`;
    if (r.legR) {
      const rc = (r.rR || 0) + r.d / 2, ry = Math.min(rc * vs, r.legR * vs * 0.9), rx = Math.min(rc * sx, (x1 - x0) * 0.3);
      d += ` L${F(x1 - rx)},${F(y)} A${F(rx)},${F(ry)} 0 0 ${dr > 0 ? 1 : 0} ${F(x1)},${F(y + dr * ry)} L${F(x1)},${F(y + dr * r.legR * vs)}`;
    } else d += ` L${F(x1)},${F(y)}`;
    const sw = r.side === 'bot' ? 2.8 : r.side === 'mid' ? 2 : 2.4;
    s += `<path d="${d}" fill="none" stroke="${col}" stroke-width="${sw}" stroke-linejoin="round" stroke-linecap="round" ${r.side === 'mid' ? 'stroke-dasharray="10 3"' : ''}/>`;
    // opis promienia gięcia (raz dla końca i rodzaju prętów)
    [['L', r.legL, r.rL, x0, dl], ['R', r.legR, r.rR, x1, dr]].forEach(([sd, lg, rr, xb, dd]) => {
      if (!lg || !rr) return;
      const key = sd + r.side + Math.round(xb); if (bendDone[key]) return; bendDone[key] = 1;
      const phm = 2 * rr, k = phm / r.d, txt = `φm = ${fmt(k, k % 1 ? 1 : 0)}⌀ = ${fmt(phm, 0)}, r = ${fmt(rr, 0)}`;
      const ty = y - dd * 9 + (dd < 0 ? 0 : 3);
      s += `<text x="${F(xb + (sd === 'L' ? 8 : -8))}" y="${F(ty)}" font-size="8.5" fill="${col}" text-anchor="${sd === 'L' ? 'start' : 'end'}" paint-order="stroke" stroke="#f1f2f4" stroke-width="3" stroke-linejoin="round">${txt}</text>`;
    });
  });
  // ---- końce prętów – klik: zmiana zakończenia (odgięcie na zadaną długość)
  { const done = {};
    rows.forEach(r => {
      if (!r.key || r.cut || !['bot', 'top'].includes(r.side)) return;
      const y = yOf(r);
      [['L', r.x0, !r.npc || r.piece === 0, r.legL, r.dirL], ['R', r.x1, !r.npc || r.piece === r.npc - 1, r.legR, r.dirR]].forEach(([sd, xx, ok, lg, dir]) => {
        if (!ok || done[r.key + sd]) return; done[r.key + sd] = 1;
        const yy = lg ? y + (dir === 'up' ? -1 : 1) * lg * vs : y;
        const spX = /^x\d+$/.test(r.key) ? R.md.sups[+r.key.slice(1)] : null, xe = spX && CONT(S) && !spX.end;     // pręty dodatkowe nad podporą pośrednią
        const dd = getEndDelta(r.key, sd), tt = `${esc(r.name.replace(/, warstwa.*$/, ''))} – koniec ${sd === 'L' ? 'lewy' : 'prawy'}${dd ? ` (${dd > 0 ? 'przedłużony' : 'skrócony'} ręcznie o ${Math.abs(dd)} mm)` : ''}: kliknij – zakończenie (zakotwienie, odgięcie), przedłużenie lub skrócenie pręta (wpisz wartość)`;
        s += `<g class="bend${xe ? ' xend' : ''}" data-key="${r.key}" data-end="${sd}"${xe ? ` data-sup="${spX.idx}"` : ''}><title>${tt}</title>`;
        s += `<circle cx="${X(xx).toFixed(1)}" cy="${yy.toFixed(1)}" r="7" fill="${colOf(r)}" fill-opacity="${dd ? 0.3 : 0.12}" stroke="${colOf(r)}" stroke-width="1" stroke-dasharray="2 2"/>`;
        if (lg) s += `<circle cx="${X(xx).toFixed(1)}" cy="${y.toFixed(1)}" r="6" fill="${colOf(r)}" fill-opacity="0.08" stroke="${colOf(r)}" stroke-width="0.8" stroke-dasharray="2 2"/>`;     // narożnik odgięcia
        s += `</g>`;
      });
    }); }
  // ---- wymiary odgięć (odcinki pionowe prętów na podporach skrajnych) – obok końców belki
  const legDone = {};
  rows.forEach(r => {
    if (!['bot', 'top'].includes(r.side)) return;
    [['L', r.legL, r.dirL, r.x0], ['R', r.legR, r.dirR, r.x1]].forEach(([sd, lg, dir, xb]) => {
      if (!lg) return;
      const inner = sd === 'L' ? r.x0 > xL + c + 5 : r.x1 < xR - c - 5;          // odgięcie przy uskoku nad podporą pośrednią
      const key = sd + r.side + lg + (inner ? 'i' + Math.round(xb) : ''); if (legDone[key]) return; legDone[key] = 1;
      const nOff = inner ? 0 : Object.keys(legDone).filter(k => k[0] === sd && !/i/.test(k)).length - 1;
      const y = yOf(r), y2 = y + (dir === 'up' ? -1 : 1) * lg * vs, xd = inner ? X(xb) + (sd === 'L' ? 10 : -10) : sd === 'L' ? X(xL) - 12 - nOff * 14 : X(xR) + 12 + nOff * 14;
      s += `<line x1="${X(xb)}" y1="${y2.toFixed(1)}" x2="${xd + (sd === 'L' ? -3 : 3)}" y2="${y2.toFixed(1)}" stroke="#7a8494" stroke-width="0.6" stroke-dasharray="2 2"/><line x1="${X(xb)}" y1="${y.toFixed(1)}" x2="${xd + (sd === 'L' ? -3 : 3)}" y2="${y.toFixed(1)}" stroke="#7a8494" stroke-width="0.6" stroke-dasharray="2 2"/>`;
      s += dimV(xd, Math.min(y, y2), Math.max(y, y2), String(lg), { fs: 10.3 });
    });
  });
  // ---- etykiety pozycji z odnośnikami
  labs.forEach(l => {
    const r = l.r, col = colOf(r);
    const yl = l.up ? top - Math.max(colUp, 6) - 14 - l.lane * LH : yLane0 + l.lane * LH;
    const cx = l.bx + 9, xa = X(l.x), isSt = r.side === 'stir' || r.side === 'stir2';
    // strzemiona: wskazanie na 1/3 wysokości (od dołu), strzałka pozioma; pręty podłużne: odnośnik ukośny do półki opisu
    const hz = l.zh || h, ya = isSt ? Y(hz - cb - (hz - cb - ct) / 3) - (r.side === 'stir2' ? 12 : 0) : yOf(r);
    const ysh = yl + 10.5, x0s = l.bx - 3, x1s = l.bx + l.w - 6;                         // półka opisu (linia pozioma pod numerem i tekstem)
    const arr = (x, y, ang) => { const a1 = ang + 0.42, a2 = ang - 0.42, L = 6.5; return `<path d="M${x.toFixed(1)},${y.toFixed(1)} L${(x + L * Math.cos(a1)).toFixed(1)},${(y + L * Math.sin(a1)).toFixed(1)} L${(x + L * Math.cos(a2)).toFixed(1)},${(y + L * Math.sin(a2)).toFixed(1)} Z" fill="${col}"/>`; };
    if (isSt) {
      const xk = xa + 18;                                                                  // odcinek poziomy od strzemienia, dalej do półki opisu
      s += `<polyline points="${(xa + 1).toFixed(1)},${ya.toFixed(1)} ${xk.toFixed(1)},${ya.toFixed(1)} ${x0s.toFixed(1)},${ysh.toFixed(1)} ${x1s.toFixed(1)},${ysh.toFixed(1)}" fill="none" stroke="${col}" stroke-width="0.8"/>` + arr(xa + 1, ya, 0);
    } else {
      const ang = Math.atan2(ysh - ya, x0s - xa);
      s += `<polyline points="${xa.toFixed(1)},${ya.toFixed(1)} ${x0s.toFixed(1)},${ysh.toFixed(1)} ${x1s.toFixed(1)},${ysh.toFixed(1)}" fill="none" stroke="${col}" stroke-width="0.8"/>` + arr(xa, ya, ang);
    }
    s += `<circle cx="${cx.toFixed(1)}" cy="${yl.toFixed(1)}" r="8" fill="#ffffff" stroke="${col}" stroke-width="1.2"/>` + tx(cx, yl + 3.5, String(r.pos), { fs: 9.5, w: 700, c: col });
    s += tx(cx + 12, yl + 3.5, esc(l.txt), { fs: 9.5, a: 'start', c: col });
  });
  // ---- pręty odgięte na ścinanie (45°): przy podporze, wznoszące się w stronę podpory
  ((R.sh && R.sh.ends) || []).forEach(e => { if (!e.bent) return; const sg = e.seg, hz = sg.g.h, yBo = Y(hz - cb - sg.stir.d - e.bent.d / 2), yTo = Y(ct + sg.stir.d + e.bent.d / 2), hsx = (hz - cb - ct) ;
    for (let k = 0; k < e.bent.ng; k++) { const xm = e.x + e.dir * (e.sup.t / 2 + e.bent.sb * (k + 0.5)), xb = xm + e.dir * hsx / 2, xt = xm - e.dir * hsx / 2;
      s += `<path d="M${X(xb + e.dir * 120).toFixed(1)},${yBo.toFixed(1)} L${X(xb).toFixed(1)},${yBo.toFixed(1)} L${X(xt).toFixed(1)},${yTo.toFixed(1)} L${X(xt - e.dir * 80).toFixed(1)},${yTo.toFixed(1)}" fill="none" stroke="#b5651d" stroke-width="1.8" stroke-linejoin="round"><title>Pręty odgięte 45°: ${e.bent.n}⌀${e.bent.d} (ścinanie, ${esc(e.name)})</title></path>`; }
    const pr = (sc0.rows || []).find(r => r.side === 'bent' && r.bent && r.bent.e === e.key); if (pr) { const xm = X(e.x + e.dir * (e.sup.t / 2 + e.bent.sb * 0.5)); s += `<circle cx="${xm.toFixed(1)}" cy="${((yBo + yTo) / 2).toFixed(1)}" r="7.5" fill="#ffffff" stroke="#b5651d" stroke-width="1.1"/>` + tx(xm, (yBo + yTo) / 2 + 3.3, String(pr.pos), { fs: 9, w: 700, c: '#b5651d' }); } });
  // ---- zakłady prętów górnych (powyżej belki)
  let dimRow = 0;
  const lapHit = (l, yy) => l.key ? `<rect class="lapdim" data-lk="${l.key}" data-lc="${l.c}" data-ll="${l.l0}" data-lr="${l.l0req || l.l0}" data-la="${l.a}" x="${(X(l.a) - 4).toFixed(1)}" y="${yy - 13}" width="${(X(l.b) - X(l.a) + 8).toFixed(1)}" height="18" fill="transparent"><title>Zakład l₀ = ${l.l0} mm, środek x = ${fmt(l.c / 1000, 2)} m${l.man ? ' (ustawiony ręcznie)' : ''} – kliknij, aby zmienić długość lub położenie</title></rect>` : '';
  lapsT.forEach(l => { const yy = 14 + 10 + (dimRow++ % 2) * 14; s += dimH(X(l.a), X(l.b), yy, `zakład l₀ = ${l.l0}${l.man ? ' ✎' : ''}`, { fs: 10.3 }) + lapHit(l, yy); s += `<line x1="${X(l.a)}" y1="${yy + 4}" x2="${X(l.a)}" y2="${Y(0)}" stroke="#7a8494" stroke-width="0.6" stroke-dasharray="2 2"/><line x1="${X(l.b)}" y1="${yy + 4}" x2="${X(l.b)}" y2="${Y(0)}" stroke="#7a8494" stroke-width="0.6" stroke-dasharray="2 2"/>`; });
  // ---- zakotwienia na podporach (pod belką): skrajne – długość w podporze (+ odgięcie), pośrednie – przedłużenie prętów dolnych za lico
  if (hasA) {
    const ya = yA + 6;
    md.sups.forEach(p => {
      if (p.end) {
        const left = p.segL === null, xb = left ? xL + c : xR - c, xf = left ? p.x + p.t / 2 : p.x - p.t / 2;
        const ae = (R.anch.ends || []).find(a => a.e.sup === p), at = (R.anch.endsTop || []).find(a => a.sup === p);
        // długość prętów w podporze (od lica) – z rzeczywistego końca pręta (także skróconego ręcznie)
        const sgE = md.segs[left ? p.segR : p.segL], endOf = key => { const rs = rows.filter(r => r.key === key && !r.cut); if (!rs.length) return null; const r = left ? (rs.find(q => !q.npc || q.piece === 0) || rs[0]) : (rs.find(q => !q.npc || q.piece === q.npc - 1) || rs[rs.length - 1]); return Math.round(left ? xf - r.x0 : r.x1 - xf); };
        const lB = sgE ? endOf('b' + sgE.idx) : null, lT = endOf('t'), man = sgE && (getEndDelta('b' + sgE.idx, left ? 'L' : 'R') || getEndDelta('t', left ? 'L' : 'R'));
        const parts = [];
        if (ae) parts.push(`dół: ${lB !== null ? lB : Math.round(p.t - c)}${ae.bent ? ` + odg. ${ae.leg}, φm = ${fmt(ae.phm, 0)}` : ''} (l<tspan font-size="7.5" dy="2">bd</tspan><tspan dy="-2"> = ${fmt(ae.bent ? ae.lbdHook : ae.lbd, 0)})</tspan>`);
        if (at) parts.push(`góra: ${lT !== null ? lT : Math.round(p.t - c)}${at.bent ? ` + odg. ${at.leg}, φm = ${fmt(at.phm, 0)}` : ''}`);
        if (!parts.length) parts.push(`${lB !== null ? lB : Math.round(p.t - c)}`);
        const x1 = Math.min(X(xb), X(xf)), x2 = Math.max(X(xb), X(xf));
        s += dimH(x1, x2, ya, '', { fs: 10.3 }) + tx(left ? x1 : x2, ya + 13, parts.join(' · ') + (man ? ' ✎' : ''), { fs: 10.3, a: left ? 'start' : 'end', c: '#3d4656' });
        const tw = parts.join(' · ').replace(/<[^>]+>/g, '').length * 5.6 + 10;
        s += `<rect class="anchdim" data-ak="e${p.idx}" x="${(left ? x1 - 4 : x2 - tw).toFixed(1)}" y="${ya - 12}" width="${Math.max(x2 - x1 + 8, tw).toFixed(1)}" height="30" fill="transparent"><title>Zakotwienie prętów w podporze ${esc(p.label)} – kliknij, aby wpisać długość ręcznie</title></rect>`;
      } else {
        const sl = md.segs[p.segL], sr = md.segs[p.segR];
        const rl = rows.find(r => r.side === 'bot' && r.seg === sl.idx && !r.cut && (r.npc ? r.piece === r.npc - 1 : true)), rr = rows.find(r => r.side === 'bot' && r.seg === sr.idx && !r.cut && (r.piece || 0) === 0);
        if (rl && rr) { const xm = X(p.x), hw = Math.max(65, (X(Math.max(rl.x1, p.x + p.t / 2)) - X(Math.min(rr.x0, p.x - p.t / 2))) / 2 + 4), xa = xm - hw, xb2 = xm + hw, man = getEndDelta('b' + sl.idx, 'R') || getEndDelta('b' + sr.idx, 'L');
          s += `<rect class="anchdim" data-ak="i${p.idx}" x="${xa.toFixed(1)}" y="${ya - 12}" width="${(xb2 - xa).toFixed(1)}" height="34" fill="${man ? 'rgba(163,93,0,0.08)' : 'transparent'}"><title>Pręty dolne nad podporą ${esc(p.label)} (zakotwienie za licem / zakład) – kliknij, aby wpisać długość ręcznie${man ? ' (zmienione ręcznie)' : ''}</title></rect>`; }
        const stp = (sc0.steps || []).find(q => (q.R && q.R.sup === p) || (q.L && q.L.sup === p));
        if (stp && rl && rr) { const shal = stp.R && stp.R.sup === p ? rr : rl, ext = shal === rr ? p.x - rr.x0 : rl.x1 - p.x;
          s += shal === rr ? dimH(X(rr.x0), X(p.x), ya, `${Math.round(ext)} za oś (uskok)`, { fs: 9.8 }) : dimH(X(p.x), X(rl.x1), ya, `${Math.round(ext)} za oś (uskok)`, { fs: 9.8 }); }
        else if (rl && rr && S.anch.innerB === 'anch') {          // pręty zakotwione za licem (≥ 10⌀), bez zakładu – długość za licem z każdej strony
          const fl = p.x - p.t / 2, fr = p.x + p.t / 2;
          s += dimH(X(Math.min(rr.x0, fl)), X(Math.max(rl.x1, fr)), ya, `za licem ${Math.round(rl.x1 - fl)} / ${Math.round(fr - rr.x0)}`, { fs: 9.8 });
        }
        else if (rl && rr && rl.x1 > rr.x0 + 1) s += dimH(X(rr.x0), X(rl.x1), ya, `zakład ${Math.round(rl.x1 - rr.x0)}`, { fs: 9.8 });
        else { if (rl && rl.x1 > p.x - p.t / 2 + 1) s += dimH(X(p.x - p.t / 2), X(rl.x1), ya, `${Math.round(rl.x1 - (p.x - p.t / 2))}`, { fs: 9.8 }); if (rr && rr.x0 < p.x + p.t / 2 - 1) s += dimH(X(rr.x0), X(p.x + p.t / 2), ya + 16, `${Math.round(p.x + p.t / 2 - rr.x0)}`, { fs: 9.8, below: true }); }
      }
    });
    lapsB.forEach(l => { s += dimH(X(l.a), X(l.b), ya + 30, `zakład l₀ = ${l.l0}${l.mid ? ' (boczne)' : ''}${l.man ? ' ✎' : ''}`, { fs: 10.3 }) + lapHit(l, ya + 30); });
  }
  // ---- długości prętów górnych dodatkowych (od osi podpory)
  topCut.forEach(tc => {
    const p = tc.sup, sl = tc.sides.find(q => q.side === 'L'), sr = tc.sides.find(q => q.side === 'R');
    const yy = 14 + 10 + (dimRow++ % 2) * 14;
    const hit = (sd, xa, xb2, q) => `<rect class="anchdim" data-ak="x${p.idx}${sd}" x="${(Math.min(xa, xb2) - 3).toFixed(1)}" y="${yy - 13}" width="${(Math.abs(xb2 - xa) + 6).toFixed(1)}" height="18" fill="transparent"><title>Pręty górne dodatkowe – ${esc(p.label)}, ${sd === 'L' ? 'w lewo' : 'w prawo'}: ${fmt(q.len, 0)} mm od osi (wymagane ${fmt(q.lenReq, 0)} mm${q.ext ? `, ${q.ext > 0 ? 'przedłużone' : 'skrócone'} ręcznie o ${Math.abs(Math.round(q.ext))} mm` : ''}) – kliknij, aby wpisać długość</title></rect>`;
    if (!sl.none) s += dimH(X(p.x - sl.len), X(p.x), yy, `${fmt(sl.len / 1000, 2)}${sl.manual ? '*' : sl.ext > 0 ? '+' : sl.ext < 0 ? '−' : ''}`, { fs: 10.3 }) + hit('L', X(p.x - sl.len), X(p.x), sl);
    if (!sr.none) s += dimH(X(p.x), X(p.x + sr.len), yy, `${fmt(sr.len / 1000, 2)}${sr.manual ? '*' : sr.ext > 0 ? '+' : sr.ext < 0 ? '−' : ''}`, { fs: 10.3 }) + hit('R', X(p.x), X(p.x + sr.len), sr);
  });
  // ---- wymiary: strefy strzemion
  zones.forEach(z => {
    const parts = (z.parts || []).map(q => [q.x0, q.x1, q.s, q.n]);
    parts.forEach(([u, v, ss, n]) => { const w = (v - u) * sx, lab = `${n}×${sTxt(ss)}`; s += dimH(X(u), X(v), yD1, w > lab.length * 6 + 40 ? `${lab} = ${fmt((v - u) / 1000, 2)}` : (w > lab.length * 5.5 ? lab : ''), { fs: 10.3 });
      s += `<rect class="stzone" data-seg="${z.seg.idx}" data-s="${ss}" data-len="${Math.round(v - u)}" x="${X(u).toFixed(1)}" y="${yD1 - 13}" width="${Math.max(4, X(v) - X(u)).toFixed(1)}" height="17" fill="transparent"><title>Strefa strzemion ${n}×${sTxt(ss)} mm – kliknij, aby zmienić rozstaw, długość strefy lub liczbę stref</title></rect>`; });
    [[z.eL, z.a, 1], [z.eR, z.b, -1]].forEach(([e, x0, dir]) => { if (e === null || e === undefined) return; s += tx(X(x0) + dir * 2, yD1 + 12, `e=${Math.round(e)}`, { fs: 8.5, c: COL.stir, a: dir > 0 ? 'start' : 'end' }); });
  });
  // ---- wymiary: szerokości podpór i rozpiętości w świetle
  const lab = (w, full, short) => w > full.length * 5.6 + 8 ? full : (w > short.length * 5.6 + 4 ? short : '');
  md.sups.forEach(p => { const w = p.t * sx; s += dimH(X(p.x - p.t / 2), X(p.x + p.t / 2), yD2, lab(w, `t=${fmt(p.t, 0)}`, fmt(p.t, 0)), { fs: 9.8 }); });
  md.segs.forEach(sg => {
    const a = sg.supL ? sg.x0 + sg.supL.t / 2 : sg.x0, b = sg.supR ? sg.x1 - sg.supR.t / 2 : sg.x1;
    if (b - a < 1) return;
    const w = (b - a) * sx, v = fmt((b - a) / 1000, 2);
    s += dimH(X(a), X(b), yD2, lab(w, sg.kind === 'span' ? `w świetle ${v} m` : `od lica ${v} m`, v), { fs: 10.3 });
  });
  // ---- wymiary: rozpiętości w osiach podpór
  md.segs.forEach(sg => { const w = sg.L * sx, v = fmt(sg.L / 1000, 2); s += dimH(X(sg.x0), X(sg.x1), yD3, lab(w, `${md.segs.length > 1 ? cap(sg.label) + ': ' : ''}${sg.kind === 'span' ? 'L' : 'l'} = ${v} m w osiach`, v), { fs: 9.5 }); });
  // ---- wymiar całkowity
  s += dimH(X(xL), X(xR), yD4, `długość belki ${fmt((xR - xL) / 1000, 2)} m`, { fs: 10 });
  // ---- legenda
  let ly = yD4 + 26, lx = ml;
  const leg = [[COL.bot, 'zbrojenie dolne'], [COL.top, 'górne ciągłe']];
  if (rows.some(r => r.sup !== undefined)) leg.push([COL.topX, 'górne dodatkowe nad podporami']);
  if (rows.some(r => r.side === 'mid')) leg.push([COL.mid, 'pręty boczne']);
  leg.push([COL.stir, `strzemiona (wymiary: liczba×rozstaw, e – odstęp od lica)`]);
  leg.push(['#7a8494', '① – nr pozycji w zestawieniu stali; wymiary przy końcach belki – odcinki odgięte [mm]; φm – średnica trzpienia gięcia (tab. 8.1N), r – promień wewnętrzny']);
  leg.push(['#1d5bb8', 'pod belką – zakotwienie w podporach [mm]; 1, 2… – przekroje obliczeniowe (jak w raporcie i DXF)']);
  if (topCut.some(q => q.sides.some(z => z.manual))) leg.push([COL.topX, '* długość przyjęta ręcznie']);
  if (topCut.some(q => q.sides.some(z => z.ext > 0))) leg.push([COL.topX, '+ pręt przedłużony ponad długość wymaganą (koniec pręta – kliknij)']);
  leg.forEach(([cc, l]) => { const w = 40 + l.length * 5.9; if (lx + w > W - mr && lx > ml) { lx = ml; ly += 18; } s += `<line x1="${lx}" y1="${ly}" x2="${lx + 22}" y2="${ly}" stroke="${cc}" stroke-width="3"/>` + tx(lx + 27, ly + 4, esc(l), { a: 'start', fs: 10 }); lx += w; });
  s += '</svg>';
  const H = Math.max(H0, Math.round(ly + 14));
  return s.replace(/height="(\d+)" viewBox="0 0 (\d+) (\d+)"/, (m0, h0, w0) => `height="${H}" viewBox="0 0 ${w0} ${H}"`);
}
// zakotwienie prętów na podporach skrajnych – sprawdzenie długości i odgięcia
function endAnchTable() {
  const a = R.anch, rows = [];
  const mand = e => e.bent ? `<br><small>gięcie na trzpieniu φ<sub>m</sub> = <b>${fmt(e.phm, 0)} mm</b> (r = ${fmt(e.phm / 2, 0)} mm): tab. 8.1N – ${e.dia <= 16 ? '4' : '7'}⌀ = ${fmt(e.phmMin, 0)} mm${e.phmReq > 0 ? `; 8.3(3) – miażdżenie betonu w zgięciu: φ<sub>m,min</sub> = F<sub>bt</sub>(1/a<sub>b</sub> + 1/(2⌀))/f<sub>cd</sub> = ${fmt(e.phmReq, 0)} mm` : ''}</small>` : '';
  (a.ends || []).forEach(e => rows.push([cap(e.name), `dolne ⌀${e.dia}`, e.lbd, e.avail, (e.bent ? `odgięte do góry: odcinek pionowy <b>${e.leg} mm</b> (l<sub>bd</sub> z odgięciem, α₁ = 0,7: ${fmt(e.lbdHook, 0)} mm)${e.okBent ? '' : ` <span style="color:var(--fail)">✖ &gt; ${fmt(e.legMax, 0)} mm – zwiększ szerokość podpory lub zmniejsz ⌀</span>`}` : 'pręty proste ✔') + mand(e)]));
  (a.endsTop || []).forEach(e => rows.push([cap(e.name), `górne ⌀${e.dia}`, e.lbd, e.avail, (e.bent ? `odgięte w dół, w podporę: odcinek <b>${e.leg} mm</b> (l<sub>bd</sub> z odgięciem: ${fmt(e.lbdHook, 0)} mm)` : 'pręty proste ✔') + mand(e)]));
  if (!rows.length) return '';
  return `<div class="h2" style="margin-top:16px">Zakotwienie prętów na podporach skrajnych<small>gdy pręt prosty nie mieści się na podporze (l<sub>bd</sub> > t − c<sub>nom</sub>) – odgięcie na wymaganą długość</small></div><div class="tscroll"><table class="sched"><tr><th>Podpora</th><th>Pręty</th><th>l<sub>bd</sub> pręta prostego [mm]</th><th>t − c<sub>nom</sub> [mm]</th><th>Rozwiązanie</th></tr>${rows.map(r => `<tr><td>${esc(r[0])}</td><td>${r[1]}</td><td class="n">${fmt(r[2], 0)}</td><td class="n">${fmt(r[3], 0)}</td><td>${r[4]}</td></tr>`).join('')}</table></div>`;
}
function scheduleTable(sc) {
  const ds = Object.keys(sc.byD).map(Number).sort((a, b) => a - b);
  let h = `<div class="tscroll"><table class="sched"><tr><th>Poz.</th><th>Opis</th><th>⌀ [mm]</th><th>Liczba [szt.]</th><th>Długość 1 szt. [m]</th><th>Długość całk. [m]</th>${ds.map(d => `<th>⌀${d} [kg]</th>`).join('')}</tr>`;
  sc.rows.forEach(r => { h += `<tr><td class="n">${r.pos}</td><td>${esc(r.name)}</td><td class="n">${r.d}</td><td class="n">${r.n}</td><td class="n">${fmt(r.len / 1000, 2)}</td><td class="n">${fmt(r.tot, 2)}</td>${ds.map(d => `<td class="n">${d === r.d ? fmt(r.mass, 1) : ''}</td>`).join('')}</tr>`; });
  h += `<tr class="tot"><td colspan="6">Razem [kg] (masa 1 m: 0,00617·⌀²)</td>${ds.map(d => `<td class="n">${fmt(sc.byD[d], 1)}</td>`).join('')}</tr>`;
  h += `<tr class="tot"><td colspan="6">Masa całkowita stali [kg] · objętość betonu ${fmt(sc.vol, 3)} m³ · wskaźnik ${fmt(sc.total / sc.vol, 0)} kg/m³</td><td class="n" colspan="${ds.length}">${fmt(sc.total, 1)}</td></tr></table></div>`;
  return h;
}
U.stirOfSec = stirOfSec; U.holdOfSec = holdOfSec; U.reactionsSVG = W => reactionsSVG(W); U.scheduleTable = scheduleTable; U.elevationSVG = elevationSVG; U.endAnchTable = () => endAnchTable();
function renderElevation(el) {
  if (R && R.bare) { el.innerHTML = `<div class="dsumx"></div><div class="h2">Widok podłużny belki – zbrojenie</div>${bareNote()}<p><button class="btn pri" id="elAuto">Dobierz zbrojenie wymagane</button></p>`; const b = $('#elAuto', el); if (b) b.onclick = () => doAutoReb(); return; }
  const narrow = el.clientWidth < 980;
  const W = narrow ? Math.max(600, el.clientWidth - 40) : Math.max(600, Math.min(1400, el.clientWidth - 40 - 336));
  const sc = E.steelSchedule(R);
  const nMan = Object.keys(S.barEdit || {}).length;
  let html = `<div class="dsumx"></div><div class="etools"><div class="h2" style="margin:0">Widok podłużny belki – zbrojenie<small>przesuń kursor po belce – obok widać rzeczywisty przekrój; kliknij koniec pręta (kółko), aby dodać odgięcie; kliknij pręt w wyciągach, aby zmienić jego wymiary</small></div><span class="sp"></span>${nMan ? `<button class="btn sm" id="bReset" title="Usuń wszystkie ręczne zmiany wymiarów prętów">Przywróć automatyczne wymiary (${nMan})</button>` : ''}<button class="btn pri sm" id="bDxf" title="Rysunek zbrojenia: widok podłużny, przekroje, wyciągi prętów i zestawienie stali">Eksport DXF</button></div>`;
  html += `<div class="elevgrid"><div class="box elevbox"><div class="v3sw segsw sm" role="tablist" aria-label="Widok"><button data-v3="2d" class="${view3d ? '' : 'on'}">2D</button><button data-v3="3d" class="${view3d ? 'on' : ''}" title="Widok przestrzenny zbrojenia – obrót, przesuw i powiększenie">3D</button></div>${view3d ? `<div class="v3tools segsw sm" role="toolbar" aria-label="Sterowanie widokiem 3D"><button data-v3m="rot" class="${V3.mode === 'pan' ? '' : 'on'}" title="Przeciąganie lewym przyciskiem obraca widok">⟳ Obrót</button><button data-v3m="pan" class="${V3.mode === 'pan' ? 'on' : ''}" title="Przeciąganie lewym przyciskiem przesuwa widok (bez obrotu i bez zmiany powiększenia)">✥ Przesuw</button><button data-v3z="1" title="Powiększ">+</button><button data-v3z="-1" title="Pomniejsz">−</button><button data-v3r="1" title="Widok domyślny">⌂</button></div><canvas class="v3d" width="${Math.round(W)}" height="${Math.round(Math.min(560, Math.max(320, W * 0.45)))}"></canvas><p class="hint" style="margin:4px 0 0">Lewy przycisk – obrót lub przesuw (wg trybu powyżej) · prawy przycisk albo Shift + przeciągnij – przesuw · Ctrl + kółko lub +/− – powiększenie (w miejscu kursora) · dwa palce – przesuw i powiększenie · dwuklik – widok domyślny. Obrót nie zmienia skali.</p>` : `<div class="tscroll elevwrap">${elevationSVG(W)}</div>`}</div><div class="box hsec" id="hsec"></div></div>`;
  html += `<p style="margin:8px 0 0"><button class="btn sm" id="bAreas" title="Pola przekroju A_s [cm²] dla n prętów ⌀ oraz masa 1 m pręta">Tablica pól przekroju prętów</button></p>`;
  html += endAnchTable();
  html += `<div class="h2" style="margin-top:16px">Wyciągi prętów<small>kształty i wymiary prętów (bez skali) – długości osiowe [mm], φ<sub>m</sub> – średnica trzpienia gięcia; haki strzemion ${[...new Set(R.md.segs.map(sg => (sg.stir || S.stir).hookA === 90 ? 90 : 135))].map(a => a + '°').join(' / ')} (minimum wg rys. 8.5: 135° – max(5⌀; 50 mm), 90° – max(10⌀; 70 mm); automatycznie max(10⌀; 70 mm)); kliknij pręt lub strzemię, aby zmienić średnicę i wymiary</small></div><div class="box"><div class="tscroll">${extractsSVG(sc, Math.max(600, Math.min(1400, el.clientWidth - 40)))}</div></div>`;
  html += `<div class="h2" style="margin-top:16px">Zestawienie stali zbrojeniowej<small>orientacyjne – długości osiowe z odgięciami i hakami; belka długości ${fmt(sc.Lb / 1000, 2)} m</small></div>${scheduleTable(sc)}`;
  html += anchTable();
  el.innerHTML = html;
  bindElev(el);
  zoomApply(el);
  $$('[data-v3]', el).forEach(b => b.addEventListener('click', () => { view3d = b.dataset.v3 === '3d'; rendered.elev = false; renderElevation(el); }));
  const cv = $('canvas.v3d', el); if (cv) draw3D(cv, sc);
  const bd = $('#bDxf', el); if (bd) bd.onclick = exportDXF;
  $$('.xbar', el).forEach(g => g.addEventListener('click', () => barPopup(g.dataset.key)));
  $$('.xstir', el).forEach(g => g.addEventListener('click', () => hookPopup(g.dataset.segs.split(',').filter(Boolean).map(Number))));
  $$('.stzone', el).forEach(g => g.addEventListener('click', ev => { ev.stopPropagation(); stirZonePopup(+g.dataset.seg, +g.dataset.s, +g.dataset.len); }));
  $$('.lapdim', el).forEach(g => g.addEventListener('click', ev => { ev.stopPropagation(); lapPopup(g.dataset.lk, +g.dataset.lc, +g.dataset.ll, +g.dataset.lr); }));
  $$('.anchdim', el).forEach(g => g.addEventListener('click', ev => { ev.stopPropagation(); anchLenPopup(g.dataset.ak); }));
  const bt = $('#bAreas', el); if (bt) bt.onclick = areasPopup;
  const br = $('#bReset', el); if (br) br.onclick = () => { S.barEdit = {}; changed(true); };
}
// okno wymiarów pręta: odcinek prosty, odgięcia na końcach (długość, kierunek); długość rozwinięta ≤ L_max
// przedłużenie (+) / skrócenie (−) końca pręta [mm]: pręty dodatkowe nad podporą belki ciągłej (strona z przęsłem) – Δ od długości wymaganej
// (cont.rebSupps[i].extL/extR [m]); pozostałe – Δ położenia końca (barEdit[key].dL/dR)
function extSide(key, sd) { const sp = /^x\d+$/.test(key) && CONT(S) && R && R.md ? R.md.sups[+key.slice(1)] : null; return sp && (sd === 'L' ? sp.segL !== null : sp.segR !== null) ? sp : null; }
function getEndDelta(key, sd) {
  const sp = extSide(key, sd); if (sp) { const z = (S.cont.rebSupps || [])[sp.idx] || {}, v = z['ext' + sd]; return v !== '' && v !== undefined && isFinite(+v) ? Math.round(+v * 1000) : 0; }
  const e = (S.barEdit || {})[key] || {}; return +e['d' + sd] || 0;
}
function setEndDelta(key, sd, mm) {
  mm = Math.round(+mm || 0); const sp = extSide(key, sd);
  if (sp) { const z = S.cont.rebSupps[sp.idx] = S.cont.rebSupps[sp.idx] || Object.assign(E.zoneOf([]), { lenL: '', lenR: '' }); z['ext' + sd] = mm ? String(mm / 1000) : ''; if (mm) z['len' + sd] = ''; return; }
  S.barEdit = S.barEdit || {}; const o = Object.assign({ len: '', legL: '', legR: '', dirL: '', dirR: '' }, S.barEdit[key] || {}); o['d' + sd] = mm || '';
  if (o.len === '' && o.legL === '' && o.legR === '' && !o.lapC && !o.dL && !o.dR) delete S.barEdit[key]; else S.barEdit[key] = o;
}
// odniesienie długości końca pręta: lico podpory (zakotwienie w podporze skrajnej / za licem podpory pośredniej) albo oś podpory (pręty dodatkowe)
function endRef(key, sd, xEnd) {
  const md = R && R.md; if (!md) return null;
  if (/^x\d+$/.test(key)) { const p = md.sups[+key.slice(1)]; if (!p) return null; if (extSide(key, sd)) { const tc = (R.anch.topCut || []).find(q => q.sup === p), si = tc ? tc.sides.find(q => q.side === sd) : null; return { x: p.x, nm: `długość od osi podpory ${p.label}`, req: si ? fmt(si.lenReq, 0) + ' mm' : '' }; } }
  // najbliższa podpora, której lico pręt przekracza: odległość końca od lica (po stronie podpory)
  let best = null; md.sups.forEach(p => { const f = sd === 'L' ? p.x + p.t / 2 : p.x - p.t / 2, ins = sd === 'L' ? xEnd <= f + 1 : xEnd >= f - 1, dd = Math.abs(xEnd - p.x);
    if (ins && dd <= p.t / 2 + 3000 && (!best || dd < best.dd)) best = { p, f, dd }; });
  if (!best) return null; const p = best.p;
  if (p.end) { const a = (R.anch.ends || []).find(q => q.e.sup === p); return { x: best.f, nm: `długość zakotwienia w podporze ${p.label} (od lica)`, req: a && key[0] === 'b' ? `l<sub>bd</sub> = ${fmt(a.bent ? a.lbdHook : a.lbd, 0)} mm${a.bent ? ' z odgięciem' : ''}` : '' }; }
  const ia = (R.anch.inner || []).find(q => q.sup === p);
  return { x: best.f, nm: `długość za licem podpory ${p.label}`, req: key[0] === 'b' && ia ? (S.anch.innerB === 'anch' ? `≥ 10⌀ = ${fmt(ia.l, 0)} mm` : 'zakład l₀ z prętami drugiego przęsła') : '' };
}
function barPopup(key, focusEnd) {
  const sc = E.steelSchedule(R), rs = sc.rows.filter(r => r.key === key); if (!rs.length) return;
  const r0 = rs.find(r => !r.npc || r.piece === 0) || rs[0], rN = rs.find(r => !r.npc || r.piece === r.npc - 1) || rs[rs.length - 1];
  const x0 = Math.min(...rs.map(r => r.x0)), x1 = Math.max(...rs.map(r => r.x1)), dmax = Math.max(...rs.map(r => r.d));
  const Lmax = S.anch.Lmax > 0 ? S.anch.Lmax * 1000 : Infinity;
  const e0 = (S.barEdit || {})[key] || {};
  const W = { len: e0.len > 0 ? e0.len : '', mL: e0.legL === '' || e0.legL === undefined ? 'auto' : (+e0.legL > 0 ? 'bend' : 'none'), mR: e0.legR === '' || e0.legR === undefined ? 'auto' : (+e0.legR > 0 ? 'bend' : 'none'),
    legL: e0.legL > 0 ? e0.legL : (r0.legL || 10 * dmax), legR: e0.legR > 0 ? e0.legR : (rN.legR || 10 * dmax), dirL: e0.dirL || r0.dirL || (r0.side === 'bot' ? 'up' : 'down'), dirR: e0.dirR || rN.dirR || (r0.side === 'bot' ? 'up' : 'down') };
  const nm = r0.name.replace(/, warstwa.*$/, '').replace(/, odcinek.*$/, '');
  const m = $('#modal'), split = rs.some(r => r.npc > 1), lapA = (sc.laps || []).find(l => l.key === key || (key[0] === 'b' && l.seg === +key.slice(1) && l.side !== 'top') || (key === 't' && l.side === 'top'));
  const ded = rr => 2 * (rr + dmax) - Math.PI * (rr + dmax / 2) / 2;
  const legNow = sd => sd === 'L' ? (W.mL === 'auto' ? r0.legL : W.mL === 'bend' ? W.legL : 0) : (W.mR === 'auto' ? rN.legR : W.mR === 'bend' ? W.legR : 0);
  const devLen = () => { const Ls = W.len > 0 ? W.len : x1 - x0, rr = E.mandrelMin(dmax) / 2; return Math.round(Ls + [legNow('L'), legNow('R')].reduce((a, lg) => a + (lg > 0 ? lg - ded(rr) : 0), 0)); };
  const dOld = {}; rs.forEach(r => { const k = r.layer + '|' + r.d; if (!(k in dOld)) dOld[k] = r.d; }); const dNew = Object.assign({}, dOld);
  // przedłużenie (+) / skrócenie (−) końca pręta o Δ [mm] – każdy pręt (koniec prosty lub odgięty); pręty dodatkowe nad podporą pośrednią – od długości wymaganej
  const W2 = { dL: getEndDelta(key, 'L'), dR: getEndDelta(key, 'R') };
  const endInfo = sd => { const ri = sd === 'L' ? r0 : rN, xa = sd === 'L' ? ri.x0 : ri.x1, xA = sd === 'L' ? ri.autoX0 : ri.autoX1, sp = endRef(key, sd, xa);
    const dl = W2['d' + sd] || 0, lenNow = sp ? Math.abs(xa - sp.x) : null, lenAuto = sp && xA !== undefined ? Math.abs(xA - sp.x) : null;
    return sp && lenAuto !== null ? `${esc(sp.nm)}: automatycznie ${fmt(lenAuto, 0)} mm${sp.req ? ` (wymagane ${sp.req})` : ''} → po zmianie ≈ <b data-bdxv="${sd}">${fmt(Math.max(0, lenAuto + dl), 0)}</b> mm${dl !== (sd === 'L' ? getEndDelta(key, 'L') : getEndDelta(key, 'R')) ? '' : (lenNow !== null && Math.abs(lenNow - lenAuto - dl) > 2 ? ` (ograniczone obrysem belki: ${fmt(lenNow, 0)} mm)` : '')}.` : `koniec pręta x = ${fmt(xa / 1000, 3)} m.`; };
  const dxHTML = sd => `<div class="zg"><span>przedłużenie (+) / skrócenie (−) o</span><input class="txt" data-bdx="${sd}" value="${W2['d' + sd] ? W2['d' + sd] : ''}" placeholder="0" inputmode="decimal" spellcheck="false" autocomplete="off"><span>mm</span></div><p class="hint keep" data-bdxi="${sd}">${endInfo(sd)}</p>`;
  const endHTML = sd => { if (focusEnd && focusEnd !== sd) return ''; const mode = W['m' + sd]; return `<div class="zl ${focusEnd === sd ? 'focus' : ''}"><h5>Koniec ${sd === 'L' ? 'lewy' : 'prawy'}</h5><div class="zg"><select data-bm="${sd}"><option value="auto" ${mode === 'auto' ? 'selected' : ''}>automatycznie (wg zakotwienia)</option><option value="none" ${mode === 'none' ? 'selected' : ''}>pręt prosty</option><option value="bend" ${mode === 'bend' ? 'selected' : ''}>odgięcie o długości…</option></select>` +
    (mode === 'bend' ? `<input class="txt" data-bl="${sd}" value="${esc(showNum(W['leg' + sd]))}" spellcheck="false" autocomplete="off"><span>mm</span><select data-bd="${sd}"><option value="up" ${W['dir' + sd] === 'up' ? 'selected' : ''}>do góry</option><option value="down" ${W['dir' + sd] === 'down' ? 'selected' : ''}>w dół</option></select>` : `<span class="hint">obecnie: ${sd === 'L' ? (r0.legL ? `odgięcie ${r0.legL} mm` : 'prosty') : (rN.legR ? `odgięcie ${rN.legR} mm` : 'prosty')}</span>`) + `</div>${dxHTML(sd)}</div>`; };
  const draw = () => {
    const dl = devLen(), over = dl > Lmax + 1;
    m.innerHTML = `<div class="dlg barpop"><h3>${focusEnd ? `Zakończenie pręta – ${esc(nm)}, koniec ${focusEnd === 'L' ? 'lewy' : 'prawy'}` : `Wymiary pręta – ${esc(nm)}`}</h3>
      <p class="hint">Pozycje: ${rs.map(r => `${r.pos} (${r.n}⌀${r.d})`).join(', ')}${split ? ' · pręt dzielony zakładem na odcinki' : ''}. Wymiary osiowe, odgięcia – wymiar zewnętrzny od osi pręta podłużnego.</p>
      ${focusEnd ? '' : `<div class="zl"><h5>Średnica</h5>${Object.keys(dOld).map(k => `<div class="zg"><span>warstwa ${+k.split('|')[0] + 1}: ${rs.find(r => r.layer + '|' + r.d === k).n} ×</span><select data-bdia="${k}">${E.BAR_DIAS.filter(dd => dd >= 8).map(dd => `<option value="${dd}" ${dd === dNew[k] ? 'selected' : ''}>⌀${dd}</option>`).join('')}</select></div>`).join('')}<p class="hint">Zmiana średnicy zmienia zbrojenie strefy (przelicza nośność, zakotwienie i rozstaw prętów).</p></div>
      <div class="zl"><h5>Odcinek prosty</h5><div class="zg"><span>długość osiowa</span><input class="txt" id="bLen" value="${esc(showNum(W.len))}" placeholder="auto ${fmt(x1 - x0, 0)}" spellcheck="false" autocomplete="off"><span>mm</span><span class="hint">puste – automatycznie (wymagana); Enter – zastosuj</span></div></div>`}
      ${endHTML('L')}${endHTML('R')}
      ${!focusEnd && (split || e0.lapC) ? `<div class="zl"><h5>Zakład pręta</h5><div class="zg"><span>środek zakładu x</span><input class="txt" id="bLapC" value="${esc(showNum(e0.lapC || ''))}" placeholder="auto ${lapA ? fmt(lapA.c / 1000, 2) : '–'}" spellcheck="false" autocomplete="off"><span>m od lewego końca belki</span></div><div class="zg"><span>długość zakładu l₀</span><input class="txt" id="bLapL" value="${esc(showNum(e0.lapL || ''))}" placeholder="auto ${lapA ? fmt(lapA.l0req || lapA.l0, 0) : '–'}" spellcheck="false" autocomplete="off"><span>mm (≥ wymagane – sprawdzane)</span></div></div>` : ''}
      <div class="${over ? 'iss' : 'okm'}" id="bInfo">${over ? `✖ Długość rozwinięta ${fmt(dl, 0)} mm > L<sub>max</sub> = ${fmt(Lmax, 0)} mm – pręt trzeba podzielić zakładem albo skrócić.` : `✔ Długość rozwinięta (prosty + odgięcia − odliczenia na gięcie) ≈ ${fmt(dl, 0)} mm ≤ L<sub>max</sub> = ${isFinite(Lmax) ? fmt(Lmax, 0) + ' mm' : 'bez ograniczeń'}`}</div>
      <p class="hint">Gięcie na trzpieniu φ<sub>m</sub> = ${fmt(E.mandrelMin(dmax), 0)} mm (tab. 8.1N). Zakotwienie z ręcznymi wymiarami jest sprawdzane w Podsumowaniu (odgięcie ≥ wymagane, zakład nad podporą ≥ l<sub>0</sub>).</p>
      <div class="dbtn"><button class="btn" id="bRst">Przywróć automatyczne</button><button class="btn" id="bCancel">Anuluj</button>${over ? '<button class="btn" id="bSplit">Zastosuj – podziel zakładem</button>' : ''}<button class="btn pri" id="bOk" ${over ? 'disabled' : ''}>Zastosuj</button></div></div>`;
    m.style.display = 'flex';
    $$('[data-bm]', m).forEach(el => el.onchange = () => { W['m' + el.dataset.bm] = el.value; draw(); });
    $$('[data-bd]', m).forEach(el => el.onchange = () => { W['dir' + el.dataset.bd] = el.value; });
    const upd = () => { const dl2 = devLen(), ov = dl2 > Lmax + 1, bi = $('#bInfo', m); bi.className = ov ? 'iss' : 'okm'; bi.innerHTML = ov ? `✖ Długość rozwinięta ${fmt(dl2, 0)} mm > L<sub>max</sub> = ${fmt(Lmax, 0)} mm – pręt trzeba podzielić zakładem albo skrócić.` : `✔ Długość rozwinięta ≈ ${fmt(dl2, 0)} mm ≤ L<sub>max</sub>`; $('#bOk', m).disabled = ov; if (ov !== over) draw(); };
    $$('[data-bl]', m).forEach(el => el.addEventListener('input', () => { const v = parseNum(el.value), bad = v === null || v < 5 * dmax; el.classList.toggle('bad', bad); if (!bad) { W['leg' + el.dataset.bl] = Math.round(v); upd(); } }));
    $$('[data-bdia]', m).forEach(el => el.onchange = () => { dNew[el.dataset.bdia] = +el.value; });
    $$('input', m).forEach(el => el.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); const b = $('#bOk', m); if (b && !b.disabled) b.click(); else { const sp = $('#bSplit', m); if (sp) sp.click(); } } }));
    $$('[data-bdx]', m).forEach(el => el.addEventListener('input', () => { const t = el.value.trim(), v = t === '' ? 0 : parseNum(t), sd = el.dataset.bdx, bad = v === null || Math.abs(v) > 20000; el.classList.toggle('bad', bad);
      if (bad) return; W2['d' + sd] = Math.round(v); const out = $(`[data-bdxi="${sd}"]`, m); if (out) out.innerHTML = endInfo(sd); }));
    const li = $('#bLen', m); if (li) li.addEventListener('input', () => { const raw = li.value.trim(), v = parseNum(raw), bad = raw !== '' && (v === null || v < 300); li.classList.toggle('bad', bad); if (!bad) { W.len = raw === '' ? '' : Math.round(v); upd(); } });
    const close = () => { m.style.display = 'none'; };
    $('#bCancel', m).onclick = close;
    $('#bRst', m).onclick = () => { if (S.barEdit) delete S.barEdit[key]; setEndDelta(key, 'L', 0); setEndDelta(key, 'R', 0); close(); changed(true); };
    const apply = () => {
      const o = { len: W.len, legL: W.mL === 'auto' ? '' : W.mL === 'none' ? 0 : W.legL, legR: W.mR === 'auto' ? '' : W.mR === 'none' ? 0 : W.legR, dirL: W.mL === 'bend' ? W.dirL : '', dirR: W.mR === 'bend' ? W.dirR : '' };
      S.barEdit = S.barEdit || {};
      const lc = $('#bLapC', m), ll = $('#bLapL', m);
      if (lc) { const v = parseNum(lc.value), w = parseNum(ll.value); o.lapC = v > 0 ? v : ''; o.lapL = w > 0 ? w : ''; } else if (e0.lapC) { o.lapC = e0.lapC; o.lapL = e0.lapL; }
      o.dL = e0.dL || ''; o.dR = e0.dR || '';
      if (o.len === '' && o.legL === '' && o.legR === '' && !o.lapC && !o.dL && !o.dR) delete S.barEdit[key]; else S.barEdit[key] = o;
      let bad = false; $$('[data-bdx]', m).forEach(el => { const t = el.value.trim(), v = t === '' ? 0 : parseNum(t); if (v === null || Math.abs(v) > 20000) { bad = true; el.classList.add('bad'); return; } setEndDelta(key, el.dataset.bdx, Math.round(v)); });
      if (bad) return;
      // zmiana średnicy – w strefie zbrojenia (warstwa, grupa prętów o danej średnicy)
      const chg = Object.keys(dOld).filter(k => dNew[k] !== dOld[k]);
      if (chg.length) { const zid = key, z0 = zoneGet(zid); if (z0) { const Wz = materialize(zid, z0); chg.forEach(k => { const [ly, d0] = k.split('|').map(Number), L = Wz.layers[ly]; if (!L) return; const gq = L.bars.find(b => b.d === d0) || L.bars[0]; if (gq) gq.d = dNew[k]; }); setP(S, zonePath(zid), E.normZone(JSON.parse(JSON.stringify(Wz)), E.zoneOf([]))); } }
      close(); changed(true);
    };
    $('#bOk', m).onclick = apply; const bs = $('#bSplit', m); if (bs) bs.onclick = apply;
  };
  draw();
}
// wymiar zakotwienia / długości pręta kliknięty na rysunku „Zbrojenie belki”: długość wpisana ręcznie (od lica podpory albo od osi – pręty
// dodatkowe nad podporą); zapisywana jako przedłużenie (+) / skrócenie (−) względem długości automatycznej; sprawdzenia w Podsumowaniu
function anchLenPopup(ak) {
  const md = R && R.md; if (!md) return;
  const sc = E.steelSchedule(R), rows = sc.rows, items = [], k = ak[0], i = parseInt(ak.slice(1), 10), p = md.sups[i]; if (!p) return;
  const add = (key, sd, label) => { const rs = rows.filter(r => r.key === key && !r.cut); if (!rs.length) return;
    const r = sd === 'L' ? (rs.find(q => !q.npc || q.piece === 0) || rs[0]) : (rs.find(q => !q.npc || q.piece === q.npc - 1) || rs[rs.length - 1]);
    const x = sd === 'L' ? r.x0 : r.x1, xa = sd === 'L' ? r.autoX0 : r.autoX1, ref = endRef(key, sd, x); if (!ref || xa === undefined) return;
    const dl = getEndDelta(key, sd), auto = Math.round(Math.abs(xa - ref.x));
    items.push({ key, sd, label: `${label} – ${rs[0].n}⌀${r.d}`, ref, cur: Math.round(Math.abs(x - ref.x)), auto, dl }); };
  let title = '';
  if (k === 'e') { const left = p.segL === null, sg = md.segs[left ? p.segR : p.segL], sd = left ? 'L' : 'R'; title = `Zakotwienie prętów w podporze ${p.label}`;
    if (sg) add('b' + sg.idx, sd, 'pręty dolne'); add('t', sd, 'pręty górne ciągłe'); if (rows.some(r => r.key === 'x' + p.idx)) add('x' + p.idx, sd, 'pręty górne dodatkowe'); }
  else if (k === 'i') { title = `Pręty dolne nad podporą ${p.label}`; add('b' + p.segL, 'R', `${md.segs[p.segL].label} (z lewej)`); add('b' + p.segR, 'L', `${md.segs[p.segR].label} (z prawej)`); }
  else if (k === 'x') { const sd = ak.slice(-1); title = `Pręty górne dodatkowe – ${p.label}`; add('x' + p.idx, sd, sd === 'L' ? 'w lewo od osi' : 'w prawo od osi'); }
  if (!items.length) return;
  const m = $('#modal');
  m.innerHTML = `<div class="dlg barpop"><h3>${esc(title)}</h3>
    ${items.map((q, j) => `<div class="zl"><h5>${esc(q.label)}</h5><div class="zg"><span>${q.ref.nm}</span><input class="txt" data-al="${j}" value="${q.dl ? q.cur : ''}" placeholder="auto ${q.auto}" inputmode="decimal" spellcheck="false" autocomplete="off"><span>mm</span></div>
      <p class="hint keep">Automatycznie ${q.auto} mm${q.ref.req ? `, wymagane ${q.ref.req}` : ''}${q.dl ? `; obecnie ${q.cur} mm (${q.dl > 0 ? 'przedłużone' : 'skrócone'} ręcznie o ${Math.abs(q.dl)} mm)` : ''}. Puste pole – długość automatyczna.</p></div>`).join('')}
    <p class="hint keep">Długość mniejsza od wymaganej jest zaznaczana w Podsumowaniu (zakotwienie, zakład, długość prętów dodatkowych); pręt nie wychodzi poza obrys belki (otulina czoła). Zmiana obowiązuje do następnego „Dobierz zbrojenie”.</p>
    <div class="iss" id="alErr" style="display:none">Podaj długość od 0 do 20 000 mm.</div>
    <div class="dbtn"><button class="btn" id="alAuto">Automatycznie</button><span class="sp"></span><button class="btn" id="alCancel">Anuluj</button><button class="btn pri" id="alOk">Zastosuj</button></div></div>`;
  m.style.display = 'flex';
  $('#alCancel', m).onclick = () => { m.style.display = 'none'; };
  $('#alAuto', m).onclick = () => { items.forEach(q => setEndDelta(q.key, q.sd, 0)); m.style.display = 'none'; changed(true); };
  $('#alOk', m).onclick = () => {
    const vals = items.map((q, j) => { const t = $(`[data-al="${j}"]`, m).value.trim(); if (t === '') return null; const v = parseNum(t); return v === null ? NaN : v; });
    if (vals.some(v => v !== null && (isNaN(v) || v < 0 || v > 20000))) { $('#alErr', m).style.display = ''; return; }
    items.forEach((q, j) => setEndDelta(q.key, q.sd, vals[j] === null ? 0 : Math.round(vals[j] - q.auto)));
    m.style.display = 'none'; changed(true);
  };
  $$('input', m).forEach(el => el.addEventListener('keydown', ev => { if (ev.key === 'Enter') $('#alOk', m).click(); }));
  setTimeout(() => { const f = $('[data-al="0"]', m); if (f) f.focus(); }, 30);
}
// okno haków strzemion (135°): długość prostego zakończenia, min. max(5⌀; 50 mm) wg rys. 8.5
// tablica pól przekroju prętów zbrojeniowych (A = n·π⌀²/4) i masy (7850 kg/m³)
function areasPopup() {
  const D = [6, 8, 10, 12, 14, 16, 20, 25, 28, 32, 40], N = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  const a = d => Math.PI * d * d / 4;
  const m = $('#modal');
  m.innerHTML = `<div class="dlg areas"><h3>Pola przekroju prętów zbrojeniowych A<sub>s</sub> [cm²]</h3><div class="tscroll"><table class="sched atab"><tr><th>⌀ [mm]</th>${N.map(n => `<th>${n}</th>`).join('')}<th>masa [kg/m]</th><th>obwód [mm]</th></tr>${D.map(d => `<tr class="${[14, 18, 22].includes(d) || d >= 32 ? 'rare' : ''}"><td><b>⌀${d}</b></td>${N.map(n => `<td class="n">${fmt(n * a(d) / 100, 2)}</td>`).join('')}<td class="n">${fmt(a(d) * 7.85e-3, 3)}</td><td class="n">${fmt(Math.PI * d, 1)}</td></tr>`).join('')}</table></div>
    <p class="hint">A<sub>s</sub> = n·π·⌀²/4; masa = A·ρ, ρ = 7850 kg/m³. Wiersze przyciemnione – średnice rzadziej stosowane (⌀14, ⌀32, ⌀40; ⌀18 i ⌀22 nie są pokazywane). Dla strzemion n-ciętych: A<sub>sw</sub> = n·π·⌀<sub>w</sub>²/4 (np. ⌀8 2-cięte: 1,01 cm²).</p>
    <div class="dbtn"><button class="btn pri" id="aClose">Zamknij</button></div></div>`;
  m.style.display = 'flex'; $('#aClose', m).onclick = () => { m.style.display = 'none'; };
}
document.addEventListener('click', e => { if (e.target.closest && e.target.closest('[data-areas]')) areasPopup(); });
// zakład kliknięty w widoku podłużnym: położenie środka i długość (≥ l₀ wymagane – sprawdzane)
function lapPopup(key, c, l0, l0req) {
  const m = $('#modal'), e0 = (S.barEdit || {})[key] || {}, L = R.md.Ltot;
  m.innerHTML = `<div class="dlg barpop"><h3>Zakład prętów</h3>
    <div class="zl"><div class="zg"><span>Środek zakładu x</span><input class="txt" id="lpC" value="${esc(showNum(e0.lapC || ''))}" placeholder="auto ${fmt(c / 1000, 2)}" spellcheck="false" autocomplete="off"><span>m od lewego końca belki (0 – ${fmt(L / 1000, 2)})</span></div>
    <div class="zg"><span>Długość zakładu l₀</span><input class="txt" id="lpL" value="${esc(showNum(e0.lapL || ''))}" placeholder="auto ${fmt(l0req, 0)}" spellcheck="false" autocomplete="off"><span>mm (wymagane l₀ = ${fmt(l0req, 0)} mm, 8.7.3)</span></div></div>
    <div class="hint">Obecnie: środek x = ${fmt(c / 1000, 2)} m, l₀ = ${fmt(l0, 0)} mm. Puste pola – położenie i długość automatycznie (zakład w miejscu najmniejszego wytężenia prętów). Długość mniejsza od wymaganej jest zaznaczana w Podsumowaniu; odcinki prętów nie mogą przekroczyć L<sub>max</sub> = ${fmt(S.anch.Lmax || 12, 1)} m.</div>
    <div class="iss" id="lpErr" style="display:none"></div>
    <div class="dbtn"><button class="btn" id="lpAuto">Automatycznie</button><span class="sp"></span><button class="btn" id="lpCancel">Anuluj</button><button class="btn pri" id="lpOk">Zastosuj</button></div></div>`;
  m.style.display = 'flex';
  const fC = $('#lpC', m), fL = $('#lpL', m), er = $('#lpErr', m);
  const chk = () => { const v = fC.value.trim() === '' ? null : parseNum(fC.value), w = fL.value.trim() === '' ? null : parseNum(fL.value);
    const bad = (fC.value.trim() !== '' && (v === null || v <= 0 || v * 1000 >= L)) || (fL.value.trim() !== '' && (w === null || w < 100));
    er.style.display = bad ? '' : 'none'; er.textContent = bad ? 'Podaj x w granicach belki i długość ≥ 100 mm.' : (w !== null && w < l0req ? '' : ''); return !bad; };
  fC.addEventListener('input', chk); fL.addEventListener('input', chk);
  const save = (lc, ll) => { S.barEdit = S.barEdit || {}; const o = Object.assign({ len: '', legL: '', legR: '', dirL: '', dirR: '' }, S.barEdit[key] || {}); o.lapC = lc; o.lapL = ll;
    if (o.len === '' && o.legL === '' && o.legR === '' && !o.lapC && !o.dL && !o.dR) delete S.barEdit[key]; else S.barEdit[key] = o; m.style.display = 'none'; changed(true); };
  $('#lpCancel', m).onclick = () => { m.style.display = 'none'; };
  $('#lpAuto', m).onclick = () => save('', '');
  $('#lpOk', m).onclick = () => { if (!chk()) return; const v = parseNum(fC.value), w = parseNum(fL.value); save(v > 0 ? v : (w > 0 ? +(c / 1000).toFixed(3) : ''), w > 0 ? w : ''); };
  $$('input', m).forEach(i => i.addEventListener('keydown', ev => { if (ev.key === 'Enter') $('#lpOk', m).click(); }));
  setTimeout(() => { fC.focus(); }, 30);
}
// strefa strzemion kliknięta w widoku podłużnym: rozstaw w strefie (≤ s_l,max), długość strefy od lica, liczba stref (auto / 1 / 2 / 3)
// długość stref zagęszczenia strzemion przy podporze – z wykresu V w Danych (przeciąganie uchwytu lub okno)
const zAuto1 = e => (e.l1req > 0 ? Math.min(Math.ceil(e.l1req / 50 - 1e-9) * 50, e.avail) : 0);
function setZoneLen(e, k, mm) {
  S.stir.zl = S.stir.zl && typeof S.stir.zl === 'object' ? S.stir.zl : {};
  const o = S.stir.zl[e.zkey] = Object.assign({}, S.stir.zl[e.zkey]);
  if (mm === null) delete o[k]; else o[k] = String(Math.round(mm) / 1000);
  if (!Object.keys(o).length) delete S.stir.zl[e.zkey];
}
function bindZoneEdit(el) {
  const svg = $('.schemewrap svg', el), mp = svg && $('g.zmap', svg);
  if (svg) $$('.cmbhit', svg).forEach(r => r.addEventListener('click', ev => { ev.stopPropagation(); camberPopup(+r.dataset.seg); }));
  if (svg) $$('.dsel', svg).forEach(t => t.addEventListener('click', ev => { ev.stopPropagation(); dselPopup(t.dataset.dz); }));
  if (!mp) return;
  const xa = +mp.dataset.xa, xk = +mp.dataset.xk;
  const xOf = ev => { const r = svg.getBoundingClientRect(), vb = svg.viewBox.baseVal; return ((ev.clientX - r.left) * vb.width / r.width - xa) / xk; };
  $$('.zclick', svg).forEach(r => r.addEventListener('click', ev => { ev.stopPropagation(); zoneLenPopup(+r.dataset.end); }));
  $$('.zh', svg).forEach(g => {
    g.addEventListener('click', ev => ev.stopPropagation());
    g.addEventListener('pointerdown', ev => {
      ev.preventDefault(); ev.stopPropagation();
      const e = R.sh.ends[+g.dataset.end], k = g.dataset.k; if (!e) return;
      const face = e.x + e.dir * e.sup.t / 2, base = k === 'lp' ? e.l1 : 0, max = Math.max(0, e.avail - base), x0 = ev.clientX;
      let len = k === 'lp' ? e.lp : e.l1, moved = false;
      const ns = 'http://www.w3.org/2000/svg', tip = document.createElementNS(ns, 'text'); tip.setAttribute('font-size', '11'); tip.setAttribute('font-weight', '700'); tip.setAttribute('text-anchor', 'middle'); tip.style.fill = '#a35d00'; svg.appendChild(tip);
      const bb = g.getBBox(); tip.setAttribute('y', (bb.y - 4).toFixed(1));
      g.setPointerCapture(ev.pointerId);
      const move = mv => { if (Math.abs(mv.clientX - x0) > 3) moved = true; if (!moved) return;
        len = Math.max(0, Math.min(max, Math.round(((xOf(mv) - face) * e.dir - base) / 50) * 50));          // co 50 mm, w granicach dostępnej długości
        const xh = xa + xk * (face + e.dir * (base + len)); g.setAttribute('transform', `translate(${(xh - (bb.x + bb.width / 2)).toFixed(1)},0)`);
        tip.setAttribute('x', xh.toFixed(1)); tip.textContent = `${k === 'l1' ? 's₁' : 's_p'} ${fmt(len / 1000, 2)} m`; };
      const up = () => { g.removeEventListener('pointermove', move); g.removeEventListener('pointerup', up); g.removeEventListener('pointercancel', up); tip.remove();
        if (!moved) { zoneLenPopup(+g.dataset.end); return; }
        setZoneLen(e, k, len); changed(true); };
      g.addEventListener('pointermove', move); g.addEventListener('pointerup', up); g.addEventListener('pointercancel', up);
    });
  });
}
function zoneLenPopup(i) {
  const e = R.sh.ends[i]; if (!e) return;
  const zo = (S.stir.zl || {})[e.zkey] || {}, m = $('#modal'), a1 = zAuto1(e), aP = e.sp ? (e.lpReq > 0 ? Math.min(Math.ceil(e.lpReq / 50 - 1e-9) * 50, Math.max(0, e.avail - e.l1)) : 0) : 0;
  const glob = k => S.stir[k] !== 'auto' && S.stir[k] !== '' && S.stir[k] !== undefined ? +S.stir[k] : null;
  // rozstaw strzemion w przęśle (s₁ przy podporach, s_p, s₂ w części środkowej): ręczny albo automatyczny
  const cont = CONT(S), md = R.md, si = e.seg.si !== undefined ? e.seg.si : (md.segs[e.seg.adj] || {}).si, q = e.stir || e.seg.stir || S.stir;
  const span = cont && si !== undefined ? (S.cont.stirSpans || [])[si] || {} : null;
  const manS = k => { const v = span && span[k] !== '' && span[k] !== undefined && span[k] !== null && +span[k] > 0 ? +span[k] : null; return v !== null ? v : (!S.stir.sAuto && +S.stir[k] > 0 ? +S.stir[k] : null); };
  const sMax = (q.sAutoInfo && q.sAutoInfo.sMax) || (R.sh && R.sh.sMax) || 0, hasP = e.sp > 0 || manS('sp') !== null || String(S.stir.nz) === '3';
  const sInp = (k, lab, cur) => `<div class="zg"><span>${lab}</span><input class="txt" id="zs_${k}" value="${manS(k) !== null ? esc(showNum(manS(k))) : ''}" placeholder="auto ${cur > 0 ? fmt(cur, 0) : '—'}" spellcheck="false" autocomplete="off" inputmode="decimal"><span>mm</span></div>`;
  m.innerHTML = `<div class="dlg barpop"><h3>Strefa zagęszczenia strzemion – ${esc(e.sup.name)}, ${esc(e.seg.label)}</h3>
    <div class="zl"><h5>Rozstaw strzemion${cont ? ` – ${esc((md.segs.find(sg => sg.si === si) || e.seg).label)}` : ''}</h5>${sInp('s1', 'Rozstaw s₁ – strefa przy podporze', q.s1)}${hasP ? sInp('sp', 'Rozstaw s_p – strefa pośrednia', q.sp) : ''}${sInp('s2', 'Rozstaw s₂ – część środkowa', q.s2)}</div>
    <div class="zl"><h5>Długości stref od lica podpory</h5><div class="zg"><span>Długość strefy s₁ (rozstaw ${e.stir.s1} mm) od lica podpory</span><input class="txt" id="zl1" value="${zo.l1 !== undefined ? esc(showNum(+zo.l1)) : ''}" placeholder="${glob('l1') !== null ? 'wspólna ' + fmt(glob('l1'), 2) : 'auto ' + fmt(a1 / 1000, 2)}" spellcheck="false" autocomplete="off" inputmode="decimal"><span>m</span></div>
    ${e.sp ? `<div class="zg"><span>Długość strefy pośredniej s_p (rozstaw ${e.sp} mm)</span><input class="txt" id="zlp" value="${zo.lp !== undefined ? esc(showNum(+zo.lp)) : ''}" placeholder="${glob('lp') !== null ? 'wspólna ' + fmt(glob('lp'), 2) : 'auto ' + fmt(aP / 1000, 2)}" spellcheck="false" autocomplete="off" inputmode="decimal"><span>m</span></div>` : ''}
    <label class="chk sm"><input type="checkbox" id="zlAll"><span>Zastosuj przy wszystkich podporach (długość wspólna)</span></label></div>
    <div class="hint">Rozstaw: puste pole – automatyczny (z V<sub>Ed</sub> i warunków 9.2.2); wartość wpisana obowiązuje w ${cont ? 'tym przęśle (przy obu podporach)' : 'całej belce'}. Maksymalny rozstaw s<sub>l,max</sub> = 0,75·d${sMax ? ` = <b>${fmt(sMax, 0)} mm</b>` : ''} (9.2.2(6)); nośność V<sub>Rd,s</sub> przy wpisanym rozstawie sprawdzana w podsumowaniu. Wymagana długość strefy s₁ – zasięg V<sub>Ed</sub> &gt; V<sub>Rd,s</sub>(${e.sp ? 's_p' : 's₂'}) od lica: <b>${fmt(e.l1req / 1000, 2)} m</b>${e.sp ? `; stref s₁ + s_p: <b>${fmt(e.l12req / 1000, 2)} m</b>` : ''}; dostępna długość: ${fmt(e.avail / 1000, 2)} m. Puste pole – długość automatyczna (wymagana zaokrąglona w górę do 0,05 m). Długość krótsza od wymaganej jest sprawdzana jako warunek 6.2.3 (✖ w podsumowaniu).</div>
    <div class="iss" id="zlErr" style="display:none"></div><div class="hint" id="zlWarn" style="display:none;color:#a35d00"></div>
    <div class="dbtn"><button class="btn" id="zlAuto" title="Rozstaw strzemion (w przęśle) i długości stref przy tej podporze – automatycznie">Automatycznie</button><span class="sp"></span><button class="btn" id="zlCancel">Anuluj</button><button class="btn pri" id="zlOk">Zastosuj</button></div></div>`;
  m.style.display = 'flex';
  const i1 = $('#zl1', m), ip = $('#zlp', m), er = $('#zlErr', m), wr = $('#zlWarn', m);
  const SK = ['s1', 'sp', 's2'].filter(k => $('#zs_' + k, m)), sIn = k => $('#zs_' + k, m);
  const rdS = k => { const t = sIn(k).value.trim(); if (t === '') return { v: null, ok: true }; const v = parseNum(t); return { v, ok: v !== null && v >= 40 && v <= 800 }; };
  const rd = inp => { if (!inp) return { v: null, ok: true }; const t = inp.value.trim(); if (t === '') return { v: null, ok: true }; const v = parseNum(t); return { v, ok: v !== null && v >= 0 && v * 1000 <= e.avail + 1 }; };
  const val = () => { const a = rd(i1), b = rd(ip); i1.classList.toggle('bad', !a.ok); if (ip) ip.classList.toggle('bad', !b.ok);
    const sv = {}; SK.forEach(k => { sv[k] = rdS(k); sIn(k).classList.toggle('bad', !sv[k].ok); });
    const okS = SK.every(k => sv[k].ok), ok = a.ok && b.ok && okS; er.style.display = ok ? 'none' : '';
    er.textContent = ok ? '' : [!(a.ok && b.ok) ? `Długość od 0 do ${fmt(e.avail / 1000, 2)} m (do końca obszaru tej podpory).` : '', !okS ? 'Rozstaw strzemion od 40 do 800 mm.' : ''].filter(Boolean).join(' ');
    const w = [];
    SK.forEach(k => { if (sv[k].ok && sv[k].v !== null && sMax && sv[k].v > sMax + 0.5) w.push(`rozstaw ${k === 's1' ? 's₁' : k === 'sp' ? 's_p' : 's₂'} > s_l,max = ${fmt(sMax, 0)} mm`); });
    if (sv.s1 && sv.s2 && sv.s1.v !== null && sv.s2.v !== null && sv.s1.v > sv.s2.v) w.push('s₁ większy od s₂'); if (a.ok && a.v !== null && a.v * 1000 < e.l1req - 1) w.push(`strefa s₁ krótsza od wymaganej (${fmt(e.l1req / 1000, 2)} m)`); if (e.sp && a.ok && b.ok && (a.v !== null || b.v !== null)) { const L12 = (a.v !== null ? a.v * 1000 : e.l1) + (b.v !== null ? b.v * 1000 : e.lp); if (L12 < e.l12req - 1) w.push(`strefy s₁ + s_p krótsze od wymaganych (${fmt(e.l12req / 1000, 2)} m)`); }
    wr.style.display = w.length ? '' : 'none'; wr.textContent = w.length ? '⚠ ' + w.join('; ') + ' – warunek nie będzie spełniony.' : ''; return ok; };
  [i1, ip, ...SK.map(sIn)].forEach(q => q && q.addEventListener('input', val)); val(); (SK.length ? sIn('s1') : i1).focus();
  // zapis rozstawu: belka ciągła – w przęśle (cont.stirSpans), inaczej – wspólny (przy pierwszym wpisie przejmuje rozstawy automatyczne)
  const applyS = () => { const sv = {}; SK.forEach(k => { sv[k] = rdS(k).v; });
    if (span) { S.cont.stirSpans = S.cont.stirSpans || []; const o = S.cont.stirSpans[si] = Object.assign({}, S.cont.stirSpans[si] || {}); SK.forEach(k => { o[k] = sv[k] === null ? '' : sv[k]; }); }
    else if (SK.some(k => sv[k] !== null)) { if (S.stir.sAuto) { S.stir.s1 = q.s1; S.stir.s2 = q.s2; S.stir.sp = q.sp > 0 ? q.sp : ''; } S.stir.sAuto = false; SK.forEach(k => { if (sv[k] !== null) S.stir[k] = sv[k]; }); }
    else S.stir.sAuto = true;
    if (sv.sp !== null && sv.sp !== undefined && String(S.stir.nz) === 'auto') S.stir.nz = '3'; };
  $('#zlCancel', m).onclick = () => { m.style.display = 'none'; };
  $('#zlAuto', m).onclick = () => { if ($('#zlAll', m).checked) { S.stir.l1 = 'auto'; S.stir.lp = 'auto'; S.stir.zl = {}; } else { setZoneLen(e, 'l1', null); setZoneLen(e, 'lp', null); }
    if (span) { const o = (S.cont.stirSpans || [])[si]; if (o) { o.s1 = ''; o.sp = ''; o.s2 = ''; } } else S.stir.sAuto = true; m.style.display = 'none'; changed(true); };
  $('#zlOk', m).onclick = () => {
    if (!val()) return; const a = rd(i1), b = rd(ip);
    applyS();
    if ($('#zlAll', m).checked) { S.stir.l1 = a.v === null ? 'auto' : String(a.v); if (ip) S.stir.lp = b.v === null ? 'auto' : String(b.v); S.stir.zl = {}; }
    else { setZoneLen(e, 'l1', a.v === null ? null : a.v * 1000); if (ip) setZoneLen(e, 'lp', b.v === null ? null : b.v * 1000); }
    m.style.display = 'none'; changed(true);
  };
  m.querySelectorAll('input.txt').forEach(q => q.addEventListener('keydown', ev => { if (ev.key === 'Enter') $('#zlOk', m).click(); }));
}
function stirZonePopup(segIdx, sCur, lenCur) {
  const md = R.md, sg = md.segs[segIdx]; if (!sg) return;
  const q = sg.stir || S.stir, info = q.sAutoInfo || {}, cont = CONT(S), si = sg.si !== undefined ? sg.si : (md.segs[sg.adj] || {}).si;
  const kind = Math.abs(sCur - q.s1) < 0.5 && q.s1 !== q.s2 ? 's1' : q.sp > 0 && Math.abs(sCur - q.sp) < 0.5 ? 'sp' : 's2';
  const sMax = info.sMax || (R.sh && R.sh.sMax) || 0;
  const KN = { s1: 'przy podporze (s₁)', sp: 'pośrednia (s_p)', s2: 'środkowa (s₂)' };
  const m = $('#modal');
  const lenK = kind === 's1' ? 'l1' : kind === 'sp' ? 'lp' : null, lenV = lenK && S.stir[lenK] !== 'auto' ? S.stir[lenK] : '';
  m.innerHTML = `<div class="dlg barpop"><h3>Strefa strzemion ${KN[kind]}${cont ? ` – ${esc(sg.label)}` : ''}</h3>
    <div class="zl"><div class="zg"><span>Rozstaw s</span><input class="txt" id="zS" value="${esc(showNum(sCur))}" spellcheck="false" autocomplete="off"><span>mm</span></div>
    ${lenK ? `<div class="zg"><span>Długość strefy od lica podpory</span><input class="txt" id="zL" value="${esc(showNum(lenV))}" placeholder="auto ${fmt(lenCur / 1000, 2)}" spellcheck="false" autocomplete="off"><span>m</span></div>` : ''}
    <div class="zg"><span>Liczba stref strzemion</span><select id="zN">${[['auto', 'automatycznie'], ['1', '1 – jeden rozstaw'], ['2', '2 – s₁ i s₂'], ['3', '3 – s₁, s_p i s₂']].map(([v, l]) => `<option value="${v}" ${String(S.stir.nz) === v ? 'selected' : ''}>${l}</option>`).join('')}</select><span></span></div></div>
    <div class="hint">Obecnie: s₁ = ${q.s1}${q.sp > 0 ? `, s_p = ${q.sp}` : ''}, s₂ = ${q.s2} mm${S.stir.sAuto ? ' (rozstaw automatyczny)' : ''}. Maksymalny rozstaw podłużny s<sub>l,max</sub> = 0,75·d${sMax ? ` = <b>${fmt(sMax, 0)} mm</b>` : ''} (9.2.2(6), wzór 9.6N); wymagany przy podporze (V<sub>Ed</sub>): s ≤ ${info.need ? fmt(info.need, 0) : '—'} mm.${lenK ? ' Długość strefy dotyczy wszystkich podpór (puste – automatycznie z obwiedni V).' : ''}${cont ? ' Rozstaw zapisywany dla tego przęsła.' : ''}</div>
    <div class="iss" id="zErr" style="display:none"></div>
    <div class="dbtn"><button class="btn" id="zAuto" title="Rozstawy i długości stref automatycznie">Automatycznie</button><span class="sp"></span><button class="btn" id="zCancel">Anuluj</button><button class="btn pri" id="zOk">Zastosuj</button></div></div>`;
  m.style.display = 'flex';
  const zS = $('#zS', m), zL = $('#zL', m), er = $('#zErr', m);
  const val = () => { const v = parseNum(zS.value), bad = v === null || v < 40 || (sMax && v > sMax + 1e-6); zS.classList.toggle('bad', bad); er.style.display = bad ? '' : 'none'; er.textContent = bad ? (v !== null && sMax && v > sMax ? `Rozstaw przekracza s_l,max = ${fmt(sMax, 0)} mm (9.2.2(6)).` : 'Podaj rozstaw ≥ 40 mm.') : ''; return !bad; };
  zS.addEventListener('input', val); val();
  $('#zCancel', m).onclick = () => { m.style.display = 'none'; };
  $('#zAuto', m).onclick = () => { S.stir.sAuto = true; S.stir.l1 = 'auto'; S.stir.lp = 'auto'; S.stir.zl = {}; if (cont) (S.cont.stirSpans || []).forEach(o => { if (o) { o.s1 = ''; o.sp = ''; o.s2 = ''; } }); m.style.display = 'none'; changed(true); };
  $('#zOk', m).onclick = () => {
    if (!val()) return; const v = parseNum(zS.value);
    S.stir.nz = $('#zN', m).value;
    if (cont && si !== undefined) { setP(S, `cont.stirSpans.${si}.${kind}`, v); if (kind === 'sp' && S.stir.nz === 'auto') S.stir.nz = '3'; }
    else { if (S.stir.sAuto) { S.stir.s1 = q.s1; S.stir.s2 = q.s2; S.stir.sp = q.sp > 0 ? q.sp : ''; } S.stir.sAuto = false; S.stir[kind] = v; if (kind === 'sp' && S.stir.nz === 'auto') S.stir.nz = '3'; }
    if (zL) { const l = zL.value.trim(), nv = l === '' ? 'auto' : String(Math.max(0, parseNum(l) || 0)); if (nv !== S.stir[lenK] || l !== '') { S.stir[lenK] = nv; Object.values(S.stir.zl || {}).forEach(o => delete o[lenK]); } }   // długość wspólna – zastępuje ustawione przy podporach
    m.style.display = 'none'; changed(true);
  };
}
// widok 3D zbrojenia: rzut z obrotem (odchylenie, pochylenie), malowanie od najdalszych; beton półprzezroczysty
let view3d = false; const V3 = { yaw: -0.55, pitch: 0.38, k: 1, px: 0, py: 0, mode: 'rot' };
function draw3D(cv, sc) {
  const md = R.md, cov = R.cov, ctx = cv.getContext('2d'), W = cv.width, H = cv.height, dpr = window.devicePixelRatio || 1;
  cv.style.width = W + 'px'; cv.style.height = H + 'px'; cv.width = W * dpr; cv.height = H * dpr; ctx.scale(dpr, dpr);
  const dark = document.documentElement.dataset.theme === 'dark' || (!document.documentElement.dataset.theme && matchMedia('(prefers-color-scheme: dark)').matches);
  const COLS = { bot: '#1d2a3f', top: '#3b5b8f', topX: '#6a3fb5', mid: '#5d7a2e', stir: '#a04848', bent: '#b5651d' }; if (dark) Object.assign(COLS, { bot: '#c9d4e6', top: '#7fa3e0', topX: '#b597ee', mid: '#a6c76a', stir: '#e08a8a', bent: '#e6a35a' });
  // geometria: x – wzdłuż belki, y – w górę, z – w poprzek (od osi); górna krawędź wspólna (y = hMax) – jak w widoku podłużnym,
  // odcinki o różnej wysokości wystają w dół; belka na całej długości – do zewnętrznych krawędzi podpór skrajnych / końców wsporników
  const hMax = Math.max(...md.segs.map(sg => sg.g.h)), xL = sc && isFinite(sc.xL) ? sc.xL : md.segs[0].x0, xR = sc && isFinite(sc.xR) ? sc.xR : md.segs[md.segs.length - 1].x1;
  const edges = [xL]; md.segs.forEach((sg, i) => { if (i < md.segs.length - 1) edges.push(E.segEdge(md, i)); }); edges.push(xR);
  const segs = md.segs.map((sg, i) => ({ x0: edges[i], x1: edges[i + 1], b: sg.g.bw, h: sg.g.h, bf: sg.g.T ? sg.g.bFlange : sg.g.bw, hf: sg.g.T ? sg.g.hf : 0 }));
  const lines = [];   // [p1, p2, kolor, grubość]
  const polys = [];   // ściany betonu
  const box = (x0, x1, y0, y1, z0, kind) => { const P = (x, y, z) => [x, y, z], c = [P(x0, y0, -z0), P(x1, y0, -z0), P(x1, y1, -z0), P(x0, y1, -z0), P(x0, y0, z0), P(x1, y0, z0), P(x1, y1, z0), P(x0, y1, z0)];
    [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [3, 2, 6, 7], [0, 3, 7, 4], [1, 2, 6, 5]].forEach(f => polys.push({ f: f.map(i => c[i]), kind })); };
  segs.forEach(q => { box(q.x0, q.x1, hMax - q.h, q.hf ? hMax - q.hf : hMax, q.b / 2, 'beam'); if (q.hf) box(q.x0, q.x1, hMax - q.hf, hMax, q.bf / 2, 'beam'); });
  const segIdxAtX = x => { const i = md.segs.findIndex(sg => x >= sg.x0 - 1 && x <= sg.x1 + 1); return i < 0 ? (x < md.segs[0].x0 ? 0 : md.segs.length - 1) : i; };
  const segAtX = x => segs[segIdxAtX(x)];
  sc.rows.filter(r => ['bot', 'top', 'mid'].includes(r.side) && r.x1 > r.x0).forEach(r => {
    const q = segAtX((r.x0 + r.x1) / 2), y = hMax - r.y, inner = q.b / 2 - cov.cs - (md.segs[0].stir || S.stir).d - r.d / 2;   // r.y – od górnej krawędzi
    const n = r.side === 'mid' ? 2 : Math.max(1, Math.round(r.n)), zs = n === 1 ? [0] : Array.from({ length: n }, (_, i) => -inner + 2 * inner * i / (n - 1));
    const col = r.side === 'top' && r.sup !== undefined ? COLS.topX : COLS[r.side], w = Math.max(1.4, r.d / 9);
    zs.forEach(z => { lines.push([[r.x0, y, z], [r.x1, y, z], col, w]);
      if (r.legL) lines.push([[r.x0, y, z], [r.x0, y + (r.dirL === 'up' ? 1 : -1) * r.legL, z], col, w]);
      if (r.legR) lines.push([[r.x1, y, z], [r.x1, y + (r.dirR === 'up' ? 1 : -1) * r.legR, z], col, w]); });
  });
  (R.stirZones || []).forEach(zn => { const q = segAtX(zn.seg.x0 + zn.seg.L / 2), st = zn.seg.stir || S.stir, zb = q.b / 2 - cov.cs - st.d / 2, y0 = hMax - q.h + cov.cb + st.d / 2, y1 = hMax - cov.ct - st.d / 2, w = Math.max(1, st.d / 7);
    zn.xs.forEach(x => { const c = [[x, y0, -zb], [x, y0, zb], [x, y1, zb], [x, y1, -zb]]; for (let i = 0; i < 4; i++) lines.push([c[i], c[(i + 1) % 4], COLS.stir, w]); }); });
  ((R.sh && R.sh.ends) || []).forEach(e => { if (!e.bent) return; const q = segAtX(e.seg.x0 + e.seg.L / 2), hs = q.h - cov.cb - cov.ct, zb = q.b / 2 - cov.cs - 20;
    for (let k = 0; k < e.bent.ng; k++) { const xm = e.x + e.dir * (e.sup.t / 2 + e.bent.sb * (k + 0.5)); [-zb * 0.5, zb * 0.5].forEach(z => lines.push([[xm + e.dir * hs / 2, hMax - q.h + cov.cb + 15, z], [xm - e.dir * hs / 2, hMax - cov.ct - 15, z], COLS.bent, 2])); } });
  // podpory: blok pod spodem belki (pod głębszym z sąsiednich odcinków); utwierdzenie – słup także nad belką
  md.sups.forEach(p => { const t = Math.max(80, p.t || 150), yb = hMax - hAtX(md, p.x, true), zb = Math.max(...[p.segL, p.segR].filter(i => i !== null && i !== undefined).map(i => md.segs[i].g.bw), 200) / 2 + 40;
    box(p.x - t / 2, p.x + t / 2, yb - 220, yb, zb, 'sup'); if (p.type === 'fix') box(p.x - t / 2, p.x + t / 2, hMax, hMax + 220, zb, 'sup'); });
  const xc = (xL + xR) / 2, yc = hMax / 2;
  const base = (W - 60) / Math.max(1500, xR - xL + 400);   // skala stała – niezależna od obrotu
  const render = () => {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
    const cy = Math.cos(V3.yaw), sy = Math.sin(V3.yaw), cp = Math.cos(V3.pitch), sp = Math.sin(V3.pitch), sc0 = base * V3.k;
    const pr = ([x, y, z]) => { const X0 = x - xc, Y0 = y - yc; const X1 = X0 * cy + z * sy, Z1 = -X0 * sy + z * cy; const Y2 = Y0 * cp - Z1 * sp, Z2 = Y0 * sp + Z1 * cp; return [W / 2 + V3.px + X1 * sc0, H / 2 + V3.py - Y2 * sc0, Z2]; };
    const items = [];
    polys.forEach(({ f, kind }) => { const pp = f.map(pr); items.push({ z: pp.reduce((a, q) => a + q[2], 0) / pp.length, poly: pp, kind }); });
    lines.forEach(([a, b, c, w]) => { const A = pr(a), B = pr(b); items.push({ z: (A[2] + B[2]) / 2 + 1, line: [A, B], c, w: w * Math.max(0.6, Math.min(2.4, V3.k)) }); });
    items.sort((u, v) => u.z - v.z);
    items.forEach(it => {
      if (it.poly) { ctx.beginPath(); it.poly.forEach((q, i) => i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1])); ctx.closePath();
        ctx.fillStyle = it.kind === 'sup' ? (dark ? 'rgba(150,160,175,0.16)' : 'rgba(110,120,135,0.16)') : (dark ? 'rgba(160,170,190,0.06)' : 'rgba(120,130,150,0.07)'); ctx.fill();
        ctx.strokeStyle = dark ? 'rgba(200,210,225,0.35)' : 'rgba(60,70,90,0.35)'; ctx.lineWidth = 0.7; ctx.stroke(); }
      else { ctx.beginPath(); ctx.moveTo(it.line[0][0], it.line[0][1]); ctx.lineTo(it.line[1][0], it.line[1][1]); ctx.strokeStyle = it.c; ctx.lineWidth = it.w; ctx.lineCap = 'round'; ctx.stroke(); }
    });
    // litery podpór pod podporami
    ctx.fillStyle = dark ? '#c9d4e6' : '#1b2230'; ctx.font = '600 11px system-ui, sans-serif'; ctx.textAlign = 'center';
    md.sups.forEach(p => { const q = pr([p.x, hMax - hAtX(md, p.x, true) - 260, 0]); ctx.fillText(p.label || p.name || '', q[0], q[1]); });
    ctx.textAlign = 'start'; ctx.fillStyle = dark ? '#c9d4e6' : '#3d4656'; ctx.font = '11px system-ui, sans-serif';
    ctx.fillText(`obrót ${Math.round(V3.yaw * 180 / Math.PI)}°, pochylenie ${Math.round(V3.pitch * 180 / Math.PI)}°, powiększenie ${Math.round(V3.k * 100)}% · tryb: ${V3.mode === 'pan' ? 'przesuw' : 'obrót'}`, 10, H - 10);
  };
  render();
  // sterowanie: lewy przycisk – wg trybu (obrót / przesuw), prawy lub środkowy przycisk albo Shift – przesuw; dwa palce – przesuw i powiększenie
  const zoomAt = (f, mx, my) => { const k1 = Math.max(0.3, Math.min(30, V3.k * f)), g = k1 / V3.k; V3.px = (mx - W / 2) - (mx - W / 2 - V3.px) * g; V3.py = (my - H / 2) - (my - H / 2 - V3.py) * g; V3.k = k1; };
  const loc = e => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  const pts = new Map(); let drag = null, pinch = null;
  cv.oncontextmenu = e => e.preventDefault();
  cv.onpointerdown = e => {
    cv.setPointerCapture(e.pointerId); pts.set(e.pointerId, loc(e));
    if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]) || 1, m: [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], v: Object.assign({}, V3) }; drag = null; return; }
    const pan = V3.mode === 'pan' || e.shiftKey || e.button === 1 || e.button === 2;
    drag = { x: e.clientX, y: e.clientY, v: Object.assign({}, V3), pan }; cv.style.cursor = pan ? 'move' : 'grabbing';
  };
  cv.onpointermove = e => {
    if (pts.has(e.pointerId)) pts.set(e.pointerId, loc(e));
    if (pinch && pts.size === 2) { const [a, b] = [...pts.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]) || 1, m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
      Object.assign(V3, { k: pinch.v.k, px: pinch.v.px + m[0] - pinch.m[0], py: pinch.v.py + m[1] - pinch.m[1] }); zoomAt(d / pinch.d, m[0], m[1]); render(); return; }
    if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (drag.pan) { V3.px = drag.v.px + dx; V3.py = drag.v.py + dy; }                      // przesuw – bez obrotu i bez zmiany skali
    else { V3.yaw = drag.v.yaw + dx * 0.008; V3.pitch = Math.max(-1.45, Math.min(1.45, drag.v.pitch + dy * 0.008)); }   // obrót – skala stała
    render();
  };
  const up = e => { pts.delete(e.pointerId); if (pts.size < 2) pinch = null; if (!pts.size) drag = null; cv.style.cursor = ''; };
  cv.onpointerup = up; cv.onpointercancel = up;
  cv.onwheel = e => { if (!e.ctrlKey) return; e.preventDefault(); const [mx, my] = loc(e); zoomAt(Math.exp(-e.deltaY * 0.002), mx, my); render(); };
  cv.ondblclick = () => { Object.assign(V3, { yaw: -0.55, pitch: 0.38, k: 1, px: 0, py: 0 }); render(); };
  const bar = cv.parentElement && cv.parentElement.querySelector('.v3tools');
  if (bar) {
    bar.querySelectorAll('[data-v3m]').forEach(b => b.onclick = () => { V3.mode = b.dataset.v3m; bar.querySelectorAll('[data-v3m]').forEach(q => q.classList.toggle('on', q === b)); cv.classList.toggle('pan', V3.mode === 'pan'); render(); });
    bar.querySelectorAll('[data-v3z]').forEach(b => b.onclick = () => { zoomAt(+b.dataset.v3z > 0 ? 1.25 : 0.8, W / 2, H / 2); render(); });
    const rb = bar.querySelector('[data-v3r]'); if (rb) rb.onclick = () => cv.ondblclick();
  }
  cv.classList.toggle('pan', V3.mode === 'pan');
}
function hookPopup(segs) {
  const md = R.md, cont = CONT(S), sgs = segs.map(i => md.segs[i]).filter(Boolean), q = (sgs[0] && sgs[0].stir) || S.stir;
  let set; try { set = E.stirSet(q, sgs[0] ? sgs[0].g : R.g, R.cov); } catch (e) { return; }
  const m = $('#modal'); let v = q.hook > 0 ? q.hook : '', dd = q.d, ang = +q.hookA === 90 ? 90 : 135;
  const minOf = () => ang === 90 ? Math.max(10 * dd, 70) : Math.max(5 * dd, 50);
  m.innerHTML = `<div class="dlg barpop"><h3>Strzemiona – średnica i haki${cont && sgs.length ? ` – ${sgs.map(sg => sg.label).join(', ')}` : ''}</h3>
    <div class="zl"><div class="zg"><span>Średnica ⌀<sub>w</sub></span><select id="hD">${[6, 8, 10, 12].map(x => `<option value="${x}" ${x === dd ? 'selected' : ''}>⌀${x}</option>`).join('')}</select><span>Kąt haka</span><select id="hA"><option value="135" ${ang === 135 ? 'selected' : ''}>135°</option><option value="90" ${ang === 90 ? 'selected' : ''}>90°</option></select></div>
    <div class="zg"><span>Długość prostego zakończenia haka</span><input class="txt" id="hLen" value="${esc(showNum(v))}" placeholder="auto ${Math.max(10 * dd, 70)}" spellcheck="false" autocomplete="off"><span>mm</span></div></div>
    <div class="hint" id="hHint"></div>
    <div class="iss" id="hErr" style="display:none"></div>
    <div class="dbtn"><button class="btn" id="hCancel">Anuluj</button><button class="btn pri" id="hOk">Zastosuj</button></div></div>`;
  m.style.display = 'flex';
  const inp = $('#hLen', m);
  const val = () => { const raw = inp.value.trim(), x = parseNum(raw), mn = minOf(), bad = raw !== '' && (x === null || x < mn); inp.classList.toggle('bad', bad); const er = $('#hErr', m); er.style.display = bad ? '' : 'none'; er.textContent = bad ? `Hak ${ang}° krótszy niż ${mn} mm (${ang === 90 ? '10⌀, ≥ 70 mm' : '5⌀, ≥ 50 mm'}) – niedopuszczalny.` : ''; if (!bad) v = raw === '' ? '' : Math.round(x);
    $('#hHint', m).innerHTML = `Minimum wg PN-EN 1992-1-1, rys. 8.5: hak ${ang}° – <b>${mn} mm</b> (${ang === 90 ? '≥ 10⌀ i ≥ 70 mm' : '≥ 5⌀ i ≥ 50 mm'}); automatycznie ${Math.max(10 * dd, 70)} mm. Przy skręcaniu wymagane haki 135° lub zakład (9.2.3(1)).`; inp.placeholder = 'auto ' + Math.max(10 * dd, 70); };
  inp.addEventListener('input', val); $('#hD', m).onchange = ev => { dd = +ev.target.value; val(); }; $('#hA', m).onchange = ev => { ang = +ev.target.value; val(); }; val();
  $('#hCancel', m).onclick = () => { m.style.display = 'none'; };
  $('#hOk', m).onclick = () => {
    if (inp.classList.contains('bad')) return;
    if (!cont) { S.stir.hook = v; S.stir.d = dd; S.stir.hookA = ang; }
    else { const sis = sgs.map(sg => sg.si).filter(i => i !== undefined); if (!sis.length || sis.length === S.cont.spans.length) { S.stir.hook = v; S.stir.d = dd; S.stir.hookA = ang; } sis.forEach(i => { setP(S, `cont.stirSpans.${i}.hook`, v); setP(S, `cont.stirSpans.${i}.d`, dd === S.stir.d ? '' : dd); setP(S, `cont.stirSpans.${i}.hookA`, ang === S.stir.hookA ? '' : ang); }); }
    m.style.display = 'none'; changed(true);
  };
}
// przekrój w miejscu kursora (panel obok widoku podłużnego)
function hoverSecHTML(x) {
  let q; try { q = E.sectionAt(R, x); } catch (e) { return ''; }
  const isS = q.kind === 'span', qs = q.stir || S.stir;
  const sw = q.sw ? `⌀${qs.d} ${qs.legs}-cięte co ${fmt(q.sw.s, Math.abs(q.sw.s - Math.round(q.sw.s)) < 1e-6 ? 0 : 1)} mm${q.sw.inZone ? ' (s₁)' : ''}` : (q.inSupp ? 'nad podporą' : '—');
  return `<h4>Przekrój pod kursorem<small> · ${esc(q.loc)}${q.g ? ` · ${q.g.bw}×${q.g.h}` : ''}</small></h4>${sectionSVG(q, { W: 300, H: 300, na: false })}
    <table class="kv"><tr><td>Dół</td><td>${esc(isS ? q.tens.desc : q.comp.desc)}</td></tr><tr><td>Góra</td><td>${esc(isS ? q.comp.desc : q.tens.desc)}${q.topExtra ? ' (z dodatkowymi)' : ''}</td></tr><tr><td>Strzemiona</td><td>${sw}</td></tr>
    <tr><td>M<sub>Ed</sub> / M<sub>Rd</sub></td><td>${fmt((isS ? q.MEdPos : q.MEdNeg) / 1e6, 1)} / ${fmt((isS ? q.MRdPos : q.MRdNeg) / 1e6, 1)} kNm</td></tr><tr><td>|V<sub>Ed</sub>|</td><td>${fmt(q.V / 1e3, 1)} kN</td></tr></table>`;
}
// wyciągi prętów: pręty podłużne (kształt z odgięciami) i strzemiona (kształt z hakami), bez skali, z wymiarami i promieniami gięcia
function extractsSVG(sc, W) {
  const rowsL = sc.rows.filter(r => ['bot', 'top', 'mid'].includes(r.side)), rowsS = sc.rows.filter(r => r.side === 'stir' || r.side === 'stir2');
  const COL = { bot: '#1d2a3f', top: '#3b5b8f', topX: '#6a3fb5', mid: '#5d7a2e', stir: '#a04848' };
  const colOf = r => r.side === 'top' && r.sup !== undefined ? COL.topX : (COL[r.side] || COL.stir);
  const maxL = Math.max(1, ...rowsL.map(r => r.x1 - r.x0));
  const x0 = 190, wMax = W - x0 - 120, F = v => v.toFixed(1);
  let y = 14, s = '';
  const pos = (cx, cy, r, col) => `<circle cx="${cx}" cy="${cy}" r="9" fill="#ffffff" stroke="${col}" stroke-width="1.2"/>` + tx(cx, cy + 3.5, String(r.pos), { fs: 9.5, w: 700, c: col });
  rowsL.forEach(r => {
    const col = colOf(r), Lh = r.x1 - r.x0, w = Math.max(160, wMax * Math.sqrt(Lh / maxL));
    const kL = r.legL ? Math.max(18, Math.min(46, r.legL * 0.1)) : 0, kR = r.legR ? Math.max(18, Math.min(46, r.legR * 0.1)) : 0;
    const up = (r.legL && r.dirL === 'up') || (r.legR && r.dirR === 'up');
    const hh = Math.max(kL, kR), yb = up ? y + hh + 18 : y + 22, a = x0, b = x0 + w, rr = 6;
    if (r.key) s += `<g class="xbar" data-key="${r.key}"><title>Kliknij, aby zmienić średnicę i wymiary pręta (odcinek prosty, odgięcia)</title><rect x="4" y="${F(y)}" width="${W - 8}" height="${F((up ? yb : yb + Math.max(kL, kR)) + 16 - y)}" rx="4" fill="transparent"/></g>`;
    let d;
    const dl = r.dirL === 'up' ? -1 : 1, dr = r.dirR === 'up' ? -1 : 1;
    if (r.legL) d = `M${F(a)},${F(yb + dl * kL)} L${F(a)},${F(yb + dl * rr)} A${rr},${rr} 0 0 ${dl < 0 ? 0 : 1} ${F(a + rr)},${F(yb)}`; else d = `M${F(a)},${F(yb)}`;
    if (r.legR) d += ` L${F(b - rr)},${F(yb)} A${rr},${rr} 0 0 ${dr > 0 ? 1 : 0} ${F(b)},${F(yb + dr * rr)} L${F(b)},${F(yb + dr * kR)}`; else d += ` L${F(b)},${F(yb)}`;
    s += `<path d="${d}" fill="none" stroke="${col}" stroke-width="2.6" stroke-linecap="round"/>`;
    s += pos(20, yb, r, col) + tx(34, yb + 4, `${r.n}⌀${r.d}`, { fs: 11, a: 'start', w: 650, c: col }) + tx(34, yb + 17, esc(r.name.replace(/^Zbrojenie /, '').slice(0, 30)), { fs: 8.5, a: 'start', c: '#5d6778' });
    s += tx((a + b) / 2, yb + (up ? 14 : -5), `${fmt(Lh, 0)}`, { fs: 10, c: '#1b2230' });
    if (r.legL) { s += tx(a - 5, yb + dl * kL / 2 + 3, String(r.legL), { fs: 9.5, a: 'end' }); if (r.rL) s += tx(a + 10, yb + dl * 12 + (dl > 0 ? 6 : 0), `φm = ${fmt(2 * r.rL, 0)}`, { fs: 8.5, a: 'start', c: col }); }
    if (r.legR) { s += tx(b + 5, yb + dr * kR / 2 + 3, String(r.legR), { fs: 9.5, a: 'start' }); if (r.rR) s += tx(b - 10, yb + dr * 12 + (dr > 0 ? 6 : 0), `φm = ${fmt(2 * r.rR, 0)}`, { fs: 8.5, a: 'end', c: col }); }
    s += tx(W - 10, yb + 4, `l = ${fmt(r.len, 0)} mm`, { fs: 10.5, a: 'end', w: 650, c: r.overMax ? '#c0262d' : '#1b2230' });
    if (r.man) s += tx(W - 10, yb + 16, 'wymiary ręczne', { fs: 8.5, a: 'end', c: '#a35d00' });
    y = (up ? yb : yb + Math.max(kL, kR)) + 22;
  });
  // pręty odgięte (45°): zakotwienie dolne 1,3·l_bd, odcinek ukośny, zakotwienie górne 0,7·l_bd
  sc.rows.filter(r => r.side === 'bent' && r.bent).forEach(r => {
    const col = '#b5651d', bt = r.bent, k = Math.min(0.08, 260 / (bt.hs + 2 * bt.lbd)), hh = Math.max(28, bt.hs * k), a = x0, l1 = 1.3 * bt.lbd * k, l2 = 0.7 * bt.lbd * k, yb = y + hh + 12;
    s += `<path d="M${F(a)},${F(yb)} h${F(l1)} l${F(hh)},${F(-hh)} h${F(l2)}" fill="none" stroke="${col}" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"/>`;
    s += pos(20, yb - hh / 2, r, col) + tx(34, yb - hh / 2 + 4, `${r.n}⌀${r.d}`, { fs: 11, a: 'start', w: 650, c: col }) + tx(34, yb - hh / 2 + 17, 'odgięte 45° (ścinanie)', { fs: 8.5, a: 'start', c: '#5d6778' });
    s += tx(a + l1 / 2, yb + 13, fmt(1.3 * bt.lbd, 0), { fs: 9.5 }) + tx(a + l1 + hh + l2 / 2, yb - hh - 5, fmt(0.7 * bt.lbd, 0), { fs: 9.5 }) + tx(a + l1 + hh / 2 + 10, yb - hh / 2, `${fmt(bt.hs * Math.SQRT2, 0)} (45°)`, { fs: 9, a: 'start' });
    s += tx(W - 10, yb - hh / 2 + 4, `l = ${fmt(r.len, 0)} mm`, { fs: 10.5, a: 'end', w: 650, c: '#1b2230' });
    y = yb + 26;
  });
  // strzemiona
  const cw = 250, chh = 232, perRow = Math.max(1, Math.floor((W - 10) / cw));
  const y0 = y + 6;
  rowsS.forEach((r, i) => {
    const col = COL.stir, cx0 = 10 + (i % perRow) * cw, cy0 = y0 + Math.floor(i / perRow) * chh;
    const sh = r.shape || { type: 'closed', B: 200, H: 400 }, set = r.set || { d: r.d, r: 2 * r.d, ext: Math.max(10 * r.d, 70), phm: 4 * r.d };
    const Hs = sh.H, Bs = sh.type === 'pin' ? 0 : sh.B, k = Math.min(110 / Math.max(Bs, 1), 130 / Hs, 0.32);
    const bx = cx0 + 60, by = cy0 + 34, bw = Math.max(4, Bs * k), bhh = Hs * k, rad = Math.max(3, (set.r + r.d / 2) * k), ex = Math.max(10, set.ext * k * 0.7071);
    s += `<g class="xstir" data-segs="${(r.segs || []).join(',')}"><title>Kliknij, aby zmienić średnicę i haki strzemion</title><rect x="${cx0}" y="${cy0}" width="${cw - 10}" height="${chh - 4}" rx="4" fill="transparent"/></g>`;
    s += pos(cx0 + 12, cy0 + 12, r, col) + tx(cx0 + 26, cy0 + 16, `${r.n} szt. ⌀${r.d} · l = ${fmt(r.len, 0)}`, { fs: 10, a: 'start', w: 650, c: col });
    if (sh.type === 'pin') {
      const xx = bx + 30;
      s += `<path d="M${F(xx + ex)},${F(by + ex)} L${F(xx)},${F(by)} V${F(by + bhh)} l${F(-ex)},${F(-ex)}" fill="none" stroke="${col}" stroke-width="2.2" stroke-linecap="round"/>`;
      s += dimV(xx - 18, by, by + bhh, String(Math.round(Hs)), { fs: 9.5 });
      s += tx(xx + 8, by + bhh / 2, `szpilka`, { fs: 9, a: 'start', c: '#5d6778' });
      s += tx(xx + ex + 4, by + ex + 4, `hak ${set.hookA || 135}° ${fmt(set.ext, 0)}`, { fs: 8.5, a: 'start', c: col });
    } else if (sh.type === 'open') {
      s += `<path d="M${F(bx)},${F(by)} V${F(by + bhh - rad)} A${F(rad)},${F(rad)} 0 0 0 ${F(bx + rad)},${F(by + bhh)} H${F(bx + bw - rad)} A${F(rad)},${F(rad)} 0 0 0 ${F(bx + bw)},${F(by + bhh - rad)} V${F(by)}" fill="none" stroke="${col}" stroke-width="2.2"/>`;
      s += `<path d="M${F(bx)},${F(by)} l${F(ex)},${F(ex * 0.5)} M${F(bx + bw)},${F(by)} l${F(-ex)},${F(ex * 0.5)}" stroke="${col}" stroke-width="2.2" stroke-linecap="round"/>`;
      s += dimH(bx, bx + bw, by + bhh + 16, String(Math.round(Bs)), { below: true, fs: 9.5 }) + dimV(bx - 16, by, by + bhh, String(Math.round(Hs)), { fs: 9.5 });
    } else if (sh.type === 'tors') {
      s += `<rect x="${F(bx)}" y="${F(by)}" width="${F(bw)}" height="${F(bhh)}" rx="${F(rad)}" fill="none" stroke="${col}" stroke-width="2.2"/>`;
      { const lp = Math.min(bw - 2 * rad, (sh.lap || 300) * k); s += `<line x1="${F(bx + rad)}" y1="${F(by + 4)}" x2="${F(bx + rad + lp)}" y2="${F(by + 4)}" stroke="${col}" stroke-width="2.2" stroke-linecap="round"/>` + tx(bx + bw / 2, by + 16, `zakład ${fmt(sh.lap, 0)}`, { fs: 8.5, c: col }); }
      s += dimH(bx, bx + bw, by + bhh + 16, String(Math.round(Bs)), { below: true, fs: 9.5 }) + dimV(bx - 16, by, by + bhh, String(Math.round(Hs)), { fs: 9.5 });
    } else {
      // strzemię zamknięte „rozchylone”: naroże z hakami rozsunięte – koniec pręta pionowego i początek poziomego zagięte do wnętrza, oba haki widoczne osobno
      const rr = Math.max(3.5, rad), g = Math.max(11, Math.min(20, bw * 0.2)), exs = Math.max(10, Math.min(ex * 1.15, bw * 0.35)), c45 = Math.SQRT1_2;
      const yL = by + g + rr, xT = bx + g + rr;
      s += `<path d="M${F(xT)},${F(by)} H${F(bx + bw - rr)} A${F(rr)},${F(rr)} 0 0 1 ${F(bx + bw)},${F(by + rr)} V${F(by + bhh - rr)} A${F(rr)},${F(rr)} 0 0 1 ${F(bx + bw - rr)},${F(by + bhh)} H${F(bx + rr)} A${F(rr)},${F(rr)} 0 0 1 ${F(bx)},${F(by + bhh - rr)} V${F(yL)}" fill="none" stroke="${col}" stroke-width="2.2" stroke-linejoin="round"/>`;
      if (set.hookA === 90) {
        s += `<path d="M${F(bx)},${F(yL)} A${F(rr)},${F(rr)} 0 0 1 ${F(bx + rr)},${F(yL - rr)} h${F(exs)} M${F(xT)},${F(by)} A${F(rr)},${F(rr)} 0 0 0 ${F(xT - rr)},${F(by + rr)} v${F(exs)}" fill="none" stroke="${col}" stroke-width="2.2" stroke-linecap="round"/>`;
      } else {
        const p1x = bx + rr + rr * c45, p1y = yL - rr * c45, p2x = xT - rr * c45, p2y = by + rr + rr * c45;
        s += `<path d="M${F(bx)},${F(yL)} A${F(rr)},${F(rr)} 0 0 1 ${F(p1x)},${F(p1y)} l${F(exs * c45)},${F(exs * c45)} M${F(xT)},${F(by)} A${F(rr)},${F(rr)} 0 0 0 ${F(p2x)},${F(p2y)} l${F(exs * c45)},${F(exs * c45)}" fill="none" stroke="${col}" stroke-width="2.2" stroke-linecap="round"/>`;
      }
      s += tx(bx + bw + 6, by + 10, `2 haki ${set.hookA || 135}°`, { fs: 8.5, a: 'start', c: col }) + tx(bx + bw + 6, by + 21, `po ${fmt(set.ext, 0)} mm`, { fs: 8.5, a: 'start', c: col });
      s += dimH(bx, bx + bw, by + bhh + 16, String(Math.round(Bs)), { below: true, fs: 9.5 }) + dimV(bx - 16, by, by + bhh, String(Math.round(Hs)), { fs: 9.5 });
    }
    s += tx(cx0 + 10, cy0 + chh - 22, `φm = ${fmt(set.phm, 0)} (${fmt(set.phm / r.d, 0)}⌀), r = ${fmt(set.r, 0)} · wymiary zewnętrzne`, { fs: 8.5, a: 'start', c: '#5d6778' });
    const lp = set.lenParts;
    s += tx(cx0 + 10, cy0 + chh - 10, lp && (sh.type === 'closed') ? `l – oś pręta: ${fmt(lp.straight, 0)} + łuki ${lp.ang}° (r+⌀/2 = ${fmt(lp.rc, 0)}) ${fmt(lp.arcs, 0)} + haki 2×${fmt(set.ext, 0)}` : 'l – długość w rozwinięciu osiowym pręta (z hakami)', { fs: 8, a: 'start', c: '#5d6778' });
  });
  const H = y0 + Math.ceil(rowsS.length / perRow) * chh + 6;
  return svgOpen(W, Math.max(40, H)) + s + '</svg>';
}
// kliknięcie w widok podłużny – okno z przekrojem poprzecznym w danym miejscu
function bindElev(el) {
  const svg = $('svg.elev', el); if (!svg) return;
  const ml = +svg.dataset.ml, sx = +svg.dataset.sx, xl = +svg.dataset.xl, top = +svg.dataset.top, bh = +svg.dataset.bh;
  const ns = 'http://www.w3.org/2000/svg';
  const cur = document.createElementNS(ns, 'line');
  cur.setAttribute('y1', top - 6); cur.setAttribute('y2', top + bh + 6); cur.setAttribute('stroke-width', '1.4'); cur.setAttribute('stroke-dasharray', '4 3');
  cur.style.stroke = 'var(--acc)'; cur.style.display = 'none'; cur.style.pointerEvents = 'none';
  svg.appendChild(cur); svg.style.cursor = 'crosshair';
  const xOf = ev => { const r = svg.getBoundingClientRect(), vb = svg.viewBox.baseVal; const px = vb.x + (ev.clientX - r.left) * vb.width / r.width, py = vb.y + (ev.clientY - r.top) * vb.height / r.height; return { x: xl + (px - ml) / sx, px, py }; };
  const inside = q => q.py >= top - 30 && q.py <= top + bh + 30 && q.x >= 0 && q.x <= R.md.Ltot;
  const hs = $('#hsec', el); let pend = null, lastX = null;
  const showSec = x => { if (!hs || x === lastX) return; lastX = x; hs.innerHTML = hoverSecHTML(x); };
  if (hs) { const s0 = R.secs && R.secs[0] ? R.secs[0].x : R.md.Ltot / 2; showSec(Math.round(s0 / 10) * 10); }
  svg.addEventListener('mousemove', ev => { const q = xOf(ev); if (inside(q)) { cur.setAttribute('x1', q.px); cur.setAttribute('x2', q.px); cur.style.display = ''; const xx = Math.round(Math.max(0, Math.min(R.md.Ltot, q.x)) / 10) * 10; if (!pend) pend = requestAnimationFrame(() => { pend = null; showSec(xx); }); } else cur.style.display = 'none'; });
  svg.addEventListener('mouseleave', () => { cur.style.display = 'none'; });
  svg.addEventListener('click', ev => { const bd = ev.target.closest('.bend'); if (bd) { barPopup(bd.dataset.key, bd.dataset.end); return; } const q = xOf(ev); if (inside(q)) sectionPopup(Math.round(q.x / 10) * 10); });
}
function sectionPopup(x) {
  const q = E.sectionAt(R, x), m = $('#modal'), L = R.md.Ltot;
  // strefy edycji w tym miejscu: dół – strefa przęsła, góra – pręty dodatkowe nad podporą (gdy są w tym miejscu) albo ciągłe
  const sgE = (() => { const md = R.md; const sg = md.segs.find(z => x >= z.x0 - 1 && x <= z.x1 + 1) || md.segs[0]; return sg.reb ? sg : (md.segs[sg.adj] || sg); })();
  const pNear = R.md.sups.filter(p => p.hasX !== false).reduce((a, p) => (!a || Math.abs(p.x - x) < Math.abs(a.x - x) ? p : a), null);
  const ez = { bot: 'b' + sgE.idx, top: q.topExtra && pNear ? 'x' + pNear.idx : 't' };
  const isS = q.kind === 'span';
  const sw = q.sw ? `⌀${(q.stir || S.stir).d} co ${fmt(q.sw.s, Math.abs(q.sw.s - Math.round(q.sw.s)) < 1e-6 ? 0 : 1)} mm${q.sw.inZone ? ' (strefa s₁)' : ''}` : (q.inSupp ? 'nad podporą – brak strzemion' : '—');
  const narrow = window.innerWidth < 700;
  m.innerHTML = `<div class="dlg secpop xres"><h3>Przekrój poprzeczny – ${esc(q.loc)}</h3>
    <div class="secnav"><button class="btn sm" data-dx="-500">◀ 0,5 m</button><button class="btn sm" data-dx="-100">◀ 0,1 m</button><label>x = <input class="txt sm" id="spX" value="${fmt(x / 1000, 2)}"> m</label><button class="btn sm" data-dx="100">0,1 m ▶</button><button class="btn sm" data-dx="500">0,5 m ▶</button></div>
    <div class="flex secedit" style="gap:0;justify-content:center">${sectionSVG(q, { W: narrow ? 300 : 330, H: narrow ? 330 : 360, edit: ez })}${narrow ? '' : strainSVG(q)}</div>
    <div class="secedbar"><span>Zmień w tym miejscu:</span><button class="btn sm" data-ez="${ez.bot}">Zbrojenie dolne</button><button class="btn sm" data-ez="${ez.top}">Zbrojenie górne</button><button class="btn sm" data-ez="stir">Strzemiona</button><button class="btn sm" data-ez="mid">Pręty boczne</button><button class="btn sm" data-eg="${sgE.idx}">Wymiary b × h</button><button class="btn sm" data-ez="cov">Otulina</button></div>
    <table class="kv">
      <tr><td>Zbrojenie dolne</td><td>${esc(isS ? q.tens.desc : q.comp.desc)}${q.botFull ? '' : ' (bez prętów skróconych)'}</td><td>${fmt((isS ? q.tens : q.comp).A, 0)} mm²</td></tr>
      <tr><td>Zbrojenie górne</td><td>${esc(isS ? q.comp.desc : q.tens.desc)}${q.topExtra ? ` (z dodatkowymi – ${esc(q.sup.name)})` : ''}</td><td>${fmt((isS ? q.comp : q.tens).A, 0)} mm²</td></tr>
      ${q.mid.length ? `<tr><td>Pręty boczne</td><td>${q.mid.length}⌀${S.reb.mid.d}</td><td>${fmt(q.mid.reduce((a, b) => a + b.A, 0), 0)} mm²</td></tr>` : ''}
      <tr><td>Strzemiona</td><td colspan="2">${sw}</td></tr>
      <tr><td>M<sub>Ed</sub> max / M<sub>Rd</sub> (+)</td><td>${fmt(q.MEdPos / 1e6, 1)} / ${fmt(q.MRdPos / 1e6, 1)}</td><td>kNm (${fmt(q.etaPos * 100, 0)}%)</td></tr>
      <tr><td>|M<sub>Ed</sub>| min / M<sub>Rd</sub> (−)</td><td>${fmt(q.MEdNeg / 1e6, 1)} / ${fmt(q.MRdNeg / 1e6, 1)}</td><td>kNm (${fmt(q.etaNeg * 100, 0)}%)</td></tr>
      <tr><td>|V<sub>Ed</sub>| (obwiednia)</td><td>${fmt(q.V / 1e3, 1)}</td><td>kN</td></tr>
      <tr><td>Wysokość użyteczna d</td><td>${fmt(q.d, 0)}</td><td>mm (${isS ? 'M > 0' : 'M < 0'})</td></tr>
    </table>
    <p class="hint">Stan graniczny pokazany dla momentu decydującego w tym miejscu (${isS ? 'rozciągane włókna dolne' : 'rozciągane włókna górne'}), N<sub>Ed</sub> = ${fmt(R.st.NEd / 1e3, 1)} kN.</p>
    <div class="dbtn"><button class="btn pri" id="nClose">Zamknij</button></div></div>`;
  setTimeout(() => {
    $$('.secedit .zhit, .secedit .covhit, [data-ez]', m).forEach(b => b.addEventListener('click', ev => { ev.stopPropagation(); const z = b.dataset.z || b.dataset.ez; m.style.display = 'none'; zoneClick(z); }));
    $$('.secedit .geohit, [data-eg]', m).forEach(b => b.addEventListener('click', ev => { ev.stopPropagation(); m.style.display = 'none'; geoPopup(+(b.dataset.geo || b.dataset.eg)); }));
  }, 0);
  m.style.display = 'flex';
  $('#nClose', m).onclick = () => { m.style.display = 'none'; };
  $$('[data-dx]', m).forEach(b => b.onclick = () => sectionPopup(Math.max(0, Math.min(L, x + +b.dataset.dx))));
  const inp = $('#spX', m);
  inp.addEventListener('change', () => { const v = parseNum(inp.value); if (v !== null) sectionPopup(Math.max(0, Math.min(L, v * 1000))); });
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') inp.dispatchEvent(new Event('change')); });
}
function anchTable() {
  const a = R.anch;
  const head = `<tr><th>Miejsce</th><th>Pręty</th><th>Przyczepność</th><th>f<sub>bd</sub> [MPa]</th><th>σ<sub>sd</sub> [MPa]</th><th>l<sub>b,rqd</sub> [mm]</th><th>α₁</th><th>α₂</th><th>l<sub>bd</sub> [mm]</th><th>l<sub>0</sub> (α₆=${a.alpha6}) [mm]</th></tr>`;
  const cells = r => `<td>${r.bond === 'good' ? 'dobra' : 'średnia'}</td><td class="n">${fmt(r.fbd, 2)}</td><td class="n">${fmt(r.sigma, 0)}</td><td class="n">${fmt(r.lbrqd, 0)}</td><td class="n">${fmt(r.al1, 2)}</td><td class="n">${fmt(r.al2, 3)}</td>`;
  if (!a.loc || !a.loc.length) {
    let html = `<div class="h2" style="margin-top:16px">Długości zakotwienia i zakładów</div><div class="tscroll"><table class="sched">${head}`;
    a.rows.forEach(r => { html += `<tr><td>—</td><td>${r.name}</td>${cells(r)}<td class="n"><b>${fmt(r.lbd, 0)}</b></td><td class="n"><b>${fmt(r.l0, 0)}</b></td></tr>`; });
    return html + `</table></div>`;
  }
  const md = R.md, rows = [];
  a.loc.forEach(r => rows.push({ x: r.x, o: r.side === 'top' ? 1 : 0, html: `<tr><td>${esc(cap(r.where))}${r.kind === 'span' ? '' : r.kind === 'end' ? ' <small>(skrajna)</small>' : ' <small>(pośrednia)</small>'}</td><td>${r.side === 'top' ? 'górne' : 'dolne'} ⌀${r.dia}${r.kind === 'span' ? ' – poza punktem odcięcia' : ' – poza punktem odcięcia (nad podporą)'}</td>${cells(r)}<td class="n"><b>${fmt(r.lbd, 0)}</b></td><td class="n"><b>${fmt(r.l0, 0)}</b></td></tr>` }));
  (a.ends || []).forEach(q => { const p = q.e.sup, r = q.bent ? q.rh : q.r; rows.push({ x: p.x, o: 0, html: `<tr><td>${esc(cap(p.name))} <small>(skrajna)</small></td><td>dolne ⌀${q.dia} – w podporze, F<sub>E</sub> = ${fmt(q.FE / 1e3, 1)} kN${q.bent ? ', z odgięciem' : ''}</td>${cells(r)}<td class="n"><b>${fmt(q.bent ? q.lbdHook : q.lbd, 0)}</b></td><td class="n">—</td></tr>` }); });
  (a.inner || []).forEach(q => { const p = q.sup, lap = S.anch.innerB === 'lap', r0 = a.loc.find(r => r.side === 'bot' && (r.seg === p.segL || r.seg === p.segR) && r.dia === q.dmax);
    rows.push({ x: p.x, o: 0, html: `<tr><td>${esc(cap(p.name))} <small>(pośrednia)</small></td><td>dolne ⌀${q.dmax} – ${lap ? 'zakład nad podporą' : 'za licem podpory, bez zakładu'}</td><td colspan="6" class="nt">${lap ? 'ciągłość zbrojenia dolnego – zakład l₀ (9.2.1.5(3))' : 'zakotwienie ≥ 10⌀ za licem podpory (9.2.1.5(1), rys. 9.4)'}</td><td class="n"><b>${lap ? '—' : fmt(q.l, 0)}</b></td><td class="n"><b>${lap && r0 ? fmt(r0.l0, 0) : '—'}</b></td></tr>` }); });
  rows.sort((u, v) => u.x - v.x || u.o - v.o);
  const mid = a.rows.filter(r => r.side === 'mid').map(r => `<tr><td>całą długość</td><td>${r.name}</td>${cells(r)}<td class="n"><b>${fmt(r.lbd, 0)}</b></td><td class="n"><b>${fmt(r.l0, 0)}</b></td></tr>`).join('');
  return `<div class="h2" style="margin-top:16px">Długości zakotwienia i zakładów<small>osobno dla przęseł i podpór (skrajnych i pośrednich): σ<sub>sd</sub>, warunki przyczepności i otulenie c<sub>d</sub> w danym miejscu (8.4.3, 8.4.4, 8.7.3)</small></div><div class="tscroll"><table class="sched">${head}${rows.map(q => q.html).join('')}${mid}</table></div>`;
}
U.anchTable = anchTable;

/* -------------------------------------------------------------- raport */
// ramka wydruku: odstępy górny/dolny powtarzane na każdej stronie (thead/tfoot), margines @page = 0 usuwa nagłówki i stopki przeglądarki
const wrapPrint = html => `<table class="pwrap"><thead><tr><td><div class="psp"></div></td></tr></thead><tfoot><tr><td><div class="psp"></div></td></tr></tfoot><tbody><tr><td class="pbody">${html}</td></tr></tbody></table>`;
const repMode = () => (S.meta && S.meta.repMode === 'static' ? 'static' : 'full');
const repView = () => (S.meta && S.meta.repMode === 'own' ? 'own' : repMode());      // widok zakładki raportu: pełny / statyka / raport własny (edytowalny)
const repBuild = () => { const m = repMode(); const h = R && R.bare && m !== 'static' ? window.BZR.buildBare(R, S) : m === 'static' ? window.BZR.buildStatic(R, S) : window.BZR.build(R, S); return window.BZR.noRefs(h); };   // raport bez odwołań do punktów / tablic normy
function renderReport(el) {
  let tools;
  if (ART) {
    tools = Cap.dl
      ? `<p class="hint">Aby wydrukować lub zapisać PDF: pobierz raport, otwórz plik w przeglądarce i wybierz Drukuj (Ctrl+P).</p><button class="btn pri" id="bExp">Pobierz raport (HTML)</button>`
      : `<p class="hint keep">Pobieranie plików nie jest dostępne w tym widoku – raport możesz przeczytać poniżej.</p>`;
  } else tools = `<button class="btn" id="bExp">Zapisz raport HTML…</button><button class="btn" id="bOdt" title="Raport do edycji: OpenDocument Text (.odt) – LibreOffice Writer, MS Word">Zapisz .odt (edytowalny)…</button><button class="btn pri" id="bPrint">Drukuj / zapisz PDF</button>`;
  if (ART && Cap.dl) tools += `<button class="btn" id="bOdt" title="Raport do edycji: OpenDocument Text (.odt)">Pobierz .odt (edytowalny)</button>`;
  const mode = repMode();
  const seg = `<div class="segsw" role="tablist" aria-label="Rodzaj raportu"><button data-rm="full" class="${mode === 'full' && repView() !== 'own' ? 'on' : ''}" title="Pełny tok obliczeń: dane, materiały, otulina, obciążenia i siły wewnętrzne, wszystkie sprawdzenia SGN i SGU ze wzorami, podstawieniami i wynikami, zbrojenie belki, zestawienie">Raport pełny</button><button data-rm="static" class="${mode === 'static' && repView() !== 'own' ? 'on' : ''}" title="Tylko statyka: dane materiałowe, wymiary przekrojów, schemat statyczny, wykresy sił wewnętrznych (M, V, N, T) i reakcje">Statyka</button><button data-rm="own" class="${repView() === 'own' ? 'on' : ''}" title="Raport do własnej edycji: pisz, usuwaj i formatuj tekst, wstawiaj obliczenia; zapisywany w projekcie">Raport własny</button></div>${R && R.bare && repView() === 'full' ? `<button class="btn sm pri" id="bRepAuto" title="Przekroje nie mają zbrojenia podłużnego – raport pełny obejmuje wtedy statykę i zbrojenie wymagane">Dobierz zbrojenie – raport pełny</button>` : ''}`;
  const bindSeg = () => $$('[data-rm]', el).forEach(b => b.addEventListener('click', () => { S.meta.repMode = b.dataset.rm; dirty = true; updateTitle(); autosave(); renderReport(el); }));
  if (repView() === 'own') { renderOwn(el, seg); bindSeg(); return; }
  el.innerHTML = `<div class="rtools">${seg}<span class="sp"></span>${tools}</div><div id="report">${wrapPrint(repBuild())}</div>`;
  bindSeg();
  const ba = $('#bRepAuto', el); if (ba) ba.onclick = () => doAutoReb();
  const bp = $('#bPrint', el), be = $('#bExp', el);
  if (bp) bp.onclick = doPrint;
  if (be) be.onclick = exportHTML;
  const bo = $('#bOdt', el); if (bo) bo.onclick = exportODT;
}

/* ------------------------------------------------- raport własny (edytowalny) */
// treść w S.meta.own (HTML); dopóki pusta – podgląd bieżącego raportu obliczeń (po pierwszej zmianie – własna kopia, niezależna od danych)
function cleanHTML(html) {
  const t = document.createElement('template'); t.innerHTML = html || '';
  t.content.querySelectorAll('script, iframe, object, embed, link, meta, base, form, input, button, select, textarea').forEach(n => n.remove());
  t.content.querySelectorAll('*').forEach(n => [...n.attributes].forEach(a => { if (/^on/i.test(a.name) || (/^(href|src|xlink:href)$/i.test(a.name) && /^\s*javascript:/i.test(a.value)) || a.name === 'contenteditable') n.removeAttribute(a.name); }));
  return t.innerHTML;
}
let ownT = 0;
function renderOwn(el, seg) {
  const own = S.meta.ownOn === true;
  if (!own && (!R || (R.errors && R.errors.length))) { el.innerHTML = `<div class="rtools">${seg || ''}</div>` + errBox(); return; }
  const B = (cmd, lab, tit, val) => `<button data-oc="${cmd}"${val ? ` data-ov="${val}"` : ''} title="${tit}">${lab}</button>`;
  const exp = ART ? (Cap.dl ? `<button class="btn" id="oExp">Pobierz HTML</button><button class="btn" id="oOdt">Pobierz .odt</button>` : '') : `<button class="btn" id="oExp">Zapisz HTML…</button><button class="btn" id="oOdt" title="OpenDocument Text – LibreOffice Writer, MS Word">Zapisz .odt…</button><button class="btn pri" id="oPrint">Drukuj / PDF</button>`;
  el.innerHTML = `<div class="rtools">${seg || ''}<span class="sp"></span>${exp}</div><div class="rtools owntools">
      <span class="grp">${B('bold', '<b>B</b>', 'Pogrubienie (Ctrl+B)')}${B('italic', '<i>I</i>', 'Kursywa (Ctrl+I)')}${B('underline', '<u>U</u>', 'Podkreślenie (Ctrl+U)')}${B('removeFormat', 'T̸', 'Usuń formatowanie zaznaczenia')}</span>
      <span class="grp">${B('formatBlock', 'H1', 'Tytuł', 'h1')}${B('formatBlock', 'H2', 'Nagłówek rozdziału', 'h2')}${B('formatBlock', 'H3', 'Podtytuł', 'h3')}${B('formatBlock', '¶', 'Zwykły akapit', 'p')}${B('insertUnorderedList', '•', 'Lista punktowana')}${B('insertOrderedList', '1.', 'Lista numerowana')}</span>
      <span class="grp">${B('undo', '↶', 'Cofnij (Ctrl+Z)')}${B('redo', '↷', 'Ponów (Ctrl+Y)')}</span>
      <button class="btn sm" id="oIns" title="Wstawia pełny raport obliczeń (aktualne dane) za akapitem z kursorem, a gdy kursora nie ma w raporcie – na końcu">Wstaw raport pełny</button>
      <button class="btn sm" id="oInsS" title="Wstawia raport statyki (aktualne dane) za akapitem z kursorem, a gdy kursora nie ma w raporcie – na końcu">Wstaw statykę</button>
      <button class="btn sm" id="oDate" title="Wstawia datę i nazwę projektu w miejscu kursora">Wstaw datę</button>
      <button class="btn sm" id="oReset" title="${own ? 'Usuwa własne zmiany – raport własny znowu pokazuje bieżący raport obliczeń' : 'Raport własny pokazuje teraz bieżący raport obliczeń'}" ${own ? '' : 'disabled'}>Przywróć raport obliczeń</button>
      <button class="btn sm" id="oClr" title="Usuwa całą treść raportu własnego">Wyczyść</button></div>
    <p class="ownstate" id="oState">${own ? 'Raport własny – zapisywany w projekcie przy każdej zmianie; nie zmienia się po zmianie danych (aktualne obliczenia: „Wstaw raport pełny” / „Wstaw statykę”).' : 'Podgląd bieżącego raportu obliczeń – kliknij w tekst i pisz albo usuwaj; po pierwszej zmianie raport staje się Twoją kopią zapisywaną w projekcie.'}</p>
    <div class="ownwrap">${wrapPrint(`<div id="ownrep" contenteditable="true" spellcheck="true" lang="pl">${own ? cleanHTML(S.meta.own || '') : window.BZR.noRefs(R.bare ? window.BZR.buildBare(R, S) : window.BZR.build(R, S))}</div>`)}</div>`;
  const ed = $('#ownrep', el), st = $('#oState', el);
  const save = () => { clearTimeout(ownT); ownT = setTimeout(() => { S.meta.own = ed.innerHTML; S.meta.ownOn = true; dirty = true; updateTitle(); autosave();
    st.textContent = 'Raport własny – zapisywany w projekcie przy każdej zmianie; nie zmienia się po zmianie danych (aktualne obliczenia: „Wstaw raport pełny” / „Wstaw statykę”).'; const rb = $('#oReset', el); if (rb) rb.disabled = false; }, 350); };
  ed.addEventListener('input', save);
  ed.addEventListener('focus', () => { try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) { /* */ } });
  $$('[data-oc]', el).forEach(b => { b.addEventListener('mousedown', ev => ev.preventDefault()); b.addEventListener('click', () => { ed.focus(); try { document.execCommand(b.dataset.oc, false, b.dataset.ov ? `<${b.dataset.ov}>` : null); } catch (e) { /* */ } save(); }); });
  const insertAtCaret = html => {
    const sel = window.getSelection(), inEd = sel && sel.rangeCount && ed.contains(sel.getRangeAt(0).commonAncestorContainer);
    const t = document.createElement('template'); t.innerHTML = html; const frag = t.content;
    // blok (np. raport obliczeń) – za akapitem z kursorem (pusty akapit zastępowany), nie wewnątrz niego; krótki tekst – w miejscu kursora
    const isBlock = [...frag.childNodes].some(n => n.nodeType === 1 && /^(h[1-6]|div|table|p|ul|ol)$/i.test(n.tagName) && !(frag.childNodes.length === 1 && /^p$/i.test(n.tagName)));
    if (inEd && isBlock) { let top = sel.getRangeAt(0).startContainer; while (top && top.parentNode !== ed) top = top.parentNode;
      if (top && top !== ed) { const empty = top.nodeType === 1 ? !top.textContent.trim() && !top.querySelector('svg, img, table') : !top.nodeValue.trim(); ed.insertBefore(frag, top.nextSibling); if (empty) top.remove(); } else ed.appendChild(frag); }
    else if (inEd) { const r = sel.getRangeAt(0); r.deleteContents(); r.insertNode(frag); r.collapse(false); } else ed.appendChild(frag);
    save();
  };
  const insRep = kind => { if (!R || (R.errors && R.errors.length)) { toast('Usuń błędy danych – raport obliczeń jest niedostępny.'); return; }
    const h = kind === 'static' ? window.BZR.buildStatic(R, S) : R.bare ? window.BZR.buildBare(R, S) : window.BZR.build(R, S); insertAtCaret(window.BZR.noRefs(h)); toast(kind === 'static' ? 'Wstawiono raport statyki.' : 'Wstawiono raport obliczeń.', 1800); };
  $('#oIns', el).onclick = () => insRep('full'); $('#oInsS', el).onclick = () => insRep('static');
  $('#oDate', el).onclick = () => { const d = new Date(); insertAtCaret(`<p>${esc(S.meta.name || '')} – ${d.toLocaleDateString('pl-PL')}</p>`); };
  $('#oReset', el).onclick = async () => { if (!(await ask('Usunąć własne zmiany? Raport własny znowu pokaże bieżący raport obliczeń.', 'Przywróć', true))) return; S.meta.own = ''; S.meta.ownOn = false; dirty = true; updateTitle(); autosave(); renderReport(el); };
  $('#oClr', el).onclick = async () => { if (!(await ask('Usunąć całą treść raportu własnego?', 'Wyczyść', true))) return; S.meta.own = ''; S.meta.ownOn = true; dirty = true; updateTitle(); autosave(); renderReport(el); };
  const bp = $('#oPrint', el); if (bp) bp.onclick = () => setTimeout(() => window.print(), 50);
  const be = $('#oExp', el); if (be) be.onclick = () => exportOwn('html');
  const bo = $('#oOdt', el); if (bo) bo.onclick = () => exportOwn('odt');
}
function ownHTML() { const ed = $('#ownrep'); return ed ? ed.innerHTML : (S.meta.ownOn ? cleanHTML(S.meta.own || '') : repBuild()); }
async function exportOwn(kind) {
  const html = ownHTML(), title = (S.meta.name || 'Belka') + ' – raport';
  if (kind === 'html') {
    const name = safeName(' – raport własny.html'), doc = reportDoc(html, title);
    if (inHost()) { const r = await hostCall('save', { path: '', name, content: doc, filter: 'html' }); if (r && r.ok) toast('Zapisano raport: ' + baseName(r.path)); else if (r && r.err) toast('Błąd: ' + r.err); }
    else if (ART) await offerFile(name, doc, 'Raport pobrany – otwórz go i wydrukuj (Ctrl+P).');
    else download(name, doc, 'text/html');
    return;
  }
  const name = safeName(' – raport własny.odt');
  toast('Tworzenie pliku .odt…', 1500);
  let u; try { u = await window.BZR.odt(html, title); } catch (e) { console.error(e); toast('Błąd tworzenia .odt: ' + e.message); return; }
  if (inHost()) { let b = ''; for (let i = 0; i < u.length; i += 0x8000) b += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); const r = await hostCall('save', { path: '', name, content: btoa(b), b64: true, filter: 'odt' }); if (r && r.ok) toast('Zapisano raport: ' + baseName(r.path)); else if (r && r.err) toast('Błąd: ' + r.err); return; }
  const blob = new Blob([u], { type: 'application/vnd.oasis.opendocument.text' });
  if (ART) { await offerFile(name, blob, 'Raport .odt pobrany – otwórz w edytorze tekstu.'); return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800);
}

/* ------------------------------------------------- kolory rysunków (motyw) */
const SVCOL = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
function themeSvgIn(root) {
  root.querySelectorAll('svg [fill], svg [stroke]').forEach(el => {
    ['fill', 'stroke'].forEach(a => {
      const v = el.getAttribute(a); if (!v || !SVCOL.test(v)) return;
      let h = v.slice(1).toLowerCase(); if (h.length === 3) h = h.replace(/./g, c => c + c);
      el.style.setProperty(a, `var(--sv-${h}, #${h})`);
    });
  });
}
new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => {
  if (n.nodeType !== 1) return;
  if (n.tagName.toLowerCase() === 'svg') themeSvgIn(n.parentNode || n);
  else if (n.querySelector('svg')) themeSvgIn(n);
}))).observe(document.documentElement, { childList: true, subtree: true });

/* ------------------------------------------------------------- host / pliki */
const ART = !!window.__ARTIFACT;                  // strona opublikowana jako artefakt claude.ai
const Cap = { dl: null, db: null, col: null, uid: null, list: [], ready: false, slow: false, err: null };
let cloudId = null, cloudName = '';
const pending = {}; let reqId = 0;
window.__hostReply = (id, res) => { const p = pending[id]; if (p) { delete pending[id]; p(res); } };
function hostCall(op, args) {
  return new Promise(res => {
    const id = ++reqId; pending[id] = res;
    try { window.hostRequest(JSON.stringify(Object.assign({ id, op }, args))); } catch (e) { delete pending[id]; res({ ok: false, err: String(e) }); }
  });
}
const inHost = () => typeof window.hostRequest === 'function';
function toast(msg, ms) { const t = $('#toast'); t.textContent = msg; t.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = 'none', ms || 2600); }
function baseName(p) { return (p || '').split(/[\\/]/).pop(); }
const safeName = (ext) => (S.meta.name || 'belka').replace(/[\\/:*?"<>|]+/g, '_').trim() + ext;
function updateTitle() {
  if (ART) {
    const lab = cloudId ? '☁ ' + (cloudName || 'projekt') : (filePath ? baseName(filePath) : 'nowy projekt');
    $('#fileName').textContent = (dirty ? '● ' : '') + lab;
    return;
  }
  const fn = filePath ? baseName(filePath) : 'bez nazwy';
  $('#fileName').textContent = (dirty ? '● ' : '') + fn;
  const t = `BelkaŻB – ${S.meta.name || 'belka'} [${fn}${dirty ? ' *' : ''}]`;
  document.title = t;
  if (typeof window.hostTitle === 'function') { try { window.hostTitle(t); } catch (e) { /* */ } }
}
// kilka belek w projekcie (zakładki 1…10 nad schematem): każda z własnymi danymi i obliczeniami; plik projektu zawiera wszystkie
let BEAMS = null, curB = 0;
const beamsSync = () => { if (!BEAMS) BEAMS = [S]; BEAMS[curB] = S; };
const beamsOut = () => { beamsSync(); return BEAMS.length > 1 ? { beams: BEAMS.map(b => b), cur: curB } : {}; };
function beamsIn(o, st) {
  if (o && Array.isArray(o.beams) && o.beams.length > 1) { BEAMS = o.beams.slice(0, 10).map(b => E.normalize(b)); curB = Math.max(0, Math.min(BEAMS.length - 1, +o.cur || 0)); return BEAMS[curB]; }
  BEAMS = null; curB = 0; return st;
}
function switchBeam(i) {
  beamsSync(); if (i === curB || !BEAMS[i]) return;
  curB = i; S = BEAMS[i]; prevStat = null; $('#projName').value = S.meta.name || ''; rendered = {}; renderInputs(); recalc(); updateTitle(); autosave();
}
function addBeam() {
  beamsSync(); if (BEAMS.length >= 10) { toast('Maksymalnie 10 belek w projekcie.'); return; }
  const n = E.defaultState(); ['mat', 'env', 'coef', 'sls', 'fire'].forEach(k => { n[k] = JSON.parse(JSON.stringify(S[k])); }); n.meta.name = `Belka B-${BEAMS.length + 1}`;
  BEAMS.push(E.normalize(n)); dirty = true; switchBeam(BEAMS.length - 1);
}
function delBeam(i) {
  beamsSync(); if (BEAMS.length < 2) return;
  BEAMS.splice(i, 1); if (i < curB) curB--; curB = Math.min(curB, BEAMS.length - 1); S = BEAMS[curB]; dirty = true;
  $('#projName').value = S.meta.name || ''; prevStat = null; rendered = {}; renderInputs(); recalc(); updateTitle(); autosave();
}
function beamTabsHTML() {
  beamsSync();
  return `<div class="beamtabs" role="tablist" aria-label="Belki w projekcie">${BEAMS.map((b, i) => `<button class="btab ${i === curB ? 'on' : ''}" data-btab="${i}" title="${esc(b.meta.name || 'Belka ' + (i + 1))} – kliknij, aby przełączyć; dwuklik – zmiana nazwy">${i + 1}<span>${esc((b.meta.name || '').slice(0, 14))}</span>${i === curB && BEAMS.length > 1 ? `<i data-bdel="${i}" title="Usuń tę belkę">×</i>` : ''}</button>`).join('')}${BEAMS.length < 10 ? '<button class="btab add" data-badd="1" title="Dodaj kolejną belkę (maks. 10) – osobne dane i obliczenia">+</button>' : ''}</div>`;
}
document.addEventListener('click', async e => {
  const d = e.target.closest && e.target.closest('[data-bdel]'); if (d) { e.stopPropagation(); const i = +d.dataset.bdel; if (await ask(`Usunąć belkę „${esc(BEAMS[i].meta.name || i + 1)}” z projektu?`, 'Usuń')) delBeam(i); return; }
  const t = e.target.closest && e.target.closest('[data-btab]'); if (t) { switchBeam(+t.dataset.btab); return; }
  if (e.target.closest && e.target.closest('[data-badd]')) addBeam();
});
document.addEventListener('dblclick', e => { const t = e.target.closest && e.target.closest('[data-btab]'); if (!t) return; const i = +t.dataset.btab; if (i !== curB) switchBeam(i); const f = $('#projName'); if (f) { f.focus(); f.select(); } });
let asT = null;
function autosave() {
  clearTimeout(asT);
  asT = setTimeout(() => {
    const data = JSON.stringify(Object.assign({ state: S, filePath, cloudId, cloudName }, beamsOut()));
    if (typeof window.hostStore === 'function') { try { window.hostStore(data); } catch (e) { /* */ } }
    else { try { localStorage.setItem('belkazb-autosave', data); } catch (e) { /* */ } }
  }, 600);
}
function projectJSON() { return JSON.stringify(Object.assign({ app: 'BelkaZB', version: BEAMS && BEAMS.length > 1 ? 2 : 1, saved: new Date().toISOString(), state: S }, beamsOut()), null, 2); }
// okno potwierdzenia w stronie (confirm() nie działa w artefakcie)
function ask(msg, okLabel, danger) {
  return new Promise(res => {
    const m = $('#modal');
    m.innerHTML = `<div class="dlg sm"><p>${msg}</p><div class="dbtn"><button class="btn" data-a="0">Anuluj</button><button class="btn ${danger ? 'dng' : 'pri'}" data-a="1">${okLabel}</button></div></div>`;
    m.style.display = 'flex';
    const done = v => { m.style.display = 'none'; m.onclick = null; document.removeEventListener('keydown', kd, true); res(v); };
    const kd = e => { if (e.key === 'Escape') { e.stopPropagation(); done(false); } };
    document.addEventListener('keydown', kd, true);
    m.onclick = e => { const b = e.target.closest('[data-a]'); if (b) done(b.dataset.a === '1'); else if (e.target === m) done(false); };
    $('[data-a="1"]', m).focus();
  });
}
async function offerFile(name, data, okMsg) {
  if (!Cap.dl) { toast('Pobieranie plików nie jest dostępne w tym widoku.'); return false; }
  try { await Cap.dl.save({ filename: name, data }); toast(okMsg); return true; }
  catch (e) {
    const c = e && e.code;
    if (c === 'declined') return false;
    if (c === 'rate_limited') toast('Poczekaj chwilę – poprzednie pobieranie jeszcze trwa.');
    else toast('Nie udało się pobrać pliku' + (c ? ` (${c})` : '') + '.');
    return false;
  }
}
async function saveFile(as) {
  if (inHost()) {
    const r = await hostCall('save', { path: as ? '' : filePath, name: safeName('.belka'), content: projectJSON(), filter: 'project' });
    if (r && r.ok) { filePath = r.path; dirty = false; updateTitle(); autosave(); toast('Zapisano: ' + baseName(filePath)); }
    else if (r && r.err) toast('Błąd zapisu: ' + r.err);
  } else if (ART) {
    if (Cap.col && !as) { await cloudSave(false); return; }
    if (await offerFile(safeName('.json'), projectJSON(), 'Plik projektu pobrany.')) { dirty = false; updateTitle(); }
    else if (!Cap.dl && !Cap.col) toast('Zapis niedostępny w tym widoku – zmiany są pamiętane tylko w tej przeglądarce.', 4000);
  } else { download(safeName('.belka'), projectJSON(), 'application/json'); dirty = false; updateTitle(); }
}
function download(name, content, mime) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], { type: mime + ';charset=utf-8' })); a.download = name;
  document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
function applyState(st, path, quiet) {
  S = E.normalize(st); if (BEAMS) BEAMS[curB] = S; filePath = path || ''; dirty = false; prevStat = null;
  $('#projName').value = S.meta.name || '';
  renderInputs(); recalc(); updateTitle(); autosave();
  if (!quiet) toast('Wczytano: ' + (baseName(path) || S.meta.name || 'projekt'));
}
function loadProject(text, path) {
  let o; try { o = JSON.parse(text); } catch (e) { toast('To nie jest plik projektu BelkaŻB (.belka / .json).'); return; }
  cloudId = null; cloudName = '';
  applyState(beamsIn(o, o.state || o), path);
}
async function openFile() {
  if (dirty && !(await ask('Niezapisane zmiany zostaną utracone. Otworzyć inny projekt?', 'Otwórz'))) return;
  if (inHost()) {
    const r = await hostCall('open', { filter: 'project' });
    if (r && r.ok) loadProject(r.content, r.path); else if (r && r.err) toast('Błąd odczytu: ' + r.err);
  } else {
    const inp = $('#fileIn'); inp.value = '';
    inp.onchange = () => { const f = inp.files[0]; if (!f) return; f.text().then(t => loadProject(t, f.name)); };
    inp.click();
  }
}
async function newProject() {
  if (dirty && !(await ask('Niezapisane zmiany zostaną utracone. Utworzyć nowy projekt?', 'Nowy projekt'))) return;
  cloudId = null; cloudName = '';
  S = E.defaultState(); BEAMS = null; curB = 0; filePath = ''; dirty = false; prevStat = null;
  $('#projName').value = S.meta.name; renderInputs(); recalc(); updateTitle(); autosave();
}
function reportDoc(body, title) {
  const css = $('#appcss').textContent;
  return `<!doctype html><html lang="pl" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(title || 'Raport – ' + S.meta.name)}</title><style>${css}\nhtml,body{height:auto}body{overflow:auto;padding:20px 16px}.rtools{margin-bottom:14px}@media print{body{padding:0}}</style></head><body>` +
    `<div class="rtools"><button class="btn pri" onclick="window.print()">Drukuj / zapisz PDF</button><span class="hint" style="margin-left:10px">Nagłówki i stopki przeglądarki są wyłączone przez ustawienia strony raportu.</span></div><div id="report">${wrapPrint(body !== undefined ? body : repBuild())}</div></body></html>`;
}
async function exportHTML() {
  if (repView() === 'own') return exportOwn('html');
  const name = safeName(repMode() === 'static' ? ' – statyka.html' : ' – raport.html');
  if (inHost()) { const r = await hostCall('save', { path: '', name, content: reportDoc(), filter: 'html' }); if (r && r.ok) toast('Zapisano raport: ' + baseName(r.path)); else if (r && r.err) toast('Błąd: ' + r.err); }
  else if (ART) await offerFile(name, reportDoc(), 'Raport pobrany – otwórz go i wydrukuj (Ctrl+P).');
  else download(name, reportDoc(), 'text/html');
}
// raport do edycji – OpenDocument Text (.odt: LibreOffice/OpenOffice Writer, MS Word)
async function exportODT() {
  if (repView() === 'own') return exportOwn('odt');
  if (!R || (R.errors && R.errors.length)) { toast('Usuń błędy danych przed eksportem raportu.'); return; }
  const name = safeName(repMode() === 'static' ? ' – statyka.odt' : ' – raport.odt');
  toast('Tworzenie pliku .odt…', 1500);
  let u; try { u = await window.BZR.odt(repBuild(), (S.meta.name || 'Belka') + (repMode() === 'static' ? ' – statyka' : ' – raport obliczeń')); } catch (e) { console.error(e); toast('Błąd tworzenia .odt: ' + e.message); return; }
  if (inHost()) { let b = ''; for (let i = 0; i < u.length; i += 0x8000) b += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); const r = await hostCall('save', { path: '', name, content: btoa(b), b64: true, filter: 'odt' }); if (r && r.ok) toast('Zapisano raport: ' + baseName(r.path)); else if (r && r.err) toast('Błąd: ' + r.err); return; }
  const blob = new Blob([u], { type: 'application/vnd.oasis.opendocument.text' });
  if (ART) { await offerFile(name, blob, 'Raport .odt pobrany – otwórz w edytorze tekstu (LibreOffice Writer, Word).'); return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 800);
}
async function exportDXF() {
  if (!R || !R.md || (R.errors && R.errors.length)) { toast('Usuń błędy danych przed eksportem rysunku.'); return; }
  if (R.bare) { toast('Najpierw zadaj zbrojenie (przycisk „Dobierz zbrojenie wymagane” w zakładce Przekrój i zbrojenie).'); return; }
  let txt; try { txt = window.BZD.build(R, S); } catch (e) { console.error(e); toast('Błąd tworzenia DXF: ' + e.message); return; }
  const name = safeName(' – zbrojenie.dxf');
  if (inHost()) { const r = await hostCall('save', { path: '', name, content: txt, filter: 'dxf' }); if (r && r.ok) toast('Zapisano rysunek: ' + baseName(r.path)); else if (r && r.err) toast('Błąd: ' + r.err); }
  else if (ART) await offerFile(name, txt, 'Rysunek DXF pobrany.');
  else download(name, txt, 'application/dxf');
}
function doPrint() {
  if (ART) { U.selectTab('report'); if (Cap.dl) exportHTML(); return; }
  if (!$('#p-report').innerHTML || !rendered.report) { rendered.report = true; renderReport($('#p-report')); }
  setTimeout(() => window.print(), 50);
}

/* --------------------------------------------- moje projekty (konto, db) */
async function initCapabilities() {
  if (!ART || !window.claude || typeof window.claude.use !== 'function') return;
  window.claude.use('downloads').then(dl => {
    Cap.dl = dl || null;
    $('#bExport').hidden = !Cap.dl;
    if (rendered.report) { rendered.report = false; if ($('.tabs button.on').dataset.tab === 'report') renderActive(); }
  }, () => { /* brak */ });
  try {
    const [db, user] = await Promise.all([window.claude.use('db'), window.claude.use('user')]);
    if (!db || !user) return;
    const uid = await user.id();
    if (!uid) return;
    Cap.db = db; Cap.uid = uid; Cap.col = db.collection('data/users/' + uid);
    $('#bCloud').hidden = false;
    const tmo = setTimeout(() => { if (!Cap.ready) { Cap.slow = true; renderCloud(); } }, 10000);
    Cap.col.orderBy('saved', 'desc').onSnapshot(snap => {
      Cap.list = snap.docs.filter(d => d.exists).map(d => Object.assign({ id: d.id }, d.data()));
      if (!snap.metadata.fromCache) { Cap.ready = true; Cap.slow = false; clearTimeout(tmo); }
      renderCloud();
    }, e => { Cap.err = e && e.code; Cap.ready = true; clearTimeout(tmo); renderCloud(); });
  } catch (e) { /* bez zapisu na koncie */ }
}
const fmtDate = iso => { try { const d = new Date(iso); return d.toLocaleDateString('pl-PL') + ' ' + d.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; } };
let cloudOpen = false;
function openCloud() { cloudOpen = true; renderCloud(); $('#modal').style.display = 'flex'; }
function renderCloud() {
  if (!cloudOpen) return;
  const m = $('#modal');
  let list;
  if (Cap.err) list = `<p class="pempty">Nie udało się odczytać zapisanych projektów (${esc(Cap.err)}). Zapis do pliku nadal działa.</p>`;
  else if (!Cap.ready && !Cap.list.length) list = `<p class="pempty">${Cap.slow ? 'Nie można teraz połączyć się z zapisanymi projektami. Spróbuj za chwilę.' : 'Wczytywanie zapisanych projektów…'}</p>`;
  else if (!Cap.list.length) list = `<p class="pempty">Nie masz jeszcze zapisanych projektów. Kliknij „Zapisz bieżący”, aby zapisać belkę na swoim koncie – będzie dostępna na każdym urządzeniu, na którym otworzysz tę stronę.</p>`;
  else list = `<ul class="plist">${Cap.list.map(p => `<li class="${p.id === cloudId ? 'cur' : ''}"><div class="pn"><b>${esc(p.name || 'bez nazwy')}</b><small>zapisano ${esc(fmtDate(p.saved))}${p.summary ? ' · ' + esc(p.summary) : ''}</small></div><button class="btn" data-po="${esc(p.id)}">Otwórz</button><button class="btn dng" data-pd="${esc(p.id)}" aria-label="Usuń">Usuń</button></li>`).join('')}</ul>`;
  m.innerHTML = `<div class="dlg"><h3>Moje projekty</h3><p>Projekty zapisane na Twoim koncie claude.ai – widoczne tylko dla Ciebie.</p>
    <div class="dbtn" style="justify-content:flex-start;margin-top:8px"><button class="btn pri" id="pcSave">${cloudId ? 'Zapisz zmiany' : 'Zapisz bieżący'}</button>${cloudId ? '<button class="btn" id="pcNew">Zapisz jako nowy</button>' : ''}${Cap.dl ? '<button class="btn" id="pcFile">Pobierz plik .json</button>' : ''}</div>
    ${list}<div class="dbtn"><button class="btn" id="pcClose">Zamknij</button></div></div>`;
  m.style.display = 'flex';
  $('#pcClose', m).onclick = () => { cloudOpen = false; m.style.display = 'none'; };
  $('#pcSave', m).onclick = () => cloudSave(false);
  if ($('#pcNew', m)) $('#pcNew', m).onclick = () => cloudSave(true);
  if ($('#pcFile', m)) $('#pcFile', m).onclick = () => offerFile(safeName('.json'), projectJSON(), 'Plik projektu pobrany.');
  $$('[data-po]', m).forEach(b => b.onclick = () => cloudLoad(b.dataset.po));
  $$('[data-pd]', m).forEach(b => b.onclick = () => cloudDelete(b.dataset.pd));
}
function summaryLine() {
  const g = S.geom;
  const Ls = S.scheme === 'cont' ? `${S.cont.spans.length} przęsła ${S.cont.spans.map(v => String(v).replace('.', ',')).join('+')} m` : `L = ${String(g.L).replace('.', ',')} m`;
  return `${g.type === 'T' ? 'teowa' : 'prostokątna'} ${g.b}×${g.h} mm, ${Ls}, ${S.mat.concrete}` + (R && R.checks ? (R.ok ? ' · OK' : ' · niespełnione warunki') : '');
}
let cloudBusy = false;
async function cloudSave(asNew) {
  if (!Cap.col || cloudBusy) return;
  cloudBusy = true;
  const ref = (!asNew && cloudId) ? Cap.col.doc(cloudId) : Cap.col.doc();
  const body = JSON.parse(JSON.stringify(Object.assign({ app: 'BelkaZB', version: 1, name: S.meta.name || 'bez nazwy', saved: new Date().toISOString(), summary: summaryLine(), state: S }, beamsOut())));
  const attempt = () => ref.set(body);
  try {
    try { await attempt(); }
    catch (e) { if (e && e.code === 'unavailable') { await new Promise(r => setTimeout(r, 400 + Math.random() * 600)); await attempt(); } else throw e; }
    cloudId = ref.id; cloudName = body.name; dirty = false; updateTitle(); autosave();
    toast('Zapisano na koncie: ' + body.name); renderCloud();
  } catch (e) {
    const c = e && e.code;
    toast(c === 'quota_exceeded' ? 'Brak miejsca na kolejne projekty – usuń niepotrzebne.' : c === 'invalid_argument' ? 'Nie masz uprawnień do zapisu na tym koncie – pobierz plik .json.' : 'Nie udało się zapisać' + (c ? ` (${c})` : '') + '.', 4000);
  } finally { cloudBusy = false; }
}
async function cloudLoad(id) {
  const p = Cap.list.find(x => x.id === id); if (!p) return;
  if (dirty && id !== cloudId && !(await ask('Niezapisane zmiany zostaną utracone. Otworzyć projekt „' + esc(p.name || '') + '”?', 'Otwórz'))) { renderCloud(); return; }
  cloudOpen = false; $('#modal').style.display = 'none';
  cloudId = p.id; cloudName = p.name || '';
  applyState(beamsIn(p, p.state || {}), '', true);
  toast('Otwarto: ' + (p.name || 'projekt'));
}
async function cloudDelete(id) {
  const p = Cap.list.find(x => x.id === id); if (!p) return;
  const okDel = await ask(`Usunąć projekt „${esc(p.name || 'bez nazwy')}” z konta? Tej operacji nie można cofnąć.`, 'Usuń', true);
  if (okDel) {
    try { await Cap.col.doc(id).delete(); if (id === cloudId) { cloudId = null; cloudName = ''; updateTitle(); autosave(); } toast('Usunięto projekt.'); }
    catch (e) { toast('Nie udało się usunąć projektu' + (e && e.code ? ` (${e.code})` : '') + '.'); }
  }
  openCloud();
}

function about() {
  const m = $('#modal');
  const keys = ART ? 'Skróty: F2 – raport, Ctrl+S – zapisz, Ctrl+O – otwórz plik.' : 'Skróty: F2 – raport, Ctrl+S – zapisz, Ctrl+O – otwórz, Ctrl+P – drukuj raport.';
  const web = ART ? `<p>Wersja przeglądarkowa: projekty zapisujesz na swoim koncie („Moje projekty”) albo jako plik .json; ten sam plik otworzy program BelkaZB.exe. Ostatni stan jest pamiętany w tej przeglądarce.</p>` : '';
  m.innerHTML = `<div class="dlg"><h3>BelkaŻB 2.9.12 – belki żelbetowe wg Eurokodu 2</h3>
  <p>Wymiarowanie i sprawdzanie belek żelbetowych wg PN-EN 1992-1-1 (wartości parametrów krajowych wg Załącznika Krajowego PL: γ<sub>c</sub> = 1,4, γ<sub>s</sub> = 1,15, α<sub>cc</sub> = 1,0), kombinacje wg PN-EN 1990, odporność ogniowa wg PN-EN 1992-1-2 (metoda tabelaryczna).</p>
  <ul>
  <li><b>Statyka</b> – belki jednoprzęsłowe, wsporniki i belki ciągłe wieloprzęsłowe (do 8 przęseł, wsporniki skrajne) liczone w całości MES; podpory z blokadą przesuwu x, y, z i obrotu (przesuwne, nieprzesuwne, sztywne), z podatnością pionową i obrotową; węzły dzielące przęsła na elementy i przeguby (belki Gerbera); obciążenia zmienne układane przęsłami (szachownica); różne przekroje (b×h) i strzemiona w przęsłach; wykresy M, V, T, N z odczytem wartości pod kursorem, reakcje podporowe.</li>
  <li><b>Obciążenia i kombinacje</b> – dowolna liczba obciążeń użytkowych, śniegu, wiatru i innych w płaszczyźnie Y (pionowo) i Z (poziomo), ciągłe na całej belce, przęśle lub jego części, siły skupione z dokładnym położeniem; automatyczne kombinacje 6.10 / 6.10a,b z każdym obciążeniem wiodącym, charakterystyczne i quasi-stałe; sytuacja wyjątkowa 6.11b.</li>
  <li><b>Otulina</b> – 4.4.1: klasa konstrukcji (tab. 4.3N), c<sub>min,dur</sub> (tab. 4.4N), c<sub>min,b</sub>, Δc<sub>dev</sub>; min. klasa betonu (zał. E).</li>
  <li><b>SGN</b> – zginanie z siłą osiową (metoda ogólna, krzywa interakcji M–N; metoda uproszczona do A<sub>s,req</sub>), zginanie ukośne (kontur M<sub>y</sub>–M<sub>z</sub>, metoda włókien), ścinanie poziome, ścinanie 6.2 (V<sub>Rd,c</sub>, V<sub>Rd,s</sub>, V<sub>Rd,max</sub>, dobór θ, strefy strzemion, redukcja V<sub>Ed</sub> wg 6.2.1(8) tylko przy obciążeniu górą i podparciu bezpośrednim), skręcanie 6.3 (momenty skręcające z obciążeń), ścinanie półka–środnik 6.2.4.</li>
  <li><b>SGU</b> – naprężenia 7.2, minimalne zbrojenie i szerokość rys 7.3, ugięcia 7.4 (metoda dokładna z interpolacją ζ, pełzanie i skurcz wg zał. B, MES z iteracją sztywności; metoda uproszczona L/d).</li>
  <li><b>Konstrukcja</b> – zakotwienia 8.4 (na podporach skrajnych pręty odginane na wymaganą długość, gdy prosty się nie mieści; średnica trzpienia gięcia wg tab. 8.1N i 8.3(3)) i zakłady 8.7, rodzaje strzemion (zamknięte, ze szpilkami, otwarte, na skręcanie; 2–8 ramion), otulina osobno dla krawędzi, wiązki prętów 8.9, rozstaw prętów 8.2, A<sub>s,min</sub>/A<sub>s,max</sub>, wymagania rozdz. 9.2, zbrojenie przypowierzchniowe 9.2.4 / zał. J, zwichrzenie 5.9.</li></ul>
  <p>Dane wprowadzasz w zakładce <b>Dane</b> – obok formularza jest schemat belki: kliknij element belki, aby zadać jego obciążenia albo wstawić węzeł lub przegub; obciążenie – aby je zmienić; podporę – aby zablokować/odblokować przesuw x, y, z i obrót, zmienić szerokość lub podatność. Zbrojenie dodajesz w zakładce <b>Przekrój i zbrojenie</b>: kliknij górną lub dolną krawędź przekroju (pręty podłużne – warstwy, różne średnice, rozmieszczenie równomierne, normowe od naroży, parami lub współrzędne), bok (pręty boczne) albo wnętrze (strzemiona).</p>
  <p>Kliknij numer punktu, tablicy, rysunku lub wzoru normy (podkreślony kropkami) – w każdej zakładce, podpowiedzi i oknie – aby zobaczyć objaśnienie punktu i podpowiedź. Sprawdzenia można odhaczać – raport obejmuje tylko odhaczone; warunek, który przestanie być spełniony, jest odznaczany automatycznie, a spełniony ponownie – zaznaczany. W zakładce Zbrojenie belki przesuń kursor po widoku podłużnym – obok widać przekrój w tym miejscu; kliknij koniec pręta, aby dodać odgięcie, albo pręt w wyciągach, aby zmienić jego wymiary (długość rozwinięta pilnowana względem L<sub>max</sub>); przycisk <b>Eksport DXF</b> zapisuje rysunek zbrojenia (widok, przekroje, wyciągi prętów, zestawienie stali). Raport obliczeń – pełny albo uproszczony.</p>
  ${web}<p>${keys}</p>
  <p style="font-size:12px;color:var(--ink3)">Program jest narzędziem pomocniczym. Wyniki wymagają weryfikacji przez osobę z odpowiednimi uprawnieniami budowlanymi. Statyka: analiza liniowo-sprężysta (MES), bez redystrybucji momentów i efektów II rzędu.</p>
  <div class="dbtn"><button class="btn pri" id="abClose">Zamknij</button></div></div>`;
  m.style.display = 'flex';
  $('#abClose', m).onclick = () => { m.style.display = 'none'; };
}

/* -------------------------------------------------------------- start */
function setMobile(view) { U.selectTab(view === 'out' ? 'sum' : 'data'); window.scrollTo(0, 0); }
function init() {
  nlObs.observe(document.body, { childList: true, subtree: true });
  hxWrap(document.body);
  // przywrócenie autozapisu
  let saved = window.__AUTOSAVE || null;
  if (!saved) { try { saved = JSON.parse(localStorage.getItem('belkazb-autosave') || 'null'); } catch (e) { saved = null; } }
  if (saved && saved.state) {
    try { S = E.normalize(beamsIn(saved, saved.state)); filePath = saved.filePath || ''; cloudId = saved.cloudId || null; cloudName = saved.cloudName || ''; }
    catch (e) { S = E.defaultState(); }
  }
  if (ART) { $('#bPrint').hidden = true; $('#bSaveAs').hidden = true; $('#bExport').hidden = true; $('#bOpen').title = 'Otwórz plik projektu (.json / .belka)'; }
  $('#projName').value = S.meta.name || '';
  $('#projName').addEventListener('input', e => { S.meta.name = e.target.value; dirty = true; updateTitle(); autosave(); rendered.report = false; const bt = $(`.btab[data-btab="${curB}"] span`); if (bt) bt.textContent = S.meta.name.slice(0, 14); });
  $$('.tabs button').forEach(b => b.addEventListener('click', () => {
    $$('.tabs button').forEach(x => x.classList.toggle('on', x === b));
    $$('.pane').forEach(p => p.classList.toggle('on', p.id === 'p-' + b.dataset.tab));
    renderActive();
  }));
  $$('[data-act]').forEach(b => b.addEventListener('click', () => ({ new: newProject, open: openFile, save: () => saveFile(false), saveas: () => saveFile(true), cloud: openCloud, print: doPrint, exporthtml: exportHTML, about })[b.dataset.act]()));
  document.addEventListener('keydown', e => {
    const k = e.key.toLowerCase();
    if (!ART && (e.key === 'F5' || (e.ctrlKey && k === 'r'))) { e.preventDefault(); return; }
    if ($('#modal').style.display === 'flex' && e.key !== 'Escape') return;
    if (e.ctrlKey && k === 's') { e.preventDefault(); saveFile(e.shiftKey); }
    else if (e.ctrlKey && k === 'o') { e.preventDefault(); openFile(); }
    else if (e.ctrlKey && k === 'n' && !ART) { e.preventDefault(); newProject(); }
    else if (e.ctrlKey && k === 'p') { e.preventDefault(); doPrint(); }
    else if (e.key === 'F2') { e.preventDefault(); $('.tabs button[data-tab="report"]').click(); }
    else if (e.key === 'Escape') { closeList(); cloudOpen = false; $('#modal').style.display = 'none'; }
  });
  $('#modal').addEventListener('mousedown', e => { if (e.target.id === 'modal' && !$('[data-a]', e.currentTarget)) { cloudOpen = false; e.currentTarget.style.display = 'none'; } });
  let rz = null, lastW = window.innerWidth;
  window.addEventListener('resize', () => { if (Math.abs(window.innerWidth - lastW) < 40) return; lastW = window.innerWidth; clearTimeout(rz); rz = setTimeout(() => { rendered = {}; renderActive(); }, 150); });
  renderInputs();
  recalc();
  renderInputs();   // podpowiedzi zależne od wyników
  updateTitle();
  initCapabilities();
}
U.setState = (s) => { S = E.normalize(s); prevStat = null; renderInputs(); recalc(); };
U.selectTab = (t) => $(`.tabs button[data-tab="${t}"]`).click();
U.setMobile = setMobile;
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
